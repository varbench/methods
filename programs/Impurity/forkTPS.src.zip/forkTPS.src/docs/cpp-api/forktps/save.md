---
# Do not edit this first section
layout: function
fancy_name: save
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Writes a state to disk.

# List of overloads. Edit only the desc
overloads:

  - signature: void save(std::string fn, forktps::ForkTPS const &psi)
    desc: Writes the forktps ```psi``` to a file with name ```fn```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: 

# Parameters of the function. Edit only the description after the :
params:
  fn: Filename to write to.
  psi: State to write

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/save/
title: forktps::save
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

