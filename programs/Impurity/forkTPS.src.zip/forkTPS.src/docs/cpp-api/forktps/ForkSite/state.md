---
# Do not edit this first section
layout: function
fancy_name: state
namespace: forktps::ForkSite
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns the IndexVal of the index with name *state*. Here, the user

# List of overloads. Edit only the desc
overloads:

  - signature: itensor::IndexVal state(std::string const &state)
    desc: Returns the IndexVal of the index with name *state*. Here, the user

# Long description. Any Markdown, with code, latex, multiline with |
desc: defines what names indices have, for example that the first entry of the index is called "Emp" and the second "Occ".

# Parameters of the function. Edit only the description after the :
params:
  state: __MISSING__

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkSite/state/
title: forktps::ForkSite::state
parent: forktps::ForkSite
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/SiteSets/ForkSite.hpp
...

