---
# Do not edit this first section
layout: function
fancy_name: (constructors)
namespace: forktps::ForkSite
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Default Constructor

# List of overloads. Edit only the desc
overloads:

  - signature: ForkSite()
    desc: Default Constructor

  - signature: ForkSite(itensor::Index I)
    desc: Constructor from an Index *I*

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  I: __MISSING__

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkSite/ForkSite-constructors/
title: forktps::ForkSite::ForkSite
parent: forktps::ForkSite
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/SiteSets/ForkSite.hpp
...

