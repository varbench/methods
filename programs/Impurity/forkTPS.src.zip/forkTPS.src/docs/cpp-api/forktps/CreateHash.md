---
# Do not edit this first section
layout: function
fancy_name: CreateHash
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Hash function that takes a variable number of arguments.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      template <typename Ts>
      std::string CreateHash(Ts... ts)
    desc: Create a hash out of ```ts```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Forwards the parameters to the function [AddToStream](/cpp-api/forktps/AddToStream).
  Therefore this function works for every object that has a ```<<``` operator for 
  a ```std::stringstream```.

# Parameters of the function. Edit only the description after the :
params:
  ts: Variadic parameter list.

# Template parameters of the function. Edit only the description after the :
tparams:
  Ts: Any object for which the operator ```<<``` for a ```std::stringstream``` is defined.

# Desc of the return value
return_value: Hash created from ```ts```.

# Code example. desc: any markdown to explain it.
example:
  desc: "Create a hash out of an ```int```, a ```double``` and a ```triqs::array```. Changing any of these values results in a different hash."
  code: |
    #include <forktps/fork/HelperFunctions.hpp>
    #include <triqs/arrays/array.hpp>

    int main(){
      int i = 3;
      const double d = 5.7;
      triqs::arrays::array<int, 2> arr(3,4);
      arr = 2.;

      // can add anything that has a << operator 
      auto hash1 = forktps::CreateHash(  i, d, arr);
      auto hash2 = forktps::CreateHash(i+1, d, arr);

      std::cout << "First hash: "  << hash1 << "\n";
      std::cout << "Second hash: " << hash2 << "\n";

      std::cout << "The two hash`s are " 
                << ( (hash1 == hash2) ? "equal"  : "not equal" )
                << std::endl;
    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/CreateHash/
title: forktps::CreateHash
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

