---
# Do not edit this first section
layout: namespace

# List of sub namespaces.  You can reorder, regroup into a dict : groupname -> list
namespaces: []

# List of functions.  You can reorder, regroup into a dict : groupname -> list
concepts: []


# TODO:
# check formatting of tables and equations using "|" see  forktps::exactApplyMPO 
# double "|" when escaping it: "\|" 


# List of classes.  You can reorder, regroup into a dict : groupname -> list
classes:
  - Parameters:
      - Names


  - Solver and Solver Related Classes:
      - solver_core
      - container_set
      - GFComponent
      - FTPS_GF
      - FTPS_GFList

  - Model Definition:
      - bath_site
      - bath
      - hloc
      - H_int

  - Computational Parameters:
      - constr_params_t
      - solve_params_t
      - params_t
      - tn_approx
      - krylov_params
      - DMRG_prep_params
      - DMRG_params
      - Tevo_params
      

  - Tensor Network & Methods:
      - Arm
      - Fork
      - ForkTN
      - ForkTPO
      - ForkTPS
      - ForkLocalOp
      - ForkGate
      - TEBD_container

  - Hamiltonians and Local Degrees of Freedom:
      - AIM
      - AIM_OffDiag
      - AIM_SpinOrbit
      - ForkSite
      - AIM_ForkSites

# List of functions.  You can reorder, regroup into a dict : groupname -> list
functions:
  - Tensor Network Methods:
      - TDVP
      - TEBD
      - ApplyGate
      - DMRG
      - exactApplyMPO
      - FitApplyMPO
      - overlap
      - GSConvergence
      - PrintGSConvergence
      - Measure
      - MeasureImp
  
  - Read/Write:
    - save
    - load
    - saveGS
    - loadGS


  - Manage Tensors and Indices:
    - AllExcept
    - Dim
    - MaxDim
    - LinkCombiner

  - Simple helpers:
    - AddToStream
    - CreateHash
    - isCustom
    - isDensity
    - isGreater
    - isLesser
    - isSelfEnergy
    - isSingleParticle
    - PrintBorderLine
    - operator<<
    - reverse
    - roundVal
    - roundVec
    - SetArgs
    - SetSVDParams
    - to_string

  - Other:
    - ApplyOperator
    - ApplyGFOperator
    - check
    - Krylov
   



# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/
qualified_name: forktps
title: forktps
...

