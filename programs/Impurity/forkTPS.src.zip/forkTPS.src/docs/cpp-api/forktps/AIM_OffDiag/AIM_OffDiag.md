---
# Do not edit this first section
layout: class
short_name: AIM_OffDiag
qualified_name: forktps::AIM_OffDiag
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class AIM_OffDiag

# Brief description. One line only.
brief: Generates the Hamiltonian FTPO for an off-diagonal bath but without spin-orbit coupling.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Generates the Hamiltonian of an Anderson Impurity model with off-diagonal
  hybridizations and possibly also single particle terms on the impurity 
  (impurity-impurity) hopping. Note that it suffices to use triangular
  hybridizations meaning that the bath of orbital $$A\uparrow$$ couples to every
  impurity site with spin-up. The bath of $$B\uparrow$$ couples to all
  sites except the first $$A\uparrow$$ etc. These couplings are drawn in the figure below where each red line corresponds
  to one hybridization term $$V_k \left( c_I^\dagger c_k + h.c. \right)$$. 
  
  Therefore, if one generates an off-diagonal bath by hand one needs to make sure to set the correct entries of the bath.
  
  ![](/assets/images/FTPS/OffDiagBath.png)

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - AIM_OffDiag-constructors
  - AIM_OffDiag-destructor
  - operator=
  - operator ForkTPO

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AIM_OffDiag/
title: forktps::AIM_OffDiag
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/FTPO/AIM_OffDiag.hpp
parent: forktps
has_children: true
...

