---
# Do not edit this first section
layout: function
fancy_name: PrintGSConvergence
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Writes information about DMRG convergence to console.

# List of overloads. Edit only the desc
overloads:

  - signature: double PrintGSConvergence(forktps::ForkTPS const &GS, forktps::ForkTPO const &H)
    desc: Prints information about the variance of state ```GS``` with operator ```H```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  The variance of the ground state $$\langle GS |H^2|GS \rangle - \langle GS |H|GS \rangle^2$$
  is a measure how well $$ | GS \rangle $$ approximates an eigenstate of $$H$$. 
  This function prints information about that to console and returns the variance.

# Parameters of the function. Edit only the description after the :
params:
  GS: State to compute variance with.
  H: Hamiltonian to compute variance with.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Variance of ```GS``` with operator ```H```.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/PrintGSConvergence/
title: forktps::PrintGSConvergence
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

