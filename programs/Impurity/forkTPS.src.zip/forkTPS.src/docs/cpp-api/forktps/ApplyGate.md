---
# Do not edit this first section
layout: function
fancy_name: ApplyGate
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Applies a two-site gate.

# List of overloads. Edit only the desc
overloads:

  - signature: void ApplyGate(forktps::ForkTPS &psi, forktps::ForkGate const &G, enum forktps::OrthoState dir, itensor::Args args)
    desc: |
      Apply gate ```G``` onto state ```psi``` and orthgonalizes the state
      in direction ```dir```. ```args``` provides truncation parameters of the SVD.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
 

# Parameters of the function. Edit only the description after the :
params:
  psi: State to apply gate to.
  G: Gate to apply.
  dir: Orthogonality direction, defines at which of the two sites ```G``` acts on will be the new orthogonality center.
  args: |
    Arguments as ```itensor::Args``` object. Forwarded to function [SetSVDParams](/cpp-api/forktps/SetSVDParams) <br> <br>
      
      
    ```Cutoff    double (default: 1E-10)```  
    Truncated weight used in the tensor decomposition. Overwritten by ```CutoffB```, ```CutoffIB```, or ```CutoffI``` respectively. <br> 
      
    ```CutoffI     double (default: Cutoff)```  
    Truncated weight used for the impurity-impurity links.  <br> 
      
    ```CutoffB     double (default: Cutoff)```  
    Truncated weight used for the bath-bath links. <br>  
      
    ```CutoffIB    double (default: Cutoff)```  
    Truncated weight used for the impurity-bath links.  <br> 
      
    ```MaxDim      int ```  
    Maximal bond dimension for the tensor decomposition. Overwritten by ```MaxmB```, ```MaxmIB``` or ```MaxmI``` respectively. <br> 
       
    ```MaxmI       int (default: MaxDim or 200 if MaxDim not provided)```  
    Maximal bond dimension for the impurity-impurity links.   <br> 
       
    ```MaxmB       int (default: MaxDim or 400 if MaxDim not provided)```  
    Maximal bond dimension for the bath-bath links.  <br> 
      
    ```MaxmIB      int (default: MaxDim or 200 if MaxDim not provided)```  
    Maximal bond dimension for the impurity-bath links. <br>

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ApplyGate/
title: forktps::ApplyGate
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

