---
# Do not edit this first section
layout: function
fancy_name: ApplyGFOperator
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Applies the operator of a Green function component.

# List of overloads. Edit only the desc
overloads:

  - signature: void ApplyGFOperator(forktps::ForkTPS &psi, forktps::GFComponent c)
    desc: Applies the operator given by component ```c``` to state ```psi```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: 

# Parameters of the function. Edit only the description after the :
params:
  psi: State to apply operator to.
  c: Component that defines the operator.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ApplyGFOperator/
title: forktps::ApplyGFOperator
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

