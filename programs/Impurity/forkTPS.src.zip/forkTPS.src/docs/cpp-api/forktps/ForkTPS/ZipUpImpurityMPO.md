---
# Do not edit this first section
layout: function
fancy_name: ZipUpImpurityMPO
namespace: forktps::ForkTPS
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Exactly applies an Operator acting non-trivially only on the impurity.

# List of overloads. Edit only the desc
overloads:

  - signature: void ZipUpImpurityMPO(std::vector<ITensor> const &Ops, itensor::Args &args)
    desc: |
      Applies an MPO-like list of operator ```Ops``` to the state. Afterwards,
      truncates as specified by ```args```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  
  Uses the zip-up method as proposed in <a href="https://iopscience.iop.org/article/10.1088/1367-2630/12/5/055026" target="_blank">New J. Phys.12 055026</a> to apply an MPO acting non-trivially only
  on the impurity. The Zip-Up algorithm is approximate in that it truncates already during the application of the operator, where there is no exact left and right basis.
  
  A non-approximate version of this function is given by 
  [ForkTPS::ApplyImpurityMPO()](/cpp-api/forktps/ForkTPS/ApplyImpurityMPO/).
  
  Note that ```Ops``` is one-indexed i.e. ```Ops[1]``` is applied to the first
  impurity site,  ```Ops[2]``` is applied to the second impurity site, etc.

# Parameters of the function. Edit only the description after the :
params:
  Ops: Operators to apply in MPO-form.
  args: |
    Arguments as ```itensor::Args``` object. <br> <br>    
      
    ```"Cutoff"    double (default: MIN_CUT)```  
    Truncated weight used in the tensor decomposition. Overwritten by ```CutoffB```, ```CutoffIB```, or ```CutoffI``` respectively.  <br><br>
      
    ```"CutoffI"     double (default: Cutoff)```  
    Truncated weight used for the impurity-impurity links.  <br><br>
      
    ```"CutoffB"     double (default: Cutoff)```  
    Truncated weight used for the bath-bath links.  <br><br>
      
    ```"CutoffIB"    double (default: Cutoff)```  
    Truncated weight used for the impurity-bath links.  <br><br>
      
    ```"MaxDim"      double (default: 30000)```  
    Maximal bond dimension for the tensor decomposition. Overwritten by ```MaxmB```, ```MaxmIB``` or ```MaxmI``` respectively. <br><br>
       
    ```"MaxmI"      double (default: MaxDim)```  
    Maximal bond dimension for the impurity-impurity links.   <br><br>
       
    ```"MaxmB"       double (default: MaxDim)```  
    Maximal bond dimension for the bath-bath links.  <br><br>
      
    ```"MaxmIB"      double (default: MaxDim)```  
    Maximal bond dimension for the impurity-bath links.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkTPS/ZipUpImpurityMPO/
title: forktps::ForkTPS::ZipUpImpurityMPO
parent: forktps::ForkTPS
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPS.hpp
...

