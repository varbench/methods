---
# Do not edit this first section
layout: function
fancy_name: ApplySingleSiteOp
namespace: forktps::ForkTPS
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Applies a operator acting on a single site.

# List of overloads. Edit only the desc
overloads:

  - signature: void ApplySingleSiteOp(itensor::ITensor const &Op, int site, bool sign = false)
    desc: |
      Applies the operator ```Op``` acting on ```site```. If ```sign``` 
      is true, this operator is considered to be fermionic and every site ```<site```
      is multiplied by a Fermi-sign operator $$(-1)^n$$.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  to be fermionic, i.e also Fermi operators "p" are applied on all sites $i : i
  <
  
  {*site*}$.

# Parameters of the function. Edit only the description after the :
params:
  Op: Operator to apply.
  site: Site to apply operator to.
  sign: Decides if operator is considered Fermionic or not.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkTPS/ApplySingleSiteOp/
title: forktps::ForkTPS::ApplySingleSiteOp
parent: forktps::ForkTPS
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPS.hpp
...

