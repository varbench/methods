---
# Do not edit this first section
layout: function
fancy_name: randomize
namespace: forktps::ForkTPS
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Fills the state with random tensors.

# List of overloads. Edit only the desc
overloads:

  - signature: void randomize(int dim)
    desc: Fills an already initialized state with random tensors of dimension ```dim```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Note that randomizing a tensor currently only makes sense if no abelian 
  qunatum number conservation is used in the ```SiteSet``` with which the 
  state was created.

# Parameters of the function. Edit only the description after the :
params:
  dim: Bond dimension on each site.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkTPS/randomize/
title: forktps::ForkTPS::randomize
parent: forktps::ForkTPS
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPS.hpp
...

