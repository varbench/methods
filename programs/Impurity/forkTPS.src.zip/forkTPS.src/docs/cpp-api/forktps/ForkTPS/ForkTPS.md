---
# Do not edit this first section
layout: class
short_name: ForkTPS
qualified_name: forktps::ForkTPS
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class ForkTPS

# Brief description. One line only.
brief: States in fork geometry.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Class to represent states in fork geometry. Most of their functionality comes
  from its parent [```ForkTN```](/cpp-api/forktps/ForkTN/) enhanced by some state
  specific functions like [norm](/cpp-api/forktps/ForkTPS/norm) for example.

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - ForkTPS-constructors
  - ForkTPS-destructor
  - randomize
  - norm
  - normalize
  - UTensor
  - ApplySingleSiteOp
  - ApplyImpurityMPO
  - ZipUpImpurityMPO
  - ImpOccs
  - PrintImpOcc
  - PrintOccs
  - operator=

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkTPS/
title: forktps::ForkTPS
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPS.hpp
parent: forktps
has_children: true
...

