---
# Do not edit this first section
layout: function
fancy_name: FitApplyMPO
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Variational application of an Operator.

# List of overloads. Edit only the desc
overloads:

  - signature: forktps::ForkTPS FitApplyMPO(forktps::ForkTPS &x, forktps::ForkTPO const &H, itensor::Args args)
    desc: Variational application of ForkTPO ```H``` onto state ```x``` with parameters ```args```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Variational application of an operator means to minimize the distance 
  $$\min_{|\psi \rangle} \| \langle \psi \| H \| x \rangle \|^2$$.
  On the impurity tensors, the minimization algorithm uses a single-site update 
  with subspace expansion.

# Parameters of the function. Edit only the description after the :
params:
  x: State to apply H on.
  H: Operator to apply.
  args: |
    Parameters of the calculation. Most parameters are forwarded to
    [SetSVDParams](/cpp-api/forktps/SetSVDParams) <br> <br>
      
    ```alpha        double (default 0.1)```  
    Value of subspace expansion mixing factor. Set to 0 if no subspace expansion should be performed.<br> 
    
    ```maxsweeps    int (default: 10)```  
    Maximal number of sweeps. <br> 
    
    ```ErrGoal      double (default: 1E-12)```  
    Convergence criterium: difference in $2\Re \rangle x |H|res\langle$.<br> 
    
    ```Cutoff    double (default: 1E-10)```  
    Truncated weight used in the tensor decomposition. Overwritten by ```CutoffB```, ```CutoffIB```, or ```CutoffI``` respectively. <br> 
      
    ```CutoffI     double (default: Cutoff)```  
    Truncated weight used for the impurity-impurity links (as long as subspace expansion is acitve).  <br> 
      
    ```CutoffB     double (default: Cutoff)```  
    Truncated weight used for the bath-bath links. <br>  
      
    ```CutoffIB    double (default: Cutoff)```  
    Truncated weight used for the impurity-bath links.  <br> 
      
    ```MaxDim      double ```  
    Maximal bond dimension for the tensor decomposition. Overwritten by ```MaxmB```, ```MaxmIB``` or ```MaxmI``` respectively. <br> 
       
    ```MaxmI       double (default: MaxDim or 200 if MaxDim not provided)```  
    Maximal bond dimension for the impurity-impurity links (as long as subspace expansion is acitve).   <br> 
       
    ```MaxmB       double (default: MaxDim or 400 if MaxDim not provided)```  
    Maximal bond dimension for the bath-bath links.  <br> 
      
    ```MaxmIB      double (default: MaxDim or 200 if MaxDim not provided)```  
    Maximal bond dimension for the impurity-bath links. <br>

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: State resulting from the application of operator.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/FitApplyMPO/
title: forktps::FitApplyMPO
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

