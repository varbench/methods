---
# Do not edit this first section
layout: function
fancy_name: roundVal
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Rounds a double number to precsion-number of digits.

# List of overloads. Edit only the desc
overloads:

  - signature: double roundVal(double v, int precision = 0)
    desc: Rounds a double number to precsion-number of digits.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  v: __MISSING__
  precision: __MISSING__

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/roundVal/
title: forktps::roundVal
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

