---
# Do not edit this first section
layout: function
fancy_name: GSConvergence
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Computes the variance of an operator.

# List of overloads. Edit only the desc
overloads:

  - signature: std::pair<double, double> GSConvergence(forktps::ForkTPS const &GS, forktps::ForkTPO const &H)
    desc: Computes $$ \langle GS \| H \|  GS \rangle $$ and $$\langle GS \| H^2 \|  GS \rangle $$.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  The variance of an operator is a measure of how well a state is an 
  eigentstate of the operator, with exact eigenstates having zero variance.
  Therefore this can be used to determine how well DMRG was able to find an 
  eigenstate or if it got stuck in a local minimum.

# Parameters of the function. Edit only the description after the :
params:
  GS: State used to compute variance.
  H: Hamiltonian used to compute variance.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: |
  Pair of doubles, the first is $$ \langle GS \| H \|  GS \rangle $$ and the 
  second is $$ \langle GS \| H^2 \|  GS \rangle $$

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/GSConvergence/
title: forktps::GSConvergence
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

