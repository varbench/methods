---
# Do not edit this first section
layout: function
fancy_name: Krylov
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Finds the ground state of a matrix using Krylov methods.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      template <typename BigMat>
      double Krylov(BigMat const &Heff, itensor::ITensor &A, itensor::Args &args)
    desc: |
      Finds the ground state vector ```A``` of matrix ```Heff``` using 
      either the Lanzcos or the Davidson algorithm depending on the 
      flag  in *args*.

# Long description. Any Markdown, with code, latex, multiline with |
desc: 

# Parameters of the function. Edit only the description after the :
params:
  Heff: Matrix.
  A: Starting vector and groundstate.
  args: |
    Arguments as ```itensor::Args``` object. <br> <br>
    
    ```UseDavidson bool (default: false)```   
    If true, use ```itensor::Davidson```, if false use lanzcos.<br>

    ```MaxIter int (default: 10)```   
    Maximal number of Krylov vectors generated. Note for DMRG this number should be small, 
    since it is iterative and it might even make convergence worse if too many steps are taken.<br>

    ```NormCutoff double (default: 1E-13) ```   
    If norm of new Krylov vector drops below this value, stop generating new vectors to avoid ghost states.<br>

    ```ErrGoal double (default: 1E-12) ```   
    Convergence criteria.<br>

    ```DiagEvery int (default: 4):```  
    Only for lanzcos, perform the diagonalization of the tri-diagonal matrix every ```DiagEvery``` step.<br>


# Template parameters of the function. Edit only the description after the :
tparams:
  BigMat: Any object that implements a ```product()``` function and a ```size()``` function (only for davidson).

# Desc of the return value
return_value: Ground state energy.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/Krylov/
title: forktps::Krylov
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

