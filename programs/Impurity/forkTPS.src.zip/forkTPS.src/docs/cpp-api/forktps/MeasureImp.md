---
# Do not edit this first section
layout: function
fancy_name: MeasureImp
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Measures a set of operators acting on the impurities only.

# List of overloads. Edit only the desc
overloads:

  - signature: double MeasureImp(forktps::ForkTPS &psi, std::vector<std::string> Ops)
    desc: Measures operators ```Ops``` acting on the impurity defined with state ```psi```.

  - signature: itensor::Complex MeasureImp(forktps::ForkTPS const &bra, std::vector<std::string> Ops, forktps::ForkTPS const &ket)
    desc: |
      Calculates the expectation value $$\langle \text{bra} \|Ops\| \text{ket} \rangle$$ 
      with ```Ops``` acting only on the impurity degrees of freedom.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  The vector ```Ops``` contains a string for each impurity that defines 
  the local operator of this site. Ops is zero-indexed. Only operators that
  are defined in the ```itensor::SiteSet``` are valid operator names. <br>

  Note that also identity operators have to be specified. For example to 
  measure the density-density correlation between orbital A-up and B-up in a 
  two-orbital problem: <br>
  ```Ops = {"N", "Id", "N", "Id"}```.

# Parameters of the function. Edit only the description after the :
params:
  psi: State to measure.
  Ops: Vector containing the names of the operators on each impurity site as defined in the SiteSet.
  bra: Bra-state in overlap.
  ket: Ket-state in overlap.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Measurement result.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/MeasureImp/
title: forktps::MeasureImp
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

