---
# Do not edit this first section
layout: function
fancy_name: (constructors)
namespace: forktps::TEBD_container
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: ""

# List of overloads. Edit only the desc
overloads:

  - signature: TEBD_container()
    desc: Default constructor.

  - signature: |
      template <class T>
      TEBD_container(forktps::H_int const &hint, forktps::bath const &b, forktps::hloc const &e0, T dt,
                     forktps::AIM_ForkSites const &sites)
    desc: |
      Creates the object with interactions given by ```hint```, bath parameters
      ```b```, non-interacting impurity Hamiltonian ```e0``` and time step
      ```dt```. Finally, ```sites``` defines the local degrees of freedom.

  - signature: TEBD_container(TEBD_container const &)
    desc: ""

  - signature: TEBD_container(TEBD_container &&)
    desc: ""

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  hint: Interaction parameters.
  b: Bath parameters (must be diagonal).
  e0: Non-interacting impurity Hamiltonian (must be diagonal).
  dt: Time step $$\Delta t$$.
  sites: Defines local degrees of freedom.

# Template parameters of the function. Edit only the description after the :
tparams:
  T: Either ```double``` or ```Complex```.

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/TEBD_container/TEBD_container-constructors/
title: forktps::TEBD_container::TEBD_container
parent: forktps::TEBD_container
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/TevoMethods.hpp
...

