---
# Do not edit this first section
layout: function
fancy_name: saveGS
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Writes a ground state as well as its energy to disk.

# List of overloads. Edit only the desc
overloads:

  - signature: void saveGS(std::string const fn, forktps::ForkTPS const &gs, forktps::AIM_ForkSites const &sites, double energy)
    desc: Writes the state ```gs``` including its SiteSet ```sites``` and ground state energy ```energy``` to file ```fn```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  fn: Filename to write to.
  gs: State to save.
  sites: SiteSet to save.
  energy: Energy to save.
  

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/saveGS/
title: forktps::saveGS
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

