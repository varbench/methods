---
# Do not edit this first section
layout: class
short_name: params_t
qualified_name: forktps::params_t
namespace: forktps
includer: forktps/forktps_include.hpp
signature: struct params_t

# Brief description. One line only.
brief: A struct combining both constr_params_t and solve_params_t.

# Long description. Any Markdown, with code, latex, multiline with |
desc: See ... for details.

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - params_t-constructors

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/params_t/
title: forktps::params_t
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/params.hpp
parent: forktps
has_children: true
...

