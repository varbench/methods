---
# Do not edit this first section
layout: function
fancy_name: check
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Tests whether the bath and local impurity Hamiltonian are in a valid state.

# List of overloads. Edit only the desc
overloads:

  - signature: void check(forktps::bath const &b, forktps::hloc const &e0)
    desc: |
      Checks that ```bath``` and ```hloc``` are compatible with the solver
      in general and with each other.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  b: Bath object.
  e0: Non-interacting impurity Hamiltonian.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/check/
title: forktps::check
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Bath.hpp
...

