---
# Do not edit this first section
layout: function
fancy_name: reverse
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Reverses direction.

# List of overloads. Edit only the desc
overloads:

  - signature: void reverse(enum forktps::TevoDir &dir)
    desc: Reverses time evolution direction.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  ```forktps::TevoDir::Forward``` becomes ```forktps::TevoDir::Back```
  and vice versa.

# Parameters of the function. Edit only the description after the :
params:
  dir: Direction that is being reversed.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/reverse/
title: forktps::reverse
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/typenames.hpp
...

