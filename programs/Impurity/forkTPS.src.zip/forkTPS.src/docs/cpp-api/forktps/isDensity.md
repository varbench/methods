---
# Do not edit this first section
layout: function
fancy_name: isDensity
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns whether *type* is density Green's function.

# List of overloads. Edit only the desc
overloads:

  - signature: bool isDensity(enum forktps::GFtype type)
    desc: Returns whether *type* is density Green's function.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  type: __MISSING__

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/isDensity/
title: forktps::isDensity
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/typenames.hpp
...

