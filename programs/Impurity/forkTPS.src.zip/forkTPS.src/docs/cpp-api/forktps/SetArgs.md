---
# Do not edit this first section
layout: function
fancy_name: SetArgs
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Adds parameters to ```itensor::args``` object.

# List of overloads. Edit only the desc
overloads:

  - signature: void SetArgs(itensor::Args &args, forktps::DMRG_params const &p)
    desc: Adds/Overwrites entries of ```args``` relevant for a DMRG calculation with parameters ```p```.

  - signature: void SetArgs(itensor::Args &args, forktps::Tevo_params const &p)
    desc: Adds/Overwrites entries of ```args``` relevant for a Time evolution with parameters ```p```.

  - signature: void SetArgs(itensor::Args &args, forktps::tn_approx const &p)
    desc: Adds/Overwrites entries of ```args``` with Tensor Network approximation parameters ```p```.

  - signature: void SetArgs(itensor::Args &args, forktps::krylov_params const &p)
    desc: Adds/Overwrites entries of ```args``` with Krylov approximation parameters ```p```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  args: Parameter collection.
  p: Object to modify ```args```.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value:

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/SetArgs/
title: forktps::SetArgs
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/setargs.hpp
...

