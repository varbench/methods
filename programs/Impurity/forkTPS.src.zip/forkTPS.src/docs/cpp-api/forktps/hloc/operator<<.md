---
# Do not edit this first section
layout: function
fancy_name: operator<<
namespace: forktps::hloc
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: stream operator to quickly write the local Hamiltonian.

# List of overloads. Edit only the desc
overloads:

  - signature: std::ostream &operator<<(std::ostream &out, forktps::hloc const &e0)
    desc: stream operator to quickly write the local Hamiltonian.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  out: __MISSING__
  e0: __MISSING__

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/hloc/operator<</
title: forktps::hloc::operator<<
parent: forktps::hloc
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Bath.hpp
...

