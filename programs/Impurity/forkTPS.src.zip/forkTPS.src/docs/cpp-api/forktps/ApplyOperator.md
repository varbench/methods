---
# Do not edit this first section
layout: function
fancy_name: ApplyOperator
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Applies a TRIQS operator.

# List of overloads. Edit only the desc
overloads:

  - signature: void ApplyOperator(triqs::operators::monomial_t const &op, forktps::ForkTPS &psi, forktps::bath const &b)
    desc: |
      Applies the operator ```op``` onto state ```psi```. The bath ```b``` gives 
      information how the TRIQS block structure is represented in the state.

# Long description. Any Markdown, with code, latex, multiline with |
desc: 

# Parameters of the function. Edit only the description after the :
params:
  op: TRIQS monomial (single string of creation/annihilation operators)
  psi: State to apply the operator onto
  b: Bath object that translates the TRIQS block structure to the ```ForkTPS``` state.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ApplyOperator/
title: forktps::ApplyOperator
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/GFComponent.hpp
...

