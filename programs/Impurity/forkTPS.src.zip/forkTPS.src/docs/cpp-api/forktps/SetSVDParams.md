---
# Do not edit this first section
layout: function
fancy_name: SetSVDParams
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Set different truncation parameters to be used by SVD.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      std::string SetSVDParams(int i, forktps::Fork const &F, enum forktps::OrthoState dir, itensor::Args &args,
                               int defaultMaxDim, double defaultCutoff)
    desc: Sets the maximal bond dimension and truncated weight to the link defined by site ```i``` and direction ```dir```. Allows to provide default parameters. 

  - signature: std::string SetSVDParams(int i, forktps::Fork const &F, enum forktps::OrthoState dir, itensor::Args &args)
    desc: Sets the maximal bond dimension and truncated weight to the link defined by site ```i``` and direction ```dir```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
    The ```ITensor``` SVD uses the the two arguments ```"Cutoff"``` and ```"MaxDim"```
    to determine the truncated weight and maximum bond dimension respectively.

    In the ForkTPS library we use different values for these parameters for
    the different kinds of indices bath-bath, bath-impurity and impurity-impurity.
    This function determines the kind of link it has to use from the site ```i```,
    the direction ```dir``` as well as Fork ```F```, takes the appropriate 
    parameter (from ```args```) and writes it into ```"Cutoff"``` and ```"MaxDim"```
    (into ```args```).

# Parameters of the function. Edit only the description after the :
params:
  i: Site of the link.
  F: Geometry of the Fork Tensor Network.
  dir: Direction of the link.
  args: Argument object to be modified.
  defaultMaxDim: Default value for maximum bond dimension.
  defaultCutoff: Default value for truncated weight.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/SetSVDParams/
title: forktps::SetSVDParams
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

