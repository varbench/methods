---
# Do not edit this first section
layout: function
fancy_name: LinkCombiner
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Generates combiner tensors which combine two or more indices into one index.

# List of overloads. Edit only the desc
overloads:

  - signature: std::pair<ITensor, Index> LinkCombiner(itensor::ITensor const &A, itensor::ITensor const &B)
    desc: Combiner of all indices that are in ```A``` as well as ```B```.

  - signature: std::pair<ITensor, Index> LinkCombiner(itensor::Index const &i, itensor::Index const &j)
    desc: Combiner combining index ```i``` and ```j```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  For example, a combiner that combines index $$i$$ and $$j$$ into index $$c$$
  can be thought of as a diagonal ```ITensor``` $$C = \delta_{(i,j),c}$$ that when 
  multiplied onto tensor $$T_{ijk}$$ results in $$\sum_{ij} T_{ijk} \delta_{(i,j),c} = T_{ck}$$.
  In practice, the ITensor library does not do any computation but maps indices
  to one another.

  Both functions return the combiner tensor $$C$$ as well as the new index $$c$$.


# Parameters of the function. Edit only the description after the :
params:
  A: First tensor, can be multiplied by the combiner directly.
  B: Second tensor, must be multiplied by the ```dag(combiner)``` because of the index directions.
  i: First index to combine.
  j: Second index to combine.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: The combiner tensor as well as the new index.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: |
    #include <itensor/global.h>
    #include <forktps/fork/HelperFunctions.hpp>


    int main(){
      Index i(2), j(3), k(4), l(5);

      ITensor A(i,j,k), B(dag(j), dag(k),l);
      A.randomize();
      B.randomize();

      auto [combiner, c] = forktps::LinkCombiner(A, B);

      // New link has the same dimension as the product of the two links combined
      std::cout<< "\nCombiner index dimension: " << dim(c) << ". Product of index dimensions: " << dim(j) * dim(k) << std::endl;  


      std::cout << "\nBefore acting with combiner: \n";
      if(hasIndex(A, i)) std::cout << "  A has index i\n"; // Yes
      if(hasIndex(A, j)) std::cout << "  A has index j\n"; // Yes
      if(hasIndex(A, k)) std::cout << "  A has index k\n"; // Yes
      if(hasIndex(A, c)) std::cout << "  A has index c\n"; // No

      A *= combiner; 

      std::cout << "\nAfter acting with combiner: \n";
      if(hasIndex(A, i)) std::cout << "  A has index i\n"; // Yes
      if(hasIndex(A, j)) std::cout << "  A has index j\n"; // No
      if(hasIndex(A, k)) std::cout << "  A has index k\n"; // No
      if(hasIndex(A, c)) std::cout << "  A has index c\n"; // Yes

    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/LinkCombiner/
title: forktps::LinkCombiner
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

