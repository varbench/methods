---
# Do not edit this first section
layout: function
fancy_name: gf_struct
namespace: forktps::bath
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns the gf_struct of the bath.

# List of overloads. Edit only the desc
overloads:

  - signature: triqs::hilbert_space::gf_struct_t gf_struct() const
    desc: Returns the gf_struct of the bath.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/bath/gf_struct/
title: forktps::bath::gf_struct
parent: forktps::bath
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Bath.hpp
...

