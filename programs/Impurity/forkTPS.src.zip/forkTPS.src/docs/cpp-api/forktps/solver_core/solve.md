---
# Do not edit this first section
layout: function
fancy_name: solve
namespace: forktps::solver_core
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Solve method that performs FORKTPS calculation

# List of overloads. Edit only the desc
overloads:

  - signature: void solve(forktps::solve_params_t const &solve_params)
    desc: Solve method that performs the calculation using all parameters defined in ```solve_params```.

  - signature: void solve(forktps::solve_params_t const &solve_params, forktps::ForkTPS const &GS)
    desc: Solve method that performs the calculation using all parameters defined in ```solve_params``` but uses ```GS``` for the ground state instead of doing a DMRG calculation.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Note that before these functions can be called, a [bath](/cpp-api/forktps/bath/)
  and a [non-interacting impurity Hamiltonian](/cpp-api/forktps/hloc/) need
  to be set.

# Parameters of the function. Edit only the description after the :
params:
  solve_params: Solver parameters.
  GS: Ground state to use.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/solve/
title: forktps::solver_core::solve
parent: forktps::solver_core
source: ""
...

