---
# Do not edit this first section
layout: function
fancy_name: post_process
namespace: forktps::solver_core
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Allow to trigger post-processing.

# List of overloads. Edit only the desc
overloads:

  - signature: void post_process(forktps::solve_params_t const &solve_params)
    desc: Allow the user to retrigger post-processing with the last set of parameters

# Long description. Any Markdown, with code, latex, multiline with |
desc: Post processing means collecting time evolved states stored to disk and computing the relevant overlaps for the Green functions.

# Parameters of the function. Edit only the description after the :
params:
  solve_params: Solve parameters. Should match the ones the solver was called with in the first place.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/post_process/
title: forktps::solver_core::post_process
parent: forktps::solver_core
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/solver_core.hpp
...

