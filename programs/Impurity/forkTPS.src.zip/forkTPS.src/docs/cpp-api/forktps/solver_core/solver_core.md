---
# Do not edit this first section
layout: class
short_name: solver_core
qualified_name: forktps::solver_core
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class solver_core

# Brief description. One line only.
brief: The core Solver class.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  This class gathers all the functions to work with 
  the Tensor Networks, managing Green functions etc. into a working
  impurity solver.
  
  To keep it consistent with other TRIQS solver, it only gets an $$\omega$$-mesh 
  and a triqs-block structure upon construction. Then the user has to set 
  the [bath (```solver_core::b```)](/cpp-api/forktps/bath/) as well as the 
  [non-interacting impurty hamiltonian (```solver_core::e0```)](/cpp-api/forktps/bath/). 
  The interaction and all other parameters specifying the exact behavior of the solver are 
  given to it at [solve-call](/cpp-api/forktps/solver_core/solve) using the class
  [solve_params_t](/cpp-api/forktps/solve_params_t/).
  
  A rough overview of how the solver works is provided in the following:
  
  
  # 1. Ground state search - DMRG
  
  The ```ForkTPS``` solver is a zero temperature method and hence starts from 
  the ground-state of the impurity problem. Probably the most efficient method
  to find ground states with Tensor Networks is the Denstiy Matrix Renormalization 
  Group <a href="https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.69.2863" target="_blank">DMRG</a>. 
  But there is one sublety when using Tensor Networks not in model systems
  but for example in real-material impurity problems. The latter have more or 
  less arbitrary hybridizations and on-site energies and a problem comes up for 
  Tensor Networks:
   
  If the Hamiltonian in question has abelian conserved quantitites like the total 
  particle number (impurity _and_ bath) or the magnetization, the Tensors can exploit that and become 
  block-sparse. The huge advantage of doing this is that it drastically improves
  efficiency. Impurity models generally conserve at least the particle number. 
  The sector of total particle number
  the Tensor Network works in has to be specified before doing any computation which is the root of 
  the problem. Since the terms in the Hamiltonian are more or less arbitrary 
  we a-priori do not know in which sector we should search for the ground-state
  (although we have a pretty good idea by just looking at the bath parameters).
  
  The ```ForkTPS``` library can solve this in two ways:
  
  ## DMRG without conserved quantities:
  
  This method is chosen by default. It performs a rough DMRG calculation by 
  switching off any conservation. It then measures the particle number in the
  ground state obtained that way. Finally it initializes a state with conserved
  quantities in the correct sector and repeats DMRG. While this usually works
  well, it can go wrong from time to time. If this happens in the middle of 
  a DMFT calculation this usually does not cause problems but if one wants
  to make sure it is the correct sector there is another way.
  
  ## User defined sectors:
  The during solve call, the user can specify a set of sectors in which to
  search for the ground state. The solver then does a DMRG calculation in each of them and takes
  the one with the lowest energy. This method is useful in two cases. 
  
  1. If the sector is known beforehand (particle hole-symmetry for example)
  2. If the sector is known approximately and the user wants to make sure 
  that the surrounding sectors do not have in fact a lower energy. User defined 
  sectors can be specified using the member 
  [NPart](/cpp-api/forktps/solve_params_t/) of ```solve_params_t```.
  
  
  The actual parameters of the two different DMRG calculations can be set using 
  the members [params_GS](/cpp-api/forktps/solve_params_t/) and 
  [params_partSector](/cpp-api/forktps/solve_params_t/) at solve call.
  

  ## DMRG how to not get stuck

  DMRG is a variational method that updates at a time only one or two of the 
  many tensors of a tensor network. That has the disadvantage that it can get 
  stuck in local minima. 
  
  ### Ground state variance
  Ultimately, it is impossible to know with certainty if
  the state that DMRG found is the ground state of the system. What we can know though 
  if it is an eigenstate of the Hamiltonian by computing the variance 
  
  $$\langle (H - E_0)^2 \rangle.$$

  At the end of DMRG, the solver computes this quantity and writes it to the 
  output. It is always a good practice to check that the variance is small.
  However, computing the variance is hard and can in some cases result in too 
  much memory allocation. In that cases a warning is printed that the variance 
  cannot be computed.

  ### Occupations
  In practice, a good measure is to see if a ground state is wrong is to
  simply look at the impurity occupations. Often one has certain exact symmetries 
  in the model (spin symmetry for example) which must be reflected in the impurity 
  occupations of course. The solver outputs the occupations at each sweep and it 
  is good to check them from time to time. Note though that Mott insulators break
  spin-symmetry so this does not always work (see python tutorial CanThisBeTheGroundState.ipynb).

  ### Preparation parameters
  As a variational method, DMRG benefits from a good starting point. For that,
  the class [DMRG_params](/cpp-api/forktps/dmrg_params/) has a couple of parameters
  that can be used to prepare the state before DMRG is even started.

  1. According to the power method, $$| GS \rangle = \lim_{n \to \infty} H^n | \phi_0 \rangle$$.
     The parameter [prep_nh](/cpp-api/forktps/dmrg_params/DMRG_params-constructors)
     allows to set the number of time the Hamiltonian is applied before DMRG is started.

  2. Similarly, $$| GS \rangle = \lim_{\tau \to \infty} e^{-\tau H} | \phi_0 \rangle$$.
     To prepare fore DMRG, we can therefore also use imaginary time evolution.
     The parameters [imag_tevo, dtau, time_steps and method](/cpp-api/forktps/dmrg_params/DMRG_params-constructors)
     allow to define how to time evolve exactly.

  ### Local Krylov Update
  DMRG iteratively uses Lanzcos-like Krylov methods to update the local tensors.
  A little unintuitive at first is that in DMRG one should make those Krylov 
  minimizations only very inaccurately! The two reasons for that is 
  
  1. Anything that is missed in one step can be made up for in the next pass. So 
     precission can be gained by simply doing more sweeps 
     (parameter [sweeps](/cpp-api/forktps/dmrg_params/))

  2. More importantly, doing the local update too precise might trap one in a local 
     minimum and that is to avoid at all cost.

  3. A very precise local update is a waste of computation time because if the
     environment of the sites that are updated in the current is not yet good enough, 
     a perfect update still cannot reach the total ground state.

  For this, the parameter [nmax in DMRG_params](/cpp-api/forktps/dmrg_params/)
  controlling the number of Krylov vectors generated should be small 
  ($$\sim 5$$ is often a good choice). 

  ### Small truncation, fixed bond dimension
  Imagine you have a ground state that know is representable as an tensor network with a bond-dimension
  of, say, $$m=100$$ and at that bond dimension you have a truncated weight of 
  $$10^{-9}$$. You fix the three [maxm](/cpp-api/forktps/dmrg_params/) parameters
  to $$100$$ and the three [tw`s](/cpp-api/forktps/dmrg_params/) accordingly to 
  $$10^{-9}$$ and start DMRG. Then it can happen that you do not find the state
  you know exists because DMRG got stuck in a local minimum.

  From practical experience, we know that in such cases it is often helpful to
  make the truncated weight very small ($$10^-{12} - 10^-{14}$$) but fix the bond dimension so the 
  computation does not get out of hand. This makes bonds that do not
  need the full dimension of $$100$$ a little larger which provides an improved
  environment for other links and in total DMRG converges much better.

  ### Apply MPO during DMRG
  Even if DMRG is stuck in a local a local minimum, a way out is to apply 
  the operator during DMRG. The parameter [napp_h](/cpp-api/forktps/dmrg_params/) 
  (do not confuse it with prep_nh) specifies the number of times the Hamiltonian
  is applied during DMRG. It first performs the number of sweeps specified and then
  repeats the following ```napp_h```-times:

  1. Apply MPO.
  2. Do 5 additional DMRG sweeps.



  # 2. Time evolution
  Having found the ground state $$| \psi_0 \rangle$$ and the corresponding
  energy $$E_0$$, the next step is to time evolve, to obtain the Green function:
  
  $$ G_{AB}(t) = \langle \psi_0 | A e^{\pm i(H-E_0)t} B | \psi_0 \rangle .$$
  
  Note that the sign in the exponent depends on exactly what kind of Green function one 
  wants to compute. A big advantage of the time evolution methods is that unlike 
  DMRG, they cannot get stuck in local minima. Instead the only problems can arise
  from too small bond-dimensions which can be checked easily be repeating the 
  calculation with larger tensor dimensions.
  
  The solver can use two very different methods to propagate in time:
  
  
  
  1. The 
  <a href="https://arxiv.org/abs/1408.5056" target="_blank">Time Depend Variational Principle (TDVP)</a> 
  aims to solve the Schroedinger equation optimally within the variational space spanned by the Tensor Network
  `that's a mouthful ... dont worry about it too much, I only needed an intro sentence :)`.
  Since this method works in all cases and since it generally is very reliable 
  it is used by default. Note that counterintuitively, one should choose a 
  rather large time step $$\Delta t \sim 0.1$$ compared to TEBD (see below). 
  Otherwise numerical errors can cause problems (see tutorial ```TDVP_LargeTimeSteps.ipynb```)
  
  2. <a href="https://arxiv.org/abs/1008.3477" target="_blank">tDMRG or TEBD</a> 
  (both are very similar, strictly speaking this solver performs tDMRG) is a standard method in Tensor Networks and relatively simple to understand. It splits all terms of the Hamiltonian into terms acting only
  on two sites using a (second order) trotter decomposition and then simply 
  applies each of them one after another. Note that this only works for 
  diagonal hybridizations.
  
  
  
  # 3. Additional Notes:
  
  ### No Self Energy $$\Sigma(\omega)$$:
  The solver does not compute the self energy $$\Sigma(\omega)$$ by itself.
  The reason is that the solver allows the user to define exactly which 
  entries of the block-Green function should be calculated (member [calc_me](/cpp-api/forktps/solve_params_t/)
  of ```solve_params_t```). For example in a 
  spin-symmetric model only the $$\uparrow$$-spin Green function needs to be 
  computed, the $$\downarrow$$-spin follows from symmetry which saves computational
  ressources as every component needs a separate time evolution. The blocks not computed 
  are empty but initialized and the inversion for the self energy would be invalid. The expected 
  workflow is that the user first sets all entries of the Green's function 
  in time $$G(t)$$, Fourier transforms to obtain $$G(\omega)$$ and computes the 
  self energy by calling the respective python functions.
  
  ### Custom Green function:
  The solver allows to compute arbitrary single-time correlation functions $$\Theta(t) \langle 
  A(t) B\rangle$$ using the member [customGF](/cpp-api/forktps/solve_params_t/)
  of ```solve_params_t```. The code splits $$A$$ and $$B$$ into all their 
  monomials and computes every monomial Green function separately. So 
  complicated operators $$A$$ and $$B$$ can result in a large number of time
  evolutions. Negative times are currently not implemented but can easily be
  obtained from $$ \langle A(-t) B\rangle = \langle B^\dagger(t) A^\dagger \rangle $$.

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - solver_core-constructors
  - solver_core-destructor
  - operator=
  - solve
  - get_gs
  - post_process
  - hdf5_format
  - h5_read_construct

# A list of non_member_functions
non_member_functions: []
member_fields:
  constr_params:
    type: forktps::constr_params_t
    desc: Parameters for solver construction.
  last_solve_params:
    type: std::optional<solve_params_t>
    desc: Last used ```solve_params_t```.
  E0:
    type: double
    desc: Ground state energy after DMRG.
  GSVariance:
    type: double
    desc: Ground state variance $$\langle H^2 \rangle - \langle H \rangle^2$$ which is a measure of how well the ground state was found.
  b:
    type: forktps::bath
    desc: Bath parameters.
  e0:
    type: forktps::hloc
    desc: Non-interacting impurity Hamiltonian.
  Delta_cont_w:
    type: forktps::g_w_t
    desc: Continuous bath spectral function from which the bath was calculated (must be set by the user).
  Delta_recons_w:
    type: forktps::g_w_t
    desc: Bath spectral function reconstructed from the bath parameters ```b``` (computed at solve call).
  measurement_results:
    type: std::vector<double>
    desc: Vector containing the results of the measurements defined in member ```measurements``` of  ```solve_params_t```.
  NPartGS:
    type: std::vector<int>
    desc: Ground state sector of particle number.
  SectorEnergies:
    type: std::vector<double>
    desc: Energy of each sector of particle number from ```NPartGS```.
  SectorImpOccs:
    type: std::vector<std::vector<double> >
    desc: Impurity Occupation of each sector of particle number from ```NPartGS```.
  customGF:
    type: std::vector<gf<retime, scalar_valued> >
    desc: Resulting custom Green functions as defined in member ```customGF``` of  ```solve_params_t```.

# Code example. desc: any markdown to explain it.
example:
  desc: Solve a simple two-band impurity problem with three bath sites for each orbital/spin degree of freedom.
  code: |
    #include <forktps/solver_core.hpp>
    #include <iomanip>
    #include <triqs/gfs/meshes/mesh_tools.hpp>
    #include <triqs/gfs/meshes/refreq.hpp>
    
    using namespace forktps;
    
    int main() {
      int N = 16, Norbs = 2, NArms = 2 * Norbs; // 3 bath sites per orbital/spin
      double U = 0.5, J = 0.1, Up = U - 2 * J;  // interaction parameters
    
      std::vector<double> eps = {-U / 2., -1.0, 0.0, 1.0}; // first entry is impurity on-site energy
      std::vector<double> V   = {0.1, 0.1, 0.1};           // hybridizations
    
      bath b(eps, V, Norbs); // bath
      hloc e0(eps, Norbs);   // impurity single-particle Hamiltonian
    
      // solve params
      solve_params_t sp;
      sp.h_int           = H_int(U, J, Up, false); // interaction with dd_only = false
      sp.tevo.dt         = 0.1;                    // size of time step size
      sp.tevo.time_steps = 10;                     // half the number of time steps
      sp.NPart           = {{2, 2, 2, 2}};         // set the sector of particle number of the ground state
                                                   // a-priori one does not know that this is the right sector though!
    
      // construct solver with w-mesh and gf_struct
      solver_core solver({-3., 3., 1001, b.gf_struct()});
    
      // set bath and e0
      solver.b  = b;
      solver.e0 = e0;
    
      // solve the model
      solver.solve(sp);
    
      //  solver.G_ret is a std::optional thats why the "*"
      const auto &Gret = *solver.G_ret;
    
      std::cout.precision(3);
      std::cout << "\n\nSolver finished ... printing retarded Green's function G(t) of block 0 and matrix index (0,0):\n";
      for (auto t : Gret[0].mesh()) std::cout << "t: " << t << " " << Gret[0][t](0, 0) << "\n";
      std::cout << "\n\n";
    
      return 0;
    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/
title: forktps::solver_core
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/solver_core.hpp
parent: forktps
has_children: true
...

