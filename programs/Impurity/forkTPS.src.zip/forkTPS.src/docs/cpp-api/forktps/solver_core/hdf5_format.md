---
# Do not edit this first section
layout: function
fancy_name: hdf5_format
namespace: forktps::solver_core
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: hdf5 scheme to identify the ```solver_core``` class when writing to hdf5.

# List of overloads. Edit only the desc
overloads:

  - signature: static std::string hdf5_format()
    desc: hdf5 scheme to identify the ```solver_core``` class when writing to hdf5.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Name of ```solver_core``` objects in hdf5 files.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/hdf5_format/
title: forktps::solver_core::hdf5_format
parent: forktps::solver_core
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/solver_core.hpp
...

