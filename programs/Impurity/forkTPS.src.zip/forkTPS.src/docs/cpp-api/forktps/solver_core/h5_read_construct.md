---
# Do not edit this first section
layout: function
fancy_name: h5_read_construct
namespace: forktps::solver_core
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Constructs a ```solver_core``` object from an hdf5 file.

# List of overloads. Edit only the desc
overloads:

  - signature: static solver_core h5_read_construct(h5::group h5group, std::string subgroup_name)
    desc: Constructs a ```solver_core``` object from an hdf5 file.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  h5group: Group in which solver is stored.
  subgroup_name: Name of the solver object in group ```h5group```.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Solver object read from hdf5.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/h5_read_construct/
title: forktps::solver_core::h5_read_construct
parent: forktps::solver_core
source: ""
...

