---
# Do not edit this first section
layout: function
fancy_name: get_gs
namespace: forktps::solver_core
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns the ground state.

# List of overloads. Edit only the desc
overloads:

  - signature: forktps::ForkTPS get_gs()
    desc: Returns the ground state.

# Long description. Any Markdown, with code, latex, multiline with |
desc: Returns a default constructed ```ForkTPS``` if no ground state was computed so far.

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: The ground state.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/solver_core/get_gs/
title: forktps::solver_core::get_gs
parent: forktps::solver_core
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/solver_core.hpp
...

