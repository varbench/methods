---
# Do not edit this first section
layout: function
fancy_name: write
namespace: forktps::AIM_ForkSites
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Write ```AIM_ForkSites``` to stream

# List of overloads. Edit only the desc
overloads:

  - signature: void write(std::ostream &s) const
    desc: Writes the object to stream ```s```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  s: Stream to write from.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AIM_ForkSites/write/
title: forktps::AIM_ForkSites::write
parent: forktps::AIM_ForkSites
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/SiteSets/AIM_ForkSites.hpp
...

