---
# Do not edit this first section
layout: class
short_name: Names
qualified_name: forktps::Names
namespace: forktps
includer: forktps/forktps_include.hpp
signature: struct Names

# Brief description. One line only.
brief: Names of various tensor network approximation parameters.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods: []

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/Names/
title: forktps::Names
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/typenames.hpp
parent: forktps
has_children: true
...

