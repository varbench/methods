---
# Do not edit this first section
layout: function
fancy_name: TDVP
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Performs a TDVP time evolution step.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      template <class T>
      void TDVP(forktps::ForkTPS &psi, forktps::ForkLocalOp &Heff, T dt, itensor::Args &args)
    desc: Performs a single TDVP time step. To time evolve state ```psi``` by a time step ```dt``` with Hamiltonian ```Heff```. Parameters are given by ```args```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  The time step is done in forwards direction (note the minus sign).
  $$ | \psi(t+\Delta t) \rangle = e^{- H \Delta t} | \psi(t) \rangle $$. So 
  for positive ```dt``` this function time evolves with an overall negative 
  exponent.

# Parameters of the function. Edit only the description after the :
params:
  psi: State to be time evolved.
  Heff: Represents the Hamiltonian in the form of an effective Hamiltonian.
  dt: Real ```dt``` means imaginary time evolution, while Complex ```dt``` real time evolution.
  args: |
    Arguments as ```itensor::Args``` object. <br> <br>
    
    
    ```TevoMethod   std::string (default: "TDVP")```  
                    Decides if two site TDVP ("TDVP_2") or single site TDVP ("TDVP") is used for the impurity-impurity links.  
    ```CutoffI      double (default: 1E-10)```  
                    Truncated weight used in the tensor decomposition for impurity-impurity links (only for two-site TDVP).  
    ```CutoffIB     double (default: 1E-10)```  
                    Truncated weight used in the tensor decomposition for impurity-bath links.  
    ```CutoffB      double (default: 1E-10)```  
                    Truncated weight used in the tensor decomposition for bath-bath links.  
    ```MaxmI        int (default: 200)```  
                    Maximal bond dimension for impurity-impurity links (only for two-site TDVP).  
    ```MaxmIB       int (default: 200)```  
                    Maximal bond dimension for impurity-bath links.  
    ```MaxmB        int (default: 400)```  
                    Maximal bond dimension for bath-bath links.  
    ```ErrGoal      double (default: set by itensor)```  
                    Convergence Criterium of Krylov exponentiation.  
    ```MaxIter      int (default: set by itensor)```  
                    Maximal number of Krylov vectors generated.  
    ```NormCutoff   double (default: set by itensor)```  
                    If norm of new Krylov vector drops below this value, stop generating new vectors to avoid ghost states.  
    ```TrackNorm    bool (default false)```  
                    If true, normalizes the state after every TDVP step, but stores the norm into the args variable totalNorm (access with getReal). This is only relevant for imaginary time evolution.

# Template parameters of the function. Edit only the description after the :
tparams:
  T: Either ```double``` for imaginary-time evolution or ```Complex``` for real-time evolution.

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: |
    Perform the TDVP time evolution for a simple 2-band model with 3 bath sites for each orbital/spin. <BR><BR>
    **Warning**: The code below is just to demonstrate how to use the ```TDVP``` function.
    Generally it is _not_ a good idea to start TDVP with a product state. To 
    understand why this can cause problems and how it can be solved, see for example
    <a href="https://arxiv.org/pdf/2005.06104.pdf" target="_blank">this paper</a>.
  code: |
    #include "forktps/fork/ForkLocalOp.hpp"
    #include "forktps/fork/TevoMethods.hpp"
    #include <forktps/fork/FTPO/AIM.hpp>
    #include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
    #include <itensor/mps/mps.h>
    
    using namespace forktps;
    
    int main() {
      int N = 16, Norbs = 2, NArms = 2 * Norbs; // 3 bath sites per orbital/spin
      double U = 0.5, J = 0.1, Up = U - 2 * J;  // interaction parameters
      double dt = 0.1;                          // time step size
      Args args;                                // only use default parameters
    
      AIM_ForkSites sites(N, NArms); // SiteSet
    
      // create product state in a certain particle number sector
      InitState init(sites);
      for (auto i : range1(NArms)) {
        init.set(sites.ImpSite(i), "Occ"); // place one particle on each impurity site
      }
      ForkTPS psi(init, NArms); // create the tensor product state
    
      // Model Parameters:
      std::vector<double> eps = {-U / 2., -1.0, 0.0, 1.0}; // first entry is impurity on-site energy
      std::vector<double> V   = {0.1, 0.1, 0.1};           // hybridizations
    
      bath b(eps, V, Norbs);       // bath
      hloc e0(eps, Norbs);         // impurity single-particle Hamiltonian
      H_int hint(U, J, Up, false); // interaction with dd_only = false
    
      // Create the effective Hamiltonian
      ForkLocalOp Heff(AIM(sites, b, e0, hint, Args()));
    
      std::cout << "Before time evolution\n";
      psi.PrintImpOcc(); // Imp. Occ.: 1   1   1   1
    
      // Time evolve
      for (auto i : range1(10)) { TDVP(psi, Heff, Complex_i * dt, args); }
    
      std::cout << "After time evolution\n";
      psi.PrintImpOcc(); // Imp. Occ.: 0.97305   0.97305   0.97305   0.97305
    
      return 0;
    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/TDVP/
title: forktps::TDVP
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/TevoMethods.hpp
...

