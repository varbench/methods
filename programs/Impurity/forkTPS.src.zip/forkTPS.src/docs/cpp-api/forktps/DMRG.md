---
# Do not edit this first section
layout: function
fancy_name: DMRG
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Performes a DMRG ground state search.

# List of overloads. Edit only the desc
overloads:

  - signature: bool DMRG(forktps::ForkTPS &GS, forktps::ForkTPO const &H, double &energy, itensor::Args &args)
    desc: |
      Performs a DMRG calculation optimizing state ```GS```, with Hamiltonian ```H``` and sets the ground state energy to ```energy```. 
      All other parameters are provided by ```args```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Note that DMRG starts with the state ```GS``` so if it has convergence problems,
  changing ```GS``` by e.g: imaginary time evolution or other approaches can help.

  By default, DMRG uses single-site DMRG with subspace expansion on the
  impurity-impurity links. This can be changed via the ```"DMRGMethod"```
  parameter in ```args```.

  Tips on how to use DMRG efficiently can be found [here](/cpp-api/forktps/solver_core/).

# Parameters of the function. Edit only the description after the :
params:
  GS: Initial state DMRG starts with. After the computation this will be the ground state.
  H: Hamiltonian.
  energy: Ground state energy.
  args: |
    Arguments as ```itensor::Args``` object. <br> <br>
      
    ```verbose        bool (default: true)```  
                      Writes information about the DMRG run into console.  
    ```FullSweep      bool (default: false)```  
                      Usual DMRG updates the impurity-impurity links only once each sweep. If true, these links are updated twice.  
    ```maxsweeps      int (default: 10)```  
                      Number of DMRG sweeps.  
    ```NAppH          int (default: 0)```  
                      After maxsweeps sweeps apply the MPO and perform 5 more sweeps. In total apply H ```NAppH```-times.  
    ```UseDavidson    bool (default: false)```  
                      If true, use ITensors Davidson algorithm instead of Lanzcos.  
    ```Cutoff         double (default: 1E-10)```  
                      Truncated weight on all links unless specified otherwise by one of the other Cutoffs below.  
    ```CutoffI        double (default: Cutoff)```  
                      Truncated weight on Impurity-Impurity links.  
    ```CutoffB        double (default: Cutoff)```  
                      Truncated weight on  Bath-Bath links.  
    ```CutoffIB       double (default: Cutoff)```  
                      Truncated weight on Impurity-Bath links.  
    ```MaxDim         int ```  
                      Maximal bond dimension on all links unless specified otherwise by one of the other Maxm's below.  
    ```MaxmI          int (default: 200)```  
                      Maxmial bond dimension allowed for impurity-impurity links.  
    ```MaxmB          int (default: 400)```  
                      Maxmial bond dimension allowed for bath-bath links.  
    ```MaxmIB         int (default: 200)```  
                      Maxmial bond dimension allowed for impurity-bath links.  
    ```DMRGMethod     std::string (default: "SSImp")```  
                      Choice between "TwoSite" which then performs two-site DMRG at the impurity-impurity links or "SSImp" doing single-site DMRG with subspace expansion at the impurity-impurity links.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Returns whether DMRG calculation was successful or not.

# Code example. desc: any markdown to explain it.
example:
  desc: DMRG calculation of a simple 2 band model with 3 bath sites for each orbital/spin.
  code: |
    #include <forktps/fork/ForkCalculus.hpp>
    #include <forktps/fork/FTPO/AIM.hpp>
    #include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
    #include <itensor/mps/mps.h>
    
    using namespace forktps;
    
    int main() {
      int N = 16, Norbs = 2, NArms = 2 * Norbs; // 3 bath sites per orbital/spin
      double U = 0.5, J = 0.1, Up = U - 2 * J;  // interaction parameters
      double energy = 0;                        // ground state energy
    
      // Maximal bond dimension 30, perform 10 sweeps and use the Method "SSImp"
      Args args{"MaxDim", 30, "maxsweeps", 10, "DMRGMethod", "SSImp"};
    
      AIM_ForkSites sites(N, NArms); // SiteSet
    
      // create product state in a certain particle number sector
      InitState init(sites);
      for (auto i : range1(NArms)) {
        init.set(sites.ImpSite(i), "Occ"); // Place one particle on each impurity site
      }
      ForkTPS psi(init, NArms); // product state
    
      // Model Parameters:
      std::vector<double> eps = {-U / 2., -1.0, 0.0, 1.0}; // first entry is impurity on-site energy
      std::vector<double> V   = {0.1, 0.1, 0.1};           // hybridizations
    
      bath b(eps, V, Norbs);       // bath
      hloc e0(eps, Norbs);         // impurity single-particle Hamiltonian
      H_int hint(U, J, Up, false); // interaction with dd_only = false
    
      // Create the Hamiltonian
      ForkTPO H = AIM(sites, b, e0, hint, Args());
    
      // apply Hamiltonian to psi so DMRG does not get stuck in a local minima
      psi = exactApplyMPO(psi, H, args);
      psi.normalize();
    
      DMRG(psi, H, energy, args);
    
      std::cout << "Ground state energy is " << energy << std::endl; // Ground state energy is -4.052960025
    
      return 0;
    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/DMRG/
title: forktps::DMRG
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

