---
# Do not edit this first section
layout: function
fancy_name: overlap
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Overlap between two states.

# List of overloads. Edit only the desc
overloads:

  - signature: itensor::Complex overlap(forktps::ForkTPS const &psi, forktps::ForkTPS const &phi)
    desc: Overlap between states ```psi``` and ```phi```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |

# Parameters of the function. Edit only the description after the :
params:
  psi: Bra-vector of $$\langle \psi \| \phi \rangle$$
  phi: Ket-vector of $$\langle \psi \| \phi \rangle$$

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Value of the overlap.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/overlap/
title: forktps::overlap
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPS.hpp
...

