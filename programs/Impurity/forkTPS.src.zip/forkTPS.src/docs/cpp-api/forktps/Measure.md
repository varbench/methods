---
# Do not edit this first section
layout: function
fancy_name: Measure
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Measures local observables.

# List of overloads. Edit only the desc
overloads:

  - signature: double Measure(forktps::ForkTPS &psi, std::string OpName, int i)
    desc: Measures the local observable with name ```OpName``` on site ```i``` with state ```psi```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  ```Opname``` must be a name of an operator defined in the ```itensor::SiteSet``` that was
  used to create ```psi```. Note that ```psi``` is passed by reference, since 
  the orthogonality center is moved site ```i``` thereby changing the state.

# Parameters of the function. Edit only the description after the :
params:
  psi: State to measure.
  OpName: Name of the operator as defined in the ```SiteSet```.
  i: Site where the operator acts.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Measurement result.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/Measure/
title: forktps::Measure
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkCalculus.hpp
...

