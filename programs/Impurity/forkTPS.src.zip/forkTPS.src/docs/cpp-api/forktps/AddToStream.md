---
# Do not edit this first section
layout: function
fancy_name: AddToStream
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Adds a variable number of arguments to a stream.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      template <typename T, typename Rest>
      void AddToStream(std::stringstream &Stream, T t)
    desc: Single parameter version of AddToStream () -> see c++ vargs

  - signature: |
      template <typename T, typename Rest>
      void AddToStream(std::stringstream &Stream, T t, Rest... rest)
    desc: Variable number of arguments combined into a single string.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  Stream: Stream to write to.
  t: First argument in argument list.
  rest: Rest of the arguments in argument list.

# Template parameters of the function. Edit only the description after the :
tparams:
  T: Any type for which ```<<``` operator with a ```std::stringstream``` is defined.
  Rest: Rest of the vargs.

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AddToStream/
title: forktps::AddToStream
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

