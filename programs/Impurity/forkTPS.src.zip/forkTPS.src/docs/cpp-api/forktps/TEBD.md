---
# Do not edit this first section
layout: function
fancy_name: TEBD
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Perform a time evolution step using the Time Dependent Variational Principle (TEBD).

# List of overloads. Edit only the desc
overloads:

  - signature: void TEBD(forktps::ForkTPS &psi, forktps::TEBD_container const &Ops, itensor::Args &args)
    desc: Performs a single TEBD step to time evolve ```psi``` using the operators and gates stored in ```Ops```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Before we start, a comment for Tensor Network experts  
  (If the following does not make sense to you just skip it):
  
  The time evolution called Time Evolving Block Decimation (TEBD) is strictly 
  speaking a method that applies to a certain Tensor Network representation 
  (so-called $$\Lambda$$-$$\Gamma$$ representation) as proposed in 
  <a href="https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.91.147902" target="_blank">this paper</a>.
  Here, we adopt a broader view and mean by TEBD any time evolution method obtained
  by a Suzuki-Trotter decomposition of the time evolution operator into a set 
  of terms acting only locally, independent of the Tensor Network state representation.
  In particular, the ```ForkTPS``` library performs the TEBD time evolution
  not in the $$\Lambda$$-$$\Gamma$$ representation but with a single orthogonality 
  center.
  
  ## Ok, so how does TEBD work?
  
  The main idea of TEBD is very simple. Let us assume for the moment we 
  want to time evolve with a Hamiltonian with nearest neighbor terms only
  $$H = \sum_i h_{i,i+1}$$. Then the time evolution operator can be approximated
  by the well known Suzuki-Trotter decomposition:
  
  $$ e^{\tau H} \approx e^{\tau \sum_{i:even} h_{i,i+1}/2} e^{\tau \sum_{i:odd} h_{i,i+1}} e^{\tau \sum_{i:even} h_{i,i+1}/2}  + \mathcal{O}(\tau^3) = \prod_{i:even}e^{\tau h_{i,i+1}/2} \prod_{i:odd} e^{\tau h_{i,i+1}} \prod_{i:even}e^{\tau h_{i,i+1}/2} + \mathcal{O}(\tau^3).$$
  
  Note that $$\tau \in \mathbb{C}$$, hence this also includes real-time evolution.
  Each of the individual terms $$e^{\tau h_{i,i+1}}$$ acts non-trivially only
  on two sites and its exponential can be computed easily. These so-called
  gates are represented by the class [```ForkGate``` ](/cpp-api/forktps/ForkGate/)
  which is the backbone of the TEBD time evolution.
  
  ## What about impurity Hamiltonians
  
  While impurity models have a representation as a nearest neighbor Hamiltonian
  (the so-called Wilson chain), it turns out that the star-geometry 
  of the bath is actually advantageous for tensor network methods even though
  the hybridization terms are not nearest neighbor terms:
  
  $$ H = H_{imp} + \sum_{ k \sigma } \underbrace{V_{k\sigma} (c_{I \sigma}^\dagger c_{k\sigma} + h.c)+
   \epsilon_{k\sigma} n_{k \sigma}}_{h_{k\sigma}}. $$
  
  Above, $$\sigma$$ is used as a combined orbital-spin degree of freedom and
  $$c_{I \sigma}^\dagger$$ is the creation operator of an impurity electron 
  with orbital/spin $$\sigma$$. Similarly $$c_{k\sigma}^\dagger$$ creates an
  electron in bath orbital $$k$$ and spin/oribtal $$\sigma$$. $$H_{imp}$$ 
  contains the interactions and will be dealt with later. For now let us focus 
  on the terms invovling the bath.
  
  ### Dealing with the hybridization terms
  
  Obviously, the on-site energy terms can be dealt with easily, since they
  trivially are of nearest neighbor type. The hopping terms on the other hand
  seem to be impossible at first, since there is one site (the impurity) that couples 
  to every other site with the same $$\sigma$$. Still it turns out there is an
  efficient TEBD algorithm to deal with these terms as we will see now.
  
  Neglecting the impurity for the moment, we see that the time evolution 
  operator trivially factorizes into a product over $$\sigma$$ since all 
  terms commute:
  
  $$e^{\tau \sum_{k\sigma} h_{ k \sigma }} = \prod_\sigma e^{\tau \sum_{k} h_{ k \sigma }}$$
  
  Focusing on a single $$\sigma$$, we repeatedly use second order Suzuki-Trotter decompositions
  to split the time evolution operator into a product of terms acting 
  on two sites only:
  
  $$e^{\tau \sum_{k} h_{ k \sigma }} \approx e^{\tau h_{1\sigma}/2} \cdot e^{\tau \sum_{k=2} h_{ k \sigma }} \cdot e^{\tau h_{1\sigma}/2} 
                         \approx e^{\tau h_{1\sigma}/2} \cdot e^{\tau h_{2\sigma}/2} \cdot e^{\tau \sum_{k=3} h_{ k \sigma }} \cdot e^{\tau h_{2\sigma}/2} \cdot e^{\tau h_{1\sigma}/2} 
  \approx \cdots \approx \prod_{k=1}^N e^{\tau h_{k\sigma}/2} \prod_{k=N}^1 e^{\tau h_{k\sigma}/2}. $$
  
  Note the order of the products above. While this is indeed a product
  of _gates_ they are still long-range. Fortunately, so-called swap-gates exist
  that swap the degrees of freedom of two sites. By looking at the above formula,
  we have to start with the term $$e^{\tau h_{1\sigma}/2}$$ which is no problem 
  because the impurity and the site with $$k=1$$ are assumed to be nearest neighbors.
  But we actually apply a gate which first time evolves and then swaps the two sites.
  Then the impurity degrees of freedom are found at the former bath with with $$k=1$$. 
  This means that the impurity is a nearest neighbor of site $$k=2$$ and we 
  can again time evolve and swap so that the impurity is now at what was previously site
  $$k=2$$. It is then a nearest neighbor of site $$k=3$$ and so on. That way we can simply 
  time evolve every term without any additional computational cost, because 
  we can add every swap gate to a time evolution gate.
  
  ### Dealing with $$H_{int}$$
  
  Since we now know what to do with the bath terms let us focus on the impurity
  and especially on the interaction terms (impurity on-site energies are actually
  taken care of during the treatment of the bath terms). 
  
  A one-orbital problem is very simple because only one nearest neighbor term
  $$Un_\uparrow n_\downarrow$$ needs to be considered which we already know 
  how to do.
  For multi-orbital problems this is a bit more involved and for reasons 
  that will become clear below, we need to differentiate between density-density
  terms $$ H_{DD}$$ and the spin-flip and pair-hopping terms $$H_{SFPH}$$ of the Kanamori interaction:
  
  $$ H_{DD} = \sum_{m} U n_{\uparrow} n_{\downarrow} + U' \sum_{m'>m} n_{m\uparrow} n_{m' \downarrow} + (U'-J) \sum_{m'>m} n_{m\uparrow} n_{m' \uparrow} + n_{m\downarrow} n_{m' \downarrow} $$
  
  $$ H_{SFPH} = J \sum_{m'>m} \underbrace{\left( c_{m \uparrow}^\dagger c_{m \downarrow} c_{m' \uparrow} c_{m' \downarrow}^\dagger +h.c \right)}_{H^{SF}_{mm'}}
              - J \sum_{m'>m} \underbrace{\left( c_{m \uparrow}^\dagger c_{m \downarrow}^\dagger c_{m' \uparrow} c_{m' \downarrow} +h.c \right)}_{H^{PH}_{mm'}}  $$
  
  The density-density terms are easy to deal with. We simply need to compute the
  exponential $$e^{\tau H_{DD}}$$ which is a manageable task and we can apply 
  this operator in form of a ```ForkTPO``` which acts trivialy on the bath degrees
  of freedom.
  
  The spin-flip and pair-hoppings cannot be dealt with in that way, because 
  they move electrons from one impurity to another. This means that we somehow
  need to take care of the fermionic sign on all sites between these two impurity
  degrees of freedom i.e. also on some of the bath sites. Fortunately, it 
  turns out that $$H^{SF}_{mm'}$$ and $$H^{PH}_{mm'}$$ both have the property
  that:
  
  $$ A^3 = A \text{~~~~for~~} A \in \{ H^{SF}_{mm'}, H^{PH}_{mm'} \}. $$
  
  The time evolution operator (now for real time evolution) of such a Hamiltonian 
  can then be written as:
  
  $$e^{ -i t J A } = \mathbb{1} + A^2 \left( \cos{Jt}-1 \right) - A \sin{Jt}.$$
  
  And a similar forumla for imaginary time evolution swapping sine and cosine 
  for their hyperbolic counterparts. Importantly, one can create a ```ForkTPO```
  for such an operator and we can simple apply it to time evolve.
  
  
  ### Putting everything together
  
  So now we have all the pieces to time evolve a multi orbital impurity model.
  The Suzuki Trotter Decomposition we perform for the total Hamiltonian is the 
  following:
  
  $$ e^{\tau H } \approx \prod_{m'>m} \left( e^{\tau H_{SF}/2} \cdot e^{\tau H_{PH}/2} \right)  \cdot e^{\tau H_{DD}/2} \cdot e^{\tau H_{0}} \cdot e^{\tau H_{DD}/2} \cdot \left( \prod_{m'>m} e^{\tau H_{SF}/2} \cdot e^{\tau H_{PH}/2} \right) ,$$
  
  where $$H_{0}$$ contains all on-site energies (impurity as well as bath) and 
  the hybridization terms.
  
  ### Final Remarks
  
  We need to take care of quite a number of things for a single TEBD calculation: 
  gates for the hybridization terms, an FTPO for the Density-Density interactions 
  as well as a list of FPTO's for the 
  spin-flip and pair-hopping terms. For this reason there exists a single container
  [```TEBD_container```](/cpp-api/forktps/TEBD_Container) that stores all of
  these objects and only it needs to be provided to the function call.
  
  The careful reader realized, that we formulated TEBD for a bath that is diagonal 
  in the orbital/spin degrees of freedom (we called them $$\sigma$$ above). 
  This is one of the restrictions of TEBD currently, that it is only applicable 
  for diagonal hybridizations and also hopping terms between the impurities 
  are not possible. Although one could think of using swap gates also for the 
  impurity degrees of freedom a quick test of it showed that it leads to large
  numerical errors (I did not invest too much time into this though). So in 
  the current state of the library, if
  one wants to use off-diagonal hybridizations, the time evolution method 
  has to be [TDVP](/cpp-api/forktps/TDVP).

# Parameters of the function. Edit only the description after the :
params:
  psi: State to time evolve.
  Ops: Operators and gates.
  args: |
    Arguments as ```itensor::Args``` object. <br> <br>
    
    ```CutoffI      double```  
    Truncated weight used in the tensor decomposition for impurity-impurity links (only for two-site TDVP).  
    ```CutoffIB     double```  
    Truncated weight used in the tensor decomposition for impurity-bath links.  
    ```CutoffB      double```  
    Truncated weight used in the tensor decomposition for bath-bath links.  
    ```MaxmI        int ```  
    Maximal bond dimension for impurity-impurity links (only for two-site TDVP).  
    ```MaxmIB       int ```  
    Maximal bond dimension for impurity-bath links.  
    ```MaxmB        int ```  
    Maximal bond dimension for bath-bath links.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/TEBD/
title: forktps::TEBD
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/TevoMethods.hpp
...

