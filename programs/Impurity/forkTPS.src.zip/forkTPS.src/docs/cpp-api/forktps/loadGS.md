---
# Do not edit this first section
layout: function
fancy_name: loadGS
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Loads a ground state as well as its energy from disk.

# List of overloads. Edit only the desc
overloads:

  - signature: void loadGS(std::string const fn, forktps::ForkTPS &gs, forktps::AIM_ForkSites &sites, double &energy)
    desc: Reads the state ```gs``` including its SiteSet ```sites``` and ground state energy ```energy``` from file ```fn```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  fn: Filename to read from.
  gs: State to load.
  sites: SiteSet to load.
  energy: Energy to load.
  

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/loadGS/
title: forktps::loadGS
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

