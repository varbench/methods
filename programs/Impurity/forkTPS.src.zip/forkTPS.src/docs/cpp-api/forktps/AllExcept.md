---
# Do not edit this first section
layout: function
fancy_name: AllExcept
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns a list of indices related to a Tensor.

# List of overloads. Edit only the desc
overloads:

  - signature: itensor::IndexSet AllExcept(itensor::ITensor A, itensor::Index remove, itensor::Index add = Index())
    desc: |
      Returns an ```itensor::IndexSet``` (a container with indices) containing
      all indices of ```A``` except index ```remove``` and adds index ```add```
      if it is provided.

# Long description. Any Markdown, with code, latex, multiline with |
desc: 

# Parameters of the function. Edit only the description after the :
params:
  A: Tensor providing indices.
  remove: Index that will be not be added to the list.
  add: If provided, this index will be added to the list.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: List of indices as an ```itensor::IndexSet```.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AllExcept/
title: forktps::AllExcept
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

