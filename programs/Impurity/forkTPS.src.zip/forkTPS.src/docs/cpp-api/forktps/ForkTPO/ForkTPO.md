---
# Do not edit this first section
layout: class
short_name: ForkTPO
qualified_name: forktps::ForkTPO
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class ForkTPO

# Brief description. One line only.
brief: Operators in fork geometry.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Class to represent operators in fork geometry. They are pretty much 
  [```ForkTN```](/cpp-api/forktps/ForkTN/)-objects with a couple of additions
  that only apply to operators.

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - ForkTPO-constructors
  - ForkTPO-destructor
  - UTensor
  - HermitianConjugate
  - operator=

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkTPO/
title: forktps::ForkTPO
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkTPO.hpp
parent: forktps
has_children: true
...

