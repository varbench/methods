---
# Do not edit this first section
layout: function
fancy_name: operator*=
namespace: forktps::ForkGate
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Operator ```*=```.

# List of overloads. Edit only the desc
overloads:

  - signature: ForkGate &operator*=(ForkGate &rhs)
    desc: Multiplies this gate with ```rhs```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Note that a multiplication of operators does not commutate. 
  The implementation is such that ```rhs``` acts last.

# Parameters of the function. Edit only the description after the :
params:
  rhs: Gate to be multiplied.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Result of multiplication.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkGate/operator*=/
title: forktps::ForkGate::operator*=
parent: forktps::ForkGate
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Gates.hpp
...

