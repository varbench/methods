---
# Do not edit this first section
layout: function
fancy_name: MakeSwap
namespace: forktps::ForkGate
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Creates a swap gate.

# List of overloads. Edit only the desc
overloads:

  - signature: void MakeSwap(int i, int j, itensor::SiteSet const &sites)
    desc: Overwrites the tensor of the gate to be a swap-gate.

# Long description. Any Markdown, with code, latex, multiline with |
desc: Swap gates exchange the position of two sites in the Tensor Network.

# Parameters of the function. Edit only the description after the :
params:
  i: One of the sites the swap gate will act on.
  j: One of the sites the swap gate will act on.
  sites: Provides local degrees of freedom for sites ```i``` and ```j```.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkGate/MakeSwap/
title: forktps::ForkGate::MakeSwap
parent: forktps::ForkGate
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Gates.hpp
...

