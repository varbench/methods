---
# Do not edit this first section
layout: class
short_name: ForkGate
qualified_name: forktps::ForkGate
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class ForkGate

# Brief description. One line only.
brief: The ForkGate class is used to represent a time evolution gate.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  A gate is an operator acting on two neighboring sites in the Tensor Network.
  Assuming a nearest neighbor Hamiltonian $$H = \sum_i h_{i,i+1}$$ for the moment,
  the time evolution operator can be approximated by the well known Suzuki-Trotter
  decomposition: 
  
  $$ e^{\tau H} \approx e^{\tau \sum_{i:even} h_{i,i+1}} e^{\tau \sum_{i:odd} h_{i,i+1}} + \mathcal{O}(\tau^2).$$
  
  Here $$\tau$$ can be real or complex meaning imaginary or real time evolution respectively.
  Also note that in practice one uses the second order version of this formula but
  the idea is exactly the same.
  Since all _even_ terms commute with each other, their exponential factorizes without any additional approximation. The same goes for the odd terms. The purpose
  of the class ```ForkGate``` is to represent one of these exponentials:  
  
  $$ G = e^{\tau h_{i,i+1} } .$$
  
  It can be computed efficiently, since the Hilbert space $$h_{i,i+1}$$ acts on
  is very small (for spins/spinless fermions its 4). Since the Suzuki-Trotter 
  decomposition has an error $$\mathcal{O}(\tau^2)$$, $$\tau$$ is chosen small 
  and the full time evolution is obtained by repeatedly applying the same set
  of gates over and over again using the fact that $$e^{\tau N H} = \left( e^{\tau H} \right)^N$$. This is the basis of the two related algorithms
  <a href="https://arxiv.org/abs/1008.3477/" target="_blank">tDMRG and TEBD</a>.
  
  Obviously, gates can encode any two-site operator not only time-evolution gates. 
  A notable example are so-called swap-gates which effectively swap the two degress
  of freedom in a tensor network. For spinless fermions they are defined as:
  
  $$ G_{S} = | 00 \rangle \langle 00 | +| 01 \rangle \langle 10 | + | 10 \rangle \langle 01 | - | 11 \rangle \langle 11 |.$$
  
  Note the minus sign in the last term which comes from the exchange
  of two fermion and it would be absent for bosons. These swap gates can be used
  for Gate-based time evolution even when the Hamiltonian contains terms with
  long-range operators. This is especially important for the star geometry of impurity models, 
  where the hybridization terms are long range (from the impurity to every bath site):
  
  $$ H_{hyb} = \sum_k V_k \left( c_{I}^\dagger c_k + h.c. \right). $$
  
  In this case, an algorithm can be found which has the same cost than if it
  were a nearest neighbor Hamiltonian (see <a href="https://journals.aps.org/prx/abstract/10.1103/PhysRevX.7.031013" target="_blank">this Paper</a>).

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - ForkGate-constructors
  - ForkGate-destructor
  - i
  - j
  - NSites
  - gate
  - mapPrime
  - MakeSwap
  - expGate
  - operator*=
  - operator*
  - operator=

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkGate/
title: forktps::ForkGate
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Gates.hpp
parent: forktps
has_children: true
...

