---
# Do not edit this first section
layout: function
fancy_name: j
namespace: forktps::ForkGate
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns second site the gate acts on.

# List of overloads. Edit only the desc
overloads:

  - signature: int j() const
    desc: Returns second site the gate acts on.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Site index.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkGate/j/
title: forktps::ForkGate::j
parent: forktps::ForkGate
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Gates.hpp
...

