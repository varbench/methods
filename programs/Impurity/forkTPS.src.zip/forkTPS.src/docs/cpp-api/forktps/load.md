---
# Do not edit this first section
layout: function
fancy_name: load
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Loads a state from disk.

# List of overloads. Edit only the desc
overloads:

  - signature: void load(std::string fn, forktps::ForkTPS &psi, itensor::SiteSet const &sites)
    desc: Reads the forktps ```psi``` created with ```sites``` from file ```fn```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Adding the SiteSet to this function has two reasons. First, the ```forktps``` 
  class itself has a SiteSet member which needs to be initialized correctly. 
  Second, it is an additional layer of security making sure that states and 
  site indices stay consistent. 

# Parameters of the function. Edit only the description after the :
params:
  fn: Filename to read from.
  psi: State to read.
  sites: SiteSet used to create the state in the first place.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: 

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/load/
title: forktps::load
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/HelperFunctions.hpp
...

