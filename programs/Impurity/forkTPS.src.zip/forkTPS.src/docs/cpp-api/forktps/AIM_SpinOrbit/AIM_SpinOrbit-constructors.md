---
# Do not edit this first section
layout: function
fancy_name: (constructors)
namespace: forktps::AIM_SpinOrbit
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Constructors.

# List of overloads. Edit only the desc
overloads:

  - signature: |
      AIM_SpinOrbit(itensor::SiteSet const &sites, forktps::bath b, forktps::hloc e0, forktps::H_int hint,
                    itensor::Args const &args = Args::global())
    desc: Hamiltonian with bath ```b```, non-interacting impurity ```e0``` and interactions ```hint```. The local degrees of freedom are given by ```sites```, while ```args``` defines a shift of energy $$H-E_0$$.

  - signature: AIM_SpinOrbit(AIM_SpinOrbit const &)
    desc: ""

  - signature: AIM_SpinOrbit(AIM_SpinOrbit &&)
    desc: ""

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  sites: Defines the local degrees of freedom and operators.
  b: Bath parameters.
  e0: Non-interacting impurity Hamiltonian
  hint: Interaction Hamiltonain.
  args: |
    List of arguments that can take the following entries: <BR>
    
    ```E0Shift   double (default 0.)```   
    Shift $$E_0$$ of the Hamiltonian: $$H \to H + E_{0}$$.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AIM_SpinOrbit/AIM_SpinOrbit-constructors/
title: forktps::AIM_SpinOrbit::AIM_SpinOrbit
parent: forktps::AIM_SpinOrbit
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/FTPO/AIM_SpinOrbit.hpp
...

