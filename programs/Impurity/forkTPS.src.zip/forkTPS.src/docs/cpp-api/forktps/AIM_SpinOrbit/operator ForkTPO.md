---
# Do not edit this first section
layout: function
fancy_name: operator ForkTPO
namespace: forktps::AIM_SpinOrbit
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Conversion to ```ForkTPO```.

# List of overloads. Edit only the desc
overloads:

  - signature: forktps::ForkTPO operator ForkTPO()
    desc: Returns the ```ForkTPO```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: The Hamiltonian as ```ForkTPO```.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AIM_SpinOrbit/operator ForkTPO/
title: forktps::AIM_SpinOrbit::operator ForkTPO
parent: forktps::AIM_SpinOrbit
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/FTPO/AIM_SpinOrbit.hpp
...

