---
# Do not edit this first section
layout: class
short_name: AIM_SpinOrbit
qualified_name: forktps::AIM_SpinOrbit
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class AIM_SpinOrbit

# Brief description. One line only.
brief: Generates the Hamiltonian FTPO for a spin-orbit coupled bath but without off-diagonals resulting from rotations.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  While spin-orbit coupling in fact results in off-diagonal hybridizations, it
  respects some form of block structure. In the $$t_2g$$ subspace, two blocks exist where the first one couples orbitals $$A\uparrow$$, $$B\downarrow$$ and 
  $$C\downarrow$$ and the second block couples the rest of the degrees of freedom.
  
  This class implements the Hamiltonian resulting from such a bath. The entries 
  of the bath look exactly the same as for the class [```AIM_OffDiag```](/cpp-api/forktps/AIM_OffDiag) but are interpreted differently (see example below).
  
  This means that the hybridizations are triangular meaning that bath sites
  of orbital $$A\uparrow$$ couples to impurity sites of orbitals $$A\uparrow$$, $$B\downarrow$$ 
  and $$C\downarrow$$, but bath sites of orbital $$B\downarrow$$ only couples to
  the impurities $$B\downarrow$$ and $$C\downarrow$$. Finally bath sites of 
  orbital $$C\downarrow$$ only couple diagonally to the impurity $$C\downarrow$$.
  These couplings are drawn in the figure below where each red line corresponds
  to one hybridization term $$V_k \left( c_I^\dagger c_k + h.c. \right)$$.
  
  Therefore, if one generates such a bath by hand one needs to make sure to set the correct entries.
  
  ![](/assets/images/FTPS/SpinOrbitBath.png)

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - AIM_SpinOrbit-constructors
  - AIM_SpinOrbit-destructor
  - operator=
  - operator ForkTPO

# A list of non_member_functions
non_member_functions: []

# Code example. desc: any markdown to explain it.
example:
  desc: Create Hamiltonian with a bath describing spin-orbit coupling. Use two bath sites for each orbital/spin.
  code: |
    #include "forktps/fork/HelperFunctions.hpp"
    #include "forktps/fork/typenames.hpp"
    #include "forktps/types.hpp"
    #include <forktps/fork/FTPO/AIM_SpinOrbit.hpp>
    #include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
    
    using namespace forktps;
    
    int main() {
      int N = 18, Norbs = 3, NArms = 2 * Norbs; // 2 bath sites per orbital/spin
      double U = 0.5, J = 0.1, Up = U - 2 * J;  // interaction parameters
    
      AIM_ForkSites sites(N, NArms, {"conserveSz", false}); // SiteSet, Sz must not be conserved!
    
      // block structure "ud_0" and "ud_1" are names enforced by the bath
      gf_struct_t gfstruct{{"ud_0", {0, 1, 2}}, {"ud_1", {0, 1, 2}}};
    
      bath b(gfstruct, true);      // empty bath with spin-orbit = true
      hloc e0(gfstruct, true);     // empty e0 with spin-orbit = true
      H_int hint(U, J, Up, false); // interaction with dd_only = false
    
      for (auto blockName : {"ud_0", "ud_1"}) {
        std::cout << blockName << std::endl;
        // hybridization of orbital A
        cvec VA = {0.10,  // diagonal
                   0.05,  // off-diagonal to orbital B
                   0.05}; // off-diagonal to orbital C
    
        // hybridization of orbital B
        cvec VB = {0.00,  // off-diagonal to orbital A (must be zero)
                   0.10,  // diagonal
                   0.05}; // off-diagonal to orbital C
    
        // hybridization of orbital C
        cvec VC = {0.00,  // off-diagonal to orbital A (must be zero)
                   0.00,  // off-diagonal to orbital B (must be zero)
                   0.10}; // diagonal
    
        // add two bath sites impurity
        for (auto eps : {-1., 1.}) {
          b.addSite({blockName, 0}, eps, VA);
          b.addSite({blockName, 1}, eps, VB);
          b.addSite({blockName, 2}, eps, VC);
        }
      }
    
      // non-interacting impurity part with a single hopping term of strenght 0.03
      array<Complex, 2> e0Mat = {{1., 0.03, 0.}, {0.03, 1., 0.}, {0., 0., 1.}};
      e0.Fill(e0Mat);
    
      // Create the FTPO
      ForkTPO H = AIM_SpinOrbit(sites, b, e0, hint, Args());
    
      PrintDat(H.A(2)); // many entries, 2 with value 0.1 and 4 with 0.05
                        // the number of terms is doubled because one
                        // describes hopping to the impurity and the
                        // other hopping from the impurity
      return 0;
    }
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/AIM_SpinOrbit/
title: forktps::AIM_SpinOrbit
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/FTPO/AIM_SpinOrbit.hpp
parent: forktps
has_children: true
...

