---
# Do not edit this first section
layout: function
fancy_name: hdf5_format
namespace: forktps::DMRG_params
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Object identifier in hdf5.

# List of overloads. Edit only the desc
overloads:

  - signature: static std::string hdf5_format()
    desc: ""

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Name of ```DMRG_params``` object in hdf5 files.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/DMRG_params/hdf5_format/
title: forktps::DMRG_params::hdf5_format
parent: forktps::DMRG_params
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/params.hpp
...

