---
# Do not edit this first section
layout: function
fancy_name: ContractAll
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Compute overlaps.

# List of overloads. Edit only the desc
overloads:

  - signature: itensor::Complex ContractAll(forktps::ForkTPS const &psi)
    desc: Computes $$\langle \psi \| H \| \psi \rangle$$. Returns same value as [ForkLocalOp::energy](/cpp-api/forktps/ForkLocalOp/energy) but as a complex number.

  - signature: itensor::Complex ContractAll(forktps::ForkTPS const &bra, forktps::ForkTPS const &ket)
    desc: Computes $$\langle \text{bra} \| H \| \text{ket} \rangle$$.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Taking the current contractions into account, computes the matrix element of
  the Hamiltonian.

# Parameters of the function. Edit only the description after the :
params:
  psi: State with which to compute expectation value $$\langle \psi \| H \| \psi \rangle$$.
  bra: Bra-vector with which to compute matrix element $$\langle \text{bra} \| H \| \text{ket} \rangle$$.
  ket: Bra-vector with which to compute matrix element $$\langle \text{bra} \| H \| \text{ket} \rangle$$.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Result of the contraction as complex number.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/ContractAll/
title: forktps::ForkLocalOp::ContractAll
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

