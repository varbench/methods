---
# Do not edit this first section
layout: function
fancy_name: UpdateMe
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Sites the effective Hamiltonian needs to recontract.

# List of overloads. Edit only the desc
overloads:

  - signature: void UpdateMe(int site)
    desc: Site ```site``` needs to be recontracted again.

  - signature: void UpdateMe(int sitei, int sitej)
    desc: Sites ```sitei``` and ```sitej``` need to be recontracted again.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Since the effective Hamiltonian reuses environments computed previously, 
  the links of a state must not change. If a site-tensor on a certain site changes,
  this function tells the effective Hamiltonian to redo the corresponding contractions.

# Parameters of the function. Edit only the description after the :
params:
  site: Site to be contracted again.
  sitei: Site to be contracted again.
  sitej: Site to be contracted again.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/UpdateMe/
title: forktps::ForkLocalOp::UpdateMe
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

