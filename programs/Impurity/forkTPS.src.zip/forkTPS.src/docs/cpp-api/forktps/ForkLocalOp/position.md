---
# Do not edit this first section
layout: function
fancy_name: position
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Shift center of single- or two-site effective Hamiltonian.

# List of overloads. Edit only the desc
overloads:

  - signature: void position(int i, int j, forktps::ForkTPS const &psi)
    desc: |
      Creates a two-site effective Hamiltonian acting on sites ```i``` and ```j```
      using state ```psi```.

  - signature: void position(int i, int j, forktps::ForkTPS const &bra, forktps::ForkTPS const &ket)
    desc: |
      Creates a two-site effective Hamiltonian acting on sites ```i``` and ```j```
      with different bra- and ket- vectors. $$H^{eff}$$ is then based on the tensor network of 
      $$ \langle \text{bra} | H | \text{ket} \rangle$$.

  - signature: void position(int i, forktps::ForkTPS const &psi)
    desc: Creates a single-site effective Hamiltonian acting on site ```i``` using state ```psi```.

  - signature: void position(int i, forktps::ForkTPS const &bra, forktps::ForkTPS const &ket)
    desc: Creates a single-site effective Hamiltonian acting on sites ```i``` with different bra- and ket- vectors. $$H^{eff}$$ is then based on the tensor network of $$ \langle \text{bra} \| H \| \text{ket} \rangle$$.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Effective Hamiltonians with different bra- and ket-vectors are useful for 
  variationally applying an Operator $$H$$. 
  
  Note that all these functions recycle already performed contractions to only do 
  necessary computations.

# Parameters of the function. Edit only the description after the :
params:
  i: One site the effective Hamiltonian acts on.
  j: One site the effective Hamiltonian acts on.
  psi: State that defines the left- and right basis.
  bra: Bra-state for the effective Hamiltonian $$ \langle \text{bra} \| H \| \text{ket} \rangle$$.
  ket: Ket-state for the effective Hamiltonian $$ \langle \text{bra} \| H \| \text{ket} \rangle$$.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/position/
title: forktps::ForkLocalOp::position
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

