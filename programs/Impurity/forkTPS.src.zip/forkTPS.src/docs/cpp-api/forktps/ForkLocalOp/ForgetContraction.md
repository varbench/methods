---
# Do not edit this first section
layout: function
fancy_name: ForgetContraction
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Deletes any knowledge of existing contractions.

# List of overloads. Edit only the desc
overloads:

  - signature: void ForgetContraction()
    desc: Deletes any knowledge of existing contractions.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  After this function is called, the Tensor Network of $$\langle \psi \| H \| \psi \rangle$$
  is contracted anew. Useful if large parts of the state changed or if one wants
  to quickly try something out without worrying about keeping the state the same
  all the time.

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/ForgetContraction/
title: forktps::ForkLocalOp::ForgetContraction
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

