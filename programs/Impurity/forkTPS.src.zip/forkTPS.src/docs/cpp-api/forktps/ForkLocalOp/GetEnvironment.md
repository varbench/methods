---
# Do not edit this first section
layout: function
fancy_name: GetEnvironment
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns an environment tensor.

# List of overloads. Edit only the desc
overloads:

  - signature: itensor::ITensor const &GetEnvironment(enum forktps::OrthoState dir) const
    desc: Returns the environment tensor the current site in direction ```dir```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  An environment tensor is a part of the contraction of the tensor network 
  $$\langle \psi \| H \| \psi \rangle$$. An example of an environment in 
  direction ```Rightwards``` is shown in the Figure below. Note that currently 
  this function only works if the effective Hamiltonian is in single-site mode.
  
  ![](/assets/images/FTPS/RightEnvironment.png)

# Parameters of the function. Edit only the description after the :
params:
  dir: Direction of environment tensor based on current site.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Environment tensor.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/GetEnvironment/
title: forktps::ForkLocalOp::GetEnvironment
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

