---
# Do not edit this first section
layout: function
fancy_name: ExpansionTensor
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Calculates the tensor used in subspace expansion.

# List of overloads. Edit only the desc
overloads:

  - signature: std::pair<ITensor, Index> ExpansionTensor(enum forktps::OrthoState dir, forktps::ForkTPS const &psi) const
    desc: |
      Computes the expansion tensor used for subspace expansion by expanding 
      link of the current active site in direction ```dir``` using state ```psi```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Since DMRG is a variational method, it can get stuck in local minima. This
  is especially problematic, if one uses single-site algorithms. Part of this
  problem is that single site algorithms cannot increase the link-dimensions. 
  Subspace expansion proposed in <a href="https://journals.aps.org/prb/abstract/10.1103/PhysRevB.91.155115" target="_blank">PRB 91, 155115</a>
  allows to increase the link dimension for single-site algorithms and very 
  often also solves the convergence issue.
  
  The idea behind subspace expansion is to extend the basis of the current state
  without actually changing it. It expands the tensor by  
  those states that the action of the Hamiltonian would create. Since subspace
  expansion only works for single-site algorithms, this 
  function throws an error if used for any effective Hamiltonian other than a single-site one.
  Also note that it only provides the expansion tensor, it does not 
  perform the actual expansion.

# Parameters of the function. Edit only the description after the :
params:
  dir: Direction in which to expand, defines the link that is enlarged.
  psi: State to perform the expansion with.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Expansion ```ITensor``` and the ```Index``` for the new basis states.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/ExpansionTensor/
title: forktps::ForkLocalOp::ExpansionTensor
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

