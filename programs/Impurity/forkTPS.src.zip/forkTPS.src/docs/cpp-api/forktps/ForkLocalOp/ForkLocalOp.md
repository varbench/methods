---
# Do not edit this first section
layout: class
short_name: ForkLocalOp
qualified_name: forktps::ForkLocalOp
namespace: forktps
includer: forktps/forktps_include.hpp
signature: class ForkLocalOp

# Brief description. One line only.
brief: Effective Hamiltonians in ForkTN-structure.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  Class that defines an effective Hamiltonian acting on zero, one or two sites.
  In general, effective Hamiltonians are an important concept in Tensor networks.
  They are the basis of the Density Matrix Renormalization Group ([DMRG](/cpp-api/forktps/DMRG)) algorithm
  which variationally searches for ground states. Similarly they are also vital 
  in the time evolution method called Time-Dependent-Variational Principle ([TDVP](/cpp-api/forktps/TDVP))
  which this library also makes heavy use of.
  
  ## What are effective Hamiltonians
  
  The term effective Hamiltonian means a Hamiltonian which does not act on the 
  full Hilbert space but is reduced to the action in a certain subset only. For 
  example, a typical state obtained from a 1d-MPS takes the form:
  
  $$| \psi \rangle = \sum_{l,s_i,r} \underbrace{c_{l,s_i,r}}_{\equiv A^{s_i}_{l,r}} | l \rangle |s_i\rangle |r\rangle,$$
  
  where $$\| l \rangle$$ only acts on the sites $$s_1 \cdots s_{i-1}$$ (sites left of $$s_i$$)
  while $$\|r\rangle$$ acts on sites $$s_{i+1} \cdots s_N$$ (sites right of $$s_i$$).
  Both are orthogonal basis states of their respective subsystem.
  If the number of states in $$l$$ and $$r$$ is large enough, every quantum state 
  $$| \psi \rangle$$ can be written in that way. But this leads to an exponential 
  growth in the number of states that need to be kept. Tensor networks avoid this
  by keeping only the most important $$\|l\rangle$$ and $$\|r\rangle$$
  basis states. The number of states kept is the so-called bond-dimension of the
  Tensor Network.
  
  With this, it is easy to understand effective Hamiltonians: they are simply the
  Hamiltonian in the (most of the time) non-complete basis $$\|l\rangle \|s_i \rangle \|r\rangle$$:
  
  $$H^{eff}_{ (l's_i'r') , (l s_i r)} = \langle l' s_i' r' \| H \| l s_i r \rangle .$$
  
  Of course the definition of effective Hamiltonians can be extended to two-sites
  $$s_i$$ and $$s_{i+1}$$:
  
  $$H^{eff}_{ (l's_i' s_{i+1}' \tilde{r}') , (l s_i s_{i+1} \tilde{r})} = \langle l' s_i' s_{i+1}' \tilde{r}' \| H \| l s_i s_{i+1} \tilde{r} \rangle .$$
  
  Where the states $$\|\tilde{r}\rangle$$ are different from the $$\|r\rangle$$ 
  above because the former only act on sites $$s_{i+2} \cdots s_N$$. A Tensor
  Network depiction of a two-site effective Hamiltonian is shown in the figure 
  below.
  
  A little bit more unconventional but quite useful is an effective Hamiltonian
  acting at no physical site at all but only on the link-degree of freedoms. We
  can write a quantum state as:
  $$| \psi \rangle = \sum_{l,r} c_{lr} | l \rangle |r\rangle,$$
  where $$\|l\rangle$$ acts on sites $$s_1 \cdots s_i$$ while $$\|r\rangle$$ acts
  on $$s_{i+1} \cdots s_N$$. Then we can define a zero-site effective Hamiltonian the same 
  way:
  
  $$H^{eff}_{ (l' r') , (l r)} = \langle l' r' \| H \| l r \rangle .$$
  
  Currently, zero-site effective Hamiltonians are needed only for the single-site variant of the
  TDVP time evolution and have little purpose beyond that.
  
  ![](/assets/images/FTPS/EffH.png) 
  
  For efficency reasons, there are two important details one needs to keep in mind:
  
  1. Effective Hamiltonians are usually not stored as a full matrix
  but in a sparse representation by keeping track of the so-called left- and right-environments $$L$$
  and $$R$$ as well as two tensors of the operator (blue rectangles in the middle) 
  shown in the figure above. Storing it that way is enough,
  since we are only interested in the action of an effective Hamiltonian on a 
  vector and not in the matrix itself.
  
  2. Computing effective Hamiltonians from scratch is quite expensive, because one needs to 
  contract large parts of the tensor network of $$ \langle \psi | H | \psi \rangle$$.
  To avoid unnecessary tensor contractions, effective Hamiltonian store
  environments generated in prior contractions and recycle them if possible. 
  
  This class implements such efficient effective Hamiltonians on the fork-geometry.
  Instead of having only left- and right-environments, impurity sites can have also
  up- and down-environments. Depending on the currently active site $$s_i$$ 
  different environment Tensor can or cannot exists. In the latter case they are
  simply default constructed ```ITensors```. 
  It implements functions like changing the number of sites the Hamiltonian acts on on the fly 
  using 
  [```position```](/cpp-api/forktps/ForkLocalOp/position) and 
  [```position_0site```](/cpp-api/forktps/ForkLocalOp/position_0site), computing 
  the [```energy```](/cpp-api/forktps/ForkLocalOp/energy) or 
  performing _matrix-vector_ multiplication via [```product```](/cpp-api/forktps/ForkLocalOp/product). 
  
  ### Important:
  Since effective Hamiltonians recycle already computed contractions, one needs
  to be very careful to not change the state on sites other than $$s_i$$ (or $$s_{i+1}$$ 
  in the case of a two-site effective Hamiltonian). If this cannot be avoided, 
  use the functions [```UpdateMe```](/cpp-api/forktps/ForkLocalOp/UpdateMe) 
  to specifiy single site(s) that were changed or 
  [```ForgetContraction```](/cpp-api/forktps/ForkLocalOp/ForgetContraction) to 
  completely recompute the whole effective Hamiltonian.

# A list of methods. You can reorder, regroup into a dict : groupname -> list
methods:
  - ForkLocalOp-constructors
  - ForkLocalOp-destructor
  - position
  - position_0site
  - i
  - j
  - GetEnvironment
  - ExpansionTensor
  - product
  - ContractAll
  - energy
  - UpdateMe
  - ForgetContraction
  - size
  - PrintEnvironment
  - operator=

# A list of non_member_functions
non_member_functions: []
member_fields:
  H:
    type: forktps::ForkTPO
    desc: Hamiltonian.
  L:
    type: itensor::ITensor
    desc: |
      Left environment tensor (default contructed ```ITensor``` if no tensor to the left exists).
      Note that a two-site effective Hamiltonian with both sites being impurities have
      two different environments to the right (one for each impurity). In that case, ```L``` is abused to store the
      right environment of the second impurity, the one with the higher index.
  R:
    type: itensor::ITensor
    desc: Right environment tensor (default contructed ```ITensor``` if no tensor to the left exists).
  U:
    type: itensor::ITensor
    desc: |
      Up environment tensor (default contructed ```ITensor``` if no tensor to the left exists).
      Only impurity tensors have an up environment.
  D:
    type: itensor::ITensor
    desc: |
      Down environment tensor (default contructed ```ITensor``` if no tensor to the left exists).
      Only impurity tensors have a down environment.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/
title: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
parent: forktps
has_children: true
...

