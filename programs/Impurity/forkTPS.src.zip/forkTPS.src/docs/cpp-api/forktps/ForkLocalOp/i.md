---
# Do not edit this first section
layout: function
fancy_name: i
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns one of the sites the effective Hamiltonian acts on.

# List of overloads. Edit only the desc
overloads:

  - signature: int i()
    desc: Returns one of the sites the effective Hamiltonian acts on.

# Long description. Any Markdown, with code, latex, multiline with |
desc: |
  In the two-site and zero-site cases, it returns the smallest of the two sites.
  (```ForkLocalOp::i() < ForkLocalOp::j()```).
  For a single site effective Hamiltonian it returns the site it acts on.

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: One of the sites the effective Hamiltonian acts on.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/i/
title: forktps::ForkLocalOp::i
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

