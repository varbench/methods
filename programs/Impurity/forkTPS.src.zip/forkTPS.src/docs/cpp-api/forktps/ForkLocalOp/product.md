---
# Do not edit this first section
layout: function
fancy_name: product
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Matrix-vector product.

# List of overloads. Edit only the desc
overloads:

  - signature: void product(itensor::ITensor const &x, itensor::ITensor &res) const
    desc: Product of the effective Hamiltonian with ```x``` is stored in ```res``` (```res = Heff*x```).

# Long description. Any Markdown, with code, latex, multiline with |
desc: Needed by sparse eigenvalue solvers like Lanzcos or Davidson.

# Parameters of the function. Edit only the description after the :
params:
  x: Vector to multiply.
  res: Result of multiplication.

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: __MISSING__

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/product/
title: forktps::ForkLocalOp::product
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

