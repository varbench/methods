---
# Do not edit this first section
layout: function
fancy_name: size
namespace: forktps::ForkLocalOp
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Returns the size of the effective Hamiltonian.

# List of overloads. Edit only the desc
overloads:

  - signature: unsigned long size() const
    desc: Returns the size of the effective Hamiltonian.

# Long description. Any Markdown, with code, latex, multiline with |
desc: Needed by the Davidson algorithm.

# Parameters of the function. Edit only the description after the :
params:
  {}

# Template parameters of the function. Edit only the description after the :
tparams:
  {}

# Desc of the return value
return_value: Matrix size.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/ForkLocalOp/size/
title: forktps::ForkLocalOp::size
parent: forktps::ForkLocalOp
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/ForkLocalOp.hpp
...

