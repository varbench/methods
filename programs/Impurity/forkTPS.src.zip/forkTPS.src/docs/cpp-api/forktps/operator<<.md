---
# Do not edit this first section
layout: function
fancy_name: operator<<
namespace: forktps
includer: forktps/forktps_include.hpp

# Brief description. One line only.
brief: Write to stream.

# List of overloads. Edit only the desc
overloads:

  - signature: std::ostream &operator<<(std::ostream &os, forktps::BandWidths const &bw)
    desc: Write Bandwidths to ```ostream```.

  - signature: |
      template <class T>
      std::ostream &operator<<(std::ostream &os, std::vector<T> const &vec)
    desc: Write a vector to ```ostream```.

# Long description. Any Markdown, with code, latex, multiline with |
desc: ""

# Parameters of the function. Edit only the description after the :
params:
  os: Out-stream to write to.
  bw: Bandwidth object to write.
  vec: Vector to write.

# Template parameters of the function. Edit only the description after the :
tparams:
  T: Any type for which ```<<``` operator is defined.

# Desc of the return value
return_value: Outstream with object written to it.

# Code example. desc: any markdown to explain it.
example:
  desc: ""
  code: ""
  comment: ""

# A list of related functions/classes
see-also: []

# ---------- DO NOT EDIT BELOW --------
permalink: /cpp-api/forktps/operator<</
title: forktps::operator<<
parent: forktps
source: /mnt/home/dbauernfeind/FORKTPS/forktps/c++/forktps/fork/Bath.hpp
...

