import forktps as ftps
from forktps.solver_core import Bath, Hloc
from forktps.Helpers import MakeGFstruct, IsOffDiag, GFDiag, getX


import triqs.utility.mpi as mpi
from triqs.gf import *

# other python libraries
import numpy as np
import sys
import numbers
import itertools
import matplotlib.pyplot as plt

from scipy import optimize, integrate
from itertools import product
from typing import List, Dict, Optional, Union, Callable
from scipy.optimize import minimize


fList = List[float]
BlockList = Dict[str, fList]
BlockMatrix = Dict[str, List[fList]]


# TODO Native typing of numpy arrays needs python 3.8 hence their typing
# is currently not yet done and often a List is used instead of np.array

# TODO make intervals consistent


class Interval:
    def __init__(self, l: float, u: float):
        if not isinstance(l, numbers.Number):
            raise RuntimeError(
                f"Lower interval boundary must be a number, tried to create an interval with lower = {l}"
            )

        if not isinstance(u, numbers.Number):
            raise RuntimeError(
                f"Upper interval boundary must be a number, tried to create an interval with upper = {u}"
            )

        self.lower = l
        self.upper = u

    def length(self):
        return self.upper - self.lower

    @staticmethod
    def keys():
        return ["lower", "upper"]

    def __getitem__(self, key: str):
        if key == "upper":
            return self.upper
        elif key == "lower":
            return self.lower

        raise KeyError("Interval keys can only be upper or lower")
        return 0

    def __setitem__(self, key: str, value: float):
        if key not in self.keys():
            raise KeyError("Interval keys can only be upper or lower")

        if key == "upper":
            self.upper = value
        else:
            self.lower = value

        return

    def __repr__(self):
        return "Interval of length %.2f: [%+.3f, %+.3f] " % (
            self.length(),
            self.lower,
            self.upper,
        )


def DiscretizeBath(
    Delta: BlockGf,
    Nb: int,
    err: float = 0.01,
    SO: bool = False,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
    symmG: Optional[Callable] = None,
):
    """Discretizes the bath hybridization Delta using Nb bath sites.

    Parameters
    ----------
    Delta:  blockGF of GfReFreq
    Hybridization function to be discretized.

    Nb:     int
    Number of bath sites used in the discretization.

    err:    float, default 0.01
    Neglected fraction of the spectral function of the hybridization, due to
    restricing the discretization interval to the most important region.

    SO:     bool, default False
    Flag indicating whether the bath is for a Spin-orbit calculation.

    gap:    List[float], default None
    A single interval in which no bath site will be placed. One list
    is used for each block index.

    outerInt:   dict
    Energy intervals for the discretization. Note that depending on wheter
    the hybridization is diagonal or off-diagonal, outerInt has a different
    shape (see description of DiscretizeDiagBath() and __DiscretizeDiag()).
    If None intervals are determined automatically.

    PlaceAt:    dict
    Energy positions at which the discretization has to place a bath site.
    One value must be specified for each orbtial. For example in a two-orbital
    problem with two blocks "up" and "dn" PlaceAt could look like this:
    PlaceAt ={ "up" : [0.3,0.25] , "dn" : [0,-0.2] } and would place a bath
    site at energy 0.3 in the first orbital of block 'up' etc. If None, bath
    sites are placed on a linear grid. Only works for diagonal baths, since
    for off-diagonal baths the bath sites are coupled.

    symmG:  Callable, default = None
    Function that will be applied to Δ(ω) to symmetrize it. The
    function must take a single Triqs Block Green function and return
    the symmetrized version of it.

    Returns
    -------
    bath:   Bath
    Bath object storing the bath parameters.
    """

    if symmG is not None:
        symmDelta = symmG(Delta)
    else:
        symmDelta = Delta

    __CheckDiscretizationInput(symmDelta, gap, outerInt, PlaceAt)

    # create GF struct and initialize empty bath with it
    bath = ftps.solver_core.Bath(MakeGFstruct(symmDelta), SO)

    # discretization of diagonal and off-diagonal hybridizations are different
    # because for a diagonal bath, the bath sites do not couple and each orbital
    # can be discretized separately, while for an off-diagonal bath, they do couple
    # and cant be treated independently.
    if IsOffDiag(symmDelta):
        return __DiscretizeOffDiag(symmDelta, Nb, err, bath, gap, outerInt, PlaceAt)
    else:
        return __DiscretizeDiag(symmDelta, Nb, err, bath, gap, outerInt, PlaceAt)


def __DiscrIntervals(
    Delta: BlockGf,
    Nb: int,
    err: float = 0.01,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
):
    """Returns intervals in which the hybridization function *Delta* should be discretized. They
    are stored in the block structure given by Delta. Note that this function does not provide
    intervals for individual bath sites, but slices Delta into intervals. For example if a gap
    is provided, the intervals do not contain this region."""

    intervals = {}
    for name, delta in Delta:
        specMat = 1j / (2 * np.pi) * (delta - conjugate(transpose(delta)))
        Norbs = specMat.target_shape[0]

        intervals[name] = []

        for i in range(Norbs):
            intervals[name].append([])
            # outer limits
            if outerInt is None:
                outer = OuterDiscrBoundaries(specMat[i, i], err)
            else:
                outer = Interval(outerInt[name][i][0], outerInt[name][i][1])

            if PlaceAt is None:
                if gap is None:
                    intervals[name][i].append(outer)
                else:
                    intervals[name][i].append(Interval(outer["lower"], gap[0]))
                    intervals[name][i].append(Interval(gap[1], outer["upper"]))

            else:
                at = PlaceAt[name][i]
                if gap is None:
                    size = outer.length() / Nb

                    intervals[name][i].append(Interval(at - size / 2, at + size / 2))
                    intervals[name][i].append(Interval(outer["lower"], at - size / 2))
                    intervals[name][i].append(Interval(at + size / 2, outer["upper"]))
                else:
                    Ltot = (gap[0] - outer["lower"]) + (outer["upper"] - gap[1])
                    size = Ltot / Nb

                    if at < gap[0]:
                        intervals[name][i].append(
                            Interval(outer["lower"], at - size / 2)
                        )
                        intervals[name][i].append(
                            Interval(at - size / 2, at + size / 2)
                        )
                        intervals[name][i].append(Interval(at + size / 2, gap[0]))
                        intervals[name][i].append(Interval(gap[1], outer["upper"]))
                    else:
                        intervals[name][i].append(Interval(outer["lower"], gap[0]))
                        intervals[name][i].append(Interval(gap[1], at - size / 2))
                        intervals[name][i].append(
                            Interval(at - size / 2, at + size / 2)
                        )
                        intervals[name][i].append(
                            Interval(at + size / 2, outer["upper"])
                        )

    return intervals


def __DiscrIntervalsMat(
    Delta: BlockGf,
    Nb: int,
    err: float = 0.01,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
):
    """Returns intervals in which the hybridization function *Delta* should be discretized. They
    are stored in the block structure given by Delta. Note that this function does not provide
    intervals for individual bath sites, but slices Delta into intervals. For example if a gap
    is provided, the intervals do not contain this region."""

    intervals = {}
    for name, delta in Delta:
        specMat = 1j / (2 * np.pi) * (delta - conjugate(transpose(delta)))

        intervals[name] = []

        if outerInt is None:
            outer = OuterDiscrBoundaries(specMat, err)
        else:
            outer = Interval(outerInt[name][0], outerInt[name][1])

        if PlaceAt is None:
            if gap is None:
                intervals[name].append(outer)
            else:
                intervals[name].append(Interval(outer["lower"], gap[0]))
                intervals[name].append(Interval(gap[1], outer["upper"]))

        else:
            at = PlaceAt[name]
            if gap is None:
                size = outer.length() / Nb

                intervals[name].append(Interval(outer["lower"], at - size / 2))
                intervals[name].append(Interval(at - size / 2, at + size / 2))
                intervals[name].append(Interval(at + size / 2, outer["upper"]))
            else:
                Ltot = (gap[0] - outer["lower"]) + (outer["upper"] - gap[1])
                size = Ltot / Nb

                if at < gap[0]:
                    intervals[name].append(Interval(outer["lower"], at - size / 2))
                    intervals[name].append(Interval(at - size / 2, at + size / 2))
                    intervals[name].append(Interval(at + size / 2, gap[0]))
                    intervals[name].append(Interval(gap[1], outer["upper"]))
                else:
                    intervals[name].append(Interval(outer["lower"], gap[0]))
                    intervals[name].append(Interval(gap[1], at - size / 2))
                    intervals[name].append(Interval(at - size / 2, at + size / 2))
                    intervals[name].append(Interval(at + size / 2, outer["upper"]))

    return intervals


def OuterDiscrBoundaries(spec: GfReFreq, err: float):
    """
    Returns the outer interval outer that contains *1-err* percent of the area of *A*.

    Parameters
    ----------
    spec :      GfReFreq
    Bath spectral function.

    err :       float
    Relative error in the total area of A.

    Returns
    ----------
    outer:     list
    Outer boundaries of discretization.
    """
    w = [w.value for w in spec.mesh]
    Adata = spec.data
    if len(spec.data.shape) == 1:
        Adata = Adata[:, np.newaxis, np.newaxis]

    totArea = integrate.simps(x=w, y=np.abs(Adata), axis=0)
    # check that diagonals are non-zero
    for d in np.diagonal(totArea):
        if np.abs(d) < 1e-14:
            raise RuntimeError("Spectral function with zero diagonals found.")

    relArea = totArea * err

    Norbs = relArea.shape[0]
    wmin = np.zeros((Norbs, Norbs), dtype=np.float64)
    wmax = np.zeros((Norbs, Norbs), dtype=np.float64)

    # lower border
    for i, j in itertools.product(list(range(Norbs)), list(range(Norbs))):
        if relArea[i, j] < 1e-14:
            continue

        found = False
        step = len(w) // 100
        indx = step
        area = 0

        while found == False:
            area = np.trapz(x=w[:indx], y=np.abs(Adata[:indx, i, j]))
            # print("integrating up to w = " + str(w[indx]) + " gives an area of " + str(area))
            if area < relArea[i, j] / 2:
                indx += step
            else:
                indx -= step
                step = step // 2
                indx += step

            if step == 1:
                found = True
                wmin[i, j] = w[indx - 1]

        if np.abs(relArea[i, j] / 2 - area) > 1e-3:
            print(
                (
                    "Deviation in orbital %i, %i: %f"
                    % (i, j, np.abs(relArea[i, j] / 2 - area))
                )
            )

    # uppper border
    for i, j in itertools.product(list(range(Norbs)), list(range(Norbs))):
        if relArea[i, j] < 1e-14:
            continue

        found = False
        step = len(w) // 100
        indx = len(w) - step
        area = 0

        while found == False:
            area = np.trapz(x=w[indx:], y=np.abs(Adata[indx:, i, j]))
            # print("integrating starting at w = " + str(w[indx]) + " gives an area of " + str(area) )

            if area < relArea[i, j] / 2:
                indx -= step
            else:
                indx += step
                step = step // 2
                indx -= step

            if step == 1:
                found = True
                wmax[i, j] = w[indx]

        if np.abs(relArea[i, j] / 2 - area) > 1e-3:
            print(
                (
                    "Deviation in orbital %i, %i: %f"
                    % (i, j, np.abs(relArea[i, j] / 2 - area))
                )
            )

    return Interval(np.min(wmin), np.max(wmax))


# number of sites in each interval
def IntervalBathSizes(intervals: List[Interval], Nb: int, printWarning=True):
    """
    For a given list of discretization intervals, returns the number of
    bath sites in each of these intervals such that the total number of
    sites is Nb.

    Parameters
    ----------
    intervals :     list of list
    List of intervals.

    Nb :            int
    Total number of bath sites.

    printWarning :  int (default = True)
    Flag for turning off the zero Nb-warning.

    Returns
    ----------
    Nbs :       numpy array of integers
    Number of bath sites in each interval.
    """

    Ltot = 0.0
    for interval in intervals:
        Ltot += interval.length()

    Nrest = Nb
    Lrest = Ltot
    Nbs = np.zeros(len(intervals), np.int64)

    for indx, interval in enumerate(intervals):
        Li = interval.length()

        Nbs[indx] = round(Li / Lrest * Nrest)

        if Nbs[indx] == 0 and printWarning:
            mpi.report(
                "   Warning: Interval without a bath site found. Check the resulting bath!"
            )
        if Nbs[indx] < 0 and printWarning:
            mpi.report(
                "   Warning: Interval a negative number of sites found. Check the resulting bath!"
            )
            print(intervals)

        Nrest += -Nbs[indx]
        Lrest += -Li

    return Nbs


# converter of triqs GF to np array for integration


def __IntegrationArrays(gf: GfReFreq, upto: float):
    """
    Generates integration arrays for the calculation of the bath paramters.
    For a given Greens function data, living on a domain ω it returns x = ω(ω < upto)
    and y = gf(ω < upto). Since both quantities live on an discrete grid, this function
    appends the point (upto, data(upto)).
    """

    indices = np.array([w.linear_index for w in gf.mesh if (w.value < upto)])
    x = np.array([w.value for w in gf.mesh if (w.value < upto)])
    y = gf.data[indices]

    # append data point exactly at upto, to avoid discretization artifacts
    x = np.append(x, upto)
    if len(y.shape) == 1:
        y = np.append(y, gf(x[-1]))
    else:
        y = np.append(y, gf(x[-1])[None, :, :], axis=0)

    return x, y


# adding of a single bath site
def __AddBathSite(
    bath: Bath,
    spec: GfReFreq,
    upTo: float,
    intervallSize: float,
    lastInt: float,
    name: str,
    indx: int,
):
    """
    Simple helper function called by DiscretizeDiagBath to calculate and put a single
    site into block *name* and index *indx* of *bath*. It returns the new bath, the new
    integration broders as well as the new total integral."""
    Norbs = bath.NArms // 2
    upTo += intervallSize

    intW, intDel = __IntegrationArrays(spec, upTo)
    thisInt = np.trapz(x=intW, y=intDel, axis=0)
    A = thisInt - lastInt

    if A < 0:
        print(
            (
                "Error in Discretization: Bath spectral function is negative around ω = %f"
                % (upTo - intervallSize / 2)
            )
        )

    # sqrt is the 1x1 analogue to cholesky
    Vchol = np.zeros((Norbs), dtype=np.complex128)
    Vchol[indx] = np.sqrt(A)

    # on-site energy is in the middle of current interval
    eps = upTo - intervallSize / 2
    bath.addSite([name, indx], eps, Vchol)

    return bath, upTo, thisInt


def __AddBathSiteMat(
    bath: Bath,
    spec: GfReFreq,
    upTo: float,
    intervallSize: float,
    lastInt: float,
    name: str,
):
    """
    Simple helper function called by DiscretizeOffDiagBath to calculate and put a single
    site into block *name* and index *indx* of *bath*. It returns the new bath, the new
    integration broders as well as the new total integral."""
    upTo += intervallSize

    intW, intDel = __IntegrationArrays(spec, upTo)
    thisInt = np.trapz(x=intW, y=intDel, axis=0)
    A = thisInt - lastInt

    # check that A is positive definite if not remove diagonals but give a warning
    D, V = np.linalg.eigh(A)
    if any(d < 0 for d in D):
        print(
            (
                "Warning, during discretization encountered non-positive definite spectral function around ω "
                + str(upTo - intervallSize / 2)
                + ". Only keeping diagonal entries of bath spectrum."
            )
        )
        A = np.diag(np.diag(A))

    # cholesky decomposition for hoppings
    Vchol = np.linalg.cholesky(A)  # A = V*V^D

    # on-site energy is in the middle of current interval
    eps = upTo - intervallSize / 2
    for i in range(Vchol.shape[0]):
        bath.addSite([name, i], eps, Vchol[:, i])

    return bath, upTo, thisInt


def __CheckDiscretizationInput(
    Delta: BlockGf,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
):
    """Checks that the input to the discretization function is valid."""

    if not isinstance(Delta, BlockGf):
        raise TypeError("Argument must be a TRIQS BlockGf.")

    if IsOffDiag(Delta):
        # outerInt
        if outerInt is not None:
            for _, intervall in list(outerInt.items()):
                if len(np.shape(intervall)) != 1:
                    print((np.shape(intervall)))
                    msg = """outerInt incorrect shape. When an off-diagonal hybridization 
                             is provided, the dictionary outerInt can only contain 1d container."""
                    raise RuntimeError(msg)
        # PlaceAt
        if PlaceAt is not None:
            for _, num in list(PlaceAt.items()):
                if not isinstance(num, numbers.Number):
                    print(num)
                    msg = """PlaceAt incorrect shape. When an off-diagonal hybridization is
                           provided, the dictionary can only contain a single number for each block, 
                           specifying the energy at which the bath site of the block should be placed"""
                    raise RuntimeError(msg)

        # Gap and PlaceAt
        if gap is not None and PlaceAt is not None:
            for _, val in list(PlaceAt.items()):
                if val > gap[0] and val < gap[1]:
                    print(val)
                    print(gap)
                    msg = "Error, value of PlaceAt inside gap!"
                    raise RuntimeError(msg)
    else:
        # Diagonal bath
        if outerInt is not None:
            for _, intervall in list(outerInt.items()):
                if len(np.shape(intervall)) != 2:
                    print((np.shape(intervall)))
                    msg = """outerInt  incorrect shape. When a diagonal hybridization 
                        is provided, the dictionary outerInt can only contain 2d lists or numpy arrays 
                        specifying the energy interval of each index in every block."""
                    raise RuntimeError(msg)

        if PlaceAt is not None:
            for _, at in list(PlaceAt.items()):
                if len(np.shape(at)) != 1:
                    print((np.shape(at)))
                    msg = """PlaceAt incorrect shape. When a diagonal hybridization is 
                            provided, the dictionary can only contain 1d arrays specifying the 
                            energy at which a bath site should be placed."""
                    raise RuntimeError(msg)

        # gap and PlaceAt
        if gap is not None and PlaceAt is not None:
            for _, at in list(PlaceAt.items()):
                for val in at:
                    if val > gap[0] and val < gap[1]:
                        print(val)
                        print(gap)
                        msg = "Error, value of PlaceAt inside gap!"
                        raise RuntimeError(msg)


def __DiscretizeDiag(
    Delta: BlockGf,
    Nb: int,
    err: float,
    bath: Bath,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
):
    """
    Discretizes an diagonal bath described by the hybridization Delta using Nb bath sites.
    In this function the orbitals are independent of each other in the sense that they can
    have different on-site energies corresponding for example to different bandwidths of each orbital.

    Parameters
    ----------
    Delta:      blockGF
    Hybridization function to be discretized.

    Nb:         int
    Number of bath sites used in the discretization.

    err:        float, default 0.01
    Neglected fraction of the spectral function of the hybridization, due
    to restricing the discretization interval to the most important region.

    bath:       forktps Bath
    Empty but initialized with the correct block structure.

    outerInt:   dict of 2-d arrays
    Energy intervals for the discretization. One interval must be provided for
    each orbital. For example in a two-orbital problem with two blocks "up" and
    "dn" outerInt could look like this:
    outerInt ={ "up" : [[0,1.], [0,0.5]] , "dn" : [[0,1.], [0,0.5]] }.
    If None, intervals are determined automatically.

    PlaceAt:    dict of 1-d arrays
    Energy positions at which the discretization has to place a bath site.
    One value must be specified for each orbtial. For example in a two-orbital
    problem with two blocks "up" and "dn" PlaceAt could look like this:
    PlaceAt ={ "up" : [0.3,0.25] , "dn" : [0,-0.2] }
    and would place a bath site at energy 0.3 in the first orbital of block 'up'
    etc. If None, bath sites are placed on a linear grid. Only works for
    diagonal baths, since for off-diagonal baths the bath sites are coupled.

    Returns
    -------
    bath: Bath
    Bath object storing the relevant information about the discrete bath.
    """

    AllIntervals = __DiscrIntervals(
        Delta, Nb, err, gap=gap, outerInt=outerInt, PlaceAt=PlaceAt
    )

    # start discretization
    for name, delta in Delta:
        specMat = 1j / (2 * np.pi) * (delta - conjugate(transpose(delta)))
        Norbs = specMat.target_shape[0]

        for i in range(Norbs):
            spec = specMat[i, i]
            intervals = AllIntervals[name][i]
            Nbs = IntervalBathSizes(intervals, Nb)

            for interval, N in zip(intervals, Nbs):
                DiscrRange = interval.length()
                size = DiscrRange / N

                intW, intDel = __IntegrationArrays(spec, interval["lower"])
                lastInt = np.trapz(x=intW, y=intDel, axis=0)
                upTo = interval["lower"]

                for _ in range(N):
                    bath, upTo, lastInt = __AddBathSite(
                        bath, spec, upTo, size, lastInt, name, i
                    )

    return bath


def __DiscretizeOffDiag(
    Delta: BlockGf,
    Nb: int,
    err: float,
    bath: Bath,
    gap: Union[fList, None] = None,
    outerInt: Union[BlockList, BlockMatrix, None] = None,
    PlaceAt: Union[BlockList, None] = None,
):
    """
    Discretizes an off-diagonal bath described by the hybridization Delta using Nb bath sites.
    In this function the bath sites of the different orbitals are coupled in the sense the discretization
    intervals are the same for each index in a block (therefore also the on-site energies).

    Parameters
    ----------
    Delta:      blockGF
    Hybridization function to be discretized.

    Nb:         int
    Number of bath sites used in the discretization.

    err:        float, default 0.01
    neglected fraction of the spectral function of the hybridization, due
    to restricing the discretization interval to the most important region.

    bath:       forktps Bath
    Empty bath initialized with the correct block structure.

    outerInt:   dict of 1-d arrays
    Energy intervals for the discretization in form of a 1d-list for each block.
    Since for off-diagonal baths, the on-site energies are coupled, it makes
    no sense to specify an energy range for each orbital separately.
    If None, intervals are determined automatically.

    PlaceAt:    dict of floats
    Energy positions at which the discretization has to place a bath site.
    For example PlaceAt ={ "up" : 0.1 , "dn" : 0.2 } which places one bath site
    at energy 0.1 in the up-block and one with energy 0.2 in the dn block.

    Returns
    -------
    bath:       Bath
    Bath object storing the relevant information about the discrete bath.
    """

    AllIntervals = __DiscrIntervalsMat(
        Delta, Nb, err, gap=gap, outerInt=outerInt, PlaceAt=PlaceAt
    )

    for name, delta in Delta:
        intervals = AllIntervals[name]
        Nbs = IntervalBathSizes(intervals, Nb)
        # calculate spectral function
        specMat = 1j / (2 * np.pi) * (delta - conjugate(transpose(delta)))
        for N, interval in zip(Nbs, intervals):
            DiscrRange = interval.length()
            size = DiscrRange / N

            intW, intDel = __IntegrationArrays(specMat, interval["lower"])
            lastInt = np.trapz(x=intW, y=intDel, axis=0)
            upTo = interval["lower"]

            for _ in range(N):
                bath, upTo, lastInt = __AddBathSiteMat(
                    bath, specMat, upTo, size, lastInt, name
                )

    return bath


def FourierTransform(Gt: GfReTime, mesh: MeshReFreq, eta: float, doSimps: bool = False):
    """Perform the Fourier transform int Gt*exp(i*w*t - eta*t) for w in `mesh`.

    To reduce oscillations due to the finite time series,
    the time series is damped by an exponential decay with strength eta.
    Mathematically, this is a Laplace transform.
    In energy space this corresponds to the usual Lorentzian broadening.

    Parameters
    ----------
    Gt:         BlockGf of GfReTime
    Green's Function in time.

    mesh:       MeshReTime
    Omega grid.

    eta:        float
    Lorentzian broadening used in the Fourier transform.

    doSimps:    bool
    If true, use Simpson rule for integration otherwise trapz.
    Simpson rule can give wrong results if dt is too large while trapz is more
    stable.

    Returns
    -------
    Gw          BlockGf of GfReFreq:
    Fourier Transform of G(t).
    """
    if isinstance(Gt, BlockGf):
        return map_block(lambda gt: FourierTransform(gt, mesh, eta, doSimps), Gt)

    t = getX(Gt.mesh)
    w = getX(mesh)

    integral = integrate.simps if doSimps else integrate.trapz
    phase = np.exp(1j * w[:, np.newaxis] * t - eta * np.abs(t))
    if Gt.data.ndim == 3:  # FIXME: this is a bad check
        phase = phase[..., np.newaxis, np.newaxis]
    integrand = Gt.data * phase

    Gw = Gf(mesh=mesh, target_shape=Gt.target_shape)
    Gw.data[:] = integral(integrand, x=t, axis=1)

    return Gw


def ReconstructDelta(bath: Bath, mesh: Union[MeshReFreq, MeshImFreq], eta: float):
    """Calculates the hybridization function from a given discrete bath. Can
        be used either for real- or imaginary freqencies. For real-freqencies,
        the delta-peaks are broadened by a lorenzian of width eta.

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    mesh:   MeshReFreq or MeshImFreq
    Freqency mesh on which hybridization function is computed.

    eta:    float
    Lorentzian broadening used in the reconstruction. Must be (close to) zero for imaginary frequencies.

    Returns
    -------
    Delta:  BlockGf of GfReFreq
    Hybridization function of the bath parameters broadened by eta.
    """

    if isinstance(mesh, MeshImTime) or isinstance(mesh, MeshReTime):
        raise RuntimeError(
            "ReconstructDelta does not work with real or imag time meshes."
        )
    if isinstance(mesh, MeshImFreq) and np.abs(eta) > 1e-15:
        raise RuntimeError(
            "ReconstructDelta: imaginary frequency mesh does not need any broadening!"
        )

    Gre = BlockGf(mesh=mesh, gf_struct=bath.gf_struct)
    for name, gre in Gre:
        Norbs = gre.target_shape[0]
        amp = np.zeros((Norbs, Norbs), dtype=np.complex128)

        # loop over each bath site defined by ik and k
        for ik in range(Norbs):
            I = [name, ik]
            for k in range(bath.NBath(I)):
                eps = bath.eps(I, k)

                # loop over matrix indices in block
                for i, j in itertools.product(list(range(Norbs)), list(range(Norbs))):
                    amp[i, j] = bath.V(I, [name, i], k) * np.conj(
                        bath.V(I, [name, j], k)
                    )

                for w_ in Gre.mesh:
                    gre[w_][:, :] += amp / (w_ - eps + 1j * eta)

    return Gre


def GSSectorH0(bath: Bath, hloc: Hloc):
    """Calculates the ground state particle number sector of each block for a non-interacting
    Anderson Impurity Model defined by bath and hloc.

    Parameters
    ----------
    bath:       Bath
    Bath object providing the bath parameters.

    hloc:       Hloc
    Impurity on-site energies.

    Returns
    -------
    partNums:   dict
    Ground state particle number sector of each block
    """

    partNums = {}

    for name, _ in bath.gf_struct:
        H = fillH0(bath, hloc, name)
        D, _ = np.linalg.eigh(H)

        partNums[name] = sum(D <= 0)

    return partNums


def GSEnergyH0(bath: Bath, hloc: Hloc):
    """Calculates the ground state energy each block for a non-interacting
    Anderson Impurity Model defined by bath and hloc.

    Parameters
    ----------
    bath:       Bath
    Bath object providing the bath parameters.

    hloc:       Hloc
    Impurity on-site energies.

    Returns
    -------
    energies:   dict
    Ground state energy of each block"""
    energies = {}
    for name, _ in bath.gf_struct:
        H = fillH0(bath, hloc, name)
        D, _ = np.linalg.eigh(H)

        energies[name] = sum(D[D <= 0])
    return energies


def fillH0(bath: Bath, hloc: Hloc, name: str):
    """
    Calculates the hopping matrix hij ( H = c_i^dag * hij * cj) in the block defined by name
    for a non-interacting Anderson Impurity Model with a bath given by bath and a local hamiltonian on the impurity hloc.


    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    name:   string
    Name of the block.

    Returns
    -------
    H:      2-d numpy array
    Single particle hamiltonian matrix.
    """
    Norbs = bath.blockSize(name)
    NBathTot = 0
    for i in range(Norbs):
        NBathTot += bath.NBath([name, i])

    H = np.zeros((NBathTot + Norbs, NBathTot + Norbs), dtype=np.complex128)

    # hybridizations
    offset = Norbs
    for i in range(Norbs):
        I = [name, i]
        for k in range(bath.NBath(I)):
            for j in range(Norbs):
                H[j, offset + k] = bath.V(I, [name, j], k)
        offset += bath.NBath(I)

    H += H.conj().T

    # on-site energies of bath
    offset = Norbs
    for i in range(Norbs):
        I = [name, i]
        for k in range(bath.NBath(I)):
            diag = offset + k
            H[diag, diag] = bath.eps([name, i], k)
        offset += bath.NBath(I)

    # impurity H0
    for i, j in itertools.product(list(range(Norbs)), list(range(Norbs))):
        H[i, j] = hloc([name, i], [name, j])
    return H


def CalcGgr(bath: Bath, hloc: Hloc, mesh: MeshReTime):
    """Calculates the impurity greater Greens function for a non-interacting
    Anderson Impurity Model with bath bath and local hamiltonian on the impurity hloc.
    Because TRIQS has currently no zero temperature imaginary time mesh implemented,
    the resulting Green's functions are a bit awkward and have to be understood in
    the following way:
    G>(tau) as well as G<(tau) are formally defined on the interval [0, inf]. To
    obtain the time ordered imaginary time GF G_t one has to use G>(tau) for positve
    times and -G<(-tau) for negative times, i.e.
    G_t = G>(tau) Theta(tau>0) - G<(-t)*Theta(tau<0)

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    mesh:   MeshReTime or MeshImTime
    Time mesh at which Green's function is calculated.

    Returns
    -------
    Ggr:    BlockGf of GfReTime
    Greater Green's function G>(t)"""

    if not isinstance(mesh, MeshReTime) and not isinstance(mesh, MeshImTime):
        raise RuntimeError("Only real or imaginary time grids allowed!")

    G = BlockGf(gf_struct=bath.gf_struct, mesh=mesh)

    for name, ggr in G:
        Norbs = ggr.target_shape[0]

        H = fillH0(bath, hloc, name)
        D, V = np.linalg.eigh(H)
        Vdag = np.conj(V.transpose())

        Np = sum(D <= 0)

        # real-time evolution add 1j to energies
        if isinstance(mesh, MeshReTime):
            D = 1j * D

        for t in mesh:
            expon = np.exp(-t.value * D)
            expon[:Np] = 0  # can only create a particle out of fermi sea

            mat = np.dot(V, np.dot(np.diag(expon), Vdag))
            ggr.data[t.linear_index][:, :] = mat[:Norbs, :Norbs]
    return G


def CalcGle(bath: Bath, hloc: Hloc, mesh: MeshReTime):
    """Calculates the impurity lesser Greens function for a non-interacting
    Anderson Impurity Model with bath bath and local hamiltonian on the impurity hloc.
    Because TRIQS has currently no zero temperature imaginary time mesh implemented,
    the resulting Green's functions are a bit awkward and have to be understood in
    the following way.
    G>(tau) as well as G<(tau) are formally defined on the interval [0, inf]. To
    obtain the time ordered imaginary time GF G_t one has to use G>(tau) for positve
    times and -G<(-tau) for negative times, i.e.
    G_t = G>(tau) Theta(tau>0) - G<(-t)*Theta(tau<0)

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    mesh:   MeshReTime or MeshImTime
    Time mesh for which Green's function is calculated.

    Returns
    -------
    Gle:    BlockGf of GfReTime
    Lesser Green's function G<(t)"""

    # G<_ij = < FS| c_j^\dag c_i(t) |FS > ... note order of j and i
    # using the usual transformations: c_i = U_ik c_k, c_j^\dag = (U^\dag)_kj c_k^\dag
    # we find after some algebra:
    # G<_ij(t) = (U^*)_jk U_ik e^{-i t e_k} \Theta(k in FS) ... or
    #
    # this is what we implement:
    # ---------------------------------------------------------------------
    # G<_ij(t) = \sum_{k,k'} U_{ik} D_{kk'} (U^\dag)_{k'j} \Theta(k in FS)
    # ---------------------------------------------------------------------
    #
    # with D_{k,k'} = e^{-i t e_k} \delta_{k,k'}
    if not isinstance(mesh, MeshReTime) and not isinstance(mesh, MeshImTime):
        raise RuntimeError("Only real or imaginary time grids allowed!")

    G = BlockGf(gf_struct=bath.gf_struct, mesh=mesh)

    for name, gle in G:
        Norbs = gle.target_shape[0]

        H = fillH0(bath, hloc, name)

        D, V = np.linalg.eigh(H)
        Vdag = np.conj(V.transpose())

        Np = sum(D <= 0)

        # real-time evolution add -1j to energies, for imaginary time D = -D
        if isinstance(mesh, MeshReTime):
            D = 1j * D
        else:
            D = -D

        for t in mesh:
            expon = np.exp(-t.value * D)
            # can only create a particle out of fermi sea ... problem is exp(0) = 1
            expon[Np:] = 0

            mat = np.dot(V, np.dot(np.diag(expon), Vdag))
            gle.data[t.linear_index][:, :] = mat[:Norbs, :Norbs]
    return G


def CalcN(bath: Bath, hloc: Hloc, mesh: MeshReTime):
    """Calculates the denisty-density Greens function for a non-interacting
    Anderson Impurity Model with bath bath and local hamiltonian on the impurity hloc.

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    mesh:   MeshReTime or MeshImTime
    Time mesh at which Green's function is calculated.

    Returns
    -------
    N:      GfReTime
    Density-Density correlation function <n(t)n>"""

    # density-density GF does not respect block structure not even in the
    # non-interacting case.
    # Since all other properties respect the block structure, the index management of
    # this function is a bit awkward. When looping over indices bI or bJ refers to
    # an index of some block and i or j to an index in the matrix-structure
    # of the resulting density-density green's function (for 3-orbitals with
    # the usual up-down block structure the density-denstiy correlation would be
    # a 6x6 matrix)
    # Analyticall the non-interacting density-density GF is given by:
    # N_ij(t) = <n_i(t) n_j> = ... =
    #      = f_i * f_j + \sum_{k, k'} U_{jk'}^* U_{ik'} U_{ik}^* U_{jk} \Theta(k>kf)
    #        \Theta(k'<kf) e^{ -i t (eps_k - eps_k') }
    #
    # where the first term is time independent with f_i = \sum_{k in FS} |U_{ik}|^2
    # and the second term determines the time dependence showing oscillations with
    # a frequency of eps_k - eps_k'.
    # The matrix U_{ik} is the single-particle transformation that diagonalizes the
    # non-interacting problem:
    # H = \sum_ij c_i^dag T_ij c_j, with T_ij = \sum_k U_{ik} eps_k (U^dag)_kj

    def convI(name, bI):
        # converts the index from block-structure to density-density GF
        return bath.blockToFTPSIndx([name, bI]) - 1

    if not isinstance(mesh, MeshReTime) and not isinstance(mesh, MeshImTime):
        raise RuntimeError("Only real or imaginary time grids allowed!")

    NArms = bath.NArms
    Norbs = NArms // 2
    N = GfReTime(target_shape=[NArms, NArms], mesh=mesh)

    for name in bath.blockNames:
        H = fillH0(bath, hloc, name)

        D, V = np.linalg.eigh(H)
        Vdag = np.conj(V.transpose())

        Np = sum(D <= 0)

        # first calculate the constant term
        f = np.zeros(Norbs)
        for bI in range(Norbs):
            for k in range(Np):
                f[bI] += abs(V[bI, k]) ** 2

        constTerm = np.zeros((Norbs, Norbs))
        for bI, bJ in product(range(Norbs), range(Norbs)):
            constTerm[bI, bJ] = f[bI] * f[bJ]

        if isinstance(mesh, MeshReTime):
            D = 1j * D

        # then time dependent term
        # inefficient but it does not matter much
        for t in mesh:
            for bI, bJ in product(range(Norbs), range(Norbs)):
                val = constTerm[bI, bJ]
                for k, kp in product(range(Np, H.shape[0]), range(Np)):
                    # k < FS, kp in FS
                    temp = V[bJ, kp].conjugate() * V[bI, kp]
                    temp *= V[bI, k].conjugate() * V[bJ, k]
                    temp *= np.exp(-(D[k] - D[kp]) * t.value)

                    val += temp
                if len(bath.blockNames) == 2:
                    N.data[t.linear_index, convI(name, bI), convI(name, bJ)] = val
                else:
                    N.data[t.linear_index, bI, bJ] = val

    # now the block-offdiagonal terms are not yet set. They are simply the
    # product of the corresponding occupations
    if len(bath.blockNames) > 1:
        Occs = CalcOccs(bath, hloc)
        for nameI, nameJ in product(bath.blockNames, bath.blockNames):
            # only want block off-diag
            if nameI == nameJ:
                continue

            for bI, bJ in product(
                range(bath.blockSize(nameI)), range(bath.blockSize(nameJ))
            ):
                nI = Occs[nameI][bI, bI]
                nJ = Occs[nameJ][bJ, bJ]

                N.data[:, convI(nameI, bI), convI(nameJ, bJ)] = nI * nJ

    return N


def CalcOccs(bath: Bath, hloc: Hloc):
    """Calculates the impurity single-particle density matrix for a non-interacting
    Anderson Impurity Model with bath bath and local hamiltonian on the impurity hloc.

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    Returns
    -------
    Occ:    dict
    Single particle density matrix."""

    Occs = {}
    Norbs = bath.NArms // 2
    for name in bath.blockNames:

        Occs[name] = np.zeros((Norbs, Norbs), dtype=np.complex128)

        H = fillH0(bath, hloc, name)
        D, V = np.linalg.eigh(H)
        Vdag = np.conj(V.transpose())

        Np = sum(D <= 0)

        # dirty step function
        expon = np.exp(0 * D)
        expon[Np:] = 0
        mat = V @ np.diag(expon) @ Vdag

        Occs[name] = mat[:Norbs, :Norbs]

    return Occs


def SigmaDyson(
    Gret: GfReTime,
    bath: Bath,
    hloc: Hloc,
    mesh: MeshReFreq,
    eta: float,
    symmG: Callable[[GfReFreq], GfReFreq] = None,
    integrator: str = "exp",
):
    """Calculates the self energy using the Dyson Equation using the discrete
    bath for the non-interacting Green's function.

    Parameters
    ----------
    Gret:   BlockGf of GfReTime
    Retarded Green's function in time.

    bath:   Bath
    Bath object providing the bath parameters.

    hloc:   Hloc
    Impurity on-site energies.

    mesh:   MeshReFreq
    Frequency mesh at which Sigma is calculated.

    eta:    float
    Lorentzian broadening used in the Fourier transform and for the discrete bath.

    symmG:  Callable, default = None
    Function that will be applied to G(ω) and Δ(ω) to symmetrize it. The
    function must take a single Triqs Block Green function and return
    the symmetrized version of it.
    
    doSimps: bool, default = False
    whether to use Simpson rule for integration in Fourier transform.


    Returns
    -------
    Sigma:  BlockGf
    Real frequency Self Energy.
    """
    if integrator not in ["simps", "trapz"]:
        G_w = FourierExpEven(Gt=Gret, mesh=mesh, eta=eta)
    else:
        G_w = FourierTransform(eta=eta, Gt=Gret, mesh=mesh, doSimps= (integrator == "simps"))
    DeltaRe = bath.reconstructDelta(mesh, eta)

    if symmG is not None:
        G_w = symmG(G_w)
        DeltaRe = symmG(DeltaRe)

    G0inv = BlockGf(mesh=mesh, gf_struct=MakeGFstruct(Gret))
    for name, g in G0inv:
        g << Omega - hloc.e[name] - DeltaRe[name] #+ 1j * eta

    return G0inv - inverse(G_w)


def SigmaFG(Gret: GfReTime, Fret: GfReTime, mesh: MeshReFreq, eta: float):
    """Calculates the self energy using the self-energy trick -F/G.

    Parameters
    ----------
    Gret    BlockGF of GfReTime
    Retarded single particle Green's function in time.

    Fret    BlockGF of GfReTime
    Retarded Green's function < {[Hint, c](t), cdag} > in time.

    mesh    MeshReFreq
    Frequency mesh at which Sigma is calculated.

    eta     float
    Lorentzian broadening used in the Fourier transform.

    Returns
    -------
    Sigma   BlockGf of GfReFreq
    Real frequency Self Energy."""

    G_w = FourierTransform(eta=eta, Gt=Gret, mesh=mesh)
    F_w = FourierTransform(eta=eta, Gt=Fret, mesh=mesh)

    return -F_w * inverse(G_w)


def TimeStepEstimation(bath: Bath, eta: float, dt: float):
    """Gives a reasonable number of time steps for a given bath, desired energy
        resolution and time step size. This function is intended to get a quick
        value for the number of time steps and does not allow you to underbroaden.
        It will raise an error if the desired resolution is much smaller than
        what the bath can resolve.

    Parameters
    ----------
    bath:   Bath
    Bath object providing the bath parameters.

    eta:    float
    Desired energy resolution should not be less than bath energy separation.

    dt:     float
    Time step size.


    Returns
    -------
    Nt:     int
    Reasonable number of time steps to achieve desired energy resolution."""

    Max_MinDeps = 0  # maximum over all bands of minimum deltaEpsilon
    MaxBandw = 0
    # do not time evolve up to max time, but a little less.
    fraction = 0.9

    for name in bath.blockNames:
        for i in range(bath.blockSize(name)):
            indx = [name, i]

            Nb = bath.NBath(indx)
            bandw = bath.eps(indx, Nb - 1) - bath.eps(indx, 0)
            MaxBandw = max(bandw, MaxBandw)

            # take average, because there might be small fluctuations
            minDeps = 1000
            for k in range(1, bath.NBath(indx)):
                deps = bath.eps(indx, k) - bath.eps(indx, k - 1)
                minDeps = min(minDeps, deps)

            Max_MinDeps = max(minDeps, Max_MinDeps)

    # if eta < Max_MinDeps*0.7:
    #    raise RuntimeError(f'Desired energy resolution {eta:.4f} much smaller than bath discretization {Max_MinDeps:.4f}. In case this is what you want to do, set number of time steps by hand to π/eta.')

    if eta < Max_MinDeps:
        mpi.report(
            f"Warning: Desired energy resolution: {eta:.4f} is smaller than bath discretization: {Max_MinDeps:.4f}. Result might show finite size effects."
        )
        mpi.report(
            f"Maximum bandwidth of bath was {MaxBandw:.4f} so to reach the desired resolution ~{int(MaxBandw//eta)} bath sites would be needed (assuming no gap in the bath spectrum)."
        )

    tmax = fraction * 2 * np.pi / eta

    # Note the factor of two, because FTPS computes time evolution two sided (on bra- and ket vector)
    return int(tmax / (2 * dt))


# def LinLogDiscretizeBath(Delta, N_linTot, N_logTot, LogWidth=1, SO=False, err = 0.01):
#     """ Discretizes the bath hybridization Delta using Nb bath sites.

#         Parameters
#         ----------
#         Delta (blockGF of GfReFreq) : Hybridization function to be discretized.

#         Nb (int): Number of bath sites used in the discretization.

#         err (float, default 0.01): Neglected fraction of the spectral function of the hybridization, due
#                                    to restricing the discretization interval to the most important region.

#         SO (bool, default False) : Flag indicating whether the bath is for a Spin-orbit calculation.

#         wInterval (dict): Energy intervals for the discretization. Note that depending on wheter the hybridization is diagonal or off-diagonal,
#                           wInterval has a different shape (see description of DiscretizeDiagBath() and __DiscretizeDiag()). If None intervals are determined automatically.

#         PlaceAt (dict) : Energy positions at which the discretization has to place a bath site. One value must be specified for each orbtial. For example in a two-orbital problem with two blocks "up" and "dn" PlaceAt
#                          could look like this: PlaceAt ={ "up" : [0.3,0.25] , "dn" : [0,-0.2] } and would place a bath site at energy 0.3 in the first orbital of block 'up' etc. If None, bath sites are placed on a linear grid. Only works for diagonal baths, since for off-diagonal baths the
#                          bath sites are coupled.
#         Returns
#         -------
#         bath (bath):
#             Bath object storing the bath parameters. """

#     print('---------------------------------------------------------------------------')
#     print('---------------------------------------------------------------------------')
#     print('---------------------------------------------------------------------------')
#     print('--- Warning this function currently performs two linear discretizations ---')
#     print('---------------------------------------------------------------------------')
#     print('---------------------------------------------------------------------------')
#     print('---------------------------------------------------------------------------')


#     if not isinstance(Delta, BlockGf):
#         raise TypeError("Argument must be a TRIQS BlockGf.")


#     #figure out whether Delta is off-diagonal or not
#     isOffdiag = False
#     for name, delta in Delta:
#         inds = list(range(delta.target_shape[0]))
#         for i,j in itertools.product( inds, inds ):
#             if(i==j):
#                 continue
#             if(np.max( np.abs(delta.data[:,i,j])) > 1E-15):
#                 isOffdiag = True
#                 break

#     if(isOffdiag):
#         raise RuntimeError('Off-diag bath not implemented for LinLog discretization.')

#     #if( N_logTot % 2 != 0 ):
#         #raise RuntimeError('NBathLog must be even.')


#     #create GF struct and initialize empty bath with it
#     bath = ftps.solver_core.Bath(  MakeGFstruct(Delta), SO )

#     for name, delta in Delta:
#         SpecMat = 1j/(2*np.pi)*( delta-conjugate(transpose(delta)))
#         Norbs = SpecMat.target_shape[0]

#         for i in range(Norbs):
#             spec = SpecMat[i,i]
#             wmin, wmax = __DiscretizationRange(spec, err)
#             if(wmin > - LogWidth or wmax < LogWidth):
#                 raise RuntimeError('Integration bounds are inside Logarythic discretization range')

#             L_linBelow = -LogWidth - wmin
#             L_linAbove = wmax - LogWidth

#             N_linBelow = int( np.round( N_linTot*(L_linBelow/(L_linBelow+L_linAbove))) )
#             N_linAbove = N_linTot - N_linBelow

#             ISize_linBelow = L_linBelow/N_linBelow
#             ISize_linAbove = L_linAbove/N_linAbove


#             # prepare discretization
#             offset = wmin
#             intW, intDel = __IntegrationArrays(spec, offset)
#             lastInt = np.trapz(x=intW, y = intDel, axis=0 )


#             for indx in range(N_linBelow):
#                 bath, offset, lastInt = __AddBathSite(bath, spec, Norbs, offset, ISize_linBelow, lastInt, name, i )

#             ISizeLog = float(2*LogWidth)/N_logTot
#             for indx in range(N_logTot):
#                 bath, offset, lastInt = __AddBathSite(bath, spec, Norbs, offset, ISizeLog, lastInt, name, i )


#             offset = LogWidth
#             intW, intDel = __IntegrationArrays(spec, offset)
#             lastInt = np.trapz(x=intW, y = intDel, axis=0 )

#             for indx in range(N_linAbove):
#                 bath, offset, lastInt = __AddBathSite(bath, spec, Norbs, offset, ISize_linAbove, lastInt, name, i )
#     return bath


# def KramersKronig_Im2Re( fIm, ω ):
#     fRe = np.zeros( len(fIm), dtype = np.float128 )

#     for om,indx in zip( ω, range(len(ω))) :

#         omInt = ω[ω!=om]
#         fImInt = fIm[ω!=om]

#         fRe[indx] = -1/np.pi*np.trapz(x=omInt, y = fImInt/(om-omInt))


#     return fRe


# class BathFitter:
#     """
#     Finds the best fit bath parameters of a broadened hybridization function
#     broadened by eta.
#     Best fit bath parameters are defined as the best hybridizations Vk
#     for energies ek defined in the smallest energy interval possible that
#     represent the hybridization well.
#     Roughly speaking it does that in a three step process:

#     1.  For a given energy interval (ek also given), it findes the best-fit Vk
#         by minimizing | E * V**2 - hyb |, where the matrix E is given by
#         E_{ik} = 1./(w_i - ek + 1j*eta), V**2 is the vector of squared
#         hybridizations V**2_k = Vk**2 and hyb is the vectorized hybridization
#         function that is supposed to be fitted.

#     2.  Make the interval smaller and see if the fit is still good enough.

#     3.  Based on the intervals and fit errors computed that way decide on the
#         best-fit interval.


#     Attributes
#     -----------
#     Nb      int
#     Number of bath sites

#     eta     float
#     Broadening used

#     step    float
#     Step size used to determine best-fit interval.

#     result  dict
#     Container with FitResult objects, one for each block/index and interval of the hybridization.

#     bath:   Bath
#     Bath object storing the bath parameters.
#     """
#     def __init__(self, Nb: int):
#         self.Nb     = Nb
#         self.eta    = None
#         self.step   = None
#         self.result = None
#         self.bath   = None

#     def FitBath(self, Delta: BlockGf, eta: float, step: Union[float,None] = None):
#         """
#         Finds the best fit bath parameters for hybridization Delta using Nb bath
#         sites assuming that Delta was artificially broadened by eta.
#         Best fit is defined as the smallest interval in which the fitted bath
#         parameters reproduce Delta.

#         Parameters
#         ----------
#         Delta:      GfReFreq
#         Broadened bath hybridization function to fit.

#         eta:        float
#         Broadening used for spec.

#         step:       float
#         Step size of interval values used for fitting.

#         Returns
#         ----------
#         bath:       Bath
#         Bath object storing the bath parameters.
#         """

#         #Things to improve / still to do:
#         #---------------------------------
#         #
#         #  Think about if using the slope is necessary for small Nb the slope seems
#         #  to be a much sharper diagnostic than the error (as a function of interval size)
#         #
#         #  add checks
#         #
#         #  remove double appearing limts

#         self.eta = eta
#         self.step = eta/8. if step is None else step


#         if eta < Delta.mesh.delta:
#             print('eta = %f, Δω = %f'%(eta, Delta.mesh.delta) )
#             raise ValueError('Broadening eta cannot be smaller than ω-mesh discretization')

#         if(IsOffDiag(Delta)):
#             raise RuntimeError('Off-diagonal Delta is not implemented in fit discretization.')

#         self.result = {}
#         self.bath = Bath(MakeGFstruct(Delta), SO = False)


#         for name, delta in Delta:
#             self.result[name] = np.empty( delta.target_shape[0], dtype =  FitResult)

#             specMat = 1j/(2.)*( delta-conjugate(transpose(delta))) # no factor pi here

#             for bIndx, [_, self._spec] in enumerate( GFDiag(specMat) ):
#                 print('\n\nOptimizing block %s index %i\n'%(name,bIndx) )

#                 # get a first rough guess for the interval via the area of spec
#                 self._areaGuess()

#                 # find all non-zero V intervals
#                 self._intervalFinder()


#                 self.result[name][bIndx] = []
#                 for self._currentIndx, self._currentI in enumerate(self._Intervals):
#                     print('  Optimizing interval %i'%(self._currentIndx+1))
#                     self._limits, self._errors, self._slopes = {}, {}, {}
#                     for self._silent in [False]:
#                         for self._mode in Interval.keys():
#                             self._findFitLimit()

#                     # store result
#                     self.result[name][bIndx].append( FitResult(self._limits, self._errors, self._slopes, self._currentI) )

#                 # best interval found, compute parameters and put into bath
#                 self._finishOrb(name, bIndx)

#         return self.bath


#     def _areaGuess(self):
#         """Makes a rough guess of the best-fit interval based on the area of spec."""

#         I = OuterDiscrBoundaries( self._spec, 1E-2 )
#         #self._Intervals = [ {'lower' : I[0], 'upper' : I[1]}]
#         self._Intervals = [ Interval(I[0], I[1]) ]


#     def _intervalFinder(self):
#         """ Finds all energy intervals with non-zero hybridization V.
#             The purpose of is two-fold:
#             First it improves the guess interval from _areadGuess.
#             Second, it can also find gaps in the spectrum.
#             It does that not with the bath size provided but with an optimized one."""

#         # change bath size to an optimal value
#         actualNb = self.Nb
#         L = self._Intervals[0]['upper'] - self._Intervals[-1]['lower'] # total length of discretization interval

#         self.Nb = int(round(L/self.eta*1.2)) # factor 1.2 do decrease oscillations

#         Vsq, eps = self._minimize(recordResult=False)
#         Vsq[ Vsq < 0.001*max(Vsq) ] = 0 # set small Vsq to 0 they cause trouble in DMRG
#         isNonZero = np.asarray(Vsq>0) # np.asarray returns a tuple hence [0]


#         deps = eps[1]-eps[0]
#         self._Intervals = []
#         inInterval = False
#         countFalse = 0

#         for i, nz in enumerate(isNonZero):
#             if nz == True and inInterval == False:
#                 inInterval = True
#                 countFalse = 0
#                 #start interval
#                 self._Intervals.append( Interval(eps[i]-deps/2., None) )

#             elif nz == False and inInterval == True:
#                 if countFalse < 2:
#                     # demand 2 consective False before ending interval
#                     countFalse += 1
#                     continue

#                 inInterval = False
#                 # finish interval
#                 self._Intervals[-1]['upper'] = eps[i-1]+deps/2.

#         # finish interval if still open
#         if inInterval:
#             self._Intervals[-1]['upper'] = eps[-1]+deps/2.


#         # reset Nb
#         self.Nb = actualNb

#         print( 'Rough guess found %i interval(s):'%len(self._Intervals))
#         for I in self._Intervals:
#             print('  ',I)


#     def _finishOrb(self, name, indx):
#         """
#         After best-fit interval is found, this function computes the bath
#         parameters and adds these entries to the Bath into the block *name*
#         with index *indx*.
#         """
#         Norbs = self.bath.NArms//2

#         # get Best bath parameters
#         Vsq, eps = self._minimize(recordResult=False)

#         assert all(Vsq>=0)

#         for e, vsq in zip(eps, Vsq):
#             V = np.zeros( (Norbs) , dtype = np.complex128)
#             V[indx] = np.sqrt(vsq)

#             self.bath.addSite( [name, indx], e, V )

#         # check that fit fitted a smooth function and not only lorenzian pekas
#         if(eps[1]-eps[0] > 2*self.eta):
#             print('\n\n Warning, fit resulted in energy discretization that is very large (%.3f) compared to the broadening (%.3f).'%(eps[1]-eps[0], self.eta) +
#                 ' A sum of sharp lorenzian peaks was fitted instead of a smooth function. Please check the result, as this can cause problems!\n\n')


#     def _findFitLimit(self):
#         """
#         Finds the smallest fit interval that gives an accurate fit by varying
#         only either the upper or the lower limit as defined by self._mode.
#         """

#         m = self._mode
#         if m is not 'lower' and m is not 'upper':
#             raise ValueError('Invalid value of mode: %s. Mode can only be lower or upper.'%mode)

#         if not self._silent:
#             print('  Fitting %s limit:\n  ----------------------'%m)

#         self._limits[m] = np.empty(0, dtype=np.float64)
#         self._errors[m] = np.empty(0, dtype=np.float64)
#         self._slopes[m] = np.empty(0, dtype=np.float64)


#         fineSearch = self._coarseSearch()

#         # fine search
#         if not self._silent:
#             print("  Evaluating Fit on a finer grid, doing %i steps with size %.3f in [%.3f, %.3f]"
#                      %(len(fineSearch), self.step, fineSearch[0], fineSearch[-1]))

#         for limit in fineSearch:
#             self._currentI[m] = limit
#             self._minimize()

#         # based on the coarse and fine search, find the optimal interval size
#         # using the slope of the errors
#         self._slopeCriteria()

#         if not self._silent:
#             print('  Finished fit of limit %s, result: '%m, self._currentI[m])


#     def _minimize(self, recordResult = True):
#         """
#         Performs the actual fit of finding the best V**2 parameters using the
#         current interval (self._currentI) for the energies ek which are simply
#         linearly spaced.
#         The minimization is restricted to positiv V**2 only.

#         Returns
#         ----------
#         Vsq:        numpy array of floats
#         Squared bath parameters V**2.

#         eps:        numpy array of floats
#         Vector of energies.
#         """
#         #Problem data.
#         E, hyb, eps = self._fitProperties()

#         # fit function that respects Vsq > 0

#         Vsq, err = optimize.nnls(E, hyb)

#         if recordResult:
#             m = self._mode
#             self._errors[m] = np.append(self._errors[m], err)
#             self._limits[m] = np.append(self._limits[m], self._currentI[m])

#         return Vsq, eps

#     def _fitProperties(self):
#         """
#         Computes the quantities needed for the minimization.
#         The bath fitting problem is given by min_{Vsq} | E * V** - hyb |^2, with
#         E_{ik} = 1./(w_i - ek + 1j*eta), V**2 is the vector of squared hybridizations
#         V**2_k = Vk**2 and hyb is the vectorized hybridization function.

#         Returns
#         ----------
#         E:          numpy array of floats
#         Fit matrix E.

#         hyb:        numpy array of floats
#         Fit vector spec (just the data of spec).

#         eps:        numpy array of floats
#         Vector of energies used to compute E.
#         """

#         Nbs = IntervalBathSizes(self._Intervals, self.Nb)
#         eps = np.zeros(0)

#         for Nb, I in zip(Nbs, self._Intervals):
#             deps = I.length()/Nb
#             eps = np.append(eps, np.linspace(I['lower']+deps/2., I['upper']-deps/2., Nb))


#         w = getX(self._spec.mesh) + 1j*self.eta

#         E = -1./np.subtract.outer(w, eps)

#         return E.imag, self._spec.real.data, eps


#     def _coarseSearch(self):
#         """
#         Perfors a coarse search of interval limits and stops when the fit gets
#         much worse.

#         Returns
#         ----------
#         fineSearch      numpy array of float
#         Array of limits which should be searched next based on the result of this function.
#         """
#         m = self._mode
#         sign = -1 if m == 'upper' else 1

#         # accuracy is used so that the algorithm doesnt stop when finding a minimum caused by "random" fluctuations in the fit quality
#         accuracy = 1E-2 * np.abs( np.trapz( getX(self._spec.mesh), self._spec.data ) )
#         counter = 0 # increases when fit gets worse, terminate when counter reaches a fixed number (3 currently)

#         #step size
#         CoarseStep = self._currentI.length()*self.eta/4.

#         self._setStartPoint(CoarseStep)

#         while counter < 6:
#             self._minimize()
#             err = self._errors[m][-1]
#             if not self._silent:
#                 print( '  Discretization limit %.5f: sqared error = %.5f'%( self._currentI[m], err) )

#             if len(self._errors[m]) is 1:
#                 bestLimit = self._limits[m][-1]
#                 minErr = err
#             else:
#                 diff = minErr - err

#                 if diff>0 or np.abs(diff) < accuracy:
#                     # fit got better or only slightly worse
#                     counter = 0
#                     # bestWl is always the smallest one that gives good results
#                     bestLimit, minErr = self._currentI[m], min(minErr, err)
#                 else:
#                     # fit got worse
#                     counter += 1

#             self._currentI[m] += sign*CoarseStep

#         # evaluate on a finer grid around bestWl
#         Nx = int(round(2*CoarseStep/self.step))
#         Nx = Nx+Nx%2 # Nx must be odd otherwise compute center twice


#         xmin = bestLimit - CoarseStep + self.step/2 # avoid starting exactly at points already calculated
#         xmax = bestLimit + CoarseStep - self.step/2


#         return np.linspace(xmin, xmax, Nx)

#     def _setStartPoint(self, CoarseStep):
#         m = self._mode
#         i = self._currentIndx
#         I = self._currentI

#         if m == 'upper':
#             if i == len(self._Intervals)-1:
#                 #last interval
#                 I[m] += CoarseStep
#             else:
#                 Idistance = self._Intervals[i+1]['lower'] - I['upper']
#                 I[m] += min(CoarseStep, Idistance/2.) # in between two intervals
#         else:
#             if i == 0:
#                 #first interval one step back
#                 I[m] -= CoarseStep
#             else:
#                 Idistance = I['lower'] - self._Intervals[i-1]['upper']
#                 I[m] -= min(CoarseStep, Idistance/2.)  # in between two intervals


#     def _slopeCriteria(self):
#         """
#         Based on the error as a function of interval limit, finds the best-fit
#         limit using the derivative of the error.
#         Around the best actual data point that was computed, a second order
#         polynomial is fitted to find the minimum of the derivative. This minimum
#         is then the best-fit limit.
#         """
#         m = self._mode

#         self._sortLimits()
#         self._computeSlope()

#         # find smallest index that has a slope close to the minimum slope
#         # cant directly take total minimum slope because for Nb large enough, slope gets flat if the interval is larger than what is needed
#         # also because of the same reason, cant take the first minimum slope, because for large Nb the slope gets flat and there is no clear minimum
#         goodSlope = np.abs(self._slopes[m])- min(np.abs(self._slopes[m])) < 1E-4
#         if m == 'upper':
#             # goodSlope is like [False, False, False, True ....]
#             # take the first True
#             bestI = np.argmax(goodSlope)
#         else:
#             # goodSlope might be like [True, False, True, True, False ....]
#             # take the last True
#             bestI = [i for i,s in enumerate(goodSlope) if s == True][-1]

#         self._currentI[m] = self._limits[m][bestI]
#         #xfit, yfit = self._limits[m][bestI-1:bestI+2], np.abs(self._slopes[m][bestI-1:bestI+2])
#         #fit = np.polyfit(xfit, yfit, 2)
#         #A, B = fit[0], fit[1]
#         #self._currentI[m] = -B/(2*A)

#         # add this last data point as well
#         #self._minimize()
#         #self._sortLimits()
#         #self._computeSlope()

#     def _sortLimits(self):
#         """ Sorts self._limits and self._errors """

#         #sort errors and limits
#         m = self._mode

#         sortedInds = np.argsort(self._limits[m])
#         self._limits[m] = np.array(self._limits[m])[sortedInds]
#         self._errors[m] = np.array(self._errors[m])[sortedInds]

#     def _computeSlope(self):
#         """ Computes the discrete derivative of self._errors """
#         def slope(lim, err, i):
#             return (err[i+1] - err[i-1])/(lim[i+1]-lim[i-1])

#         m = self._mode
#         lim = self._limits[m]
#         err = self._errors[m]

#         # minimum slope should not be at the edges of the arrays anyway
#         self._slopes[m] = np.array( [ slope(lim, err, i) for i in range(1,len(lim)-1) ] )

#         # insert dummy first and last entries to make slopes and limits the same length
#         self._slopes[m] = np.append(self._slopes[m][0], self._slopes[m])
#         self._slopes[m] = np.append(self._slopes[m], self._slopes[m][-1])


class fitBathImagSymResFilling:
    """
    fit the hybridyzation function on the imag axis
    the number of postive and negative poles on are restricted to ensure the correct filling
    the hopping- and on-site energies are varied by respecting the symmetry asigned

    for on-site potential, the grid is assigned as
    negative (valance): [-tv*lamV**0, -tv*lamV**1, -tv*lamV**2, ...., -tv*lamV**(Nv-1)]
    positive (conduction) : [tc*lamC**0, tc*lamC**1, tc*lamC**2, ...., tc*lamC**(Nc-1)]
    for each free elements, there are four free parameters , i.e., {tc, lamC} for conduction band
    and {tv, lamV} for valance band

    """

    def __init__(
        self,
        Delta=None,
        Nc=None,
        Nv=None,
        wlimt=None,
        SO=None,
        alpha=None,
        fitEps=None,
        vInfo=None,
        epsInfo=None,
        blockInfo=None,
        freeEleV=None,
        freeEleEps=None,
        freeBloc=2.0,
    ):
        self.Delta = Delta.copy()
        self.Nc = Nc
        self.Nv = Nv
        self.Nb = Nc + Nv
        self.wlimt = wlimt
        self.SO = SO
        self.alpha = alpha
        self.fitEps = fitEps
        self.vInfo = vInfo
        self.epsInfo = epsInfo
        self.blockInfo = blockInfo
        self.freeEleV = freeEleV
        self.freeEleEps = freeEleEps
        self.freeBlocks = freeBlocks
        self.blockNames = []
        self.blockSizes = {}
        self.DGrid = DGrid

        for name, g in self.Delta:
            self.blockNames.append(name)
            self.blockSizes[name] = g.target_shape[0]

        self.epsvec_tot = {}
        self.Vvec_tot = {}
        for name in self.blockNames:
            self.epsvec_tot[name] = np.zeros([4 * len(self.freeEleEps[name])])
            self.Vvec_tot[name] = np.zeros(
                [self.Nb * len(self.freeEleV[name])], dtype=complex
            )
        self.Vmat_tot = {}
        self.epsmat_tot = {}
        for name in self.blockNames:
            size = self.blockSizes[name]
            self.Vmat_tot[name] = np.zeros([self.Nb, size, size], dtype=complex)
            self.epsmat_tot[name] = np.zeros([self.Nb, size])

        if mpi.is_master_node():
            print(
                "fitting hybridization function on imaginary axis (restrict filling) with ",
                self.Nb,
                "bath sites for each orb\n",
                "@beta=",
                self.Delta.mesh.beta,
                ", in window = [",
                self.wlimt[0],
                ",",
                self.wlimt[1],
                "]",
                " and alpha=",
                self.alpha,
            )
            for name in self.freeBlocks:
                print(
                    "--- block ",
                    name,
                    " has ",
                    self.blockSizes[name],
                    " orbs, with ",
                    len(self.Vvec_tot[name]),
                    " free hopping params and ",
                    len(self.epsvec_tot[name]),
                    " on site energies",
                )

    def constructEpsGrid(self, tc, lamC, tv, lamV):
        energies = np.zeros([slef.Nb])
        positive = np.zeros([self.Nc])
        negative = np.zeros([self.Nv])
        for i in np.arange(self.Nc):
            positive[i] = tc * (lamC**i)
        for i in np.arange(self.Nv):
            negative[i] = -tv * (lamV**i)
        energies[: self.Nc] = positive[::-1]
        energies[self.Nc :] = negative[:]
        return energies


class fitBathImagSym:
    """
    fit the hybridization function on the imaginary time axis with symmetry constrains
    1.fit Delta block by block
    -----------
    parameters

    Delta  :: Block Green's function, the input hybridization function

    Nb :: #number of bath sites for each orbital

    symInfo_ :: contains the symmetry infomation of the hybridization function
                of block, e.g., symInfo[blockName][0] = {(0,0), (1,1), "E"} means that
                G[blockName][0,0] = G[blockName][1,1]
                currently, we have the following relation between the elements
                Equal ::  second = first
                mEqual :: second = -first
                Conj :: second = conj(firtt)
                mConj :: second = -conj(first)
                Complex :: second = 1j*first
                mComplex :: second = -1j*first
                Real :: second = real(first)
                mReal :: second = -real(first)
                Imag :: second = imag(first)
                mImag :: second = -imag(first)

    blockInfo_ :: defines the relation between the blocks of the input
                    Green's function
                    for example, [ "up", "dn", "Equal" ] means that "dn" is
                    equal to "up" block, hence only "up" block will be fitted
    """

    def __init__(
        self,
        Delta=None,
        Nb=None,
        wlimt=None,
        SO=None,
        alpha=None,
        fitEps=None,
        vInfo=None,
        epsInfo=None,
        blockInfo=None,
        freeEleV=None,
        freeEleEps=None,
        freeBlocks=None,
        DGrid=2.0,
    ):
        self.Delta = Delta.copy()
        self.Nb = Nb
        self.wlimt = wlimt
        self.SO = SO
        self.alpha = alpha
        self.fitEps = fitEps
        self.vInfo = vInfo
        self.epsInfo = epsInfo
        self.blockInfo = blockInfo
        self.freeEleV = freeEleV
        self.freeEleEps = freeEleEps
        self.freeBlocks = freeBlocks
        self.blockNames = []
        self.blockSizes = {}
        self.DGrid = DGrid

        for name, g in self.Delta:
            self.blockNames.append(name)
            self.blockSizes[name] = g.target_shape[0]

        self.epsvec_tot = {}
        self.Vvec_tot = {}
        for name in self.blockNames:
            self.epsvec_tot[name] = np.zeros([self.Nb * len(self.freeEleEps[name])])
            self.Vvec_tot[name] = np.zeros(
                [self.Nb * len(self.freeEleV[name])], dtype=complex
            )
        self.Vmat_tot = {}
        self.epsmat_tot = {}
        for name in self.blockNames:
            size = self.blockSizes[name]
            self.Vmat_tot[name] = np.zeros([self.Nb, size, size], dtype=complex)
            self.epsmat_tot[name] = np.zeros([self.Nb, size])

        if mpi.is_master_node():
            print(
                "fitting hybridization function on imaginary axis with ",
                self.Nb,
                "bath sites for each orb\n",
                "@beta=",
                self.Delta.mesh.beta,
                ", in window = [",
                self.wlimt[0],
                ",",
                self.wlimt[1],
                "]",
                " and alpha=",
                self.alpha,
            )
            for name in self.freeBlocks:
                print(
                    "--- block ",
                    name,
                    " has ",
                    self.blockSizes[name],
                    " orbs, with ",
                    len(self.Vvec_tot[name]),
                    " free hopping params and ",
                    len(self.epsvec_tot[name]),
                    " on site energies",
                )

    def costFunVSingle(self, vs_, eps_, wn_, data_):
        value_ = np.zeros(len(data_), dtype=complex)
        for ib in np.arange(self.Nb):
            value_ += vs_[ib] / (1j * wn_ - eps_[ib])
        return np.sqrt(
            np.real(np.sum(abs(value_ - data_) / abs(wn_) ** self.alpha))
            / float(len(data_))
        )

    def costFunEspSingle(self, eps_, v_, wn_, data_):
        value_ = np.zeros(len(data_), dtype=complex)
        for ib in np.arange(self.Nb):
            value_ += v_[ib] ** 2 / (1j * wn_ - eps_[ib])
        return lg.norm(
            (value_ - data_) / abs(wn_) ** self.alpha
        )  # np.sqrt( np.sum( abs(value_ - data_)/ abs(wn_)**self.alpha ) )/ float(len(data_))

    def costFunCombinedSingle(self, x_, wn_, data_):
        v_s = x_[: self.Nb].copy()
        eps_s = x_[self.Nb :].copy()
        value_ = np.zeros(len(data_), dtype=complex)
        for ib in np.arange(self.Nb):
            value_ += v_s[ib] ** 2 / (1j * wn_ - eps_s[ib])
        return np.sum( abs(value_ - data_)**2.0 / ( (abs(wn_)**self.alpha ) ) )/ float(len(data_))
        #np.sum( abs(value_ - data_)**2/ ( (abs(wn_)**self.alpha ) ) )
        #np.linalg.norm((value_ - data_) / (abs(wn_) ** self.alpha))  # / float(len(data_)) #np.sum( abs(value_ - data_)**2/ ( (abs(wn_)**self.alpha ) ) )#/ float(len(data_))#

    def fit(
        self,
        tolerance=1e-10,
        maxIte=10,
        stepSize=1.4901161193847656e-08,
        ftol=1e-06,
        method="SLSQP",
    ):
        """ """
        # initialize the parameters Vvcec and epsvec
        self.initialize_params_rand()
        offdiag = False
        for name in self.freeBlocks:
            # fit the diagonal ones first
            for ele in self.freeEleV[name]:
                if ele[0] != ele[1]:
                    offdiag = True
                if ele[0] == ele[1]:
                    v_ = np.zeros(self.Nb)
                    eps_ = np.zeros(self.Nb)
                    for ib in np.arange(self.Nb):
                        eps_[ib] = self.epsmat_tot[name][ib, ele[0]]
                        v_[ib] = np.real(self.Vmat_tot[name][ib, ele[0], ele[1]])
                    # prepare the target data
                    wn_ = getX(self.Delta.mesh)
                    data_ = self.Delta[name].data[:, ele[0], ele[1]].copy()
                    data_ = data_[
                        np.logical_and(wn_ > self.wlimt[0], wn_ < self.wlimt[1])
                    ]
                    wn_ = wn_[np.logical_and(wn_ > self.wlimt[0], wn_ < self.wlimt[1])]

                    # start to fit
                    cons = {"type": "ineq", "fun": lambda x: self.DGrid - abs(x)}
                    Error = 100.0
                    ite = 0
                    while abs(Error) > tolerance and ite < maxIte:
                        # fit Vvce with epsvec fixed
                        # print(self.Vvec_tot[name])
                        # Nelder-Mead ,  SLSQP , BFGS Newton-CG

                        """
                        vs_ = v_ * v_
                        res = minimize(self.costFunVSingle  , vs_ , args=(eps_, wn_, data_),  method='SLSQP', constraints=({'type': 'ineq', 'fun': lambda x: x}), tol=tolerance,  options={'disp': False, 'maxiter': 3000},)
                        v_ = np.sqrt( abs( res.x ) )

                        if self.fitEps:
                            res = minimize(self.costFunEspSingle, eps_, args=(v_, wn_, data_),  method='SLSQP', constraints=({'type': 'ineq', 'fun': lambda x: 5. - abs(x)}), tol=tolerance,
                                   options={'disp': False, 'maxiter': 3000},)
                            eps_ = np.real(res.x).copy()

                        Error = self.costFunVSingle(v_*v_, eps_, wn_, data_)
                        """
                        # v_ += 0.001 * (np.random.rand(self.Nb) - 0.5)
                        # eps_ += 0.001 * (np.random.rand(self.Nb) - 0.5)
                        if mpi.is_master_node():
                            print("--- initial v_\n", v_)
                            print("--- initial eps_\n", eps_)

                        x_ = np.concatenate((v_, eps_))
                        res = minimize(
                            self.costFunCombinedSingle,
                            x_,
                            args=(wn_, data_),
                            method=method,
                            constraints=({'type': 'ineq', 'fun': lambda x: self.DGrid - abs(x)}),
                            tol=tolerance,
                            options={
                                "disp": False,
                                "maxiter": 300000,
                                # "gtol": ftol,
                                # "eps": stepSize,
                            },
                        )
                        v_ = abs(res.x[: self.Nb].copy())
                        eps_ = res.x[self.Nb :].copy()
                        
                        mpi.barrier()
                        v_ = mpi.bcast(v_)
                        eps_=mpi.bcast(eps_)
                        
                        if mpi.is_master_node():
                            print("---  v_\n", v_)
                            print("---  eps_\n", eps_)
                        """res = minimize(self.costFunCombinedSingle  , x_ , args=(wn_, data_),  method='SLSQP', constraints=(), tol=tolerance,  options={'disp': False, 'maxiter': 3000},)
                        v_ = abs(res.x[:self.Nb].copy())
                        eps_ = res.x[self.Nb:].copy()
                        if mpi.is_master_node():
                            print("--- SLSQP v_\n", v_)
                            print("--- SLSQP eps_\n", eps_)"""
                        # v_ = abs(res.x[:self.Nb].copy())
                        # eps_ = res.x[self.Nb:].copy()
                        Error = self.costFunVSingle(v_ * v_, eps_, wn_, data_)

                        if mpi.is_master_node():
                            print(
                                "------ (diag) fit ",
                                name,
                                " block (",
                                ele[0],
                                ",",
                                ele[1],
                                ") with fitEps=",
                                self.fitEps,
                                " ::Error=",
                                Error,
                                ", fit method ::",
                                method,
                            )
                        ite += 1

                    # fill in the results
                    for ib in np.arange(self.Nb):
                        self.epsmat_tot[name][ib, ele[0]] = eps_[ib]
                        self.Vmat_tot[name][ib, ele[0], ele[1]] = v_[ib]
            self.epsvec_tot[name], self.Vvec_tot[name] = self.matTovec(
                self.epsmat_tot[name], self.Vmat_tot[name], name
            )

            # fit Delta block by block
            if offdiag:
                # for name in self.freeBlocks:
                cons = ({'type': 'ineq', 'fun': lambda x: 5. - abs(x)})
                Error = 100.0
                ite = 0
                while abs(Error) > tolerance and ite < maxIte:
                    # fit Vvce with epsvec fixed
                    # print(self.Vvec_tot[name])
                    # Nelder-Mead ,  SLSQP
                    """
                    res = minimize(self.costFunV, self.Vvec_tot[name], args=(
                        self.epsvec_tot[name], name),  method='SLSQP', constraints=cons, tol=tolerance,  options={'disp': False, 'maxiter': 3000},)
                    self.Vvec_tot[name] = res.x
                    if self.fitEps:
                        res = minimize(self.costFunEps, self.epsvec_tot[name], args=(self.Vvec_tot[name], name),  method='SLSQP', constraints=({'type': 'ineq', 'fun': lambda x: 5. - abs(x)}), tol=tolerance,
                                    options={'disp': False, 'maxiter': 3000},)
                        self.epsvec_tot[name] = np.real(res.x)
                    """
                    offTermsIndices = []
                    for ie, ele in enumerate(self.freeEleV[name]):
                        if ele[0] != ele[1]:
                            offTermsIndices.append(ie)
                    numVImage = self.Nb * len(offTermsIndices)
                    numVReal = self.Nb * len(self.freeEleV[name])
                    numEps = self.Nb * len(self.freeEleEps[name])

                    x_v_real_ = np.real(self.Vvec_tot[name]).copy()
                    x_v_imag_ = np.zeros(numVImage)
                    x_eps_ = self.epsvec_tot[name].copy()
                    x_ = np.concatenate((x_v_real_, x_eps_, x_v_imag_))
                    res = minimize(
                        self.costFunCombinedComplex,
                        x_,
                        args=(name, offTermsIndices),
                        method=method,
                        constraints=({'type': 'ineq', 'fun': lambda x: self.DGrid - abs(x)}),
                        tol=tolerance,
                        options={
                            "disp": False,
                            "maxiter": 300000,
                            # "gtol": ftol,
                            # "eps": stepSize,
                        },
                    )

                    x_v_real_ = res.x[:numVReal].copy()
                    x_eps_ = res.x[numVReal : (numVReal + numEps)].copy()
                    x_v_imag_ = res.x[(numVReal + numEps) :]
                    
                    mpi.barrier()
                    x_v_real_ = mpi.bcast( x_v_real_ )
                    x_eps_ = mpi.bcast( x_eps_ )
                    x_v_imag_ = mpi.bcast( x_v_imag_ )


                    self.Vvec_tot[name] = x_v_real_.copy() + 1j * np.zeros(
                        numVReal
                    )  # + 1j*res.x[ self.Nb * len(self.freeEleV[name]) : 2 * self.Nb * len(self.freeEleV[name]) ].copy()
                    # print(offTermsIndices)
                    for ib in np.arange(self.Nb):
                        for ip, p in enumerate(offTermsIndices):
                            self.Vvec_tot[name][ib * len(self.freeEleV[name]) + p] += (
                                x_v_imag_[ib * len(offTermsIndices) + ip] * 1j
                            )
                    self.epsvec_tot[name] = x_eps_.copy()

                    Error = self.costFunV(
                        self.Vvec_tot[name], self.epsvec_tot[name], name
                    )
                    if mpi.is_master_node():
                        print(
                            "------ (off-diag) fit ",
                            name,
                            " block with fitEps=",
                            self.fitEps,
                            " ::Error=",
                            Error,
                            ", fit method ::",
                            method,
                        )
                    ite += 1

        # fill in symmetric blocks
        for relation in self.blockInfo:
            first = relation[0]
            second = relation[1]
            if mpi.is_master_node():
                print("----- block ", first, "  ", relation[2], " >> ", second)
            if relation[2] == "Equal":
                self.epsvec_tot[second] = self.epsvec_tot[first].copy()
                self.Vvec_tot[second] = self.Vvec_tot[first].copy()
            else:
                if mpi.is_master_node():
                    print("unsuported relation ", relation[2], " between blocks")
        for name in self.blockNames:
            self.epsmat_tot[name], self.Vmat_tot[name] = self.vecTomax(
                self.epsvec_tot[name], self.Vvec_tot[name], name
            )
        # check the diagonal terms are positive
        # for name in self.blockNames:
        #    size = self.blockSizes[name]
        #    for ib in np.arange(self.Nb):
        #        for i in np.arange(size):
        #            if np.real(self.Vmat_tot[name][ib, i, i]) < 0.0 : raise RuntimeError("---@fitBath:: have negative diagonal hopping terms")

    def initialize_params_rand(self):
        for name in self.blockNames:
            size = self.blockSizes[name]
            D = self.DGrid

            # dw = 2.*D/self.Nb
            # eps = np.arange(-D+0.5*dw,D, dw)
            if self.Nb % 2 == 0:
                n = self.Nb // 2
            else:
                n = (self.Nb - 1) // 2
            lam = 2.0  # pow(D*self.Delta.mesh.beta, 1./(n-1))
            eps = []
            for k in range(n):
                eps.append(+1. / lam**k)
                eps.append(-1. / lam**k)

            # dw = 2.*D/float(self.Nb)
            # eps = np.arange(-D,D,dw)
            if self.Nb % 2 != 0:
                eps.append(0)  # add 0
            eps = np.sort(np.array(eps))

            for ib in np.arange(self.Nb):
                self.epsmat_tot[name][ib, :] = eps[ib]
                for ipara in np.arange(len(self.freeEleV[name])):
                    iorb = self.freeEleV[name][ipara][0]
                    jorb = self.freeEleV[name][ipara][1]
                    if iorb == jorb:
                        self.Vmat_tot[name][ib, iorb, jorb] = np.sqrt(
                            1.0 / float(self.Nb)
                        )
                    else:
                        self.Vmat_tot[name][ib, iorb, jorb] = 0.1 + 1j * 0.1
            for ib in np.arange(self.Nb):
                self.fillVSym(self.Vmat_tot[name][ib, :, :], name)
            self.epsvec_tot[name], self.Vvec_tot[name] = self.matTovec(
                self.epsmat_tot[name], self.Vmat_tot[name], name
            )

            # n_param_v = len(self.Vvec_tot[name])
            # n_param_eps = len(self.epsvec_tot[name])
            # self.Vvec_tot[name] = np.random.rand(n_param_v) + 0.0*1j
            # self.epsvec_tot[name] = np.random.rand(n_param_eps) + 0.0*1j

    def fillVSym(self, mat, name):
        for relation in self.vInfo[name]:
            first_i = relation[0][0]
            first_j = relation[0][1]
            second_i = relation[1][0]
            second_j = relation[1][1]
            if relation[2] == "Equal":
                mat[second_i, second_j] = mat[first_i, first_j]
            elif relation[2] == "mEqual":
                mat[second_i, second_j] = -mat[first_i, first_j]
            elif relation[2] == "Conj":
                mat[second_i, second_j] = np.conj(mat[first_i, first_j])
            elif relation[2] == "mConj":
                mat[second_i, second_j] = -np.conj(mat[first_i, first_j])
            elif relation[2] == "Complex":
                mat[second_i, second_j] = 1j * (mat[first_i, first_j])
            elif relation[2] == "mComplex":
                mat[second_i, second_j] = -1j * (mat[first_i, first_j])
            elif relation[2] == "Real":
                mat[second_i, second_j] = np.real(mat[first_i, first_j])
            elif relation[2] == "mReal":
                mat[second_i, second_j] = -np.real(mat[first_i, first_j])
            elif relation[2] == "Imag":
                mat[second_i, second_j] = 1j * np.imag(mat[first_i, first_j])
            elif relation[2] == "mImag":
                mat[second_i, second_j] = -1j * np.imag(mat[first_i, first_j])
            else:
                raise RuntimeError("Wrong relation between hopping elements")

    def vecTomax(self, epsvec, Vvec, name):
        """
        convert the V vector into matrix form
        return : epsmat, type [Nb, size]
                 Vmat,   type [Nb, size, size]
        0
        """
        size = self.blockSizes[name]
        Vmat = np.zeros([self.Nb, size, size], dtype=complex)
        epsmat = np.zeros([self.Nb, size])
        # fill the hopping matrix using freeEleV
        for ib in np.arange(self.Nb):
            for ipara in np.arange(len(self.freeEleV[name])):
                iorb = self.freeEleV[name][ipara][0]
                jorb = self.freeEleV[name][ipara][1]
                Vmat[ib, iorb, jorb] = Vvec[ib * len(self.freeEleV[name]) + ipara]
        # fill the hopping matrix using Vinfo
        for ib in np.arange(self.Nb):
            self.fillVSym(Vmat[ib, :, :], name)
        # fill the onsite energies using freeEleEps
        for ib in np.arange(self.Nb):
            for ipara in np.arange(len(self.freeEleEps[name])):
                epsmat[ib, ipara] = epsvec[ib * len(self.freeEleEps[name]) + ipara]
        # fill the onsite energies using epsInfo
        for ib in np.arange(self.Nb):
            for relation in self.epsInfo[name]:
                first_i = relation[0][0]
                second_i = relation[1][0]
                if relation[2] == "Equal":
                    epsmat[ib, second_i] = epsmat[ib, first_i]
                else:
                    print("Unsuported relation between on-site energies")
        return epsmat, Vmat

    def matTovec(self, epsmat, Vmat, name):
        """
        convert the bath parameters in matrix form into vector form
        """
        size = self.blockSizes[name]
        Vvec = np.zeros([self.Nb * len(self.freeEleV[name])], dtype=complex)
        epsvec = np.zeros([self.Nb * len(self.freeEleEps[name])])

        for ib in np.arange(self.Nb):
            for ipara in np.arange(len(self.freeEleV[name])):
                iorb = self.freeEleV[name][ipara][0]
                jorb = self.freeEleV[name][ipara][1]
                Vvec[ib * len(self.freeEleV[name]) + ipara] = Vmat[ib, iorb, jorb]
            for ipara in np.arange(len(self.freeEleEps[name])):
                epsvec[ib * len(self.freeEleEps[name]) + ipara] = epsmat[ib, ipara]
        return epsvec, Vvec

    def costFunCombined(self, x_, name):
        """
        compute the constfunction by varing V
        """
        Vvec = x_[: self.Nb * len(self.freeEleV[name])].copy()
        epsvec = x_[self.Nb * len(self.freeEleV[name]) :].copy()

        epsmat, Vmat = self.vecTomax(epsvec, Vvec, name)

        wn = getX(self.Delta.mesh)
        data = self.Delta[name].data
        size = self.blockSizes[name]
        # print(np.shape(data))
        if self.wlimt is not None:
            data = data[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1]), :, :]
            wn = wn[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1])]

        distance = np.zeros([size, size], dtype=complex)

        Error = 0.0
        for iw, w in enumerate(wn):
            weight = np.zeros([size, size], dtype=complex)
            for ib in np.arange(self.Nb):
                E = np.diag(1.0 / (1j * w - epsmat[ib, :]))
                # E @ Vmat[ib,:,:] #
                weight += (Vmat[ib, :, :] @ E) @ (Vmat[ib, :, :].conj().T)
            distance[:, :] = data[iw, :, :] - weight
            # np.sum(np.sum(np.abs(distance)**2))#np.linalg.norm(distance,'fro')#np.sum(np.sum(np.abs(distance)**2))
            Error += np.linalg.norm(distance, "fro") / abs(w) ** self.alpha
        Error = np.sqrt(Error) / (1.0 * len(wn))
        return Error

    def costFunCombinedComplex(self, x_, name, offTermsIndices):
        """
        complex version of distance function
        """
        numVImag = len(offTermsIndices) * self.Nb
        numVReal = self.Nb * len(self.freeEleV[name])
        numEps = self.Nb * len(self.freeEleEps[name])

        x_v_real_ = x_[:numVReal].copy()
        x_eps_ = x_[numVReal : (numVReal + numEps)].copy()
        x_v_imag_ = x_[(numVReal + numEps) :]

        Vvec = np.zeros(numVReal, dtype=complex)
        Vvec += (
            x_v_real_.copy()
        )  # + 1j*res.x[ self.Nb * len(self.freeEleV[name]) : 2 * self.Nb * len(self.freeEleV[name]) ].copy()
        for ib in np.arange(self.Nb):
            for ip, p in enumerate(offTermsIndices):
                Vvec[ib * len(self.freeEleV[name]) + p] += (
                    x_v_imag_[ib * len(offTermsIndices) + ip] * 1j
                )
        epsvec = x_eps_.copy()

        # Vvec = x_[ : self.Nb * len(self.freeEleV[name])].copy() + 1j*x_[ self.Nb * len(self.freeEleV[name]) : 2 * self.Nb * len(self.freeEleV[name])]
        # epsvec = x_[2 * self.Nb * len(self.freeEleV[name]) : ].copy()

        epsmat, Vmat = self.vecTomax(epsvec, Vvec, name)
        # enforce the diagonal hopping terms to be positive
        # for ib in np.arange(self.Nb):
        #    for i in np.arange(self.blockSizes[name]):
        #        Vmat[ib, i, i ] = abs(Vmat[ib, i, i ]) + 0.*1j

        wn = getX(self.Delta.mesh)
        data = self.Delta[name].data
        size = self.blockSizes[name]
        # print(np.shape(data))
        if self.wlimt is not None:
            data = data[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1]), :, :]
            wn = wn[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1])]

        distance = np.zeros([size, size], dtype=complex)

        Error = 0.0
        totalLen = len(wn)
        wnIndexList = np.arange(totalLen)
        wnIndexList = mpi.slice_array(wnIndexList)
        #print("rank ", mpi.rank(), ", has len(wn) ", len(wn))
        for iw in wnIndexList:
            w = wn[iw]
            weight = np.zeros([size, size], dtype=complex)
            for ib in np.arange(self.Nb):
                E = np.diag(1.0 / (1j * w - epsmat[ib, :]))
                # E @ Vmat[ib,:,:] #
                weight += (Vmat[ib, :, :] @ E) @ (Vmat[ib, :, :].conj().T)
            distance[:, :] = data[iw, :, :] - weight
            # np.sum(np.sum(np.abs(distance)**2))#np.linalg.norm(distance,'fro')#np.sum(np.sum(np.abs(distance)**2))
            Error += np.linalg.norm(distance, "fro")**2.0 / abs(w) ** self.alpha
        Error = mpi.all_reduce(0.0, Error, 0.0)
        Error = np.sqrt(Error) / float(totalLen)
        return Error

    def costFunV(self, Vvec, epsvec, name):
        """
        compute the constfunction by varing V
        """
        epsmat, Vmat = self.vecTomax(epsvec, Vvec, name)

        wn = getX(self.Delta.mesh)
        data = self.Delta[name].data
        size = self.blockSizes[name]
        # print(np.shape(data))
        if self.wlimt is not None:
            data = data[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1]), :, :]
            wn = wn[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1])]

        distance = np.zeros([size, size], dtype=complex)

        Error = 0.0
        for iw, w in enumerate(wn):
            weight = np.zeros([size, size], dtype=complex)
            for ib in np.arange(self.Nb):
                E = np.diag(1.0 / (1j * w - epsmat[ib, :]))
                # E @ Vmat[ib,:,:] #
                weight += (Vmat[ib, :, :] @ E) @ (Vmat[ib, :, :].conj().T)
            distance[:, :] = data[iw, :, :] - weight
            # np.sum(np.sum(np.abs(distance)**2))#np.linalg.norm(distance,'fro')#np.sum(np.sum(np.abs(distance)**2))
            Error += np.linalg.norm(distance, "fro") / abs(w) ** self.alpha
        Error = np.sqrt(Error) / (1.0 * len(wn))
        return Error

    def costFunEps(self, epsvec, Vvec, name):
        """
        compute the constfunction by varing V
        """
        epsmat, Vmat = self.vecTomax(epsvec, Vvec, name)

        wn = getX(self.Delta.mesh)
        data = self.Delta[name].data
        size = self.blockSizes[name]
        # print(np.shape(data))
        if self.wlimt is not None:
            data = data[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1]), :, :]
            wn = wn[np.logical_and(wn > self.wlimt[0], wn < self.wlimt[1])]

        distance = np.zeros([size, size], dtype=complex)

        Error = 0.0
        for iw, w in enumerate(wn):
            weight = np.zeros([size, size], dtype=complex)
            for ib in np.arange(self.Nb):
                E = np.diag(1.0 / (1j * w - epsmat[ib, :]))
                # E @ Vmat[ib,:,:] #
                weight += (Vmat[ib, :, :] @ E) @ (Vmat[ib, :, :].conj().T)
            distance[:, :] = data[iw, :, :] - weight
            # np.sum(np.sum(np.abs(distance)**2))#np.linalg.norm(distance,'fro')#np.sum(np.sum(np.abs(distance)**2))
            Error += np.linalg.norm(distance, "fro") / abs(w) ** self.alpha
        Error = np.sqrt(Error) / (1.0 * len(wn))
        return Error

    def constructBath(self):
        """
        construct the bath object
        """
        gf_struct = MakeGFstruct(self.Delta)
        bath = Bath(gf_struct, self.SO)
        # vkmat = ff_imag.vec2mat(res.x, k, Norbs)
        for name in self.blockNames:
            size = self.blockSizes[name]
            vecmat = np.zeros([self.Nb, size, size], dtype=complex)
            epsmat = np.zeros([self.Nb, size])
            if mpi.is_master_node():
                epsmat, vecmat = self.vecTomax(
                    self.epsvec_tot[name], self.Vvec_tot[name], name
                )
            epsmat = mpi.bcast(epsmat)
            vecmat = mpi.bcast(vecmat)
            for iorb in range(size):
                eps_ = epsmat[:, iorb].copy()
                for ib in np.argsort(eps_):
                    # np.linalg.cholesky(vecmat[ib,:,:])
                    # take the lower triangular data and fix the gauge
                    Vb = np.tril(vecmat[ib, :, :]) @ np.diag(
                        [np.sign(vecmat[ib, i, i]) for i in np.arange(size)]
                    )
                    weight = Vb @ Vb.conj().T
                    Vchol = np.linalg.cholesky(weight)  # np.tril(vecmat[ib, :, :])
                    indx = [name, iorb]
                    #if mpi.is_master_node() and ib ==0:
                    #    print("@", name, ", @iorb ", iorb, ", @ib ", ib,"\n @eps ", epsmat[ib, iorb], "\n")
                    #    for ie,e in enumerate(Vchol[:, iorb]):
                    #        print(e, "\n")
                            
                    bath.addSite(indx, epsmat[ib, iorb], Vchol[:, iorb])
        return bath
    
    def constructBathAbs(self):
        """
        construct the bath object
        """
        gf_struct = MakeGFstruct(self.Delta)
        bath = Bath(gf_struct, self.SO)
        # vkmat = ff_imag.vec2mat(res.x, k, Norbs)
        for name in self.blockNames:
            size = self.blockSizes[name]
            vecmat = np.zeros([self.Nb, size, size], dtype=complex)
            epsmat = np.zeros([self.Nb, size])
            if mpi.is_master_node():
                epsmat, vecmat = self.vecTomax(
                    self.epsvec_tot[name], self.Vvec_tot[name], name
                )
            epsmat = mpi.bcast(epsmat)
            vecmat = mpi.bcast(vecmat)
            for iorb in range(size):
                eps_ = epsmat[:, iorb].copy()
                for ib in np.argsort(abs(eps_))[::-1]:
                    # np.linalg.cholesky(vecmat[ib,:,:])
                    # take the lower triangular data and fix the gauge
                    Vb = np.tril(vecmat[ib, :, :]) @ np.diag(
                        [np.sign(vecmat[ib, i, i]) for i in np.arange(size)]
                    )
                    weight = Vb @ Vb.conj().T
                    Vchol = np.linalg.cholesky(weight)  # np.tril(vecmat[ib, :, :])
                    indx = [name, iorb]
                    #if mpi.is_master_node() and ib ==0:
                    #    print("@", name, ", @iorb ", iorb, ", @ib ", ib,"\n @eps ", epsmat[ib, iorb], "\n")
                    #    for ie,e in enumerate(Vchol[:, iorb]):
                    #        print(e, "\n")
                            
                    bath.addSite(indx, epsmat[ib, iorb], Vchol[:, iorb])
        return bath
    
    
    def constructBathRotation(self, rotationMatrix, gf_struct_RT, map_index, symops):
        """
        construct the bath object in the rotated basis, note that, inorder to 
        make such a basis rotation valid, the fitted hybridzation MUST have
        only one block.
        """
        #gf_struct = MakeGFstruct(self.Delta)
        bath = Bath(gf_struct_RT, self.SO)
        blockNamesRT = []
        blockSizeRT = {}
        for structure in gf_struct_RT:
            blockNamesRT.append( structure[0] )
            blockSizeRT[structure[0]] = structure[1]
        # vkmat = ff_imag.vec2mat(res.x, k, Norbs)
        name = self.blockNames[0]
        size = self.blockSizes[name]
        #if(size != 1):
        #    if mpi.is_master_node():
        #        print("to make a basis rotation fit, the input delta can only have 1 block")
            
        vecmat = np.zeros([self.Nb, size, size], dtype=complex)
        epsmat = np.zeros([self.Nb, size])
        if mpi.is_master_node():
            epsmat, vecmat = self.vecTomax(
                self.epsvec_tot[name], self.Vvec_tot[name], name
                )
        epsmat = mpi.bcast(epsmat)
        vecmat = mpi.bcast(vecmat)
        
        #construct bath parameters in the rotated basis
        #map_index defines how the rotated basis is connected with the initial one
        #for example, to J->Cubic for Sr2RuO4 is
        # ["ud_0"] = [0, 4, 5] and ["ud_1"] = [3, 1, 2]    
        weightRT={}  
        for nameRT in blockNamesRT:
            eps_ = epsmat[:, 0].copy()
            for ib in np.argsort(eps_):
                weightRT[nameRT] = np.zeros([blockSizeRT[nameRT], blockSizeRT[nameRT]], dtype=complex)
                # np.linalg.cholesky(vecmat[ib,:,:])
                # take the lower triangular data and fix the gauge
                Vb = np.tril(vecmat[ib, :, :]) @ np.diag([np.sign(vecmat[ib, i, i]) for i in np.arange(size)])
                #from J to cubic
                weight =  Vb @ Vb.conj().T
                weight = rotationMatrix.T.conj() @ weight @ rotationMatrix
                #symmetrize the density matrix
                numSymops = len(symops[:, 0, 0])
                den_ = weight.copy()
                for iop in np.arange(numSymops):
                    weight += symops[iop, :, :] @ den_ @ symops[iop, :, :].T.conj()
                weight[:, :] /= (1. + float(numSymops))
                    
                for iorb in np.arange(blockSizeRT[nameRT]):
                    for jorb in np.arange(blockSizeRT[nameRT]):
                        weightRT[nameRT][iorb, jorb] = weight[ map_index[nameRT][iorb], map_index[nameRT][jorb]]
                                        

                Vchol = np.linalg.cholesky(weightRT[nameRT])  # np.tril(vecmat[ib, :, :])
                for iorb in range(blockSizeRT[nameRT]):
                    iorb_original = map_index[nameRT][iorb]
                    indx = [nameRT, iorb]
                    #vec_ = np.zeros([blockSizeRT[nameRT]], dtype=complex)
                    #for i in np.arange(blockSizeRT[nameRT]):
                    #    vec_[i] = Vchol[map_index[nameRT][i] , iorb_original]
                    #regulize the hopping parameters
                    if mpi.is_master_node() and ib ==0:
                        print("@", nameRT, ", @iorb ", iorb, ", @ib ", ib,"\n @eps ", epsmat[ib, iorb_original], "\n")
                        for ie,e in enumerate(Vchol[:, iorb]):
                            print(e, "\n")
                    bath.addSite(indx, epsmat[ib, iorb_original], Vchol[:, iorb] )
        return bath


def fourierExponetialEven(Gtau, iwMesh):
    sign = 1
    Giw = BlockGf(mesh=iwMesh, gf_struct=MakeGFstruct(Gtau))
    for name, g in Giw:
        wnList = getX(Giw[name].mesh)
        tau = getX(Gtau[name].mesh)
        for itau in np.arange(len(tau) - 1):
            am = (Gtau[name].data[itau + 1, :, :] - Gtau[name].data[itau, :, :]) / (
                tau[itau + 1] - tau[itau]
            )
            bm = Gtau[name].data[itau, :, :] - am * tau[itau]
            for i in np.arange(Gtau[name].target_shape[0]):
                for j in np.arange(Gtau[name].target_shape[1]):
                    g.data[:, i, j] += (am[i, j] / wnList) * (
                        (1.0 / wnList - 1j * tau[itau + 1])
                        * np.exp(sign * 1j * wnList * tau[itau + 1])
                        - (1.0 / wnList - 1j * tau[itau])
                        * np.exp(sign * 1j * wnList * tau[itau])
                    ) - (1j * bm[i, j] / wnList) * (
                        np.exp(sign * 1j * wnList * tau[itau + 1])
                        - np.exp(sign * 1j * wnList * tau[itau])
                    )
    return Giw


def fourierExponetialCustom(Gtau, iwMesh, TimeGrid):
    sign = 1
    Giw = BlockGf(mesh=iwMesh, gf_struct=MakeGFstruct(Gtau))
    for name, g in Giw:
        wnList = getX(Giw[name].mesh)
        tau = TimeGrid
        if len(tau) != len(Gtau[name].data[:, 0, 0]):
            raise RuntimeError("FourierExp:the time grid doesn't math G(tau")
        for itau in np.arange(len(tau) - 1):
            am = (Gtau[name].data[itau + 1, :, :] - Gtau[name].data[itau, :, :]) / (
                tau[itau + 1] - tau[itau]
            )
            bm = Gtau[name].data[itau, :, :] - am * tau[itau]
            for i in np.arange(Gtau[name].target_shape[0]):
                for j in np.arange(Gtau[name].target_shape[1]):
                    g.data[:, i, j] += (am[i, j] / wnList) * (
                        (1.0 / wnList - 1j * tau[itau + 1])
                        * np.exp(sign * 1j * wnList * tau[itau + 1])
                        - (1.0 / wnList - 1j * tau[itau])
                        * np.exp(sign * 1j * wnList * tau[itau])
                    ) - (1j * bm[i, j] / wnList) * (
                        np.exp(sign * 1j * wnList * tau[itau + 1])
                        - np.exp(sign * 1j * wnList * tau[itau])
                    )
    return Giw


def FourierExpEven(Gt: GfReTime, 
                   mesh: MeshReFreq, 
                   eta: float=1e-12):
    """fourier transformation assuming a linear form on an even grid

    Args:
        Gt (GfReTime): the retarded Green's function in time domain
        mesh (MeshReFreq): the mesh in frequency domain
        eta (float): Lorentzian broadening. Defaults to 1e-12.


    Returns:
        Gw: the Green's function in frequency domain
    """
    sign = 1
    Gw = BlockGf(mesh=mesh, gf_struct=MakeGFstruct(Gt))
    TimeGrid = getX(Gt.mesh)
    #lorentzion dumping
    data_ = {}
    for name,g in Gt:
        data_[name] = g.data.copy()
        for i in np.arange(g.target_shape[0]):
            for j in np.arange(g.target_shape[1]):
                data_[name][:, i, j] *= np.exp(-eta*abs(TimeGrid))
                
    for name, g in Gw:
        wList = getX(Gw[name].mesh)
        for itau in np.arange(len(TimeGrid) - 1):
            am = (data_[name][itau + 1, :, :] - data_[name][itau, :, :]) / (
                TimeGrid[itau + 1] - TimeGrid[itau]
            )
            bm = data_[name][itau, :, :] - am * TimeGrid[itau]
            for i in np.arange(g.target_shape[0]):
                for j in np.arange(g.target_shape[1]):
                    g.data[:, i, j] += (am[i, j] / wList) * (
                        (1.0 / wList - 1j * TimeGrid[itau + 1])
                        * np.exp(sign * 1j * wList * TimeGrid[itau + 1])
                        - (1.0 / wList - 1j * TimeGrid[itau])
                        * np.exp(sign * 1j * wList * TimeGrid[itau])
                    ) - (1j * bm[i, j] / wList) * (
                        np.exp(sign * 1j * wList * TimeGrid[itau + 1])
                        - np.exp(sign * 1j * wList * TimeGrid[itau])
                    )
    return Gw


def DiscretizeBathEqualWeight(
    Delta: BlockGf, Nb: int, SO: bool = False, CrossFermi: bool = True
):
    bath = ftps.solver_core.Bath(MakeGFstruct(Delta), SO)
    for name, g in Delta:
        # g.total_density()
        specMat = 1j / (2 * np.pi) * (g - conjugate(transpose(g)))
        wData = getX(specMat.mesh)
        dwGf = wData[1] - wData[0]
        specData = specMat.data[:, :, :].copy()
        specData *= dwGf
        n_orb = g.target_shape[0]

        ListPoles = np.zeros([Nb, 2, n_orb])
        for iorb in np.arange(n_orb):
            if CrossFermi:
                pwt = 1.0 / float(Nb)
                ind = 0
                for i in np.arange(Nb - 1):
                    dm0 = 0.0
                    dm1 = 0.0
                    while dm0 + specData[ind, iorb, iorb] < pwt - 1e-12:
                        dm0 += specData[ind, iorb, iorb]
                        dm1 += wData[ind] * specData[ind, iorb, iorb]
                        ind += 1
                    dm1 += (pwt - dm0) * wData[ind]
                    specData[ind, iorb, iorb] -= (pwt - dm0).real
                    ListPoles[i, 1, iorb] = (pwt).real
                    ListPoles[i, 0, iorb] = (dm1 / pwt).real
                dm1 = 0.0
                for i in np.arange(ind, len(wData)):
                    dm1 += wData[i] * specData[i, iorb, iorb]
                    # print(dm1)
                ListPoles[Nb - 1, 1, iorb] = pwt.real
                ListPoles[Nb - 1, 0, iorb] = (dm1 / pwt).real

            else:
                Nl = int(g.density()[iorb, iorb].real * Nb)
                Nr = int(Nb - Nl)
                pwtl = g.density()[iorb, iorb] / float(Nl)
                pwtr = (1.0 - g.density()[iorb, iorb]) / float(Nr)

                # filled
                ind = 0
                for i in np.arange(Nl):
                    dm0 = 0.0
                    dm1 = 0.0
                    while dm0 + specData[ind, iorb, iorb] < pwtl - 1e-12:
                        dm0 += specData[ind, iorb, iorb]
                        dm1 += wData[ind] * specData[ind, iorb, iorb]
                        ind += 1
                    dm1 += (pwtl - dm0) * wData[ind]
                    specData[ind, iorb, iorb] -= (pwtl - dm0).real
                    ListPoles[i, 1, iorb] = (pwtl).real
                    ListPoles[i, 0, iorb] = (dm1 / pwtl).real
                # empty
                for i in np.arange(Nl, Nb - 1):
                    dm0 = 0.0
                    dm1 = 0.0
                    while dm0 + specData[ind, iorb, iorb] < pwtr - 1e-12:
                        dm0 += specData[ind, iorb, iorb]
                        dm1 += wData[ind] * specData[ind, iorb, iorb]
                        ind += 1
                        # print(ind)
                    dm1 += (pwtr - dm0) * wData[ind]
                    specData[ind, iorb, iorb] -= (pwtr - dm0).real
                    ListPoles[i, 1, iorb] = pwtl.real
                    ListPoles[i, 0, iorb] = (dm1 / pwtr).real
                # residue
                dm1 = 0.0
                for i in np.arange(ind, len(wData)):
                    dm1 += wData[i] * specData[i, iorb, iorb]
                    # print(dm1)
                ListPoles[Nb - 1, 1, iorb] = pwtr.real
                ListPoles[Nb - 1, 0, iorb] = (dm1 / pwtr).real
            # add the bath
            for ibath in np.arange(Nb):
                Vchol = np.zeros((n_orb), dtype=np.complex128)
                Vchol[iorb] = np.sqrt(ListPoles[ibath, 1, iorb])
                bath.addSite([name, iorb], ListPoles[ibath, 0, iorb], Vchol)

    return bath
