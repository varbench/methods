import numpy as np
import matplotlib.pyplot as plt

import itertools
from itertools import product
from triqs.gf import *


def MakeGFstruct(G):
    """Creates a gf_struct object from TRIQS Green's function G."""

    if not isinstance(G, BlockGf):
        raise TypeError("MakeGFstruct: argument must be a TRIQS BlockGf.")

    gf_struct = []
    for name, block in G:
        gf_struct.append([name, block.target_shape[0]])

    return gf_struct


def IsOffDiag(Delta):
    """ Returns true if any off-diagonal entry of Delta is larger that 1E-15.
    Parameters
    ----------
    Delta:      TriqsGf
                Any TRIQS Green's function.
    """
    for _, delta in Delta:
        inds = list(range(delta.target_shape[0]))
        for i, j in itertools.product(inds, inds):
            if(i == j):
                continue
            if(np.max(np.abs(delta.data[:, i, j])) > 1E-15):
                return True
    return False


def IsCausal(Delta):
    for name, d in Delta:
        specMat = 1j/(2.)*(d - conjugate(transpose(d)))

        for w in specMat.mesh:
            A = specMat[w]
            D, _ = np.linalg.eig(A)
            D = D.real
            if any(d < 0 for d in D):
                return False

    return True


def getX(obj):
    """ Simple helper function returning a numpy array to plot representing the x-axis.
    Parameters
    ----------
    obj:        Any of MeshReFreq, MeshReTime, MeshImFreq, MeshImFreq, GfReFreq
                        GfReFreq, GfReTime, GfImFreq, GfImTime
                Object having an x-axis.
    Returns
    ----------
    x           numpy.array
                X-axis of object.
    """
    if isinstance(obj, GfReFreq) or isinstance(obj, GfReTime) or isinstance(obj, GfImTime):
        return np.array([t.value for t in obj.mesh])
    elif isinstance(obj, GfImFreq):
        return np.array([t.value.imag for t in obj.mesh])
    elif isinstance(obj, MeshReFreq) or isinstance(obj, MeshImTime) or isinstance(obj, MeshReTime):
        return np.array([t.value for t in obj])
    elif isinstance(obj, MeshImFreq):
        return np.array([t.value.imag for t in obj])
    else:
        raise RuntimeError('Invalid object of type',
                           type(obj), 'provided to getX.')


def extrapolateGF(Gs, etas, ord=3):
    """ Extrapolates self energies Sigmas to zero broadening eta.

    Parameters
    ----------
    G:          dict of TRIQS Green's functions.
                Green's functions as a dict of various broadenings eta.
    etas:       list or numpy array
                Broadenings used for the self energies.
    ord         int
                Order of polynomial fit.
    Returns
    ----------
    x           numpy.array
    """
    if(len(etas) != len(Gs)):
        RuntimeError('Sigmas and etas are not compatible.')
    if(len(etas) == 0):
        RuntimeError('Provided empty etas array.')

    G_ext = Gs[etas[0]].copy()

    for name, g in G_ext:
        mesh = g.mesh
        blockSize = g.target_shape[0]
        for i, j in product(range(blockSize), range(blockSize)):
            for w in mesh:
                y = []
                for eta in etas:
                    y.append(Gs[eta][name][i, j][w])

                fit = np.poly1d(np.polyfit(etas, y, ord))
                g[i, j][w] = fit(0.)

    return G_ext


# very simple helpers to have autocomplete in python instead of undocumented kwargs
def WMesh(wmin, wmax, Nw):
    return MeshReFreq(wmin, wmax, Nw)


def TMesh(tmin, tmax, Nt):
    return MeshReTime(tmin, tmax, Nt)


def TauMesh(beta, Nt, s='Fermion'):
    return MeshImTime(beta, s, Nt)


def IWMesh(beta, Nw, s='Fermion'):
    return MeshImFreq(beta, s, Nw)


def EmptyBlockGf(mesh, gf_struct):
    return BlockGf(mesh=mesh, gf_struct=gf_struct)


def MakeMatsubara(Ggr, Gle):
    """ For the greater (Ggr) and lesser (Gle) Green's function from the FPTS solver,
        this function compute the resulting Matsubara Green's function G still using a
        real-time grid. Note that the convention is such that the time axis of Gle is
        inverted, so Gle[t] is actually Gle[-t].

        Parameters
        ----------
        Ggr:        GfReTime
                    Greater Green's function from FTPS solver.
        Gle:        GfReTime
                    Lesser Green's function from FTPS solver.
        Returns
        ----------
        Gmat        Matsubara Green's function Gmat[t] = Ggr[t] - Gle[-t]
    """

    if not isinstance(Ggr.mesh, MeshReTime):
        raise TypeError("Ggr must be real-time GF.")
    if not isinstance(Gle.mesh, MeshReTime):
        raise TypeError("Gle must be real-time GF.")

    OrigTMesh = Ggr.mesh
    dt = OrigTMesh.delta
    tmax = OrigTMesh.t_max
    Nt = int(np.round(tmax/dt))

    NewTMesh = TMesh(-tmax, tmax, 2*Nt+1)
    Gmat = EmptyBlockGf(NewTMesh, MakeGFstruct(Ggr))

    for name, g in Gmat:
        gr = Ggr[name]
        le = Gle[name]
        for i in range(g.target_shape[0]):
            for j in range(g.target_shape[0]):
                g[i, j].data[Nt:] = -gr[i, j].data[:]
                g[i, j].data[:Nt+1] = +le[i, j].data[::-1]
                # take average at tau = 0
                g[i, j].data[Nt] = 0.5*(-gr[i, j].data[0] + le[i, j].data[0])
    return Gmat


def plotDiag(G, extraLabel=''):
    assert isinstance(G, BlockGf) or isinstance(G, Gf)

    for name, g in GFDiag(G):
        ax = plt.gca()
        ax.plot(getX(g.mesh), g.data, label=extraLabel + ' ' + name)
    plt.legend()


# Iterate over diagonal of TRIQS-Green's function
def GFDiag(G):
    return GFDiagIterator(G)


class GFDiagIterator:
    def __init__(self, G):
        self.G = G
        self.blockIndx = 0
        self.isBlockGF = True if isinstance(G, BlockGf) else False

        if self.isBlockGF:
            self.blockNames = []
            for name, _ in G:
                self.blockNames.append(name)

            self.blockName = self.blockNames[0]
            self.blockNameIndx = 0

    def __next__(self):
        if self.isBlockGF:
            g = self.G[self.blockName]

            if self.blockIndx < g.target_shape[0]:
                # stay in block take next blockIndx
                self.blockIndx += 1

                name = self.blockName + f' Orb {self.blockIndx}'

                return name, g[self.blockIndx-1, self.blockIndx-1]

            elif self.blockNameIndx < len(self.blockNames)-1:
                # next block
                self.blockNameIndx += 1
                self.blockName = self.blockNames[self.blockNameIndx]

                g = self.G[self.blockName]

                # reset blockIndx ... set to 1 since in this iteration we already return index 0
                self.blockIndx = 1

                name = self.blockName + f' Orb {self.blockIndx}'
                return name, g[self.blockIndx-1, self.blockIndx-1]
        else:
            if self.blockIndx < self.G.target_shape[0]:
                self.blockIndx += 1
                return f'Orb {self.blockIndx}', self.G[self.blockIndx-1, self.blockIndx-1]

        raise StopIteration

    def __iter__(self):
        return self
