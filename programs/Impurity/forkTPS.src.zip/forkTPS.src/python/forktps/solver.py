###############################################################################
#
# forktps: A TRIQS based impurity solver
#
# Copyright (c) 2019 The Simons foundation
#   authors: Nils Wentzell
#
# forktps is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# forktps is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# forktps. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from inspect import signature
from . import solver_core

from triqs.gf import *
from triqs.utility import mpi

from .DiscreteBath import FourierTransform


def _repr(self):
    """Represent object using its attributes as arguments."""
    arguments = (arg for arg in self.__dir__()
                 if not arg.startswith('_') and arg != "hdf5_format")
    arg_string = ", ".join(f"{arg}={getattr(self, arg)}" for arg in arguments)
    return f"{self.__class__.__name__}({arg_string})"


# === The SolverCore Wrapper

class Solver(solver_core.SolverCore):
    """Solver object."""

    def __init__(self, gf_struct, wmin=10, wmax=10, nw=1001):
        """ Initialise the solver.

        Parameters
        ----------
        gf_struct : list of pairs [ [str,[int,...]], ...]
                    Structure of the Green's functions. It must be a
                    list of pairs, each containing the name of the
                    Green's function block as a string and a list of integer
                    indices.
                    For example: ``[ ['up', [0, 1, 2]], ['down', [0, 1, 2]] ]``.
        wmin : double 
                     smallest omega value
        wmax : double 
                     largest omega value
        nw : integer [default=1001]
                     number of omega points
        """

        gf_struct = fix_gf_struct_type(gf_struct)

        # Initialise the core solver
        super().__init__(gf_struct=gf_struct,
                         w_min=wmin,
                         w_max=wmax,
                         n_w=nw
                         )

        self.gf_struct = gf_struct
        self.wmin = wmin
        self.wmax = wmax
        self.nw = nw

    def solve(self, **params_kw):
        """
        Solve the impurity problem.

        Parameters
        ----------
        params_kw :     dict {'param':value} that is passed to the core solver.

        h_int:          forktps::H_int, 
                        Interaction parameters for Kanamorin Interaction (U, J and U').
                        Number of FTPO applications during DMRG to improve convergence.
        NPart:          list of lists of integers of length 2*Norbs
                        If provided, the state with the lowest energy among the sectors defined in NPart is used.
                        For each orbital/spin, one number has to be given in the order [[N_Aup, N_Adn, N_Bup, N_Bdn ...]]
        eta:            double, default = 0.1
                        Lorentzian broadening during fourier transform
        calc_me:        list of pairs of string and int, optional
                        Specifies the which Green's function need to be calculated by providing a list of 
                        block-names and block-indices. E.g: [['up', 0],['dn', 0]] calculates the Green's function
                        only for the first entry of block 'up' and 'dn'.
                        If not provided, all possible Green's functions are calculated.
        measurements:   list of TRIQS many_body_operators
                        A list of measurements to be performed on the impurity degrees of freedom of ground state. 
        """

        #h_int = params_kw['h_int']

        gf_struct = self.gf_struct
        super().solve(**params_kw)

        eta = self.last_solve_params["eta"]
        for gf in self.last_solve_params["GFs"]:
            if(gf == 'S'):
                self.G_w = FourierTransform(self.G_ret, self.G_w.mesh, eta)
            if(gf == 'F'):
                self.F_w = FourierTransform(self.F_ret, self.F_w.mesh, eta)
            if(gf == 'N'):
                self.N_w = FourierTransform(self.N_t, self.N_w.mesh, eta)

        #G0inv = BlockGf(mesh= self.G_w.mesh, gf_struct = gf_struct)
        # for name, ginv in G0inv:
        #    ginv << Omega + 1j*eta - self.Delta_recons_w[name]
        #    self.Sigma_w[name] << ginv - inverse( self.G_w[name] )
        return

    def __repr__(self):
        return (f"{self.__class__.__name__}(gf_struct={self.gf_struct}"
                f", wmin={self.wmin}, wmax={self.wmax}, nw={self.nw})")


# Note difference in lower and upper case letter between DMRGParams and DMRGparams.
class DMRGParams(solver_core.DmrgParams):
    """Parameters for DMRG calculations."""

    def __init__(self, **kwargs):
        """Initialise the DMRGParams object.

        Parameters
        ----------
        params_kw : dict {'param':value} with the following possible keys

        sweeps:         int (default 15)
                        Number of sweeps
        maxm:           int (default 100)
                        Maximal Bond Dimension used for every link. Overrules any other maximal bond dimensions if provided.
        maxmI:          int (default 100)
                        Maximal Bond Dimension used for Impurity-Impurity links
        maxmIB:         int (default 100)
                        Maximal Bond Dimension used for Impurity-Bath links
        maxmB:          int (default 100)
                        Maximal Bond Dimension used for Bath-Bath links
        tw:             float (default 1E-9)
                        Truncated Weight used for every link. Overrules any other truncated weigths if provided.
        twI:            float (default 1E-9)
                        Truncated Weight used for Impurity-Impurity links
        twIB:           float (default 1E-9)
                        Truncated Weight used for Impurity-Bath links
        twB:            float (default 1E-9)
                        Truncated Weight used for Bath-Bath links      
        nmax:           int 
                        Maximal Number of Krylov vectors created
        normErr:        float 
                        Stop Krylov Iteration when norm of new Krylov vector is below this value
        conv:           float
                        Convergence Criterium    
        napph           int (default 0)
                        Number of times the Hamiltonian is applied during DMRG
        prep_napph      int (default 3)
                        Number of times the hamiltonian is applyied to the initial product state
        prep_imagTevo   bool (default False)
                        If true, perform imaginary time evolution to prepare for DMRG.
        prep_dtau       float (default 0.2)
                        Time step size of imaginary time evolution, only used if prep_imagTevo is True.
        prep_time_steps int (default 20)
                        Number of preparation time steps, only used if prep_imagTevo is True.
        prep_method     string (default "TDVP")
                        Time evolution method for preparation, eiterh "TDVP", "TDVP_2" or "TEBD", only used if prep_imagTevo is True.
        """

        allowedArgs = ['maxm', 'maxmI', 'maxmIB', 'maxmB',     # max bond dims
                       'tw', 'twI', 'twIB', 'twB',             # truncation
                       'nmax', 'normErr', 'conv',              # krylov
                       'sweeps', 'napph', 'DMRGMethod',        # other
                       'prep_napph', 'prep_imagTevo', 'prep_dtau', 'prep_time_steps', 'prep_method']  # preparation

        if(not set(kwargs.keys()) <= set(allowedArgs)):
            raise ValueError(
                'Invalid argument provided, allowed arguments are ' + str(allowedArgs))

        mi = kwargs.get('maxm', kwargs.get('maxmI',  100))
        mb = kwargs.get('maxm', kwargs.get('maxmB',   100))
        mib = kwargs.get('maxm', kwargs.get('maxmIB', 100))

        twi = kwargs.get('tw', kwargs.get('twI',  1E-9))
        twb = kwargs.get('tw', kwargs.get('twB',  1E-9))
        twib = kwargs.get('tw', kwargs.get('twIB', 1E-9))

        nmax = kwargs.get('nmax', 40)
        err = kwargs.get('normErr', 1E-12)
        conv = kwargs.get('conv', 1E-12)

        sw = kwargs.get('sweeps', 15)
        nh = kwargs.get('napph', 0)
        dmrgmethod = kwargs.get('DMRGMethod', 'SSImp')

        prep_nh = kwargs.get('prep_napph',      3)
        prep_imagT = kwargs.get('prep_imagTevo',   False)
        prep_dt = kwargs.get('prep_dtau',       0.2)
        prep_Nt = kwargs.get('prep_time_steps', 20)
        prep_method = kwargs.get('prep_method',     'TDVP')

        # call constructor of c++ wrapped DmrgParams
        super().__init__(mi, mb, mib,          # max bond dims
                         twi, twb, twib,       # truncation
                         nmax, err, conv,      # krylov
                         sw, nh, dmrgmethod,   # other
                         prep_nh, prep_imagT, prep_dt, prep_Nt, prep_method)  # state preparation

    __repr__ = _repr  # FIXME: arguments don't match attribute names


class TevoParams(solver_core.TevoParams):
    """Parameters for DMRG calculations."""

    def __init__(self, *, dt=None, time_steps, TDVPOrder=2, imag_tevo=False, method="TDVP",
                 maxm=None, maxmI=100, maxmB=100, maxmIB=100,
                 tw=None, twI=1e-9, twB=1e-9, twIB=1e-9,
                 nmax=40, normErr=1E-8, conv=1e-12):
        """Initialise the DMRGParams object.

                Parameters
                ----------
                dt:             double
                                Size of time step
                time_steps:     int
                                Half the number of time steps take. Maximal time is then 2*dt*time_steps.
                TDVPOrder       int (default 2)
                                Order of TDVP integration 1 or 2 for first or second order integration respectively.
                imag_tevo:      bool (default False)
                                If true perform imaginary time evolution
                method:         string (default "TDVP")
                                Time evolution method, eiterh "TDVP", "TDVP_2" or "TEBD"
                maxm:           int (default 100)
                                Maximal Bond Dimension used for every link. Overrules any other maximal bond dimensions if provided.
                maxmI:          int (default 100)
                                Maximal Bond Dimension used for Impurity-Impurity links
                maxmB:          int (default 100)
                                Maximal Bond Dimension used for Impurity-Bath links
                maxmIB:         int (default 100)
                                Maximal Bond Dimension used for Bath-Bath links
                tw:             float (default 1E-9)
                                Truncated Weight used for every link. Overrules any other truncated weigths if provided.
                twI:            float (default 1E-9)
                                Truncated Weight used for Impurity-Impurity links
                twIB:           float (default 1E-9)
                                Truncated Weight used for Impurity-Bath links
                twB:            float (default 1E-9)
                                Truncated Weight used for Bath-Bath links      
                nmax:           int (default 40)
                                Maximal Number of Krylov vectors created
                normErr:        float (default 1e-12)
                                Stop Krylov Iteration when norm of new Krylov vector is below this value
                conv:           float (default 1e-12)
                                Convergence Criterium    
        """

        if time_steps == 0:
            dt = 0.

        if maxm is not None:  # overwrites all other maxmX
            sig_params = signature(self.__init__).parameters
            # check if any maxmX was set to a value different from maxm
            loc = locals()
            bad_maxm = [arg for arg in ("maxmI", "maxmB", "maxmIB")
                        if sig_params[arg].default != loc[arg] != maxm]
            if bad_maxm:
                bad_arguments = ", ".join(f"{name}={loc[name]}"
                                          for name in bad_maxm)
                raise ValueError(
                    f"Arguments {bad_arguments} contradict maxm={maxm}")
            maxmI = maxmB = maxmIB = maxm

        if tw is not None:  # overwrites all other twX
            sig_params = signature(self.__init__).parameters
            # check if any tw was set to a value different from tw
            loc = locals()
            bad_tw = [arg for arg in ("twI", "twB", "twIB")
                      if sig_params[arg].default != loc[arg] != tw]
            if bad_tw:
                bad_arguments = ", ".join(f"{name}={loc[name]}"
                                          for name in bad_tw)
                raise ValueError(
                    f"Arguments {bad_arguments} contradict tw={tw}")
            twI = twB = twIB = tw

        # call constructor of c++ wrapped DmrgParams
        super().__init__(dt, time_steps,        # time step & number of steps
                         TDVPOrder,             # integration order
                         maxmI, maxmB, maxmIB,  # max bond dims
                         twI, twB, twIB,        # truncation
                         nmax, normErr, conv,   # krylov
                         imag_tevo, method)    # other

    __repr__ = _repr


# Note difference in lower and upper case letter between TNApprox and TnApprox.
# TnApprox (lower case "n") is the wrapped version without documentation, while
# TNApprox (upper case "N") is the object inteded for the User to use including docstrings
class TNApprox(solver_core.TnApprox):
    """Approximation parameters for the ForkTPS Tensor Network."""

    def __init__(self, **kwargs):
        """Initialise the TNApprox object.

        Parameters
        ----------
        params_kw : dict {'param':value} with the following possible keys
        maxm:   int (default 100)
                Maximal Bond Dimension used for every link. Overrules any other maximal bond dimensions if provided.
        maxmI:  int (default 100)
                Maximal Bond Dimension used for Impurity-Impurity links
        maxmB:  int (default 100)
                Maximal Bond Dimension used for Impurity-Bath links
        maxmIB: int (default 500)
                Maximal Bond Dimension used for Bath-Bath links
        tw:     float (default 1E-9)
                Truncated Weight used for every link. Overrules any other truncated weigths if provided.
        twI:    float (default 1E-9)
                Truncated Weight used for Impurity-Impurity links
        twIB:   float (default 1E-9)
                Truncated Weight used for Impurity-Bath links
        twB:    float (default 1E-9)
                Truncated Weight used for Bath-Bath links              
        """

        allowedArgs = ["maxm", "maxmI", "maxmIB",
                       "maxmB", "tw", "twI", "twIB", "twB"]
        # if( not set(kwargs.keys())  <= set(allowedArgs)  ):
        #        raise ValueError('Invalid argument provided, allowed arguments are ' + str(allowedArgs))

        super().__init__()

        self.maxm_i = kwargs.get("maxm", kwargs.get("maxmI", 100))
        self.maxm_ib = kwargs.get("maxm", kwargs.get("maxmIB", 100))
        self.maxm_b = kwargs.get("maxm", kwargs.get("maxmB", 100))

        self.tw_i = kwargs.get("tw", kwargs.get("twI", 1E-9))
        self.tw_ib = kwargs.get("tw", kwargs.get("twIB", 1E-9))
        self.tw_b = kwargs.get("tw", kwargs.get("twB", 1E-9))

    __repr__ = _repr


# Note difference in lower and upper case letter between KrylovApprox and KrylovParams.
# KrylovParams (lower case "a") is the wrapped version without documentation, while
# KrylovApprox (upper case "A") is the object inteded for the User to use including docstrings
class KrylovApprox(solver_core.KrylovParams):
    """Approximation parameters for Krylov algorithms."""

    def __init__(self, **kwargs):
        """Initialise the KrylovApprox object.

        Parameters
        ----------
        params_kw : dict {'param':value} with the following possible keys
        nmax:           int 
                        Maximal Number of Krylov vectors created
        normErr:        float 
                        Stop Krylov Iteration when norm of new Krylov vector is below this value
        conv:           float
                        Convergence Criterium         
        """

        if(not set(kwargs.keys()) <= set(['nmax', 'normErr', 'conv'])):
            raise ValueError('Only nmax, normErr and conv are allowed args')

        super().__init__()

        self.nmax = kwargs.get("nmax", 40)
        self.norm_err = kwargs.get("normErr", 1E-12)
        self.conv = kwargs.get("conv", 1E-12)

    __repr__ = _repr  # FIXME: arguments don't match attributes
