# Generated automatically using the command :
# c++2py ../../c++/forktps/solver_core.hpp -p -N forktps -a forktps -m solver_core -o solver_core --moduledoc="The forktps solve_core module" --includes="../../c++" -C triqs --cxxflags="-std=c++20" --only "tn_approx krylov_params aim_h0 solver_core hloc bath bath_site H_int Tevo_params DMRG_params DMRG_prep_params"
from cpp2py.wrap_generator import *

# The module
module = module_(
    full_name="finiteT_solver_core",
    doc=r"The forktps finiteT_solver_core module",
    app_name="forktps",
)

# Imports
module.add_imports(*["triqs.gf", "triqs.gf.meshes", "triqs.operators", "h5._h5py"])

# Add here all includes
module.add_include("forktps/finiteT_solver_core.hpp")

# Add here anything to add in the C++ code at the start, e.g. namespace using
module.add_preamble(
    """
#include <cpp2py/converters/complex.hpp>
#include <cpp2py/converters/map.hpp>
#include <cpp2py/converters/optional.hpp>
#include <cpp2py/converters/pair.hpp>
#include <cpp2py/converters/std_array.hpp>
#include <cpp2py/converters/string.hpp>
#include <cpp2py/converters/vector.hpp>
#include <triqs/cpp2py_converters/gf.hpp>
#include <triqs/cpp2py_converters/operators_real_complex.hpp>
#include <triqs/cpp2py_converters/real_or_complex.hpp>

using namespace forktps;
"""
)


# -----------------------------------------#
# global krylov time evolotion parameters
# -----------------------------------------#

c = class_(
    py_type="GlobalKrylov",
    c_type="forktps::globalKrylov_params",
    doc=r""" global krylov time evolution parameters""",
    hdf5=False,
)
c.add_member(
    c_name="gKrylov",
    c_type="bool",
    read_only=False,
    doc=r""" whether to perform global krylov time evolution """,
)

c.add_member(
    c_name="nKrylov", c_type="int", read_only=False, doc=r"""krylov subspace size """
)

c.add_member(
    c_name="orthoSize",
    c_type="int",
    read_only=False,
    doc=r"""orthogonal subspace size """,
)

c.add_member(
    c_name="threshold", c_type="double", read_only=False, doc=r"""weight threshold """
)
c.add_constructor("""()""", doc=r"""""")
c.add_constructor(
    """(bool gKrylov, int nKrylov, int orthoSize, double threshold)""", doc=r""""""
)
module.add_class(c)
# -----------------------------------------#
# basis expansion parameters
# -----------------------------------------#
c = class_(
    py_type="BasisExpansion",
    c_type="forktps::basisExpansion_params",
    doc=r""" basis expansion parameters""",
    hdf5=False,
)
c.add_member(
    c_name="useBE",
    c_type="bool",
    read_only=False,
    doc=r""" whether to use basis expansion for time evolution """,
)

c.add_member(
    c_name="cutoffBE", c_type="double", read_only=False, doc=r""" cut off threshold """
)

c.add_member(
    c_name="bondBE",
    c_type="int",
    read_only=False,
    doc=r""" bond dimension of auxiliaries states for basis expansion""",
)

c.add_member(
    c_name="nKrylovBE",
    c_type="int",
    read_only=False,
    doc=r""" krylov vecots used for basis expansion""",
)
c.add_member(
    c_name="expand_every",
    c_type="int",
    read_only=False,
    doc=r""" make a basis expansion every *expand_every" steps """,
)


c.add_member(
    c_name="minBond",
    c_type="int",
    read_only=False,
    doc=r""" the minimal bond dimension criterial """,
)


c.add_member(
    c_name="expand_everyList",
    c_type="std::vector<int>",
    read_only=False,
    doc=r""" make a basis expansion every *expand_every" steps """,
)


c.add_member(
    c_name="BETimeList",
    c_type="std::vector<double>",
    read_only=False,
    doc=r""" basis expansion time list """,
)

c.add_member(
    c_name="timeToExpand",
    c_type="std::vector<double>",
    read_only=False,
    doc=r""" basis expansion time list """,
)

c.add_member(
    c_name="critical_time",
    c_type="std::vector<double>",
    read_only=False,
    doc=r""" basis expansion time list """,
)


c.add_member(
    c_name="BEMethod",
    c_type="std::string",
    read_only=False,
    doc=r""" method to generate reference states """,
)


c.add_member(
    c_name="expand_critical",
    c_type="bool",
    read_only=False,
    doc=r""" whether to expand at critical time point """,
)

c.add_constructor("""()""", doc=r"""""")
c.add_constructor("""(double cutoff, int nKrylov, int expand_every)""", doc=r"""""")
c.add_constructor(
    """(double cutoff, int nKrylov, int expand_every, std::string BEMethod)""",
    doc=r"""""",
)
c.add_constructor(
    """(bool useBE, double cutoff, int nKrylov, int expand_every, std::string BEMethod)""",
    doc=r"""""",
)

c.add_constructor(
    """(bool useBE, double cutoff, int nKrylov, std::vector<double> BETimeList, std::vector<int> expand_everyList, std::string BEMethod)""",
    doc=r"""""",
)


c.add_constructor(
    """(bool useBE, double cutoff, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod)""",
    doc=r"""""",
)


c.add_constructor(
    """(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod)""",
    doc=r"""""",
)


c.add_constructor(
    """(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond)""",
    doc=r"""""",
)

c.add_constructor(
    """(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond, bool expand_critical)""",
    doc=r"""""",
)


c.add_constructor(
    """(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond, bool expand_critical, std::vector<double> critical_time)""",
    doc=r"""""",
)

module.add_class(c)

# -----------------------------------------#
# sampling parameters
# -----------------------------------------#
c = class_(
    py_type="SamplingParameters",
    c_type="forktps::sampling_params",
    doc=r""" sampling parameters""",
    hdf5=False,
)
c.add_member(
    c_name="n_thermal",
    c_type="int",
    read_only=False,
    doc=r""" number of thermalization step""",
)
c.add_member(
    c_name="n_sampling", c_type="int", read_only=False, doc=r""" sampling number """
)
c.add_member(
    c_name="measure_every",
    c_type="int",
    read_only=False,
    doc=r""" make a measurement every *MeasureEvery* sampling """,
)
c.add_member(
    c_name="purification_threshold",
    c_type="double",
    read_only=False,
    doc=r""" purification energy threshold """,
)

c.add_member(
    c_name="purificationSites",
    c_type="int",
    read_only=False,
    doc=r""" purification sites """,
)

c.add_member(
    c_name="n_fluctuating_sites",
    c_type="int",
    read_only=False,
    doc=r""" number of fluctuating sites close to fermi level""",
)


c.add_member(
    c_name="puriMethod",
    c_type="std::string",
    read_only=False,
    doc=r""" the method adopted to determine the purified bath sites """,
)

c.add_member(
    c_name="minTwoSiteStep",
    c_type="int",
    read_only=False,
    doc=r""" minimal two site tdvp steps when generating METTS """,
)

c.add_member(
    c_name="minTwoSiteTime",
    c_type="double",
    read_only=False,
    doc=r""" minimal two site tdvp time when generating METTS """,
)

c.add_member(
    c_name="BETime",
    c_type="double",
    read_only=False,
    doc=r""" minimal Basis expansion time when generating METTS """,
)

c.add_member(
    c_name="TSTime",
    c_type="double",
    read_only=False,
    doc=r""" minimal two-site time when generating METTS """,
)


c.add_member(
    c_name="minTwoSiteStepGf",
    c_type="int",
    read_only=False,
    doc=r""" minimal two site tdvp steps when calculating green's function """,
)

c.add_member(
    c_name="minTwoSiteTimeGf",
    c_type="double",
    read_only=False,
    doc=r""" minimal two site tdvp time when calculating green's function """,
)

c.add_member(
    c_name="saveIntermedia",
    c_type="bool",
    read_only=False,
    doc=r""" whether to save the intermedia sampling information or not """,
)

c.add_member(
    c_name="uniEvo",
    c_type="bool",
    read_only=False,
    doc=r""" whether to perform an unitary time  evolution when generating the METTS """,
)


c.add_member(
    c_name="uniEvoSteps",
    c_type="int",
    read_only=False,
    doc=r"""unitary time evolution times """,
)


c.add_member(
    c_name="uniEvodt",
    c_type="double",
    read_only=False,
    doc=r"""unitary time evolution dt """,
)


c.add_member(
    c_name="exp_grid_steps",
    c_type="int",
    read_only=False,
    doc=r"""exponentail tau grid steps """,
)

c.add_member(
    c_name="fixedSites",
    c_type="int",
    read_only=False,
    doc=r"""number of fixed filling bath sites """,
)
c.add_member(
    c_name="minNumGfEachRank",
    c_type="int",
    read_only=False,
    doc=r"""minimum number of Gfs to be calculated on each rank """,
)
c.add_member(
    c_name="shiftedSteps",
    c_type="int",
    read_only=False,
    doc=r"""number of shifted imaginary time steps in calculating the Green's function """,
)


c.add_constructor("""()""", doc=r"""""")
c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod)""",
    doc=r"""""",
)
c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep, int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double minTwoSiteTime, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double BETime, double TSTime, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps)""",
    doc=r"""""",
)

c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, int purificationSites, double TSTime, std::string puriMethod, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps)""",
    doc=r"""""",
)


c.add_constructor(
    """(int n_thermal, int n_sampling, int measure_every, int purificationSites, double TSTime, std::string puriMethod, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank, int shiftedSteps, int n_fluctuating_sites)""",
    doc=r"""""",
)
module.add_class(c)


# -----------------------------------------#
# quickDMRG parameters
# -----------------------------------------#
c = class_(
    py_type="QuickDMRGParams",
    c_type="forktps::quickDMRG_params",
    doc=r""" quick dmrg parameters""",
    hdf5=False,
)

c.add_member(
    c_name="quickDMRG",
    c_type="bool",
    read_only=False,
    doc=r""" perform a quick DMRG run or not""",
)

c.add_member(
    c_name="nDMRGSweep", c_type="int", read_only=False, doc=r""" quick DMRG sweeps"""
)

c.add_member(
    c_name="nWarmUp",
    c_type="int",
    read_only=False,
    doc=r""" quick DMRG warm up iterations""",
)

c.add_member(
    c_name="mDMRG", c_type="int", read_only=False, doc=r""" quick DMRG bond dimension"""
)

c.add_member(
    c_name="twDMRG",
    c_type="double",
    read_only=False,
    doc=r""" quick DMRG truncation weight""",
)

c.add_member(
    c_name="DMRGMethod",
    c_type="std::string",
    read_only=False,
    doc=r""" quick DMRG method""",
)

c.add_constructor("""()""", doc=r"""""")
c.add_constructor(
    """(bool quickDMRG, int nDMRGSweep, int nWarmUp, int mDMRG, double twDMRG, std::string DMRGMethod)""",
    doc=r"""""",
)
module.add_class(c)

# -----------------------------------------#
# The class solver_core
# -----------------------------------------#

c = class_(
    py_type="FiniteTSolverCore",  # name of the python class
    c_type="forktps::finiteT_solver_core",  # name of the C++ class
    doc=r"""/ The Solver class""",  # doc of the C++ class
    hdf5=False,
)


c.add_member(
    c_name="constr_params",
    c_type="forktps::finiteT_constr_params_t",
    read_only=False,
    doc=r"""Struct containing the parameters relevant for the solver construction""",
)

c.add_member(
    c_name="solve_params",
    c_type="forktps::finiteT_solve_params_t",
    read_only=False,
    doc=r"""Struct containing the parameters relevant for the solving""",
)

c.add_member(
    c_name="b",
    c_type="forktps::bath",
    read_only=False,
    doc=r"""Bath object containing the bath parameters""",
)

c.add_member(
    c_name="bUni",
    c_type="forktps::bath",
    read_only=False,
    doc=r"""Unitary Bath object containing the bath parameters""",
)

c.add_member(
    c_name="e0",
    c_type="forktps::hloc",
    read_only=False,
    doc=r"""Non-interacting impurity Hamiltonian""",
)

c.add_member(
    c_name="G_tau",
    c_type="g_tau_t",
    read_only=False,
    doc=r"""" The Calculated imaginary time Green's function""",
)

c.add_member(
    c_name="G_tau_by_norm",
    c_type="g_tau_t",
    read_only=False,
    doc=r"""" The Calculated by norm imaginary time Green's function""",
)

c.add_member(
    c_name="G_tau_var",
    c_type="g_tau_t",
    read_only=False,
    doc=r"""" The Calculated variance of the imaginary time Green's function""",
)

c.add_member(
    c_name="BondGrowthAve",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""" The averaged bond growth in generating metts""",
)


c.add_member(
    c_name="MeasuredStatic",
    c_type="std::vector<std::complex<double>>",
    read_only=False,
    doc=r"""" Measured static quantities""",
)


c.add_member(
    c_name="DistributionCount",
    c_type="std::vector<int>",
    read_only=False,
    doc=r"""" saved repeated times of sampled unique metts""",
)

c.add_member(
    c_name="DistributionLogNorm",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""" saved log norm of sampled unique metts""",
)


c.add_member(
    c_name="G_t",
    c_type="g_t_t",
    read_only=False,
    doc=r"""" The Calculated real time Green's function""",
)

c.add_member(
    c_name="G_iw",
    c_type="g_iw_t",
    read_only=False,
    doc=r"""" The Calculated imaginary time Green's function on the frequency axis""",
)

c.add_member(
    c_name="Energy",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""Collection of sampled Energy""",
)

c.add_member(
    c_name="EInfty",
    c_type="double",
    read_only=False,
    doc=r"""Collection of sampled Energy""",
)

c.add_member(
    c_name="BigNorm",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""Collection of sampled norm""",
)

c.add_member(
    c_name="TimeGrid",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""time grid""",
)

c.add_constructor(
    """(**forktps::finiteT_constr_params_t)""",
    doc=r"""Construct a FORKTPS solver

+----------------+-----------------------------------+---------+-------------------------------------------+
| Parameter Name | Type                              | Default | Documentation                             |
+================+===================================+=========+===========================================+
| w_min          | double                            | --      | Energy interval borders.                  |
+----------------+-----------------------------------+---------+-------------------------------------------+
| w_max          | double                            | --      | Energy interval borders.                  |
+----------------+-----------------------------------+---------+-------------------------------------------+
| n_w            | int                               | --      | Number of grid points.                    |
+----------------+-----------------------------------+---------+-------------------------------------------+
| gf_struct      | triqs::hilbert_space::gf_struct_t | --      | Block structure of the Green's function.  |
+----------------+-----------------------------------+---------+-------------------------------------------+
""",
)
c.add_method("""void solve (**forktps::finiteT_solve_params_t)""", doc=r"""" """)
c.add_method("""void solveDLR (**forktps::finiteT_solve_params_t)""", doc=r"""" """)
c.add_method("""void solveBasis (**forktps::finiteT_solve_params_t)""", doc=r"""" """)
c.add_method("""void solveReal (**forktps::finiteT_solve_params_t)""", doc=r"""" """)
c.add_method("""void EinftyEstimate (**forktps::finiteT_solve_params_t)""", doc=r"""" """)

module.add_class(c)

# -----------------------------------------#
# Converter for finiteT_constr_params_t
# -----------------------------------------#

c = converter_(
    c_type="forktps::finiteT_constr_params_t",
    doc=r"""Parameters provided at finiteT solver construction.""",
)

c.add_member(
    c_name="beta",
    c_type="double",
    initializer="""  """,
    doc=r"""inverse temperature.""",
)

c.add_member(
    c_name="n_iw",
    c_type="int",
    initializer="""  """,
    doc=r"""Number of Matsubara frequency.""",
)

c.add_member(
    c_name="gf_struct",
    c_type="triqs::hilbert_space::gf_struct_t",
    initializer="""  """,
    doc=r"""Block structure of the Green's function.""",
)

c.add_member(
    c_name="samplingFolder",
    c_type="std::string",
    initializer="""  """,
    doc=r"""samping files folder.""",
)

module.add_converter(c)

# -----------------------------------------#
# Converter for finiteT_solve_params_t
# -----------------------------------------#
c = converter_(
    c_type="forktps::finiteT_solve_params_t",
    doc=r""" finite temperature solve parameters""",
)

c.add_member(
    c_name="verbose", c_type="int", initializer="""  """, doc=r""" print out verbose"""
)

c.add_member(
    c_name="timeGrid",
    c_type="std::string",
    initializer="""  """,
    doc=r""" type of time grid {Even, Exp}""",
)


c.add_member(
    c_name="impPurified",
    c_type="bool",
    initializer="""  """,
    doc=r""" whether the impurity sites are purified or not""",
)

c.add_member(
    c_name="h_int",
    c_type="forktps::H_int",
    initializer="""  """,
    doc=r""" the impurity interaction Hamiltonian""",
)

c.add_member(
    c_name="tevo",
    c_type="forktps::Tevo_params",
    initializer="""  """,
    doc=r""" time evolution parameters""",
)

c.add_member(
    c_name="basisExpansion",
    c_type="forktps::basisExpansion_params",
    initializer="""  """,
    doc=r""" basis expansion parameters""",
)

c.add_member(
    c_name="sampling",
    c_type="forktps::sampling_params",
    initializer="""  """,
    doc=r""" sampling parameters""",
)

c.add_member(
    c_name="quickDMRG",
    c_type="forktps::quickDMRG_params",
    initializer="""  """,
    doc=r""" quick dmrg parameters""",
)

c.add_member(
    c_name="gKrylov",
    c_type="forktps::globalKrylov_params",
    initializer="""  """,
    doc=r""" global krylov time evolution parameters""",
)

c.add_member(
    c_name="calc_me",
    c_type="std::vector<std::vector<triqs_indx>>",
    initializer="""  """,
    doc=r""" calculated Green's function components""",
)


c.add_member(
    c_name="measured_static_op",
    c_type="std::vector<std::vector<std::pair<std::string, triqs_indx>>>",
    initializer="""  """,
    doc=r""" measured static quatities""",
)

c.add_member(
    c_name="tau_grid",
    c_type="std::vector<double>",
    initializer="""  """,
    doc=r""" input imaginary time grid""",
)

module.add_converter(c)


# -----------------------------------------#
module.generate_code()
