"""Handle the discretization of the Bath."""
from forktps.solver_core import Bath
from forktps.Helpers import MakeGFstruct, IsOffDiag, GFDiag, getX, IsCausal

from forktps.DiscreteBath import OuterDiscrBoundaries, Interval, IntervalBathSizes


from triqs.gf import *
import triqs.utility.mpi as mpi

# other python libraries
import numpy as np
from scipy import optimize
from typing import Optional, Callable
import matplotlib.pyplot as plt
# from dataclasses import dataclass #python > 3.7


# Bath Fitting
# @dataclass #python > 3.7
class FitResult:
    """Represents the results of the fit.

    Contains the discretization interval values
    in limits, the corresponding errors as well as the optimized interval.
    """

    # for dataclass remove constructor and uncomment below:
    #limits: dict
    #errors: dict
    #interval: Interval

    def __init__(self, l: dict, e: dict, I: Interval):
        self.limits = l
        self.errors = e
        self.interval = I

    def plot(self, ax, doLabel=True):

        colors = {'lower': '#1f77b4', 'upper': '#ff7f0e'}

        maxErr = max(max(self.errors['upper']), max(self.errors['lower']))
        ax.set_title('Error vs Interval Boundaries')
        for key, l in self.limits.items():
            if doLabel:
                ax.plot(l, self.errors[key], 'x-',
                        label=key, color=colors[key])
            else:
                ax.plot(l, self.errors[key], 'x-', color=colors[key])

        minError = min(np.min(self.errors['lower']), np.min(
            self.errors['upper']))

        ax.set_ylim(0.9*minError)
        ax.set_xlabel('limits')
        ax.legend()


class BathFitter:
    """Find the best fit bath parameters of a hybridization function broadened by η.

    Best fit bath parameters are defined as the best hybridizations Vk
    for energies ek defined in the smallest energy interval possible that
    represent the hybridization well.
    Roughly speaking it does that in a three step process:

    1.  For a given energy interval (ek also given), it findes the best-fit Vk
        by minimizing | E * V**2 - hyb |, where the matrix E is given by
        E_{ik} = 1./(w_i - ek + 1j*η), V**2 is the vector of squared 
        hybridizations V**2_k = Vk**2 and hyb is the vectorized hybridization 
        function that is supposed to be fitted.

    2.  Make the interval smaller and see if the fit is still good enough.

    3.  Based on the intervals and fit errors computed that way decide on the 
        best-fit interval.

    These steps are all performed with a number of bath sites that is optimized
    for the current total interval length and the value of the broadening. Only 
    when the optimal interval size is found, the user provide number of bath
    sites ist used to perform the actual fit to obtain the bath parameters.


    Attributes
    -----------
    Nb:     int (default None)
    Number of bath sites, if none provided, determines the bath size automatically
    based on the broadening.

    eta:    float
    Broadening. In energy space it corresponds to a convolution of Green function
    G with a lorenzian of width eta.

    step:   float
    Step size used to determine best-fit interval.

    result: dict
    Container with FitResult objects, one for each block/index and interval of 
    the hybridization.

    bath:   Bath
    Bath object storing the bath parameters.
    """

    def __init__(self, Nb: int = None):
        if Nb is not None:
            if Nb <= 0:
                raise RuntimeError(
                    f'Bath Fitter with less than 1 number of bath sites. Nb: {Nb}')

        self.Nb = Nb
        self.eta = None
        self.step = None
        self.result = None
        self.bath = None
        self.Delta = None

        self._printWarning = True

    def FitBath(self,
                Delta: BlockGf,
                eta: float,
                step: Optional[float] = None,
                ignoreL: Optional[float] = None,
                ignoreWeight: float = 0.,
                fixNb: Optional[bool] = False,
                symmG: Optional[Callable] = None
                ):
        """Fit function to find the optimal fit.

        Parameters
        ----------
        Delta:          GfReFreq
        Broadened bath hybridization function to fit.

        eta:            float
        Broadening.

        step:           float
        Step size of interval values used for fitting.

        ignoreL:  flota (default = 0.5*eta)
        Ignore Intervals with a length smaller than this value.

        ignoreWeight: float (default 0)
        Ignore Intervals with a relative weight of less than this number.
        Relative weight means the total area of the spectrum compared to the area
        of the interval.

        fixNb: bool (default False)
        If true, the exact number of bath sites the user provides is enforced.
        Otherwise, the algorithm can remove small bath parameters.

        symmG:  Callable, default = None
        Function that will be applied to Δ(ω) to symmetrize it. The
        function must take a single Triqs Block Green function and return 
        the symmetrized version of it.

        Returns
        ----------
        bath:       Bath
        Bath object storing the bath parameters.
        """
        # Things to improve / still to do:
        # ---------------------------------
        #  add checks

        if symmG is not None:
            symmDelta = symmG(Delta)
        else:
            symmDelta = Delta

        self.Delta = symmDelta
        self.eta = eta
        self.step = eta/10. if step is None else step
        self.ignoreL = ignoreL if ignoreL is not None else 0.5*eta
        self.ignoreWeight = ignoreWeight
        self.fixNb = fixNb

        if eta < self.Delta.mesh.delta:
            mpi.report('η = %f, Δω = %f' % (eta, self.Delta.mesh.delta))
            raise ValueError(
                'Broadening η cannot be smaller than ω-mesh discretization')

        if IsOffDiag(self.Delta):
            raise RuntimeError(
                'Off-diagonal Δ(ω) is not implemented in fit discretization.')

        if not IsCausal(self.Delta):
            raise RuntimeError('Non-Causal hybridization -Im Δ(ω)<0 provided.')

        self.result = {}
        self.bath = Bath(MakeGFstruct(self.Delta), SO=False)

        for name, delta in self.Delta:
            self.result[name] = np.empty(
                delta.target_shape[0], dtype=FitResult)

            # no factor pi here
            specMat = 1j/(2.)*(delta-conjugate(transpose(delta)))

            for bIndx, [_, self._spec] in enumerate(GFDiag(specMat)):
                mpi.report('\n\nOptimizing block %s index %i' % (name, bIndx))
                mpi.report('--------------------------------')

                # get a first rough guess for the interval via the area of spec
                self._areaGuess()

                # find all non-zero V intervals
                self._intervalFinder()

                self.result[name][bIndx] = []
                # loop over intervals
                for self._currentIndx, self._currentI in enumerate(self._Intervals):
                    self._limits, self._errors = {}, {}
                    for self._silent in [False]:
                        for self._mode in Interval.keys():
                            self._findFitLimit()

                    self._updateNb(factor=0.9)
                    # store result
                    self.result[name][bIndx].append(
                        FitResult(self._limits, self._errors, self._currentI))

                # best interval found, compute parameters and put into bath
                self._finishOrb(name, bIndx)

        return self.bath

    def _areaGuess(self):
        """Make a rough guess of the best-fit outer-interval boundaries based on the area of spec."""

        self._Intervals = [OuterDiscrBoundaries(self._spec, 1E-2)]
        self._updateNb(factor=0.9)

    def _intervalFinder(self):
        """Find all energy intervals with non-zero hybridization V.

        The purpose of is two-fold:
        First it improves the guess interval from _areaGuess.
        Second, it can also find gaps in the spectrum.
        """

        w = getX(self._spec.mesh)
        spec = self._spec.data
        totalWeight = np.abs(np.trapz(x=w, y=spec))

        Vsq, eps = self._minimize(recordResult=False)

        # set small Vsq to 0 they cause trouble in DMRG
        Vsq[Vsq < 0.005*max(Vsq)] = 0
        deps = eps[1]-eps[0]

        isNonZero = np.asarray(Vsq > 0)

        inInterval = False  # interval started
        nFalse = 2  # number consecutive zero Vsq to finish interval
        countFalse = 0  # number consecutive zero Vsq found

        self._Intervals = []

        for i, nz in enumerate(isNonZero):
            if nz == True and inInterval == False:
                inInterval = True
                countFalse = 0
                # start interval with arbitrary upper boundary
                newInterval = Interval(eps[i]-deps/2., eps[i]-deps/2. + 1)

            elif nz == False and inInterval == True:
                if countFalse < nFalse:
                    # demand 2 consective False before ending interval
                    countFalse += 1
                    continue

                inInterval = False
                # finish interval
                newInterval['upper'] = eps[i-1-nFalse]+deps/2.
                self._Intervals.append(newInterval)

        # finish interval if still open
        if inInterval:
            newInterval['upper'] = eps[-1]+deps/2.
            self._Intervals.append(newInterval)

        mpi.report('  Rough guess found %i interval(s):' %
                   len(self._Intervals))
        # copy self._Intervals
        for I in list(self._Intervals):
            # compute relative weight of this interval
            mask = np.logical_and(w > I['lower'], w < I['upper'])
            relWeight = np.abs(np.trapz(x=w[mask], y=spec[mask]))/totalWeight

            if relWeight < self.ignoreWeight:
                mpi.report(
                    '  ' + str(I) + f'   not enough weight {relWeight:.3f} -> will be ignored.')
                self._Intervals.remove(I)
            elif I.length() < self.ignoreL:
                mpi.report('  ' + str(I) + '   too small -> will be ignored.')
                self._Intervals.remove(I)
            else:
                mpi.report('  '+str(I))

        self._updateNb(factor=0.9)

    def _updateNb(self, factor: float = 1.):
        """Set the number of bath sites according to interval length and broadening.

        Based on the total interval length L and the broadening eta, set
        the number of bath sites to factor*L/eta. Factor is a fine tuning
        parameter to control how spiky the fit is.
        """

        totalL = 0
        for I in self._Intervals:
            totalL += I.length()

        newNb = int(round(totalL/self.eta)*factor)

        # it doesnt hurt to have a center of each interval, so for one and two
        # intervals make sure fitNb is an appropriate
        if len(self._Intervals) == 1:
            # newNb must be odd
            newNb += newNb % 2 - 1
        elif len(self._Intervals) == 2:
            # newNb must be even, half of NewNb must be odd
            newNb += newNb % 2
            if round(newNb/2) % 2 == 0:
                newNb -= 2

        self._fitNb = newNb

    def _finishOrb(self, name: str, indx: int):
        """Compute bath parameters after finding best-fit intervals.

        After best-fit intervals are found, this function computes the bath
        parameters and adds entries to the Bath into the block *name* with
        index *indx*.
        """
        Norbs = self.bath.NArms//2

        # use user provided Nb if provided to finish the fitting, otherwise use
        # optimum given by L/eta
        if self.Nb is None:
            # hard coded factor 1.2 to be on the safe side
            self._updateNb(factor=1.2)
            mpi.report(
                'Finishing orbital, auto detect optimal bath size: %i' % self._fitNb)
        else:
            self._fitNb = self.Nb
            mpi.report(
                'Finishing orbital, use user defined bath size: %i' % self._fitNb)

        # get Best bath parameters
        Vsq, eps = self._minimize(recordResult=False)

        if not self.fixNb:
            Vsq[Vsq < 0.001*max(Vsq)] = 0

        assert all(Vsq >= 0)

        for e, vsq in zip(eps, Vsq):
            if abs(vsq) < 1E-12 and not self.fixNb:
                mpi.report(
                    f'Ignoring site with ε = {e:.4} and V = {vsq:.4}. V is too small.')
                continue

            V = np.zeros((Norbs), dtype=np.complex128)
            V[indx] = np.sqrt(vsq)

            self.bath.addSite([name, indx], e, V)

        # check that fit fitted a smooth function and not only lorenzian pekas
        totalL = 0
        for I in self._Intervals:
            totalL += I.length()

        if(totalL/len(eps) > 2*self.eta):
            mpi.report('\n\n Warning, fit resulted in energy discretization that is very large (%.3f) compared to the broadening (%.3f).' % (eps[1]-eps[0], self.eta) +
                       ' A sum of sharp lorenzian peaks was fitted instead of a smooth function. Please check the result, as this can cause problems!\n\n')

    def _findFitLimit(self):
        """Find the smallest fit interval that gives an accurate fit.

        This is done by varying only either the upper or the lower limit as
        defined by self._mode.
        """
        m = self._mode
        if m != 'lower' and m != 'upper':
            raise ValueError(
                'Invalid value of mode: %s. Mode can only be lower or upper.' % mode)

        if not self._silent:
            mpi.report('\n  Optimizing %s boundary of interval %i:' %
                       (m, self._currentIndx+1))

        self._newFitLimitReset()

        fineSearch = self._coarseSearch()

        # fine search
        if not self._silent and len(fineSearch) > 1:
            mpi.report("  Evaluating Fit on a fine grid, doing %i steps with size %.3f in [%.3f, %.3f]"
                       % (len(fineSearch), self.step, fineSearch[0], fineSearch[-1]))

        for limit in fineSearch:
            self._currentI[m] = limit
            self._minimize()

        # based on the coarse and fine search, find the optimal interval size
        self._sortLimits()
        bestI = np.argmin(self._errors[m])
        start, end = max(0, bestI-2), min(len(self._limits[m]), bestI+3)

        if end-start > 2:
            # try to fit parabola to data to get a better guess for optimum
            xfit, yfit = self._limits[m][start:end], self._errors[m][start:end]
            fit = np.polyfit(xfit, yfit, 2)
            A, B = fit[0], fit[1]

            self._currentI[m] = -B/(2*A)

            # evaluate potential optimum
            self._minimize()
            self._sortLimits()

            # use best fit-result (might not be the optimum of parabola-fit)
            bestI = np.argmin(self._errors[m])

        self._currentI[m] = self._limits[m][bestI]

        if not self._silent:
            mpi.report('  Found %s boundary: %.3f' % (m, self._currentI[m]))

    def _minimize(self, recordResult: bool = True):
        """Perform the actual fit of finding the best V**2 parameters.

        It uses the current interval (self._currentI) for the energies ek which are simply
        linearly spaced.
        The minimization is restricted to positive V**2 only.

        Parameters
        ----------
        recordResult:   bool (default: True)
        Decides wheter the result of the fit should be recorded for later evaluation.

        Returns
        -------
        Vsq:        numpy array of floats
        Squared bath parameters V**2.

        eps:        numpy array of floats
        Vector of energies.
        """
        # Problem data.
        E, hyb, eps = self._fitProperties()

        # fit function that respects Vsq > 0
        Vsq, err = optimize.nnls(E, hyb)

        if recordResult:
            m = self._mode
            self._errors[m] = np.append(self._errors[m], err)
            self._limits[m] = np.append(self._limits[m], self._currentI[m])

        return Vsq, eps

    def _fitProperties(self):
        """Compute the quantities needed for the minimization.

        The bath fitting problem is given by min_{Vsq} | E * V** - hyb |^2, with
        E_{ik} = 1./(w_i - ek + 1j*eta), V**2 is the vector of squared hybridizations
        V**2_k = Vk**2 and hyb is the vectorized hybridization function.

        Returns
        ----------
        E:          numpy array of floats
        Fit matrix E.

        hyb:        numpy array of floats
        Fit vector spec (just the data of spec).

        eps:        numpy array of floats
        Vector of energies used to compute E.
        """
        Nbs = IntervalBathSizes(
            self._Intervals, self._fitNb, self._printWarning)
        eps = np.zeros(0)

        for indx, [Nb, I] in enumerate(zip(Nbs, self._Intervals)):
            if Nb <= 0:
                # warning only needs to be printed once
                self._printWarning = False
                if self._currentIndx == indx:
                    self._currentIIsEmpty = True
                continue

            def epsVec(I, Nb):
                dE = I.length()/Nb
                return np.linspace(I['lower']+dE/2., I['upper']-dE/2., Nb)

            deps = I.length()/Nb
            if I['lower'] < 0 and I['upper'] > 0:
                # interval goes through 0, place one site at 0 and distribute the rest
                # to one interval left and one interval right
                left = Interval(I['lower'], -deps/2)
                right = Interval(deps/2, I['upper'])

                restSizes = IntervalBathSizes([left, right], Nb-1)
                epsLeft = epsVec(left, restSizes[0])
                epsRight = epsVec(right, restSizes[1])

                newEps = np.append(epsLeft, [0.])
                newEps = np.append(newEps, epsRight)

            else:
                newEps = epsVec(I, Nb)

            eps = np.append(eps, newEps)

        w = getX(self._spec.mesh) + 1j*self.eta

        E = -1./np.subtract.outer(w, eps)

        return E.imag, self._spec.real.data, eps

    def _newFitLimitReset(self):
        """Reset attributes before starting a new boundary optimization."""
        m = self._mode

        self._printWarning = True
        self._currentIIsEmpty = False
        self._limits[m] = np.empty(0, dtype=np.float64)
        self._errors[m] = np.empty(0, dtype=np.float64)

        # accuracy is used so that the algorithm doesnt stop when finding a minimum caused by "random" fluctuations in the fit quality
        self._accuracy = 1E-2 * \
            np.abs(np.trapz(getX(self._spec.mesh), self._spec.data))

    def _coarseSearch(self):
        """Perform a coarse search of interval limits and stops when the fit gets much worse.

        Returns
        ----------
        fineSearch      numpy array of float
        Array of limits which should be searched next based on the result.
        """
        m = self._mode
        I = self._currentI
        sign = -1 if m == 'upper' else 1

        # increases when fit gets worse, terminate when counter reaches a fixed number (3 currently)
        counter = 0

        # step size
        CoarseStep = self._currentI.length()*self.eta/8.

        self._setStartPoint(CoarseStep)

        while counter < 8:
            self._minimize()
            err = self._errors[m][-1]
            # if not self._silent:
            #    print( '  Discretization limit %.5f: sqared error = %.5f'%( self._currentI[m], err) )

            if len(self._errors[m]) == 1:
                bestLimit = self._limits[m][-1]
                minErr = err
            else:
                diff = err-minErr
                if diff < 0 or np.abs(diff) < self._accuracy:
                    # fit got better or only slightly worse
                    counter = 0
                    if diff < 0:
                        bestLimit, minErr = I[m], min(minErr, err)
                else:
                    # fit got worse
                    counter += 1

            I[m] += sign*CoarseStep
            if I.length() <= 0.:
                # this shouldnt happen normally, is more of a recovery message
                mpi.report(
                    'Warning Interval length became zero, check hybridization.')
                I[m] -= sign*CoarseStep
                return []

            if self._currentIIsEmpty:
                break

        # evaluate on a finer grid around best guess so far, make at least 9 steps
        Nx = max(10, round(2*CoarseStep/self.step))
        Nx = Nx+Nx % 2  # Nx must be odd otherwise compute center twice

        # avoid starting exactly at points already calculated
        xmin = bestLimit - CoarseStep + 2.*CoarseStep/Nx
        xmax = bestLimit + CoarseStep - 2.*CoarseStep/Nx

        return np.linspace(xmin, xmax, Nx)

    def _setStartPoint(self, CoarseStep: float):
        """Set the start point for _coarseSearch.

        Start either halfway between intervals or CoarseStep away from the current boundary, 
        whatever is smallest.
        """
        m = self._mode
        i = self._currentIndx
        I = self._currentI

        if m == 'upper':
            if i == len(self._Intervals)-1:
                # last interval
                I[m] += CoarseStep
            else:
                Idistance = self._Intervals[i+1]['lower'] - I['upper']
                # in between two intervals
                I[m] += min(CoarseStep, Idistance/2.)
        else:
            if i == 0:
                # first interval one step back
                I[m] -= CoarseStep
            else:
                Idistance = I['lower'] - self._Intervals[i-1]['upper']
                # in between two intervals
                I[m] -= min(CoarseStep, Idistance/2.)

    def _sortLimits(self):
        """Sort self._limits and self._errors."""
        m = self._mode

        sortedInds = np.argsort(self._limits[m])
        self._limits[m] = np.array(self._limits[m])[sortedInds]
        self._errors[m] = np.array(self._errors[m])[sortedInds]

    def plotFit(self, f: plt.Figure):
        """
        Plot function showing the original and fitted hybridization, the actual
        intervals used and the fit error for the fit-interval boundaries. 
        """
        if self.Delta is None or self.bath is None:
            raise RuntimeError('Cant plot result before fitting')

        DeltaRe = self.bath.reconstructDelta(self.Delta.mesh, self.eta)

        plotCounter = 0
        axs = f.subplots(self.bath.NArms, 2)
        for name, d in self.Delta:
            for i in range(d.target_shape[0]):
                # plot delta and recontructed delta
                axs[plotCounter, 0].plot(
                    getX(d.mesh), -d[i, i].imag.data, label='Orig')
                axs[plotCounter, 0].plot(
                    getX(DeltaRe.mesh), -DeltaRe[name][i, i].imag.data, label='Fit')

                axs[plotCounter, 0].set_xlabel('$\omega$')
                axs[plotCounter, 0].set_ylabel('$-\Im \Delta(\omega)$')

                for indx, res in enumerate(self.result[name][i]):
                    # plot interval boundaries into both plots
                    lab = 'Interval(s)' if indx == 0 else ''
                    maxD = max(-d[i, i].imag.data)
                    maxErr = max(max([[np.max(r.errors['upper']), np.max(
                        r.errors['lower'])] for r in self.result[name][i]]))
                    maxima = [maxD, maxErr]
                    for lr in range(2):
                        axs[plotCounter, lr].vlines(
                            res.interval['upper'], 0, maxima[lr], color='gray', ls='--', label=lab, lw=1.0)
                        axs[plotCounter, lr].vlines(
                            res.interval['lower'], 0, maxima[lr], color='gray', ls='--', lw=1.0)

                    # plot fit result
                    res.plot(axs[plotCounter, 1],
                             doLabel=True if indx == 0 else False)

                axs[plotCounter, 0].set_title(f'$\Delta(\omega)$ {name} {i}')
                axs[plotCounter, 0].legend()
                plotCounter += 1

        f.tight_layout()
