# Generated automatically using the command :
# c++2py ../../c++/forktps/solver_core.hpp -p -N forktps -a forktps -m solver_core -o solver_core --moduledoc="The forktps solve_core module" --includes="../../c++" -C triqs --cxxflags="-std=c++20" --only "tn_approx krylov_params aim_h0 solver_core hloc bath bath_site H_int Tevo_params DMRG_params DMRG_prep_params"
from cpp2py.wrap_generator import *

# The module
module = module_(
    full_name="solver_core", doc=r"The forktps solve_core module", app_name="forktps"
)

# Imports
module.add_imports(*["triqs.gf", "triqs.gf.meshes", "triqs.operators", "h5._h5py"])

# Add here all includes
module.add_include("forktps/solver_core.hpp")

# Add here anything to add in the C++ code at the start, e.g. namespace using
module.add_preamble(
    """
#include <cpp2py/converters/complex.hpp>
#include <cpp2py/converters/map.hpp>
#include <cpp2py/converters/optional.hpp>
#include <cpp2py/converters/pair.hpp>
#include <cpp2py/converters/std_array.hpp>
#include <cpp2py/converters/string.hpp>
#include <cpp2py/converters/vector.hpp>
#include <triqs/cpp2py_converters/gf.hpp>
#include <triqs/cpp2py_converters/operators_real_complex.hpp>
#include <triqs/cpp2py_converters/real_or_complex.hpp>

using namespace forktps;
"""
)


# The class bath_site
c = class_(
    py_type="BathSite",  # name of the python class
    c_type="forktps::bath_site",  # name of the C++ class
    doc=r"""A bath site consists of an on-site energy eps
 and hopping amplitudes V. The vector structure in V are the
 hoppings of the bath site to the different impurity sites.""",  # doc of the C++ class
    hdf5=False,
)

c.add_member(c_name="eps", c_type="double", read_only=False, doc=r"""""")

c.add_member(c_name="V", c_type="forktps::cvec", read_only=False, doc=r"""""")

module.add_class(c)

# The class bath
c = class_(
    py_type="Bath",  # name of the python class
    c_type="forktps::bath",  # name of the C++ class
    doc=r"""A bath is a collection of bath sites in a block structure similar to what is used for triqs Green's functions.""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="b",
    c_type="std::map<std::string, bath_block>",
    read_only=False,
    doc=r"""Stores the actual parameters.""",
)

c.add_constructor("""()""", doc=r"""""")

c.add_constructor(
    """(triqs::hilbert_space::gf_struct_t gfstruct, bool SO = false)""",
    doc=r"""Create an empty bath with the block structure give by gfstruct. This is the usual constructer used from triqs.
 All other constructors are for backwards compatibility/convenience. SO determines how this block structure
 is interpreted. If false (usual case), one block is a spin-up block while the other represents the spin-down
 degrees of freedom. If true, the block structure is that of a spin-orbit coupled impurity which mixes spin channels.

Parameters
----------
gfstruct
     triqs gf_struct_t
     Definies the block structure, i.e, the names and number of orbitals of the bath.

SO
     bool (default false)
     If false, use spin-up and spin-down blocks, otherwise use spin-orbit coupled block structure.""",
)

c.add_constructor(
    """(forktps::dvec eps, forktps::dvec V, int blockSize, std::string bNameUp = \"up\", std::string bNameDn = \"dn\")""",
    doc=r"""Creates the bath of a fully degenerate AIM with the same bath parameters on each arm.

Parameters
----------
eps
     std::vector<double>
     Vector of on-site energies.

V
     std::vector<double>
     Vector of hopping amplitudes to the bath.

blockSize
     int
     Size of each block such that the forktps has 2*blocksize arms.

bNameUp
     std::string (default: up)
     Name of spin-up block.

bNameDn
     std::string (default: dn)
     Name of spin-down block.""",
)

c.add_constructor(
    """(forktps::Dmat eps, forktps::Cmat V, int blockSize, std::string bNameUp = \"up\", std::string bNameDn = \"dn\", bool isOffDiag = false)""",
    doc=r"""Creates the bath of an AIM with different parameters for each arm.

Parameters
----------
eps
     Dmat aka std::vector<std::vector<double>>
     Matrix with on-site energies (one indexed in the second dimension) i.e.: eps[0][3] is the on-site energy of the third bath site on the first arm.

V
     Cmat aka std::vector<std::vector<Complex>>
     Complex matrix of hopping amplitudes (zero indexed in both dimensions).
     i.e., V[0][2] is the amplitude of the hopping of the first impurity site to the third bath site.

blockSize
     int
     Size of each block such that the forktps has 2*blocksize arms

bNameUp
     std::string (default: up)
     Name of spin-up block.

bNameDn
     std::string (default: dn)
     Name of spin-down block.""",
)

c.add_method(
    """int NBath (forktps::triqs_indx indx)""",
    doc=r"""Returns the number of Bath sites on the arm *arm*.""",
)

c.add_method(
    """itensor::Complex V (forktps::triqs_indx indx, int k)""",
    doc=r"""Access diagonal hopping amplitude, equivalent to *V(bName, bIndx, bIndx, k)*.
 The returned value is the amplitude of the hopping onto the impurity (:math:`c^/dagger` operator on impurity),
 while the amplitude onto the bath site is the complex conjugate of this value.

Parameters
----------
indx
     triqs_indx
     Block name and index.

k
     int
     Bath index.""",
)

c.add_method(
    """itensor::Complex V (forktps::triqs_indx indxI, forktps::triqs_indx indxJ, int k)""",
    doc=r"""Access the hopping amplitude between a bath site and an impurity site.
 The bath site is defined by *indxI* and *k* while the impurity site is
 defined by indxJ*.
 The returned value is the amplitude of the hopping ONTO the impurity (:math:`c^/dagger` operator on impurity),
 while the amplitude onto the bath site is the complex conjugate of this value.

Parameters
----------
indxI
     triqs_indx
     Block name and index of bath site.

indxJ
     triqs_indx
     Block name and index of impurity site.

k
     int
     Bath index.""",
)

c.add_method(
    """double eps (forktps::triqs_indx indx, int k)""",
    doc=r"""Returns on-site energy of the bath site in block *bName* defined by *bIndx* and *k*.

Parameters
----------
indx
     triqs_indx
     Block name and index.

k
     int
     Bath index.""",
)

c.add_method(
    """int blockSize (std::string bName)""",
    doc=r"""Returns the size of the block *bName*""",
)

c.add_method(
    """int blockToFTPSIndx (forktps::triqs_indx indx)""",
    doc=r"""Returns the forktps-impurity-index of the triqs_indx *indx*.
 For example the block "up" with bI = 0 is described by the first arm, i.e, it has index 1.""",
)

c.add_method(
    """forktps::triqs_indx FTPSIndxToBlock (int arm)""",
    doc=r"""Returns the forktps-impurity-index of the triqs_indx *indx*.
 For example the block "up" with bI = 0 is described by the first arm, i.e, it has index 1.""",
)

c.add_method(
    """forktps::g_w_t reconstructDelta (gf_mesh<triqs::mesh::refreq> w, double eta)""",
    doc=r"""Calculates and returns the hybridization function defined by the discrete bath.

Parameters
----------
w
     gf_mesh<refreq>
     Real frequency mesh used for the hybridization function.

eta
     double
     Lorentzian broadening used to broaden the delta-peaks.""",
)

c.add_method(
    """void addSite (forktps::triqs_indx indx, double eps, forktps::cvec V)""",
    doc=r"""Adds the bath to the block *indx* and parameters *eps* and *V

Parameters
----------
indx
     triqs_indx
     Block name and index.

eps
     double
     On-site energy  of the site.

V
     std::vector<Complex>
     Hopping parameters of the site.""",
)

c.add_method(
    """std::string hdf5_format ()""",
    is_static=True,
    doc=r"""hdf5 scheme to identify the bath when writing to hdf5.""",
)

c.add_property(
    name="NArms",
    getter=cfunction("int NArms ()"),
    doc=r"""Returns the number of Arms.""",
)

c.add_property(
    name="N",
    getter=cfunction("int N ()"),
    doc=r"""Returns the total Number of sites ( $N= NArms*(NBath +1)$ ).""",
)

c.add_property(
    name="blockNames",
    getter=cfunction("std::vector<std::string> blockNames ()"),
    doc=r"""Returns a vector containing the names of the blocks.""",
)

c.add_property(
    name="blockNameUp",
    getter=cfunction("std::string blockNameUp ()"),
    doc=r"""Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_0".""",
)

c.add_property(
    name="blockNameDn",
    getter=cfunction("std::string blockNameDn ()"),
    doc=r"""Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_1".""",
)

c.add_property(
    name="todiag",
    getter=cfunction("forktps::bath todiag ()"),
    doc=r"""Returns a copy of this bath with only diagonal entries.""",
)

c.add_property(
    name="bandwidth",
    getter=cfunction("forktps::BandWidths bandwidth ()"),
    doc=r"""Returns a BandWidths object containing the bandwidth of each spin-orbital.""",
)

c.add_property(
    name="MakePHSymmetric",
    getter=cfunction("void MakePHSymmetric ()"),
    doc=r"""Enforces particle hole-symmetry by symmetrizing the bath parameters. Fails
 for off-diagonal baths, because in that case no particle hole symmetry
 exists.""",
)

c.add_property(
    name="numNegative",
    getter=cfunction("std::vector<int> numNegative ()"),
    doc=r"""Returns the number of bath sites with negative on-site energy in form of a vector of integers suitable for the FTPS solver.""",
)

c.add_property(
    name="isOffDiag",
    getter=cfunction("bool isOffDiag ()"),
    doc=r"""Determines whether bath is off-diagonal or not by checking all hopping amplitudes.""",
)

c.add_property(
    name="isSpinOrbit",
    getter=cfunction("bool isSpinOrbit ()"),
    doc=r"""Returns true if bath block structure results from spin-orbit coupling.""",
)

c.add_property(
    name="hasOnlyOneBlock", getter=cfunction("bool hasOnlyOneBlock ()"), doc=r""""""
)

c.add_property(
    name="gf_struct",
    getter=cfunction("triqs::hilbert_space::gf_struct_t gf_struct ()"),
    doc=r"""Returns the gf_struct of the bath.""",
)

module.add_class(c)

# The class hloc
c = class_(
    py_type="Hloc",  # name of the python class
    c_type="forktps::hloc",  # name of the C++ class
    doc=r"""Non-interacting impurity Hamiltonian.""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="e",
    c_type="std::map<std::string, array<Complex, 2>>",
    read_only=False,
    doc=r"""Matrix of on-site energies and hopping amplitudes.""",
)

c.add_constructor("""()""", doc=r"""""")

c.add_constructor(
    """(triqs::hilbert_space::gf_struct_t gfstruct, bool SO = false)""",
    doc=r"""Create an empty local Hamiltonian with the block structure give by gfstruct. This is the usual constructer used by triqs.
 All other constructors are for backwards compatibility/convenience. \n
 SO determines how this block structure is interpreted. If false (usual case), one block is a spin-up block while the other represents the spin-down
 degrees of freedom. If true, the block structure is that of a spin-orbit coupled impurity which mixes spin channels.

Parameters
----------
gfstruct
     triqs gf_struct_t
     Definies the block structure and the block names of the bath

SO
     bool (default false)
     If false, use spin-up and spin-down blocks, otherwise use spin-orbit coupled block structure.""",
)

c.add_constructor(
    """(forktps::dvec eps, int blockSize, std::string blockNameUp = \"up\", std::string blockNameDn = \"dn\")""",
    doc=r"""Creates the local Hamiltonian of a fully degenerate AIM with the same bath parameters on each arm.
 Uses the zeroth entry of the vector *eps* as on-site energy.

Parameters
----------
eps
     std::vector<double>
     Zeroth *eps[0]* entry is the on-site energy.

blockSize
     int
     Size of each block such that the forktps has 2*blocksize arms

bNameUp
     std::string (default: up)
     Name of spin-up block.

bNameDn
     std::string (default: dn)
     Name of spin-down block.""",
)

c.add_constructor(
    """(forktps::Dmat eps, int blockSize, std::string blockNameUp = \"up\", std::string blockNameDn = \"dn\")""",
    doc=r"""Creates the local Hamiltonian of a diagonal non-degenerate AIM.
 *eps[i][0]* is the on-site energy of the impurity on the forktps arm *i+1*.

Parameters
----------
eps
     std::vector< std::vector<double> >
     Zeroth *eps[0]* entry is the on-site energy.

blockSize
     int
     Size of each block such that the forktps has 2*blocksize arms

bNameUp
     std::string (default: up)
     Name of spin-up block.

bNameDn
     std::string (default: dn)
     Name of spin-down block.""",
)

c.add_method(
    """void Fill (std::string bName, array<itensor::Complex, 2> e0)""",
    doc=r"""Fills the local Hamiltonian of block *bName* with the matrix *e0*.""",
)

c.add_method(
    """void Fill (array<itensor::Complex, 2> e0)""",
    doc=r"""Fills both blocks of the local Hamiltonian with the matrix *e0*.""",
)

c.add_method(
    """array<itensor::Complex, 2> operator() (std::string bName)""",
    name="__call__",
    doc=r"""Returns the local Hamiltonian of block *bName*.""",
)

c.add_method(
    """itensor::Complex operator() (forktps::triqs_indx indx)""",
    name="__call__",
    doc=r"""Returns on-site energy of block *indx*.""",
)

c.add_method(
    """itensor::Complex operator() (forktps::triqs_indx indxI, forktps::triqs_indx indxJ)""",
    name="__call__",
    doc=r"""Returns matrix entry of hloc between indices *i* and *j*. \n
 For :math:`i==j`: on-site energy. \n
 For :math:`i \neq j`: hopping amplitude of the term :math:`c_i^\dagger c_j` (note order of indices).""",
)

c.add_method(
    """std::string hdf5_format ()""",
    is_static=True,
    doc=r"""hdf5 scheme to identify the local Hamiltonian when writing to hdf5""",
)

c.add_property(
    name="isOffDiag",
    getter=cfunction("bool isOffDiag ()"),
    doc=r"""Checks if off-diagonal hoppings are present, i.e, if $e0(i,j) /neq 0$ for $i /neq j$""",
)

c.add_property(
    name="isSpinOrbit",
    getter=cfunction("bool isSpinOrbit ()"),
    doc=r"""Returns true if h0loc's block structure results from spin-orbit coupling""",
)

c.add_property(
    name="blockNames",
    getter=cfunction("std::vector<std::string> blockNames ()"),
    doc=r"""Returns a vector containing the names of the blocks.""",
)

c.add_property(
    name="blockNameUp",
    getter=cfunction("std::string blockNameUp ()"),
    doc=r"""Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_0".""",
)

c.add_property(
    name="blockNameDn",
    getter=cfunction("std::string blockNameDn ()"),
    doc=r"""Returns the block name of the block with spin down. In case of Spin-orbit coupling, returns "ud_1".""",
)

c.add_property(name="todiag", getter=cfunction("forktps::hloc todiag ()"), doc=r"""""")

module.add_class(c)

# The class tn_approx
c = class_(
    py_type="TnApprox",  # name of the python class
    c_type="forktps::tn_approx",  # name of the C++ class
    doc=r"""Approximation parameters of the forktps tensor network. Sets the truncated weight as well as the maximally allowed bond dimension separately for the three different kinds of links: impurity-impurity, bath-bath and impurity-bath.""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="tw_i",
    c_type="double",
    read_only=False,
    doc=r"""Truncated weight on impurity-impurity links (default $10^{-10}$)""",
)

c.add_member(
    c_name="tw_b",
    c_type="double",
    read_only=False,
    doc=r"""Truncated weight on bath-bath links (default $10^{-10}$)""",
)

c.add_member(
    c_name="tw_ib",
    c_type="double",
    read_only=False,
    doc=r"""Truncated weight on impurity-bath links (default $10^{-10}$)""",
)

c.add_member(
    c_name="maxm_i",
    c_type="int",
    read_only=False,
    doc=r"""Maximal bond dimension on impurity-impurity links (default $200$)""",
)

c.add_member(
    c_name="maxm_b",
    c_type="int",
    read_only=False,
    doc=r"""Maximal bond dimension on bath-bath links (default $500$)""",
)

c.add_member(
    c_name="maxm_ib",
    c_type="int",
    read_only=False,
    doc=r"""Maximal bond dimension on impurity-bath links (default $300$)""",
)

c.add_constructor("""()""", doc=r"""""")

c.add_constructor(
    """(double tr, int maxm)""",
    doc=r"""Constructor setting all truncated weigths to *tw* and all maximal bond dimensions to *maxm

Parameters
----------
tr:
     double
     Value of all truncated weights

maxm:
     int
     Value of all maximal bond dimensions""",
)

c.add_constructor(
    """(int mi, int mb, int mib, double twi, double twb, double twib)""",
    doc=r"""Constructor setting every parameter individually.

Parameters
----------
mi:
     int
     Maximal bond dimension of impurity-impurity links.

mb:
     int
     Maximal bond dimension of bath-bath links.

mib:
     int
     Maximal bond dimension of impurity-bath links.

twi:
     double
     Truncated weight of impurity-impurity links.

twb:
     double
     Truncated weight of bath-bath links.

twib:
     double
     Truncated weight of impurity-bath links.""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class krylov_params
c = class_(
    py_type="KrylovParams",  # name of the python class
    c_type="forktps::krylov_params",  # name of the C++ class
    doc=r"""Parameters for krylov methods. Used in lanczos during DMRG and in Krylov exponentiation TDVP (time evolution).""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="nmax",
    c_type="int",
    read_only=False,
    doc=r"""Maximal number of Krylov vectors generated (default $100$)""",
)

c.add_member(
    c_name="norm_err",
    c_type="double",
    read_only=False,
    doc=r"""Norm of new Krylov vector must be bigger than this value, otherwise terminate the generation of new vectors (default $10^{-13}$)""",
)

c.add_member(
    c_name="conv",
    c_type="double",
    read_only=False,
    doc=r"""Convergence criterium (default $10^{-12}$)""",
)

c.add_constructor("""()""", doc=r"""""")

c.add_constructor(
    """(int nmax, double norm_err, double conv)""",
    doc=r"""Constructor setting every parameter individually.

Parameters
----------
nmax:
     int
     Maximum number of Krylov vectors generated..

norm_err:
     double
     Termination criterea based on norm of new Krylov vector.

conv:
     double
     Convergence criteria.""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class DMRG_prep_params
c = class_(
    py_type="DmrgPrepParams",  # name of the python class
    c_type="forktps::DMRG_prep_params",  # name of the C++ class
    doc=r"""""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(c_name="napp_h", c_type="int", read_only=False, doc=r"""""")

c.add_member(c_name="imag_tevo", c_type="bool", read_only=False, doc=r"""""")

c.add_member(c_name="dtau", c_type="double", read_only=False, doc=r"""""")

c.add_member(c_name="time_steps", c_type="int", read_only=False, doc=r"""""")

c.add_member(c_name="method", c_type="std::string", read_only=False, doc=r"""""")

c.add_constructor("""()""", doc=r"""""")

c.add_constructor("""(int napp_h)""", doc=r"""""")

c.add_constructor(
    """(int napp_h, bool imag_tevo, double dtau, int time_steps, std::string method)""",
    doc=r"""""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class H_int
c = class_(
    py_type="HInt",  # name of the python class
    c_type="forktps::H_int",  # name of the C++ class
    doc=r"""Interaction Hamiltonian. Currently only Kanamori Hamiltonians with and without spin-flip and pair-hopping terms are implemented.

Parameters
----------
U
     :   double

J
     :   double

Up
     :   double

dd_only
     :   bool""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="U",
    c_type="double",
    read_only=False,
    doc=r"""Coulomb repulsion between spin-up and spin-down electrons on the same orbital""",
)

c.add_member(c_name="J", c_type="double", read_only=False, doc=r"""Hund's coupling""")

c.add_member(
    c_name="Up",
    c_type="double",
    read_only=False,
    doc=r"""Coulomb repulsion between spin-up and spin-down electrons on different orbitals (usually Up = U-2J)""",
)

c.add_member(
    c_name="dd_only",
    c_type="bool",
    read_only=False,
    doc=r"""If true, perform the calculations with density-density terms only, i.e., neglect spin-flip and pair hopping terms (default true)""",
)

c.add_constructor("""()""", doc=r"""Default constructor""")

c.add_constructor(
    """(double u)""",
    doc=r"""Creates an *H_int* objects with U=u only, all other parameters are set to zero""",
)

c.add_constructor(
    """(double u, double j, double up, bool dd)""",
    doc=r"""Creates an *H_int* objects with U=u, J=j, Up = up and dd_only = dd""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class DMRG_params
c = class_(
    py_type="DmrgParams",  # name of the python class
    c_type="forktps::DMRG_params",  # name of the C++ class
    doc=r"""Set of parameters used for DMRG calculations.

Parameters
----------
approx
     :   forktps::tn_approx
     Tensor network approximation parameters.

krylov
     :   forktps::krylov_params
     Krylov approximation parameters for the local groundstate search.

sweeps
     :   int
     Number of DMRG sweeps.

napp_h
     :   int
     Number of times the hamiltonian gets applied during DMRG.""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(c_name="approx", c_type="forktps::tn_approx", read_only=False, doc=r"""""")

c.add_member(
    c_name="krylov", c_type="forktps::krylov_params", read_only=False, doc=r""""""
)

c.add_member(
    c_name="prep", c_type="forktps::DMRG_prep_params", read_only=False, doc=r""""""
)

c.add_member(c_name="sweeps", c_type="int", read_only=False, doc=r"""""")

c.add_member(c_name="napp_h", c_type="int", read_only=False, doc=r"""""")


c.add_member(c_name="DMRG_method", c_type="std::string", read_only=False, doc=r"""""")


c.add_constructor("""()""", doc=r"""Default constructor""")

c.add_constructor(
    """(int mi, int mb, int mib, double twi, double twb, double twib, int nmax, double err, double conv, int sw, int nh, std::string dmrg_method)""",
    doc=r"""Constructor setting every parameter except preparation. *m* are bond dimensions, tw are truncated weights, nmax, err and conv are the
   krylov parameters, sw is the number of sweeps and nh the number of applications of H. Kept for backwards compatibility.""",
)

c.add_constructor(
    """(int mi, int mb, int mib, double twi, double twb, double twib,  int nmax, double err, double conv, int sw, int nh, std::string dmrg_method, int prep_nh, bool imag_tevo, double dtau, int time_steps, std::string method)""",
    doc=r"""Constructor setting every parameter including preparation. *m* are bond dimensions, tw are truncated weights, nmax, err and conv are the
   krylov parameters, sw is the number of sweeps and nh the number of applications of H.""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class Tevo_params
c = class_(
    py_type="TevoParams",  # name of the python class
    c_type="forktps::Tevo_params",  # name of the C++ class
    doc=r"""Set of parameters used for the time evolution.

Parameters
----------
dt
     : double
     Size of time step.

time_steps
     : forktps::tn_approx
     Half the number of time steps, i.e., perform *timeSteps* steps for the bra as well as the ket vector

approx
     : forktps::tn_approx
     Tensor network approximation parameters.

krylov
     : forktps::krylov_params
     Krylov approximation parameters for the local matrix exponentiation (only for TDVP).

imag_tevo
     : bool
     If true, perform imaginary time evolution.

method
     : std::string
     Time evolution method, either "TDVP" (default) for single-site TDVP, "TDVP_2" for two-site TDVP or "TEBD" for TEBD-like time evolution using gates. Note "TEBD" only works for diagonal hybridizations..""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(c_name="dt", c_type="double", read_only=False, doc=r"""""")

c.add_member(
    c_name="time_steps",
    c_type="int",
    read_only=False,
    doc=r"""Half number of total time steps i.e.: perform *timeSteps* steps for the bra as well as the ket vector""",
)

c.add_member(
    c_name="TDVPOrder",
    c_type="int",
    read_only=False,
    doc=r"""Order of TDVP integration.""",
)

c.add_member(
    c_name="approx",
    c_type="forktps::tn_approx",
    read_only=False,
    doc=r"""TN approximation""",
)

c.add_member(
    c_name="krylov",
    c_type="forktps::krylov_params",
    read_only=False,
    doc=r"""Krylov parameters for TDVP only""",
)

c.add_member(
    c_name="imag_tevo",
    c_type="bool",
    read_only=False,
    doc=r"""If true, perform imaginary time evolution instead of real time evolution.""",
)

c.add_member(
    c_name="method",
    c_type="std::string",
    read_only=False,
    doc=r"""Method of time evolution, either "TDVP" (default) for single-site TDVP, "TDVP_2" for two-site TDVP or "TEBD" for TEBD-like time evolution using gates. Note "TEBD" only works for diagonal hybridizations.""",
)

c.add_constructor("""()""", doc=r"""""")

c.add_constructor(
    """(double dt, int steps, int order, int mi, int mb, int mib, double twi, double twb, double twib, int nmax, double err, double conv, bool imagT, std::string method)""",
    doc=r"""Constructor for all possible parameters.""",
)

c.add_method("""std::string hdf5_format ()""", is_static=True, doc=r"""""")

module.add_class(c)

# The class solver_core
c = class_(
    py_type="SolverCore",  # name of the python class
    c_type="forktps::solver_core",  # name of the C++ class
    doc=r"""/ The Solver class""",  # doc of the C++ class
    hdf5=True,
)

c.add_member(
    c_name="G_gr",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Greater single particle Greens functions in real time $G_{ij}^{>}(t) = e^{i E_0 t} \langle  c_i e^{-iHt} c_j^\dagger \rangle$""",
)

c.add_member(
    c_name="G_le",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Lesser single particle Greens functions in real time $G_{ij}^{<}(t) = e^{-i E_0 t} \langle  c_j^\dagger e^{iHt} c_i \rangle$""",
)

c.add_member(
    c_name="G_ret",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Retarded single particle Greens functions in real time $G_{ij}^{ret}(t) = -i \Theta(t) \left( G_{ij}^{>}(t) + G_{ij}^{<}(t) \right)$""",
)

c.add_member(
    c_name="F_gr",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Greater Green's function $F_{ij}^{>}(t) = e^{i E_0 t} \langle  [H_{int}, c_i] e^{-iHt} c_j^\dagger \rangle$""",
)

c.add_member(
    c_name="F_le",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Lesser Green's function $F_{ij}^{<}(t) = e^{-i E_0 t} \langle  c_j^\dagger e^{iHt}  [H_{int}, c_i]  \rangle$""",
)

c.add_member(
    c_name="F_ret",
    c_type="std::optional<g_t_t>",
    read_only=False,
    doc=r"""Retarded Green's function $F_{ij}^{ret}(t) = -i \Theta(t) \left( F_{ij}^{>}(t) + F_{ij}^{<}(t) \right)$. Calculate self energy using $\Sigma(\omega) = \frac{-F(\omega)}{G(\omega)}$""",
)

c.add_member(
    c_name="N_t",
    c_type="std::optional<n_t_t>",
    read_only=False,
    doc=r"""Greater density Greens functions in real time $N_{ij}^{>}(t) = e^{i E_0 t} \langle  n_i e^{-iHt} n_j^\dagger \rangle$""",
)

c.add_member(
    c_name="G_w",
    c_type="std::optional<g_w_t>",
    read_only=False,
    doc=r"""Single particle Greens function in energy $G(\omega) = /int G^{ret} exp( i \omega t ) dt$""",
)

c.add_member(
    c_name="F_w",
    c_type="std::optional<g_w_t>",
    read_only=False,
    doc=r"""Greens function in energy $F(\omega) = /int F^{ret} exp( i \omega t ) dt$. Self energy is given by $\Sigma(\omega) = -\frac{F(\omega)}{G(\omega)}$.""",
)

c.add_member(
    c_name="N_w",
    c_type="std::optional<n_w_t>",
    read_only=False,
    doc=r"""Greens function in energy $F(\omega) = /int F^{ret} exp( i \omega t ) dt$. Self energy is given by $\Sigma(\omega) = -\frac{F(\omega)}{G(\omega)}$.""",
)

c.add_member(
    c_name="Sigma_w",
    c_type="std::optional<g_w_t>",
    read_only=False,
    doc=r"""Self-energy $\Sigma(\omega)$""",
)

c.add_member(
    c_name="constr_params",
    c_type="forktps::constr_params_t",
    read_only=False,
    doc=r"""Struct containing the parameters relevant for the solver construction""",
)

c.add_member(
    c_name="last_solve_params",
    c_type="std::optional<solve_params_t>",
    read_only=False,
    doc=r"""Struct containing the parameters relevant for the solve process""",
)

c.add_member(
    c_name="E0",
    c_type="double",
    read_only=False,
    doc=r"""Ground state energy after DMRG""",
)

c.add_member(
    c_name="Ehyb",
    c_type="double",
    read_only=False,
    doc=r"""hybridization energy after DMRG""",
)

c.add_member(
    c_name="Ee0",
    c_type="double",
    read_only=False,
    doc=r"""impurity single-particle energy after DMRG""",
)

c.add_member(
    c_name="Ehint",
    c_type="double",
    read_only=False,
    doc=r"""impurity interaction energy after DMRG""",
)

c.add_member(c_name="GSVariance", c_type="double", read_only=False, doc=r"""""")

c.add_member(
    c_name="b",
    c_type="forktps::bath",
    read_only=False,
    doc=r"""Bath object containing the bath parameters""",
)

c.add_member(
    c_name="e0",
    c_type="forktps::hloc",
    read_only=False,
    doc=r"""Non-interacting impurity Hamiltonian""",
)

c.add_member(
    c_name="Delta_cont_w",
    c_type="forktps::g_w_t",
    read_only=False,
    doc=r"""Bath spectral function from which the bath is calculated""",
)

c.add_member(
    c_name="Delta_recons_w",
    c_type="forktps::g_w_t",
    read_only=False,
    doc=r"""Bath spectral function reconstructed from the bath parameters""",
)

c.add_member(
    c_name="measurement_results",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""Vector containing the results of the measurements defined in solve_params_t's measurements member""",
)

c.add_member(
    c_name="singleParticleDensity",
    c_type="std::vector<std::complex<double>>",
    read_only=False,
    doc=r"""Vector containing the results of the measurements of the single particle density""",
)

c.add_member(
    c_name="NPartGS",
    c_type="std::vector<int>",
    read_only=False,
    doc=r"""Ground state sector of particle number.""",
)

c.add_member(
    c_name="SectorEnergies",
    c_type="std::vector<double>",
    read_only=False,
    doc=r"""For each sector of particle number DMRG searches, stores the energy.""",
)

c.add_member(
    c_name="SectorImpOccs",
    c_type="std::vector<std::vector<double>>",
    read_only=False,
    doc=r"""For each sector of particle number DMRG searches, stores the occupation.""",
)

c.add_member(
    c_name="customGF",
    c_type="array<gf<triqs::mesh::retime, triqs::gfs::scalar_valued>, 1>",
    read_only=False,
    doc=r"""After solve call stores a vector of all custom Green's functions, defined in sovle_params.""",
)

c.add_constructor(
    """(**forktps::constr_params_t)""",
    doc=r"""Construct a FORKTPS solver



+----------------+-----------------------------------+---------+-------------------------------------------+
| Parameter Name | Type                              | Default | Documentation                             |
+================+===================================+=========+===========================================+
| w_min          | double                            | --      | Energy interval borders.                  |
+----------------+-----------------------------------+---------+-------------------------------------------+
| w_max          | double                            | --      | Energy interval borders.                  |
+----------------+-----------------------------------+---------+-------------------------------------------+
| n_w            | int                               | --      | Number of grid points.                    |
+----------------+-----------------------------------+---------+-------------------------------------------+
| gf_struct      | triqs::hilbert_space::gf_struct_t | --      | Block structure of the Green's function.  |
+----------------+-----------------------------------+---------+-------------------------------------------+
""",
)

c.add_method(
    """void solve (**forktps::solve_params_t)""",
    doc=r"""Solve method that performs FORKTPS calculation



+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| Parameter Name    | Type                                                           | Default                       | Documentation                                                                                                                   |
+===================+================================================================+===============================+=================================================================================================================================+
| h_int             | forktps::H_int                                                 | --                            | Interaction Hamiltonian                                                                                                         |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| params_partSector | forktps::DMRG_params                                           | {}                            | DMRG parameters used during the search for the ground state particle number sector.                                             |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| params_GS         | forktps::DMRG_params                                           | {}                            | DMRG parameters used to find the true groundstate once the sector is found.                                                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| NPart             | forktps::Imat                                                  | {}                            | Particle number sector in which GS should be calculated, if none, auto detect sector                                            |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| path_to_gs        | std::optional<std::string>                                     | {}                            | Use ground state from this file is provided.                                                                                    |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| tevo              | forktps::Tevo_params                                           | {}                            |                                                                                                                                 |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| GFs               | std::vector<std::string>                                       | std::vector<std::string>{"S"} | Vector containing all GFs to calculate:  "S" for single particle "F" for self-energy trick "N" for density-density              |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| customGF          | std::vector<std::pair<many_body_operator, many_body_operator>> | {}                            | A list of pairs of TRIQS many-body operators A_i and B_i for which the  Green's function <A_i(t) B_i> should to be calculated.  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| eta               | double                                                         | 0.1                           | Lorentzian broadening during fourier transform                                                                                  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| calc_me           | std::vector<triqs_indx>                                        | {}                            | Vector containing all the Green's functions that need to be calculated. If empty, everything is calculated.                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| measurements      | std::vector<many_body_operator>                                | {}                            | Vector TRIQS many_body_operators for specifying the obeservables measured in the Groundstate.                                   |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| state_storage     | std::string                                                    | ""                            | Path where to stor tevo states, default is execution directory                                                                  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| del_states        | bool                                                           | true                          | If true (default), deletes the states stored to disk after post processing.                                                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
""",
)

c.add_method(
    """void post_process (**forktps::solve_params_t)""",
    doc=r"""Allow the user to retrigger post-processing with the last set of parameters



+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| Parameter Name    | Type                                                           | Default                       | Documentation                                                                                                                   |
+===================+================================================================+===============================+=================================================================================================================================+
| h_int             | forktps::H_int                                                 | --                            | Interaction Hamiltonian                                                                                                         |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| params_partSector | forktps::DMRG_params                                           | {}                            | DMRG parameters used during the search for the ground state particle number sector.                                             |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| params_GS         | forktps::DMRG_params                                           | {}                            | DMRG parameters used to find the true groundstate once the sector is found.                                                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| NPart             | forktps::Imat                                                  | {}                            | Particle number sector in which GS should be calculated, if none, auto detect sector                                            |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| path_to_gs        | std::optional<std::string>                                     | {}                            | Use ground state from this file is provided.                                                                                    |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| tevo              | forktps::Tevo_params                                           | {}                            |                                                                                                                                 |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| GFs               | std::vector<std::string>                                       | std::vector<std::string>{"S"} | Vector containing all GFs to calculate:  "S" for single particle "F" for self-energy trick "N" for density-density              |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| customGF          | std::vector<std::pair<many_body_operator, many_body_operator>> | {}                            | A list of pairs of TRIQS many-body operators A_i and B_i for which the  Green's function <A_i(t) B_i> should to be calculated.  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| eta               | double                                                         | 0.1                           | Lorentzian broadening during fourier transform                                                                                  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| calc_me           | std::vector<triqs_indx>                                        | {}                            | Vector containing all the Green's functions that need to be calculated. If empty, everything is calculated.                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| measurements      | std::vector<many_body_operator>                                | {}                            | Vector TRIQS many_body_operators for specifying the obeservables measured in the Groundstate.                                   |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| state_storage     | std::string                                                    | ""                            | Path where to stor tevo states, default is execution directory                                                                  |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
| del_states        | bool                                                           | true                          | If true (default), deletes the states stored to disk after post processing.                                                     |
+-------------------+----------------------------------------------------------------+-------------------------------+---------------------------------------------------------------------------------------------------------------------------------+
""",
)

c.add_method(
    """std::string hdf5_format ()""",
    is_static=True,
    doc=r"""hdf5_format for storing solver to hdf5""",
)

module.add_class(c)


# Converter for solve_params_t
c = converter_(
    c_type="forktps::solve_params_t",
    doc=r"""The parameters for the solve function""",
)
c.add_member(
    c_name="h_int",
    c_type="forktps::H_int",
    initializer="""  """,
    doc=r"""Interaction Hamiltonian""",
)

c.add_member(
    c_name="params_partSector",
    c_type="forktps::DMRG_params",
    initializer=""" {} """,
    doc=r"""DMRG parameters used during the search for the ground state particle number sector.""",
)

c.add_member(
    c_name="params_GS",
    c_type="forktps::DMRG_params",
    initializer=""" {} """,
    doc=r"""DMRG parameters used to find the true groundstate once the sector is found.""",
)

c.add_member(
    c_name="NPart",
    c_type="forktps::Imat",
    initializer=""" {} """,
    doc=r"""Particle number sector in which GS should be calculated, if none, auto detect sector""",
)

c.add_member(
    c_name="path_to_gs",
    c_type="std::optional<std::string>",
    initializer=""" {} """,
    doc=r"""Use ground state from this file is provided.""",
)

c.add_member(
    c_name="tevo", c_type="forktps::Tevo_params", initializer=""" {} """, doc=r""""""
)

c.add_member(
    c_name="GFs",
    c_type="std::vector<std::string>",
    initializer=""" std::vector<std::string>{"S"} """,
    doc=r"""Vector containing all GFs to calculate:
   "S" for single particle
   "F" for self-energy trick
   "N" for density-density""",
)

c.add_member(
    c_name="customGF",
    c_type="std::vector<std::pair<many_body_operator, many_body_operator>>",
    initializer=""" {} """,
    doc=r"""A list of pairs of TRIQS many-body operators A_i and B_i for which the
     Green's function <A_i(t) B_i> should to be calculated.""",
)

c.add_member(
    c_name="eta",
    c_type="double",
    initializer=""" 0.1 """,
    doc=r"""Lorentzian broadening during fourier transform""",
)

c.add_member(
    c_name="calc_me",
    c_type="std::vector<triqs_indx>",
    initializer=""" {} """,
    doc=r"""Vector containing all the Green's functions that need to be calculated. If empty, everything is calculated.""",
)

c.add_member(
    c_name="measurements",
    c_type="std::vector<many_body_operator>",
    initializer=""" {} """,
    doc=r"""Vector TRIQS many_body_operators for specifying the obeservables measured in the Groundstate.""",
)

c.add_member(
    c_name="state_storage",
    c_type="std::string",
    initializer=""" "" """,
    doc=r"""Path where to stor tevo states, default is execution directory""",
)

c.add_member(
    c_name="del_states",
    c_type="bool",
    initializer=""" true """,
    doc=r"""If true (default), deletes the states stored to disk after post processing.""",
)

c.add_member(
    c_name="calc_gf",
    c_type="bool",
    initializer=""" true """,
    doc=r"""If true (default), calculate Green's function.""",
)

module.add_converter(c)

# Converter for constr_params_t
c = converter_(
    c_type="forktps::constr_params_t",
    doc=r"""Parameters provided at solver construction.""",
)
c.add_member(
    c_name="w_min",
    c_type="double",
    initializer="""  """,
    doc=r"""Energy interval borders.""",
)

c.add_member(
    c_name="w_max",
    c_type="double",
    initializer="""  """,
    doc=r"""Energy interval borders.""",
)

c.add_member(
    c_name="n_w", c_type="int", initializer="""  """, doc=r"""Number of grid points."""
)

c.add_member(
    c_name="gf_struct",
    c_type="triqs::hilbert_space::gf_struct_t",
    initializer="""  """,
    doc=r"""Block structure of the Green's function.""",
)

module.add_converter(c)


module.generate_code()
