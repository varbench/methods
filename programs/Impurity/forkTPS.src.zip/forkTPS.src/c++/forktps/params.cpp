/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************************************/
#include "./params.hpp"
#include "forktps/fork/typenames.hpp"
#include <csignal>
#include <iostream>
#include <h5/h5.hpp>
#include <triqs/utility/exceptions.hpp>

namespace forktps {

  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------
  // ------------------------- Construction params ----------------------------------
  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------

  void h5_write(h5::group h5group, std::string subgroup_name, constr_params_t const &cp) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "wmin", cp.w_min);
    h5_write(grp, "wmax", cp.w_max);
    h5_write(grp, "Nw", cp.n_w);
    h5_write(grp, "gf_struct", cp.gf_struct);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, constr_params_t &cp) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "wmin", cp.w_min);
    h5_read(grp, "wmax", cp.w_max);
    h5_read(grp, "Nw", cp.n_w);
    h5_read_gf_struct(grp, "gf_struct", cp.gf_struct);
  }

  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------
  // -------------------------------- Solve params ----------------------------------
  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------

  // --------------------------------------------------------------------------------
  // ----------------------------- TN_approx ----------------------------------------

  tn_approx::tn_approx(int mi, int mb, int mib, double twi, double twb, double twib)
     : tw_i(twi), tw_b(twb), tw_ib(twib), maxm_i(mi), maxm_b(mb), maxm_ib(mib) {}

  void h5_write(h5::group h5group, std::string subgroup_name, tn_approx const &tw) {
    auto grp = h5group.create_group(subgroup_name);
    h5_write(grp, "maxm_i", tw.maxm_i);
    h5_write(grp, "maxm_b", tw.maxm_b);
    h5_write(grp, "maxm_ib", tw.maxm_ib);

    h5_write(grp, "twI", tw.tw_i);
    h5_write(grp, "twB", tw.tw_b);
    h5_write(grp, "twIB", tw.tw_ib);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, tn_approx &tw) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "maxm_i", tw.maxm_i);
    h5_read(grp, "maxm_b", tw.maxm_b);
    h5_read(grp, "maxm_ib", tw.maxm_ib);

    h5_read(grp, "twI", tw.tw_i);
    h5_read(grp, "twB", tw.tw_b);
    h5_read(grp, "twIB", tw.tw_ib);
  }

  std::ostream &operator<<(std::ostream &os, const tn_approx &tw) {
    os << "Tensor Network Approximation Parameters:\n";
    os << "   Truncated weights (Imp-Imp, Imp-Bath, Bath-Bath): " << tw.tw_i << " " << tw.tw_ib << " " << tw.tw_b << "\n";
    os << "   Maximum bond dims (Imp-Imp, Imp-Bath, Bath-Bath): " << tw.maxm_i << " " << tw.maxm_ib << " " << tw.maxm_b << "\n";
    return os;
  }

  // --------------------------------------------------------------------------------
  // ----------------------------- Krylov params ------------------------------------

  krylov_params::krylov_params(int nmax, double norm_err, double conv) : nmax(nmax), norm_err(norm_err), conv(conv) {}

  void h5_write(h5::group h5group, std::string subgroup_name, krylov_params const &kp) {
    auto grp = h5group.create_group(subgroup_name);
    h5_write(grp, "nmax", kp.nmax);
    h5_write(grp, "norm_err", kp.norm_err);
    h5_write(grp, "Convergence", kp.conv);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, krylov_params &kp) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "nmax", kp.nmax);
    h5_read(grp, "norm_err", kp.norm_err);
    h5_read(grp, "Convergence", kp.conv);
  }

  std::ostream &operator<<(std::ostream &os, const krylov_params &kp) {

    os << "Krylov Parameters:\n";
    os << "   Number of Krylov vectors: " << kp.nmax << "\n   Convergence Criterium: " << kp.conv << "\n   Krylov Vector Norm Termination Criterium "
       << kp.norm_err << "\n";

    return os;
  }

  // --------------------------------------------------------------------------------
  // --------------------------------- H_int ----------------------------------------
  bool H_int::operator!() const {
    if (std::abs(U) > TOOSMALL) return false;
    if (std::abs(J) > TOOSMALL) return false;
    if (std::abs(Up) > TOOSMALL) return false;

    return true;
  }

  std::ostream &operator<<(std::ostream &os, const H_int &h_int) {
    std::string sfph;
    if (h_int.dd_only) {
      sfph = " excluding SF and PH.";
    } else {
      sfph = " including SF and PH.";
    };
    os << "Interaction parameters: "
       << "U = " << h_int.U << " J = " << h_int.J << " Up = " << h_int.Up << sfph << std::endl;
    return os;
  }

  void h5_write(h5::group h5group, std::string subgroup_name, H_int const &h_int) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "U", h_int.U);
    h5_write(grp, "J", h_int.J);
    h5_write(grp, "Up", h_int.Up);
    h5_write(grp, "dd_only", h_int.dd_only);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, H_int &h_int) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "U", h_int.U);
    h5_read(grp, "J", h_int.J);
    h5_read(grp, "Up", h_int.Up);
    h5_read(grp, "dd_only", h_int.dd_only);
  }

  // --------------------------------------------------------------------------------
  // --------------------------------- DMRG_prep_params ----------------------------------

  DMRG_prep_params::DMRG_prep_params(int napp_h) : napp_h(napp_h){};

  DMRG_prep_params::DMRG_prep_params(int napp_h, bool imag_tevo, double dt, int steps, std::string meth) : napp_h(napp_h), imag_tevo(imag_tevo) {
    // tevo are optional so only set them if needed
    if (imag_tevo == true) {
      this->dtau       = dt;
      this->time_steps = steps;
      this->method     = meth;
    }
  };

  void h5_write(h5::group h5group, std::string subgroup_name, const DMRG_prep_params &p) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "NAppH", p.napp_h);
    h5_write(grp, "ImagTevo", p.imag_tevo);
    h5_write(grp, "dtau", p.dtau);
    h5_write(grp, "NTimeSteps", p.time_steps);
    h5_write(grp, "TevoMethod", p.method);
  };

  void h5_read(h5::group h5group, std::string subgroup_name, DMRG_prep_params &p) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "NAppH", p.napp_h);
    h5_read(grp, "ImagTevo", p.imag_tevo);
    h5_read(grp, "dtau", p.dtau);
    h5_read(grp, "NTimeSteps", p.time_steps);
    h5_read(grp, "TevoMethod", p.method);
  };

  std::ostream &operator<<(std::ostream &os, const DMRG_prep_params &dmrg_pp) {
    os << "DMRG Preparation Parameters:\n"
       << "   Number of times Hamiltonian is applied: " << dmrg_pp.napp_h
       << "\n   Doing imaginary-time evolution: " << (dmrg_pp.imag_tevo ? "true" : "false") << "\n";
    if (dmrg_pp.imag_tevo)
      os << "      Number of time steps: " << dmrg_pp.time_steps << " of size " << dmrg_pp.dtau << " using the " << dmrg_pp.method << " algorithm\n";

    return os;
  }

  // --------------------------------------------------------------------------------
  // --------------------------------- DMRG_params ----------------------------------

  DMRG_params::DMRG_params() : approx(), krylov(), prep(), sweeps(15), napp_h(0), DMRG_method("SSImp"){};

  DMRG_params::DMRG_params(int mi, int mb, int mib,             // maxm
                           double twi, double twb, double twib, //tws
                           int nmax, double err, double conv,   // krylov
                           int sw, int nh, std::string dmrg_method)
     : // other
       approx(),
       krylov(),
       prep(),
       sweeps(sw),
       napp_h(nh),
       DMRG_method(std::move(dmrg_method)) {

    if (DMRG_method != "SSImp" && DMRG_method != "TwoSite") { TRIQS_RUNTIME_ERROR << "Invalid DMRG method provided"; }

    approx.maxm_i  = mi;
    approx.maxm_b  = mb;
    approx.maxm_ib = mib;

    approx.tw_i  = twi;
    approx.tw_b  = twb;
    approx.tw_ib = twib;

    krylov.nmax     = nmax;
    krylov.norm_err = err;
    krylov.conv     = conv;
  }

  DMRG_params::DMRG_params(int mi, int mb, int mib,                 // maxm
                           double twi, double twb, double twib,     //tws
                           int nmax, double err, double conv,       // krylov
                           int sw, int nh, std::string dmrg_method, // other
                           int prep_nh, bool imag_tevo, double dtau, int time_steps, std::string prep_method)
     : // prep
       approx(mi, mb, mib, twi, twb, twib),
       krylov(nmax, err, conv),
       prep(prep_nh, imag_tevo, dtau, time_steps, prep_method),
       sweeps(sw),
       napp_h(nh),
       DMRG_method(std::move(dmrg_method)) {
    if (DMRG_method != "SSImp" && DMRG_method != "TwoSite") { TRIQS_RUNTIME_ERROR << "Invalid DMRG method provided"; }
  }

  void h5_write(h5::group h5group, std::string subgroup_name, DMRG_params const &dmrg_p) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "TNApprox", dmrg_p.approx);
    h5_write(grp, "KrylovApprox", dmrg_p.krylov);
    h5_write(grp, "PrepParams", dmrg_p.prep);
    h5_write(grp, "Nsweeps", dmrg_p.sweeps);
    h5_write(grp, "NAppH", dmrg_p.napp_h);
    h5_write(grp, "DMRG_Method", dmrg_p.DMRG_method);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, DMRG_params &dmrg_p) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "TNApprox", dmrg_p.approx);
    h5_read(grp, "KrylovApprox", dmrg_p.krylov);
    h5_try_read(grp, "PrepParams", dmrg_p.prep); // try read for backwards comp.
    h5_read(grp, "Nsweeps", dmrg_p.sweeps);
    h5_read(grp, "NAppH", dmrg_p.napp_h);
    h5_try_read(grp, "DMRG_Method", dmrg_p.DMRG_method);
  }

  std::ostream &operator<<(std::ostream &os, const DMRG_params &dmrg_p) {

    //TODO
    os << "\n\nParameters of a DMRG calculation: \n"
       << "Perform " << dmrg_p.sweeps << " sweeps with method " << dmrg_p.DMRG_method << " and apply H " << dmrg_p.napp_h << " times during DMRG.\n";

    os << "Other parameters include: \n" << dmrg_p.approx << dmrg_p.krylov << dmrg_p.prep << "\n";
    ;

    return os;
  }

  // --------------------------------------------------------------------------------
  // --------------------------------- Tevo_params ----------------------------------
  Tevo_params::Tevo_params() : dt(0.1), time_steps(30) {}

  Tevo_params::Tevo_params(double dt, int steps, int order, int mi, int mb, int mib, double twi, double twb, double twib, int nmax, double err,
                           double conv, bool imagT, std::string meth)
     : dt(dt), time_steps(steps), TDVPOrder(order), imag_tevo(imagT), method(std::move(meth)) {
    approx.maxm_i  = mi;
    approx.maxm_b  = mb;
    approx.maxm_ib = mib;

    approx.tw_i  = twi;
    approx.tw_b  = twb;
    approx.tw_ib = twib;

    krylov.nmax     = nmax;
    krylov.norm_err = err;
    krylov.conv     = conv;
  }

  void h5_write(h5::group h5group, std::string subgroup_name, Tevo_params const &tevo_p) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "TNApprox", tevo_p.approx);
    h5_write(grp, "KrylovApprox", tevo_p.krylov);
    h5_write(grp, "dt", tevo_p.dt);
    h5_write(grp, "NTimeSteps", tevo_p.time_steps);
    h5_write(grp, "TevoMethod", tevo_p.method);
    h5_write(grp, "ImagTevo", tevo_p.imag_tevo);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, Tevo_params &tevo_p) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "TNApprox", tevo_p.approx);
    h5_read(grp, "KrylovApprox", tevo_p.krylov);
    h5_read(grp, "dt", tevo_p.dt);
    h5_read(grp, "NTimeSteps", tevo_p.time_steps);
    h5_read(grp, "TevoMethod", tevo_p.method);
    h5_read(grp, "ImagTevo", tevo_p.imag_tevo);
  }

  std::ostream &operator<<(std::ostream &os, const Tevo_params &tevo_p) {
    os << "Time Evolution Parameters: \n"
       << "Perform " << ((tevo_p.imag_tevo) ? "imaginary " : "real ") << "time evolution doing " << tevo_p.time_steps << " time steps of size "
       << tevo_p.dt << " using the " << tevo_p.method << " algorithm\n";

    os << "Other parameters include: \n" << tevo_p.approx << tevo_p.krylov << "\n";

    return os;
  }

  // --------------------------------------------------------------------------------
  // ----------------------------- Solve Params -------------------------------------
  // clang-format off
  void h5_write(h5::group h5group, std::string subgroup_name, solve_params_t const &sp) {
    auto grp = h5group.create_group(subgroup_name);

    //model
    h5_write(grp, "Hint", sp.h_int);

    //GS
    h5_write(grp, "DMRG_paramsSS",            sp.params_partSector);
    h5_write(grp, "DMRG_paramsGS",            sp.params_GS);

    h5_write(grp, "NPart",                    sp.NPart);

    //tevo
    h5_write(grp, "Tevo_params",  sp.tevo);
    
    //other
    h5_write(grp, "eta",            sp.eta);
    h5_write(grp, "calc_me",            sp.calc_me);
    h5_write(grp, "measurements",       sp.measurements);
    h5_write(grp, "StateStorageFolder", sp.state_storage);
    h5_write(grp, "DeleteStates",       sp.del_states);


    // new
    h5_write(grp, "PathToGS",     sp.path_to_gs);
    h5_write(grp, "GFs", sp.GFs);
    h5_write(grp, "customGFOperators", sp.customGF);
    
  }

  void h5_read(h5::group h5group, std::string subgroup_name, solve_params_t &sp) {
    auto grp = h5group.open_group(subgroup_name);
    // Take care! Do not read verbosity as they should be different based on mpi rank
    h5_read(grp, "Hint", sp.h_int);

    //GS
    h5_try_read(grp, "DMRG_paramsSS",  sp.params_partSector);
    h5_try_read(grp, "DMRG_paramsGS",  sp.params_GS);
    std::cout<<"Reading of NPart and measurements temporarily disabled!!!"<<std::endl;
    //h5_try_read(grp,     "NPart",                     sp.NPart);

    //tevo
    h5_try_read(grp, "Tevo_params",  sp.tevo);
    
    //other
    h5_read(grp, "eta",                    sp.eta);
    h5_read(grp,     "calc_me",            sp.calc_me);
    //h5_try_read(grp, "measurements",       sp.measurements);
    h5_try_read(grp, "StateStorageFolder", sp.state_storage);
    h5_try_read(grp, "DeleteStates",       sp.del_states);

    // new
    h5_try_read(grp, "PathToGS",          sp.path_to_gs);
    h5_try_read(grp, "GFs",               sp.GFs);
    h5_try_read(grp, "customGFOperators", sp.customGF);
  }

  std::ostream& operator << (std::ostream& os, const solve_params_t& sp ){
    os << "Solve Parameters: \n";
    os << "  --------------------------------------------------------------";
    os << "---------------------------------------------------------------- \n";

    os << "    "<<sp.h_int <<std::endl; 

    if(!sp.path_to_gs){
      os << "    GS-search is performed using "<< sp.params_GS.sweeps<<" sweeps with method "<< sp.params_GS.DMRG_method <<" and parameters:\n";
      os << "      tw_I:  " << sp.params_GS.approx.tw_i  << " maxmI:  "<< sp.params_GS.approx.maxm_i  <<std::endl;
      os << "      tw_IB: " << sp.params_GS.approx.tw_ib << " maxmIB: "<< sp.params_GS.approx.maxm_ib <<std::endl;
      os << "      tw_B:  " << sp.params_GS.approx.tw_b  << " maxmB:  "<< sp.params_GS.approx.maxm_b  <<std::endl;

      
      if(sp.NPart.size() > 0 ){
        os << "    For the particle number sector use: "<<std::endl;
        for(auto vec : sp.NPart){
          os<< "                                       ";
          for(auto val : vec){
            os << val<< " " ;
          }
          os << std::endl;
        }
      }
    }
    else{
      os << "    Read in ground state from file: " <<  *sp.path_to_gs <<std::endl;
    }
    
    os <<std::endl<< "    Time evolution method: "<< sp.tevo.method << " to perform ";
    if(sp.tevo.imag_tevo){
      os << "imaginary time evolution" <<std::endl;
    }
    else{
      os << "real time evolution" <<std::endl;
    }
    os << "    Number of time steps: "<<sp.tevo.time_steps << " with step size: "<<sp.tevo.dt <<std::endl;
    os << "    Use the following approximation paramters:\n"; 
    os << "      tw_I:  " << sp.tevo.approx.tw_i  << " maxmI:  "<< sp.tevo.approx.maxm_i  <<std::endl;
    os << "      tw_IB: " << sp.tevo.approx.tw_ib << " maxmIB: "<< sp.tevo.approx.maxm_ib <<std::endl;
    os << "      tw_B:  " << sp.tevo.approx.tw_b  << " maxmB:  "<< sp.tevo.approx.maxm_b  <<std::endl;
    if(sp.calc_me.size() == 0){
      os <<"    Calcule Green's function on all blocks/indices.\n";
    }
    else{
      os <<"    Calcule Green's function on the following blocks/indices:\n";
      for(auto cm : sp.calc_me)
        os <<"       "<< cm.first<< " "<<cm.second << std::endl;
    }

    // print which GFs to do
    for(auto gf : sp.GFs){
      if     (gf=="S")  os << "    Calculate single-particle Green's function\n";
      else if(gf=="F")  os << "    Calculate self-energy Green's function\n";
      else if(gf=="N")  os << "    Calculate density-density Green's function\n";
      else              os << "    Invalid Green's function provided\n"; 
    }

    if(sp.customGF.size()>0){
      os << "    Also calculate custom Green's function(s) <A(t)B>:\n";
      for(auto opPair : sp.customGF) os << "     A = "<< opPair.first << "\n     B = " << opPair.second<<"\n\n";
    }

    //std::cout << sp.customGF.at(0).first <<std::endl;
    
    os << "  --------------------------------------------------------------";
    os << "---------------------------------------------------------------- \n";
    os << "  --------------------------------------------------------------";
    os << "---------------------------------------------------------------- \n";
    return os;
  }
  // clang-format on
} // namespace forktps
