#include <forktps/params.hpp>
//#include <forktps/setargs.hpp>
#include <forktps/fork/BasisExpansion.hpp>
#include <forktps/finiteT_solver_core.hpp>
#include <forktps/fork/makros.hpp>
#include <stdio.h>
#include <iostream>
#include <filesystem>
#include <cstdint>

using namespace itensor;
namespace forktps {

  // Constructor definition for the finiteT_solver_core class, which takes a reference to a
  // finiteT_constr_params_t object as an input parameter and initializes the constr_params member
  // with the provided input parameter.
  finiteT_solver_core::finiteT_solver_core(finiteT_constr_params_t const &p) : constr_params(p) {
    // Check if the MPI environment is already initialized.
    int initialized = 0;
    MPI_Initialized(&initialized);

    // If the MPI environment is not initialized, initialize it.
    if (!initialized) MPI_Init(nullptr, nullptr);

    // Create a vector of char to store the file name.
    std::vector<char> nameContainer;

    // Get the current time as a string and store it in timeString.
    std::string timeString = currenttime();

    // Create the base file name for intermediate data storage using the current time.
    fileNameIntermedia = "SamplingInfo-";

    // Check if the sampling folder is provided in the construction parameters.
    if (constr_params.samplingFolder == "") {
      // If not provided, concatenate the timeString to the base file name.
      fileNameIntermedia += timeString;

      // Copy the file name to the nameContainer vector.
      std::copy(fileNameIntermedia.begin(), fileNameIntermedia.end(), std::back_inserter(nameContainer));

      // Synchronize all MPI processes using a barrier.
      world.barrier(0);

      // Broadcast the nameContainer to all MPI processes.
      mpi::broadcast(nameContainer);

      // Reconstruct the fileNameIntermedia string from the broadcasted nameContainer.
      fileNameIntermedia = "";
      for (auto const &c : nameContainer) { fileNameIntermedia.push_back(c); }
    } else {
      // If the sampling folder is provided, append it to the base file name.
      fileNameIntermedia = "SamplingInfo-" + constr_params.samplingFolder;
    }

    // If the current MPI process is the master process (rank 0), create a directory for the intermediate file.
    if (world.rank() == 0) { CreateDir(fileNameIntermedia); };

    // Output a message indicating the initialization of the finite_solver_core with the current time.
    ReportOnce("finite_solver_core initialized at ", timeString, "\n");

    // Output a message indicating the number of MPI processes (ranks) being used for the calculation.
    ReportOnce("Calculation are performed with ", world.size(), " ranks \n");

    // Output a message indicating the location where the intermediate sampling information will be stored.
    ReportOnce("The intermedia sampling information are stored in ", fileNameIntermedia, "\n");
  };

  //solve the impurity proble by METTS sampling
  void finiteT_solver_core::solve(finiteT_solve_params_t const &solve_params_) {
    //combined parameters
    finiteT_params_t params(constr_params, solve_params_);
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    args.add("SVDMethod", "ITensor"); //"ITensor" , "gesdd" ,"gesvd");
    ReportOnce("args::\n", args, "\n");
    E0Shift = 0.0;

    //a quick dmrg to check the input Hamiltonian
    if (params.quickDMRG.quickDMRG && world.rank() == 0) { E0Shift = QuickDMRG(params); };
    world.barrier(0);
    mpi::broadcast(E0Shift);

    //generate the time grid elin/xponetial grid has the follow data
    //[0, t0* lam^0, t0 * lam^1, t0 * lam^2, ..., t0*lam^{N-1}] -> N+1 elements
    //with t0*lam^{N-1} = beta/2
    int evoSteps = 0;
    evoSteps     = std::round(params.beta / params.tevo.dt / 2.);
    tListLin.resize(evoSteps + 1, 0.);
    tListLin.at(0) = 0.0;
    for (int step(0); step < evoSteps; step++) { tListLin.at(step + 1) = double(step + 1) * params.tevo.dt; }
    //the total time grid for the Green's function has 2*N+1 points
    TimeGrid.resize(evoSteps * 2 + 1);
    for (int idx(0); idx < evoSteps; idx++) {
      TimeGrid.at(idx)       = tListLin.at(idx);
      TimeGrid.rbegin()[idx] = params.beta - tListLin.at(idx);
    }
    TimeGrid.at(evoSteps) = tListLin.at(evoSteps);

    //the exponential grid
    evoSteps = params.sampling.exp_grid_steps;
    tListExp.resize(evoSteps + 1, 0.);
    tListExp.at(0) = 0.0;
    double t0Exp   = 0.05;
    double lam     = pow(params.beta / 2. / t0Exp, 1. / (double(evoSteps) - 1.));
    for (int step(0); step < evoSteps; step++) { tListExp.at(step + 1) = t0Exp * pow(lam, step); };
    tListExp = spareExpTimeGrid(tListExp);
    ReportOnce("--- the exponential grid has ", tListExp.size(), " points.\n");
    if (params.verbose > 1) { ReportOnce("\t with values ::\n", tListExp, "\n"); }
    //check the purification threshold is in [0., 1]
    if (params.sampling.purification_threshold < 0.0 || params.sampling.purification_threshold > 1) {
      Error("The purification threshold SHOULD in [0.0, 1.0] with 0.0 to leave all bath sites unpurified while 1 to purify all bath sites");
    };

    // an initial sites object which will be overwritten if new purificed bath sites are asign
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    doubledBath = DeterminePurificeBathSitesEachOrb(params);

    //reassign the sites and state object
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    if (params.verbose >= 1) {
      ReportOnce("bath information :: ", " total bath sites = ", b.N(), ", #num of arms = ", b.NArms(), "\n");
      ReportOnce("\n--- there are ", doubledBath.size(), " (", b.N() - b.NArms(), ") purified bath sites :: \n");
      for (auto site : doubledBath) { ReportOnce(site, "\t"); }
      ReportOnce("\n--- and the imputities are ", params.impPurified ? "Purified " : " not purified\n");
    }

    E0Shift = 0.0;
    if (params.verbose >= 1) { ReportOnce("Rough estimation of E0Shift is ", E0Shift, "\n"); }
    //FTPOs
    H               = whichFTPO(params, sites);
    HeffState       = ForkLocalOp(H);
    auto E0ShiftOri = E0Shift;
    //check e0
    {
      for (auto block : params.gf_struct) {
        for (int iorb(0); iorb < block.second; iorb++) {
          for (int jorb(0); jorb < block.second; jorb++) {
            ReportOnce(block.first, " , e0[", iorb, ", ", jorb, "]=", e0.e.at(block.first)(iorb, jorb), "\n");
          }
        }
      }
    }
    Huni = H;

    //initialize a product state with impuritiy sites and
    // bath sites in doubledBath will be in (|01> + |10>)
    InitState init(sites, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init.set(sites.ArmToSite(arm, k + 1), "Occ");
        }
      }
      //the impurity sites are  purified or not
      if (params.impPurified) {
        init.set(sites.ImpSite(arm), "01");
      } else {
        std::random_device rd;
        std::mt19937 RNG(rd()); //
        std::uniform_real_distribution<double> Uniform(0., 1.);
        auto randomNumber = Uniform(RNG);
        //init.set(sites.ImpSite(arm), randomNumber >= 0.5 ? "Occ" : "Emp");
        if (world.rank() % 2 == 0) {
          init.set(sites.ImpSite(arm), arm % 2 == 0 ? "Emp" : "Occ");
        } else {
          init.set(sites.ImpSite(arm), arm % 2 == 0 ? "Occ" : "Emp");
        }
      }
    }
    for (auto site : doubledBath) { init.set(site, "01"); };

    //initialize the state
    state = ForkTPS(init, sites.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(state, sites, doubledBath);
    world.barrier(0);
    state.normalizeLim();

    //construct the operatore for basis expansion 1 - dt*H
    // dt is estimated by the product state energy
    auto Heff_ = ForkLocalOp(H);
    Heff_.position(1, state);
    double energy_ = std::real(Heff_.ContractAll(state));
    HBasis         = taylorFTPO(params, b, e0, 1. / abs(energy_));

    //the default time grid is the even time grid
    tList = tListLin;

    //thermalization
    HeffState = ForkLocalOp(H);
    if (params.sampling.n_thermal > 0) {
      // determine the time grid
      if (params.timeGrid == "Even") {
        tList = tListLin;
      } else if (params.timeGrid == "Exp") {
        tList = tListExp;
      } else {
        Error("@solver, wrong time grid option (Even or Exp)");
      }
      ThermalizeUnitary(params);
      //reassign E0Shift base on the thermalization states
      world.barrier(0);
      E0Shift = 0.0;
      if (params.verbose >= 1) { ReportOnce("----- E0Shift from thermalization energy is ", E0Shift, "\n"); }
    };
    world.barrier(0);

    //Monte Carlo Sampling
    //if we use an exponential time grid, the we need to evaluate both e^{-tau H} and e^{tau H}, hence,
    //we should not shift the zero energy position in such case
    // reassign the FTPO of H based on the new E0Shift from thermalization (currently, E0Shift is set to 0.0)
    H = whichFTPO(params, sites);

    // effective Hamiltonians
    HeffState = ForkLocalOp(H);
    HeffGr    = ForkLocalOp(H);
    HeffLe    = ForkLocalOp(H);
    HeffGrb   = ForkLocalOp(H);
    HeffLeb   = ForkLocalOp(H);

    //measure green's function and statics quantities, also store the bond growth, and the distribution of the norm and repeated count
    if (params.calc_me.size() != 0) {

      SamplingUnitaryMPISplit(params);
      // Collect the final results and perform MPI communication.
      world.barrier(0);
      G_tau               = mpi::all_reduce(G_tau, world);
      BondGrowthAve       = mpi::all_reduce(BondGrowthAve, world);
      MeasuredStatic      = mpi::all_reduce(MeasuredStatic, world);
      G_tau_by_norm       = mpi::all_reduce(G_tau_by_norm, world);
      DistributionCount   = mpi::all_reduce(DistributionCount, world);
      DistributionLogNorm = mpi::all_reduce(DistributionLogNorm, world);

      totalCount = mpi::all_reduce(totalCount, world) / params.calc_me.size();
      ReportOnce("\t total count ::", totalCount);
      G_tau /= double(totalCount);
      for (auto &ele : BondGrowthAve) { ele /= double(totalCount * params.calc_me.size()); }
      for (auto &ele : MeasuredStatic) { ele /= double(totalCount * params.calc_me.size()); }

      // broadcast the final results to all nodes.
      mpi::broadcast(G_tau);
      mpi::broadcast(BondGrowthAve);
      mpi::broadcast(MeasuredStatic);
      mpi::broadcast(DistributionCount);
      mpi::broadcast(DistributionLogNorm);

      //collect the variance of the green's function
      gf_mesh<imtime> meshImTau_(params.beta, Fermion, TimeGrid.size());
      g_tau_t G_tau_var_node(meshImTau_, params.gf_struct);
      for (auto ginfo : g_tau_list_info) {
        int iblock = 0;
        for (auto block : params.gf_struct) {
          for (auto tau : meshImTau_) {
            for (int iorb(0); iorb < block.second; iorb++) {
              for (int jorb(0); jorb < block.second; jorb++) {
                auto value_ = ginfo.second[iblock][tau](iorb, jorb);
                if (abs(value_) >= 1E-4) {
                  auto ele = G_tau[iblock][tau](iorb, jorb) - value_;
                  G_tau_var_node[iblock][tau](iorb, jorb) += ginfo.first * ele * conj(ele);
                }
              }
            } //end for block
          }   //end for tau
          iblock += 1;
        }
      }
      G_tau_var_node = mpi::all_reduce(G_tau_var_node, world);
      G_tau_var      = G_tau_var_node;
      G_tau_var /= totalCount;
    }
    // Collect additional sampling information and synchronize MPI processes.
    CollectSamplingInfo();
    world.barrier(0);
  };

  //solve the impurity proble by METTS sampling on a given DLR grid
  void finiteT_solver_core::solveDLR(finiteT_solve_params_t const &solve_params_) {
    //combined parameters
    finiteT_params_t params(constr_params, solve_params_);
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    args.add("SVDMethod", "ITensor"); //"ITensor" , "gesdd" ,"gesvd");
    ReportOnce("args::\n", args, "\n");
    E0Shift = 0.0;

    //a quick dmrg to check the input Hamiltonian
    if (params.quickDMRG.quickDMRG && world.rank() == 0) { E0Shift = QuickDMRG(params); };
    world.barrier(0);
    mpi::broadcast(E0Shift);

    tListDLR = spareExpTimeGrid(params.tau_grid);
    //regulate the time grid
    for (auto t_ : params.tau_grid) { tListDLR.push_back(params.beta / 2.0 - t_ / 2.0); }
    tListDLR.push_back(params.beta / 2.0);
    tListDLR.push_back(0.0);
    std::sort(tListDLR.begin(), tListDLR.end());

    ReportOnce("--- the time evolution grid has ", tListDLR.size(), " points.\n");
    if (params.verbose > 1) { ReportOnce("\t with values ::\n", tListDLR, "\n"); }
    int evoSteps = params.tau_grid.size();
    //the total time grid for the Green's function has 2*N points, DO NOT include beta/2
    TimeGrid.resize(evoSteps * 2);
    for (int idx(0); idx < evoSteps; idx++) {
      TimeGrid.at(idx)       = params.tau_grid.at(idx);
      TimeGrid.rbegin()[idx] = params.beta - params.tau_grid.at(idx);
    }
    if (params.verbose > 1) { ReportOnce("\t The actual tau grid is ::\n", TimeGrid, "\n"); }

    //check the purification threshold is in [0., 1]
    if (params.sampling.purification_threshold < 0.0 || params.sampling.purification_threshold > 1) {
      Error("The purification threshold SHOULD in [0.0, 1.0] with 0.0 to leave all bath sites unpurified while 1 to purify all bath sites");
    };

    // an initial sites object which will be overwritten if new purificed bath sites are asign
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    doubledBath = DeterminePurificeBathSitesEachOrb(params);

    //reassign the sites and state object
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    if (params.verbose >= 1) {
      ReportOnce("bath information :: ", " total bath sites = ", b.N(), ", #num of arms = ", b.NArms(), "\n");
      ReportOnce("\n--- there are ", doubledBath.size(), " (", b.N() - b.NArms(), ") purified bath sites :: \n");
      for (auto site : doubledBath) { ReportOnce(site, "\t"); }
      ReportOnce("\n--- and the imputities are ", params.impPurified ? "Purified " : " not purified\n");
    }

    E0Shift = 0.0;
    if (params.verbose >= 1) { ReportOnce("Rough estimation of E0Shift is ", E0Shift, "\n"); }
    //FTPOs
    H               = whichFTPO(params, sites);
    HeffState       = ForkLocalOp(H);
    auto E0ShiftOri = E0Shift;
    //check e0
    {
      for (auto block : params.gf_struct) {
        for (int iorb(0); iorb < block.second; iorb++) {
          for (int jorb(0); jorb < block.second; jorb++) {
            ReportOnce(block.first, " , e0[", iorb, ", ", jorb, "]=", e0.e.at(block.first)(iorb, jorb), "\n");
          }
        }
      }
    }
    Huni = H;

    //initialize a product state with impuritiy sites and
    // bath sites in doubledBath will be in (|01> + |10>)
    InitState init(sites, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init.set(sites.ArmToSite(arm, k + 1), "Occ");
        }
      }
      //the impurity sites are  purified or not
      if (params.impPurified) {
        init.set(sites.ImpSite(arm), "01");
      } else {
        std::random_device rd;
        std::mt19937 RNG(rd()); //
        std::uniform_real_distribution<double> Uniform(0., 1.);
        auto randomNumber = Uniform(RNG);
        //init.set(sites.ImpSite(arm), randomNumber >= 0.5 ? "Occ" : "Emp");
        if (world.rank() % 2 == 0) {
          init.set(sites.ImpSite(arm), arm % 2 == 0 ? "Emp" : "Occ");
        } else {
          init.set(sites.ImpSite(arm), arm % 2 == 0 ? "Occ" : "Emp");
        }
      }
    }
    for (auto site : doubledBath) { init.set(site, "01"); };

    //initialize the state
    state = ForkTPS(init, sites.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(state, sites, doubledBath);
    world.barrier(0);
    state.normalizeLim();

    //construct the operatore for basis expansion 1 - dt*H
    // dt is estimated by the product state energy
    auto Heff_ = ForkLocalOp(H);
    Heff_.position(1, state);
    double energy_ = std::real(Heff_.ContractAll(state));
    HBasis         = taylorFTPO(params, b, e0, 1. / abs(energy_));

    //thermalization
    HeffState = ForkLocalOp(H);

    // determine the time grid
    if (params.timeGrid == "DLR") {
      tList = tListDLR;
    } else {
      Error("@solverDLR, wrong time grid option (DLR)");
    }
    if (params.sampling.n_thermal > 0) {
      ThermalizeUnitary(params);
      //reassign E0Shift base on the thermalization states
      world.barrier(0);
      E0Shift = 0.0;
      if (params.verbose >= 1) { ReportOnce("----- E0Shift from thermalization energy is ", E0Shift, "\n"); }
    };
    world.barrier(0);

    //Monte Carlo Sampling
    //if we use an exponential time grid, the we need to evaluate both e^{-tau H} and e^{tau H}, hence,
    //we should not shift the zero energy position in such case
    // reassign the FTPO of H based on the new E0Shift from thermalization (currently, E0Shift is set to 0.0)
    H = whichFTPO(params, sites);

    // effective Hamiltonians
    HeffState = ForkLocalOp(H);
    HeffGr    = ForkLocalOp(H);
    HeffLe    = ForkLocalOp(H);
    HeffGrb   = ForkLocalOp(H);
    HeffLeb   = ForkLocalOp(H);

    //measure green's function and statics quantities, also store the bond growth, and the distribution of the norm and repeated count
    if (params.calc_me.size() != 0) {

      SamplingUnitaryMPISplit(params);
      // Collect the final results and perform MPI communication.
      world.barrier(0);
      G_tau               = mpi::all_reduce(G_tau, world);
      BondGrowthAve       = mpi::all_reduce(BondGrowthAve, world);
      MeasuredStatic      = mpi::all_reduce(MeasuredStatic, world);
      G_tau_by_norm       = mpi::all_reduce(G_tau_by_norm, world);
      DistributionCount   = mpi::all_reduce(DistributionCount, world);
      DistributionLogNorm = mpi::all_reduce(DistributionLogNorm, world);

      totalCount = mpi::all_reduce(totalCount, world) / params.calc_me.size();
      ReportOnce("\t total count ::", totalCount);
      G_tau /= double(totalCount);
      for (auto &ele : BondGrowthAve) { ele /= double(totalCount * params.calc_me.size()); }
      for (auto &ele : MeasuredStatic) { ele /= double(totalCount * params.calc_me.size()); }

      // broadcast the final results to all nodes.
      mpi::broadcast(G_tau);
      mpi::broadcast(BondGrowthAve);
      mpi::broadcast(MeasuredStatic);
      mpi::broadcast(DistributionCount);
      mpi::broadcast(DistributionLogNorm);

      //collect the variance of the green's function
      gf_mesh<imtime> meshImTau_(params.beta, Fermion, TimeGrid.size());
      g_tau_t G_tau_var_node(meshImTau_, params.gf_struct);
      for (auto ginfo : g_tau_list_info) {
        int iblock = 0;
        for (auto block : params.gf_struct) {
          for (auto tau : meshImTau_) {
            for (int iorb(0); iorb < block.second; iorb++) {
              for (int jorb(0); jorb < block.second; jorb++) {
                auto value_ = ginfo.second[iblock][tau](iorb, jorb);
                if (abs(value_) >= 1E-4) {
                  auto ele = G_tau[iblock][tau](iorb, jorb) - value_;
                  G_tau_var_node[iblock][tau](iorb, jorb) += ginfo.first * ele * conj(ele);
                }
              }
            } //end for block
          }   //end for tau
          iblock += 1;
        }
      }
      G_tau_var_node = mpi::all_reduce(G_tau_var_node, world);
      G_tau_var      = G_tau_var_node;
      G_tau_var /= totalCount;
    }
    // Collect additional sampling information and synchronize MPI processes.
    CollectSamplingInfo();
    world.barrier(0);
  };

  // Monte Carlo Sampling with MPI split of the Green's function conponents and unitary evolution implementated
  void finiteT_solver_core::SamplingUnitaryMPISplit(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();

    // variables for the sampling countings
    int step               = 0;
    totalCount             = 0;
    int totalCountThisRank = 0;
    double totalNormSq     = 0;
    //generate the states
    while (totalCountThisRank < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) { ReportOnce("\n\n\n--- Sampling ", totalCountThisRank + 1, "/", params_.sampling.n_sampling, "\n"); };

      // determine the type of the unitary evolution
      int uniTypeThisSample = (totalCountThisRank + 1) % 2;
      UniEvoType uniType;
      if (params_.sampling.uniEvoSteps != 0) {
        if (uniTypeThisSample == 0) {
          uniType = UniEvoType::Even;
        } else if (uniTypeThisSample == 1) {
          uniType = UniEvoType::Odd;
        }
      } else {
        uniType = UniEvoType::None;
      }

      // print the current product state occupation
      if (params_.verbose >= 1) {
        if (world.rank() == 0) { state.PrintOccs(); };
      }

      // check if the current product state is already in the pool
      auto label = generateLabel(state, params_, uniType);
      if (isRegistered(state, params_, uniType)) {
        auto tmp_count_fileName = fileNameIntermedia;
        tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(totalCountThisRank) + ".h5";
        auto psi_                = statesPool[label].productState;
        auto productStateFilling = fillingFromProductState(psi_);
        auto arch                = h5::file(tmp_count_fileName, 'a');
        h5_write(arch, "repeated", 1); //h5_write(arch, "Repeated", statesPool[label_].repeated);
        h5_write(arch, "bigNorm", statesPool[label].bigNorm);
        h5_write(arch, "productStateFilling", productStateFilling);
        h5_write(arch, "uniType", uniTypeThisSample);

        totalCountThisRank += 1;
        //update the product state to the registered Metts
        state = statesPool[label].state;
        statesPool[label].repeated += 1;

      } else {
        // generate the Metts and save the product state to file
        GenerateMettsBE(label, true, params_, uniType, false);
        auto tmp_count_fileName = fileNameIntermedia;
        tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(totalCountThisRank) + ".h5";
        auto psi_                = statesPool[label].productState;
        auto productStateFilling = fillingFromProductState(psi_);
        auto arch                = h5::file(tmp_count_fileName, 'a');
        h5_write(arch, "repeated", 1); //h5_write(arch, "Repeated", statesPool[label_].repeated);
        h5_write(arch, "bigNorm", statesPool[label].bigNorm);
        h5_write(arch, "productStateFilling", productStateFilling);
        h5_write(arch, "uniType", uniTypeThisSample);

        step += 1;
        totalCountThisRank += 1;
      }
      // restricted projection with fixed bath sites, determine the bath sites to be fixed
      bool wrongConf = true;
      auto stateCopy = state;
      std::vector<int> emptySites, occSites;
      for (int iArm = 1; iArm <= sites.NArms(); ++iArm) {
        for (int i(0); i < params_.sampling.fixedSites; i++) {
          int site = sites.ArmToSite(iArm, sites.NBath(iArm) - i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { emptySites.push_back(site); }
          site = sites.ArmToSite(iArm, 1 + i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { occSites.push_back(site); };
        }
      }
      if (params_.verbose >= 1) {
        ReportOnce("---@ThermalizeUnitary, enfored empty bath sites::", emptySites, "\n");
        ReportOnce("---@ThermalizeUnitary, enfored occupied bath sites::", occSites, "\n");
      }
      // restricted projection with fixed bath sites, projection
      while (wrongConf) {
        state = stateCopy;
        Project(params_);
        wrongConf = false;
        for (auto site : emptySites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n) > 0.1) { wrongConf = true; }
        }
        for (auto site : occSites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n - 1.0) > 0.1) { wrongConf = true; }
        }
      }

      if (params_.verbose >= 1) { ReportOnce("\n--- Accumulated unique confs. on this rank=", step, "\n"); };
    }
    world.barrier(0);

    // count the number of unique configurations on the master node
    statesPool.clear();
    std::vector<std::tuple<ForkTPS, double, int>> configurations;
    int repeated;
    double bigNorm;
    int numSampleToCount = params_.sampling.n_sampling;

    if (world.rank() == 0) {
      std::vector<double> productStateFilling;
      for (int step(0); step < numSampleToCount; step++) {
        for (int irank(0); irank < world.size(); irank++) {
          auto tmp_count_fileName = fileNameIntermedia;
          tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(irank) + "_sample_" + std::to_string(step) + ".h5";
          auto arch = h5::file(tmp_count_fileName, 'r');
          h5_read(arch, "repeated", repeated);
          h5_read(arch, "bigNorm", bigNorm);
          h5_read(arch, "productStateFilling", productStateFilling);
          ForkTPS psi_read = productStateFromFilling(productStateFilling, sites, doubledBath);

          //store the information into the statesPool
          auto label = generateLabel(psi_read, params_);
          if (isRegistered(psi_read, params_)) {
            statesPool[label].repeated += repeated;
          } else {
            statesPool[label].label        = label;
            statesPool[label].labelHash    = std::hash<std::string>{}(label);
            statesPool[label].productState = psi_read;
            statesPool[label].repeated     = repeated;
            statesPool[label].bigNorm      = bigNorm;
          }
        }
        // each iteration of sampling, we sort the configurations and sort them by the number of repeated times
        configurations.clear();
        for (auto const &conf : statesPool) {
          configurations.push_back(std::make_tuple(conf.second.productState, conf.second.bigNorm, conf.second.repeated));
        }
        std::sort(configurations.begin(), configurations.end(),
                  [](const std::tuple<ForkTPS, double, int> &e1, const std::tuple<ForkTPS, double, int> &e2) -> bool {
                    return std::get<2>(e1) > std::get<2>(e2);
                  });

        //write our the intermedie distribution to check the convergence if needed
        auto arch = h5::file(fileNameIntermedia + "/distribution_ite_" + std::to_string(step) + ".h5", 'a');
        std::vector<int> counts;
        std::vector<double> weights;
        for (auto const &conf : configurations) {
          counts.push_back(std::get<2>(conf));
          weights.push_back(std::get<1>(conf));
        }
        h5_write(arch, "counts", counts);
        h5_write(arch, "weights", weights);
      }

      ReportOnce("There are ", statesPool.size(), " unique states", "\n");
      int needJobsNum = params_.calc_me.size() * configurations.size();
      ReportOnce("Requiring ", needJobsNum, " jobs to be computed\n");
      //discard states with low probability if needed
      int performedJobsNum = world.size() * params_.sampling.minNumGfEachRank;
      ReportOnce(performedJobsNum, " jobs can be computed\n");
      if(needJobsNum > performedJobsNum)
      {
        ReportOnce("Discarding low prob states\n");
        int discardedUniNum = 0, discardedTotNum = 0;
        int performedUniNum = int(performedJobsNum/params_.calc_me.size() );
        ReportOnce(performedUniNum, " unique states will be considered\n");
        ReportOnce("Giving ", performedUniNum*params_.calc_me.size(), " jobs\n");
        for(int i(performedUniNum); i< configurations.size(); i++)
        {
          discardedUniNum += 1;
          discardedTotNum += std::get<2>(configurations.at(i));
        }
        ReportOnce("Discard ", discardedUniNum, " unique states out of ",configurations.size(), " total ones\n" );

        configurations.resize(performedUniNum);
        int considerTotNum = 0;
        for(auto conf : configurations)
        {
          considerTotNum += std::get<2>(conf);
        }
        ReportOnce("Discard ", discardedTotNum, " total states out of ", considerTotNum + discardedTotNum, " total ones\n" );

      }


      
      for (int ic(0); ic < configurations.size(); ic++) {
        if (ic < world.size()) { totalNormSq += pow(std::get<1>(configurations.at(ic)), 2.); }
      }

      //save conf information for later use
      for (int ic(0); ic < configurations.size(); ic++) {
        auto fileConf = fileNameIntermedia;
        fileConf += "/conf_" + std::to_string(ic) + ".h5";
        auto productStateFilling = fillingFromProductState(std::get<0>(configurations.at(ic)));
        auto arch                = h5::file(fileConf, 'a');
        h5_write(arch, "bigNorm", std::get<1>(configurations.at(ic)));
        h5_write(arch, "repeated", std::get<2>(configurations.at(ic)));
        h5_write(arch, "productStateFilling", productStateFilling);
      }
    }
    world.barrier(0);

    // distribute the jobs and calculate the Gfs component by component
    int numUniqueStates;
    if (world.rank() == 0) { numUniqueStates = configurations.size(); }
    mpi::broadcast(numUniqueStates);
    mpi::broadcast(totalNormSq);
    int numGfCompoment = params_.calc_me.size();
    ReportOnce("--- And for each unique state , there are ", numGfCompoment, " components.\n");
    ReportOnce("--- calculating ", numUniqueStates * numGfCompoment, " Gfs on ", world.size(), " nodes \n");
    int numGfEachRank = (numUniqueStates * numGfCompoment) / world.size() + ((numUniqueStates * numGfCompoment) % world.size() == 0 ? 0 : 1);
    ReportOnce("--- ", numGfEachRank, " different Gfs will be calculated on each rank...\n");
    std::vector<std::tuple<ForkTPS, int, std::vector<triqs_indx>>> jobsThisRank;

    //save the distribution on the master node, and set to zeros on other nodes
    DistributionCount.resize(numUniqueStates);
    DistributionLogNorm.resize(numUniqueStates);
    if (world.rank() == 0) {
      for (int istate(0); istate < numUniqueStates; istate++) {
        DistributionLogNorm.at(istate) = std::get<1>(configurations.at(istate));
        DistributionCount.at(istate)   = std::get<2>(configurations.at(istate));
      }
    }
    world.barrier(0);
    // distribute the jobs
    for (int istate(0); istate < numUniqueStates; istate++) {
      for (int icomponent(0); icomponent < numGfCompoment; icomponent++) {
        int whichrank = (istate * numGfCompoment + icomponent) / numGfEachRank;
        if (world.rank() == whichrank) {
          auto fileConf = fileNameIntermedia;
          fileConf += "/conf_" + std::to_string(istate) + ".h5";
          std::vector<double> productStateFilling;
          auto arch = h5::file(fileConf, 'r');
          h5_read(arch, "bigNorm", bigNorm);
          h5_read(arch, "repeated", totalCount);
          h5_read(arch, "productStateFilling", productStateFilling);
          state = productStateFromFilling(productStateFilling, sites, doubledBath);
          //std::cout << " on rank " << world.rank() << " has " << totalCount << std::endl;
          jobsThisRank.push_back(std::make_tuple(state, totalCount, params_.calc_me.at(icomponent)));
        }
      }
    }
    //fill other nodes with jobs
    for (int iresidual(numUniqueStates * numGfCompoment); iresidual < (world.size() * numGfEachRank); iresidual++) {
      int whichrank = (iresidual) / numGfEachRank;
      if (world.rank() == whichrank) {
        auto fileConf = fileNameIntermedia;
        fileConf += "/conf_" + std::to_string(0) + ".h5";
        std::vector<double> productStateFilling;
        auto arch = h5::file(fileConf, 'r');
        h5_read(arch, "bigNorm", bigNorm);
        h5_read(arch, "repeated", totalCount);
        h5_read(arch, "productStateFilling", productStateFilling);
        state = productStateFromFilling(productStateFilling, sites, doubledBath);
        //std::cout << " on rank " << world.rank() << " has " << totalCount << std::endl;
        jobsThisRank.push_back(std::make_tuple(state, 0, params_.calc_me.at(0)));
      }
    }
    world.barrier(0);
    //perform the calculation
    totalCount = 0;
    for (int iteGf(0); iteGf < numGfEachRank; iteGf++) {
      state                  = std::get<0>(jobsThisRank.at(iteGf));
      auto repeated          = std::get<1>(jobsThisRank.at(iteGf));
      auto calc_me_component = std::get<2>(jobsThisRank.at(iteGf));
      ReportOnce("--- Starting to calculate the ( ", iteGf + 1, "/", numGfEachRank, " )th Gfs which repeated ", repeated, " times ... \n");
      ReportOnce("--- with inital configuaration:: \n");
      if (world.rank() == 0) { state.PrintOccs(); }

      //note that if unitary gate is used, only gfs in the new basis will be calculated
      UniEvoType uniEvoType = UniEvoType::None;
      // label for the state
      auto label = generateLabel(state, params_);
      //an linear grid is used to generate the metts information in calculating Gfs
      if (params_.timeGrid == "DLR") {
        tList = tListDLR;
      } else {
        tList = tListLin;
      }
      //generate the metts with basis expansion
      GenerateMettsBE(label, true, params_, uniEvoType, true);

      //measure static quantities
      std::vector<std::complex<double>> measured_static;
      for (auto quanty : params_.measured_static_op) {
        auto state_mesure_ket = statesPool[label].state;
        auto state_mesure_bra = statesPool[label].state;

        std::string opName;
        for (auto ele : quanty) {
          std::string op_name = ele.first;
          auto site_op        = sites.ImpSite(TriqsIndxToArm(ele.second));
          opName += op_name + "_";
          opName += std::to_string(site_op);
          state_mesure_ket.position(site_op);
          state_mesure_ket.ApplySingleSiteOp(sites.op(op_name, site_op), site_op, true);
        }

        ReportOnce("--- Measuring ", opName, "\n");
        measured_static.push_back(double(repeated) * overlap(state_mesure_bra, state_mesure_ket));
      }

      g_tau_t g_tau;
      if (params_.timeGrid == "DLR") {
        g_tau = CalcGFDLR(label, params_, calc_me_component);
      } else {
        g_tau = CalcGFShiftedSplit(label, params_, params_.sampling.shiftedSteps, calc_me_component);
      }
      //G_tau_by_norm = G_tau;

      //save the Green's function
      if (params_.sampling.saveIntermedia) {
        auto fileNameGf = fileNameIntermedia;
        fileNameGf += "/Gf_" + std::to_string(iteGf * world.size() + world.rank()) + ".h5";
        auto arch = h5::file(fileNameGf, 'a');
        h5_write(arch, "G_tau", g_tau);
        h5_write(arch, "repeated", repeated);
        h5_write(arch, "bondGrowth", statesPool[label].bondGrowth);
      }
      // accumulate the Green's function and the static quantities
      if (iteGf == 0) {
        G_tau = (repeated * g_tau);
        for (auto ele : statesPool[label].bondGrowth) { BondGrowthAve.push_back((double(repeated * ele))); }
        MeasuredStatic = measured_static;
        totalCount     = repeated;
      } else {
        G_tau += (repeated * g_tau);
        for (int i(0); i < BondGrowthAve.size(); i++) { BondGrowthAve.at(i) += (double(repeated * statesPool[label].bondGrowth.at(i))); }
        for (int ie(0); ie < MeasuredStatic.size(); ie++) { MeasuredStatic.at(ie) += measured_static.at(ie); }

        totalCount += repeated;
      };
      g_tau_list_info.push_back(std::make_pair(repeated, g_tau));
      //G_tau_by_norm *= pow(bigNorm, 2.) / totalNormSq;
    }
    world.barrier(0);

    //remove the tmp files
    if (world.rank() == 0) {
      for (int ic(0); ic < params_.sampling.n_sampling; ic++) {
        for (int irank(0); irank < world.size(); irank++) {
          auto tmpFileNames = fileNameIntermedia;
          tmpFileNames += "/countAndproductState_rank_" + std::to_string(irank) + "_sample_" + std::to_string(ic) + ".h5";
          std::filesystem::remove(tmpFileNames);
        }
      }

      for (int ic(0); ic < configurations.size(); ic++) {
        auto tmpFileNames = fileNameIntermedia;
        tmpFileNames += "/conf_" + std::to_string(ic) + ".h5";
        std::filesystem::remove(tmpFileNames);
      }
    }
  };

  void finiteT_solver_core::GenerateMettsBE(std::string const &label, bool const &reg, finiteT_params_t const &params_, UniEvoType const &uniEvoType,
                                            bool measurement_) {
    if (params_.verbose >= 1) { ReportOnce("---@GenerateMettsBE, time evolution is performed by hybrid BE+TS for the bath \n"); }
    // initialize the effective Hamiltonian and path
    HeffState.ForgetContraction();
    phitau.resize(tList.size());
    if (reg) { statesPool[label].productState = state; }

    //expand the basis at inital time
    if (params_.verbose >= 6) { args.add("verbose", true); }
    auto args_inital = args;
    if (params_.verbose >= 1) { ReportOnce("@GenerateMettsBE, using addBasis to expand the basis (without OffDia) @inital time...\n"); }
    HBasis = taylorFTPO(params_, b, e0, tList.at(1) - tList.at(0));
    addBasis(state, HBasis, args_inital);

    HeffState.ForgetContraction();
    //since tdvp will start by moving the orthogonality center to the first impurity site with the
    //given truncation, we need to move the OC to this site with no truncation first, otherwise
    //the added basis states will be truncated entially.
    auto args_check = args;
    args_check.add("Cutoff", -1);
    state.position(1, args_check);

    if (params_.verbose >= 1) { ReportOnce("@GenerateMettsBE, using addBasis to expand the basis @inital time...Done\n"); }
    {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }
      if (minI_ == 1) { Error(" @GenerateMettsBE, the smallest bond dimension is 1 perform another basis expansion"); }
    }

    //make a forward real time evolution in a measure step
    double norm   = std::log(state.normalizeLim());
    phitau[0]     = {state, norm};
    double totalT = 0;
    std::vector<int> bondGrowth;
    std::vector<double> evoTauList;
    evoTauList.push_back(totalT);
    // do TDVP
    //determine where to make basis expansion
    std::vector<int> stepsToExpand_;
    for (int it(0); it < params_.basisExpansion.timeToExpand.size(); it++) {
      for (int i(0); i < tList.size() - 1; i++) {
        if (params_.basisExpansion.timeToExpand.at(it) >= tList.at(i) && params_.basisExpansion.timeToExpand.at(it) < tList.at(i + 1)) {
          if (std::find(stepsToExpand_.begin(), stepsToExpand_.end(), i) == stepsToExpand_.end()) { stepsToExpand_.push_back(i); }
        }
      }
    }
    std::vector<double> timesToExpand_;
    for (auto const &it : stepsToExpand_) { timesToExpand_.push_back(tList.at(it)); }
    if (params_.verbose >= 1) { ReportOnce("@GenerateMettsBE, basis expansion will be performed at :: ", timesToExpand_, "\n"); }

    //time evolution
    args.add("TevoMethod", "TDVP");
    int expand_every_ = 0;
    double origCutoff = args.getReal("Cutoff", -1);
    auto HBasisE0     = HBasis;
    // start time evolution
    for (int step = 0; step < tList.size() - 1; step++) {
      // find the minimal and maximal bond dimension
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }

      long maxI_ = 0;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        maxI_    = std::max(maxI_, dim(ind));
      }

      for (int it(0); it < params_.basisExpansion.BETimeList.size(); it++) {
        if (totalT < params_.basisExpansion.BETimeList.at(it)) {
          expand_every_ = params_.basisExpansion.expand_everyList.at(it);
          break;
        }
      }
      bool expandHalfGrid = false;
      if (tList.at(step) <= params_.beta / 4.0 && tList.at(step + 1) >= params_.beta / 4.0) { expandHalfGrid = true; }
      bool expandNow_ = std::find(stepsToExpand_.begin(), stepsToExpand_.end(), step) == stepsToExpand_.end() ? false : true;
      //expansion w.r.t. the maximal bond dimension critial
      if ((step != 0 && expandNow_ && maxI_ < params_.tevo.approx.maxm_i)) {
        if (params_.basisExpansion.BEMethod == "ApplyH") {
          HBasis = H;
        } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
          HBasis = taylorFTPO(params_, b, e0, tList.at(step + 1) - tList.at(step));
        }
        addBasis(state, HBasis, args);
        HeffState.ForgetContraction();
        if (params_.verbose >= 3) { ReportOnce("@GenerateMettsBE, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
      }
      //expansion w.r.t. the minmal bond dimension critial, only for the measurement step
      if (step != 0 && expandNow_ && maxI_ >= params_.tevo.approx.maxm_i && minI_ < params_.basisExpansion.minBond && measurement_) {
        if (params_.basisExpansion.BEMethod == "ApplyH") {
          HBasis = H;
        } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
          HBasis = taylorFTPO(params_, b, e0, tList.at(step + 1) - tList.at(step));
        }
        addBasis(state, HBasis, args);
        HeffState.ForgetContraction();
        if (params_.verbose >= 3) { ReportOnce("@GenerateMettsBE, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
      }
      //expansion at critical time point
      if (step != 0 && params_.basisExpansion.expand_critical && measurement_) {
        for (auto tcritical : params_.basisExpansion.critical_time) {
          if (tList.at(step) <= tcritical && tList.at(step + 1) >= tcritical) {
            if (params_.basisExpansion.BEMethod == "ApplyH") {
              HBasis = H;
            } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
              double time_step_ = std::min(0.2, tList.at(step + 1) - tList.at(step));
              HBasis            = taylorFTPO(params_, b, e0, time_step_);
            }
            addBasis(state, HBasis, args);
            HeffState.ForgetContraction();
            if (params_.verbose >= 1) { ReportOnce("@GenerateMettsBE, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
          }
        }
      }

      // TDVP step
      TDVP(state, HeffState, tList.at(step + 1) - tList.at(step), args);

      //check whether to change to tdvp full single site depending on the bond dimension between impurity sites and bath sites
      long minIB_ = 1000000;
      for (int iArm = 1; iArm <= state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm) + 1));
        minIB_   = std::min(minIB_, dim(ind));
      }
      double ts_bath_time;
      if (measurement_) {
        ts_bath_time = params_.sampling.minTwoSiteTimeGf;
      } else {
        ts_bath_time = params_.sampling.TSTime;
      }
      bool changeTDVP;
      if (measurement_) {
        changeTDVP = (totalT > ts_bath_time && minIB_ >= params_.basisExpansion.minBond);
      } else {
        changeTDVP = (totalT > ts_bath_time);
      }
      if (changeTDVP && maxI_ >= params_.tevo.approx.maxm_i && args.getString("TevoMethod") != "TDVPFullSS") {
        args.add("TevoMethod", "TDVPFullSS");
        HeffState.ForgetContraction();
        ReportOnce("--- change to TDVPFullSS @", totalT, " with minI_= ", minI_, "\n");
      }

      totalT = tList[step + 1];
      norm   = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));

      if (params_.verbose >= 3) {
        ReportOnce("BasisExansion ", args.getString("TevoMethod"), ":: Generating Metts Imaginary time @ ", totalT,
                   "(with dt=", tList.at(step + 1) - tList.at(step), ")", "::expand_evry ", expand_every_, " \n");
        if (world.rank() == 0) { state.PrintImpM(3); };
        ReportOnce("\n");
        ReportOnce("And norm ::", norm, ", current norm :: ", state.norm(), "\n");
        ReportOnce("\n\n");
      }

      //make a backward real time evolution {}
      if (world.rank() == 0 && params_.verbose >= 3) { PrintBigDensity(); };
      phitau[step + 1] = {state, norm};
      auto psi_        = state;
      bondGrowth.push_back(psi_.MaxM());
      evoTauList.push_back(totalT);
    }

    if (abs(totalT - params_.beta / 2.) > 1E-6) {
      PRINT(totalT);
      PRINT(params_.beta / 2.);
      PRINT(totalT - params_.beta / 2.);
      Error("Missmatch in time steps");
    }

    //register this metts
    if (reg) {
      statesPool[label].repeated   = 1;
      statesPool[label].statesPath = phitau;
      statesPool[label].evoTauList = evoTauList;
      statesPool[label].state      = state;
      statesPool[label].label      = label;
      statesPool[label].labelHash  = std::hash<std::string>{}(label);
      double bigNorm               = 0.0;
      for (int i(0); i < phitau.size(); ++i) { bigNorm += phitau.at(i).normFactor; };
      statesPool[label].bigNorm    = bigNorm;
      statesPool[label].bondGrowth = bondGrowth;
      if (phitau.size() != evoTauList.size()) { Error("phitau.size() !=  evoTauList.size()"); }
    }
    if (params_.verbose >= 1) {
      ReportOnce("--- Big norm of this METTS::", statesPool[label].bigNorm, "\n");
      ReportOnce("--- Filling of this METTS::\n");
      if (world.rank() == 0) {
        state.PrintOccs();
        state.PrintImpM();
      };
      ReportOnce("\n\n");
      state.position(1);
      ReportOnce("--- Particle Number of this METTS::", div(state.A(1)).val("Nf"), "\n");
      //print out the occupation matrix
      if (world.rank() == 0) {
        for (auto block : params_.gf_struct) {
          std::cout << "Impurity Occupation Matrix <c_i^d c_j > for block " << block.first << "\n";
          for (int iorb(0); iorb < block.second; iorb++) {
            std::cout << std::endl;
            for (int jorb(0); jorb < block.second; jorb++) {
              triqs_indx ind_i = {block.first, iorb}, ind_j = {block.first, jorb};
              auto arm_i  = TriqsIndxToArm(ind_i);
              auto arm_j  = TriqsIndxToArm(ind_j);
              auto site_i = sites.ImpSite(arm_i);
              auto site_j = sites.ImpSite(arm_j);
              ForkTPS bra = state, ket = state;
              bra.position(site_i);
              ket.position(site_j);
              bra.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
              ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
              auto val = overlap(bra, ket);
              std::cout << std::setprecision(4) << val << "      ";
            }
          }
          std::cout << std::endl;
        }
      } //end print density matrix
    }   //end print out information
  };

  // Monte Carlo thermalization
  void finiteT_solver_core::ThermalizeUnitary(finiteT_params_t const &params_) {
    double Eaccumulate = 0., EthisMett = 0.;
    for (auto step : range1(params_.sampling.n_thermal)) {
      if (params_.verbose >= 1) { ReportOnce("\n\n\n--- thermalizing ", step, "/", params_.sampling.n_thermal, "\n"); }
      if (params_.verbose == -1) {
        std::cout << "\n\n @rank :: " << world.rank() << "--- thermalizing " << step << "/" << params_.sampling.n_thermal << "\n\n\n" << std::endl;
      }

      HeffState.ForgetContraction();
      auto label = generateLabel(state, params_);

      // determine the type of unitary evolution
      UniEvoType uniType;
      if (params_.sampling.uniEvoSteps != 0) {
        if (step % 2 == 0) {
          uniType = UniEvoType::Even;
        } else {
          uniType = UniEvoType::Odd;
        }
      } else {
        uniType = UniEvoType::None;
      }
      // print out the product state occuption
      if (params_.verbose >= 1) {
        if (world.rank() == 0) { state.PrintOccs(); };
      }
      // generate the metts on exponential time grid
      GenerateMettsBE(label, true, params_, uniType, false);

      Measure(label, true);
      Energy.push_back(statesPool[label].energy);
      QuantumNumber.push_back(statesPool[label].quantumNumber);
      Eaccumulate += statesPool[label].energy;
      if (params_.verbose >= 1) {
        ReportOnce("--- accumulated average energy is ", Eaccumulate / double(step), ", and this METTS has energy ", statesPool[label].energy, "\n");
      }

      // projection with retriction of fixed bath sites
      bool wrongConf = true;
      auto stateCopy = state;
      std::vector<int> emptySites, occSites;
      for (int iArm = 1; iArm <= sites.NArms(); ++iArm) {
        for (int i(0); i < params_.sampling.fixedSites; i++) {
          int site = sites.ArmToSite(iArm, sites.NBath(iArm) - i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { emptySites.push_back(site); }
          site = sites.ArmToSite(iArm, 1 + i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { occSites.push_back(site); };
        }
      }
      if (params_.verbose >= 1) {
        ReportOnce("---@ThermalizeUnitary, enfored empty bath sites::", emptySites, "\n");
        ReportOnce("---@ThermalizeUnitary, enfored occupied bath sites::", occSites, "\n");
      }
      while (wrongConf) {
        state = stateCopy;
        Project(params_);
        wrongConf = false;
        for (auto site : emptySites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n) > 0.1) { wrongConf = true; }
        }
        for (auto site : occSites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n - 1.0) > 0.1) { wrongConf = true; }
        }
      }
      //end restrict conf.
    }
  };

  // quick DMRG to estimate the ground state
  double finiteT_solver_core::QuickDMRG(finiteT_params_t params_) {
    //some predefined parameters
    int nmax    = params_.tevo.krylov.nmax;
    double err  = params_.tevo.krylov.norm_err;
    double conv = params_.tevo.krylov.conv;
    int nh      = 0;

    //calculation with out qunatum number
    //init object
    auto sites_nq = ThermalForkSites(b.N(), b.NArms(), {}, {"conserveN", false, "conserveSz", false, "impPurified", false});
    InitState init_nq(sites_nq, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_nq.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (b.eps(ind, k) < 0) init_nq.set(sites_nq.ArmToSite(arm, k + 1), "Occ");
      }
      //the impurity sites are always purified
      init_nq.set(sites_nq.ImpSite(arm), "Occ");
    }
    ForkTPS psi_nq(init_nq, b.NArms());
    //ResetPurifiedTensors(psi_, sites_, {});

    ForkTPO HH_nq = whichFTPO(params_, sites_nq);
    if (params_.verbose >= 3) {
      if (world.rank() == 0) {
        ReportOnce("--- QuickDMRG:: initial state occupation (No quantum number)\n");
        psi_nq.PrintOccs();
        ReportOnce("\n");
      }
    }

    double energy_;
    //psi_nq.randomize(10);
    auto totOcc  = MeasureTotN(psi_nq);
    auto occs    = MeasureAllArmN(psi_nq);
    auto varNtot = std::pow(totOcc.first, 2) - totOcc.second;
    //increase the bond dimension and truncation accuracy step by step to aviod local minimal
    for (int it(0); it < params_.quickDMRG.nWarmUp; it++) {
      if (params_.verbose >= 3) { ReportOnce("\n\n--- Quick DMRG warm up iteration ", it + 1, "\n"); };
      int bond = 10 + it * 10;
      DMRG_params dmrg_params_warmUp(bond, bond, bond,                                              // maxm
                                     1E-6 / double(bond), 1E-6 / double(bond), 1E-6 / double(bond), //tws
                                     nmax, err, conv,                                               // krylov
                                     5, nh, "SSImp");
      Args args_warmUp;
      SetArgs(args_warmUp, dmrg_params_warmUp);
      if (params_.verbose >= 3) {
        args_warmUp.add("verbose", true);
      } else {
        args_warmUp.add("verbose", false);
      }
      DMRG(psi_nq, HH_nq, energy_, args_warmUp);
      // look at particle number variance
      totOcc  = MeasureTotN(psi_nq);
      occs    = MeasureAllArmN(psi_nq);
      varNtot = std::pow(totOcc.first, 2) - totOcc.second;
      if (params_.verbose >= 3) {
        ReportOnce("total N: ", totOcc.first, "\n");
        ReportOnce("Variance of total N: ", varNtot, "\n");
        for (int arm(0); arm < b.NArms(); arm++) { ReportOnce("--- arm ", arm + 1, " has ", occs.at(arm).first, " particles \n"); };
      }
    }
    //calculation with qunatum number

    //reconstruct objects for particle numer conserved calculation
    auto sites_ = ThermalForkSites(b.N(), b.NArms(), {}, {"conserveN", true, "conserveSz", false, "impPurified", false});
    InitState init_(sites_, "Emp");

    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      int filling    = 0;
      for (auto k : itertools::range(b.NBath(ind))) {
        if (abs(filling - (occs.at(arm - 1).first - 1)) > 0.5) {
          init_.set(sites_.ArmToSite(arm, k + 1), "Occ");
          filling += 1;
        }
      }
      //the impurity sites are always purified
      init_.set(sites_.ImpSite(arm), "Occ");
    }
    ForkTPS psi_(init_, b.NArms());
    //ResetPurifiedTensors(psi_, sites_, {});

    ForkTPO HH = whichFTPO(params_, sites_);

    DMRG_params dmrg_params(params_.quickDMRG.mDMRG, params_.quickDMRG.mDMRG, params_.quickDMRG.mDMRG,    // maxm
                            params_.quickDMRG.twDMRG, params_.quickDMRG.twDMRG, params_.quickDMRG.twDMRG, //tws
                            nmax, err, conv,                                                              // krylov
                            params_.quickDMRG.nDMRGSweep, nh, params_.quickDMRG.DMRGMethod);

    Args args_;
    SetArgs(args_, dmrg_params);
    if (params_.verbose >= 3) {
      args_.add("verbose", true);
    } else {
      args_.add("verbose", false);
    }

    DMRG(psi_, HH, energy_, args_);
    if (params_.verbose >= 3) {
      if (world.rank() == 0) {
        ReportOnce("--- QuickDMRG:: Out state occupation\n");
        psi_.PrintOccs();
        ReportOnce("\n");
        ReportOnce("--- with energy::", energy_, "\n");
      }
    }

    //measure the first element of the Green's function
    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites_.ImpSite(arm_A);
      auto site_B = sites_.ImpSite(arm_B);

      ForkTPS ket = psi_, bra = psi_;
      ket.position(site_B);
      bra.position(site_A);
      ket.ApplySingleSiteOp(sites_.op("CkD", site_B), site_B, true);
      bra.ApplySingleSiteOp(sites_.op("CkD", site_A), site_A, true);
      if (params_.verbose >= 1) { ReportOnce("--- from DMRG :: -<c_", comp[0], "c^+_", comp[1], ">=", -overlap(bra, ket), "\n"); };
    }

    return -energy_;
  }

  // print out the density matrix
  void finiteT_solver_core::PrintBigDensity() {
    if (world.rank() == 0) {
      //big density matrix
      for (auto arm_1 : range1(b.NArms())) {
        std::cout << std::endl;
        for (auto arm_2 : range1(b.NArms())) {
          int site_1  = sites.ImpSite(arm_1);
          int site_2  = sites.ImpSite(arm_2);
          ForkTPS bra = state, ket = state;
          bra.ApplySingleSiteOp(sites.op("Ck", site_1), site_1, true);
          ket.ApplySingleSiteOp(sites.op("Ck", site_2), site_2, true);
          auto val = overlap(bra, ket);
          std::cout << std::setprecision(4) << val << "      ";
        }
      }
      std::cout << std::endl;
    }
  }

  //spare the exponential time grid
  std::vector<double> finiteT_solver_core::spareExpTimeGrid(std::vector<double> const &timeGrid_) {
    std::vector<double> timeGridNew_ = timeGrid_, thisIteTime;
    for (int ite(0); ite < 20; ite++) {
      thisIteTime = timeGridNew_;
      timeGridNew_.clear();
      timeGridNew_.push_back(thisIteTime.at(0));
      for (int ic(1); ic < thisIteTime.size(); ic++) {
        double distance_ = 0.0;
        //(timeGridNew_.back() >= 25.0) ? 0.7 : 0.5;
        /*
        if (timeGridNew_.back() < 1.0) {
          distance_ = 0.1;
        } else if (timeGridNew_.back() >= 1.0 && timeGridNew_.back() < 2.0) {
          distance_ = 0.15;
        } else if (timeGridNew_.back() >= 2.0 && timeGridNew_.back() < 5.0) {
          distance_ = 0.2;
        } else if (timeGridNew_.back() >= 5.0 && timeGridNew_.back() < 30.0) {
          distance_ = 0.5;
        } else if (timeGridNew_.back() >= 30.0 && timeGridNew_.back() < 100.0) {
          distance_ = 0.65;
        } else if (timeGridNew_.back() >= 100.0) {
          distance_ = 0.75;
        }
        */
       distance_ = 0.75;

        if ((thisIteTime.at(ic) - timeGridNew_.back()) > distance_) {
          timeGridNew_.push_back(timeGridNew_.back() + 0.5 * (thisIteTime.at(ic) - timeGridNew_.back()));
          timeGridNew_.push_back(thisIteTime.at(ic));
        } else {
          timeGridNew_.push_back(thisIteTime.at(ic));
        }
      }
    }
    return timeGridNew_;
  };

  // FTPO for 1-dt*H
  ForkTPO finiteT_solver_core::taylorFTPO(finiteT_params_t const &params_, bath const &b_, hloc const &e0_, double const &dt_) {

    auto e0Basis    = e0_;
    auto bBasis     = b_;
    auto E0ShiftOri = E0Shift;

    //bath terms
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(bBasis.NBath(ind))) {
        //onsite energies, always diagonal
        bBasis.b.at(ind.first).at(ind.second).at(k).eps *= (-1 * dt_);
        //hopping terms
        for (auto arm_J : range1(sites.NArms())) {
          triqs_indx ind_J = ArmToTriqsIndx(arm_J);
          //must in the same block
          if (ind.first == ind_J.first) { bBasis.b.at(ind.first).at(ind.second).at(k).V.at(ind_J.second) *= (-1 * dt_); }
        }
      }
    }

    //e0
    for (auto block : params_.gf_struct) {
      for (int iorb(0); iorb < block.second; iorb++) {
        for (int jorb(0); jorb < block.second; jorb++) { e0Basis.e.at(block.first)(iorb, jorb) *= (-1 * dt_); }
      }
    }

    //interaction
    auto h_int_Basis = H_int(-params_.h_int.U * dt_, -params_.h_int.J * dt_, -params_.h_int.Up * dt_, params_.h_int.dd_only);
    E0Shift          = 1;
    auto H_          = whichFTPO(params_, sites, bBasis, e0Basis, h_int_Basis);
    E0Shift          = E0ShiftOri;
    return H_;
  };

  // determine the bath sites to be purified
  std::vector<int> finiteT_solver_core::DeterminePurificeBathSitesEachOrb(finiteT_params_t params_) {
    auto sites_ = ThermalForkSites(b.N(), b.NArms(), {}, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params_.impPurified});
    InitState init_(sites_, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (b.eps(ind, k) < 0) init_.set(sites_.ArmToSite(arm, k + 1), "Occ");
      }
      if (params_.impPurified) {
        init_.set(sites_.ImpSite(arm), "01");
      } else {
        init_.set(sites_.ImpSite(arm), "Occ");
      }
    }

    auto psi_ = ForkTPS(init_, sites_.NArms());
    ReportOnce("--- determine the purified bath sites by ", params_.sampling.puriMethod, " for each orb. \n");
    std::vector<int> purifiedBath;
    std::vector<std::pair<int, double>> probList;

    for (auto arm : range1(sites_.NArms())) {
      probList.clear();
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        int site = sites_.ArmToSite(arm, k + 1);
        if (!psi_.IsImp(site)) { probList.push_back(std::make_pair(site, (b.eps(ind, k)))); }
      }
      int numPurifiedSites = params_.sampling.purificationSites; //int(probList.size() * params_.sampling.purification_threshold);
      if (params_.sampling.puriMethod == "Energy") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return abs(e1.second) < abs(e2.second); });
      } else if (params_.sampling.puriMethod == "EnergyReverse") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return abs(e1.second) > abs(e2.second); });
      } else if (params_.sampling.puriMethod == "EnergyReverseConduction") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return (e1.second) > (e2.second); });
      } else if (params_.sampling.puriMethod == "EnergyReverseValence") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return (e1.second) < (e2.second); });
      } else if (params_.sampling.puriMethod == "SampleFermi") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return abs(e1.second) < abs(e2.second); });
        for (int i(0); i < params_.sampling.n_fluctuating_sites; i++) {
          if (probList.empty()) { break; }
          probList.erase(probList.begin());
        }
      }

      for (int ic(0); ic < numPurifiedSites; ic++) {
        if (ic > probList.size() - 1) { break; };
        purifiedBath.push_back(probList.at(ic).first);
      };
    }
    return purifiedBath;
  };

  // generate imaginary time mesh
  gf_mesh<imtime> finiteT_solver_core::GenerateImMesh(finiteT_params_t const &params_) {

    gf_mesh<imtime> mesh(params_.beta, Fermion, 10);
    for (auto t : mesh) { ReportOnce(t, "\n"); }
    return mesh;
  }

  // map the arm index to triqs index
  triqs_indx finiteT_solver_core::ArmToTriqsIndx(int const &iarm) {
    if (!b.isSpinOrbit()) {
      std::string bN_up = "up", bN_dn = "dn";
      std::string blockName = (iarm % 2 == 1) ? bN_up : bN_dn;
      auto blockI           = static_cast<int>((iarm - 1 - (iarm - 1) % 2) / 2);
      triqs_indx ind        = {blockName, blockI};
      return ind;
    } else {
      //currently, spin-orbital coupling works only for 3-orbital systems
      std::vector<triqs_indx> indices(6);
      indices[0] = {"ud_0", 0}; // arm 1
      indices[3] = {"ud_0", 1}; // arm 4
      indices[5] = {"ud_0", 2}; // arm 6

      indices[1] = {"ud_1", 0}; // arm 2
      indices[2] = {"ud_1", 1}; // arm 3
      indices[4] = {"ud_1", 2}; // arm 5
      return indices[iarm - 1];
    }
  };

  // map the triqs index to arm index
  int finiteT_solver_core::TriqsIndxToArm(triqs_indx const &indx_triqs) {
    if (!b.isSpinOrbit()) {
      if (indx_triqs.first == "up") { return (indx_triqs.second) * 2 + 1; };
      if (indx_triqs.first == "dn") { return (indx_triqs.second) * 2 + 2; };
    } else {
      std::vector<triqs_indx> indices(6);
      indices[0] = {"ud_0", 0}; // arm 1
      indices[3] = {"ud_0", 1}; // arm 4
      indices[5] = {"ud_0", 2}; // arm 6

      indices[1] = {"ud_1", 0}; // arm 2
      indices[2] = {"ud_1", 1}; // arm 3
      indices[4] = {"ud_1", 2}; // arm 5
      auto iter  = std::find(indices.cbegin(), indices.cend(), indx_triqs);
      return std::distance(indices.cbegin(), iter) + 1;
    }
    return NAN;
  };

  // map the triqs index to block index
  int finiteT_solver_core::BlockNameIndx(triqs_indx const &indx, finiteT_params_t const &params_) {
    std::vector<std::string> names;
    for (auto st : params_.gf_struct) { names.push_back(st.first); }
    auto iter = std::find(names.cbegin(), names.cend(), indx.first);
    return std::distance(names.cbegin(), iter);
  }

  // determine the FTPO type and return the corresponding ForkTPO object
  ForkTPO finiteT_solver_core::whichFTPO(const finiteT_params_t &p, ThermalForkSites const &sites_) {
    if (p.verbose >= 1) {
      if (b.hasOnlyOneBlock()) {
        ReportOnce("FTPO:: one block FTPO \n");
      } else if (b.isSpinOrbit()) {
        ReportOnce("FTPO:: spin-orbital coupling FTPO\n");
      } else if (b.isOffDiag() || e0.isOffDiag()) {
        ReportOnce("FTPO:: off-diag FTPO\n");
      } else {
        ReportOnce("FTPO:: diagonal FTPO\n");
      }
    }
    // use different MPO depending on whether the bath has only a single block, is spin-orbit coupled, off-diagonal or diagonal
    if (b.hasOnlyOneBlock()) return ForkTPO(AIM_FullOffDiag(sites_, b, e0, p.h_int, {"E0Shift", E0Shift}));

    if (b.isSpinOrbit()) return ForkTPO(AIM_SpinOrbit(sites_, b, e0, p.h_int, {"E0Shift", E0Shift}));

    if (b.isOffDiag() || e0.isOffDiag()) return ForkTPO(AIM_OffDiag(sites_, b, e0, p.h_int, {"E0Shift", E0Shift}));

    // In all other cases
    return ForkTPO(AIM(sites_, b, e0, p.h_int, {"E0Shift", E0Shift}));
  }

  ForkTPO finiteT_solver_core::whichFTPO(const finiteT_params_t &p, ThermalForkSites const &sites_, bath const &bath_, hloc const &e0_,
                                         H_int const &h_int_) {
    if (p.verbose >= 1) {
      if (bath_.hasOnlyOneBlock()) {
        //ReportOnce("FTPO:: one block FTPO \n");
      } else if (bath_.isSpinOrbit()) {
        //ReportOnce("FTPO:: spin-orbital coupling FTPO\n");
      } else if (bath_.isOffDiag() || e0_.isOffDiag()) {
        //ReportOnce("FTPO:: off-diag FTPO\n");
      } else {
        //ReportOnce("FTPO:: diagonal FTPO\n");
      }
    }
    // use different MPO depending on whether the bath has only a single block, is spin-orbit coupled, off-diagonal or diagonal
    if (bath_.hasOnlyOneBlock()) return ForkTPO(AIM_FullOffDiag(sites_, bath_, e0_, h_int_, {"E0Shift", E0Shift}));

    if (bath_.isSpinOrbit()) return ForkTPO(AIM_SpinOrbit(sites_, bath_, e0_, h_int_, {"E0Shift", E0Shift}));

    if (bath_.isOffDiag() || e0_.isOffDiag()) return ForkTPO(AIM_OffDiag(sites_, bath_, e0_, h_int_, {"E0Shift", E0Shift}));

    // In all other cases
    return ForkTPO(AIM(sites_, bath_, e0_, h_int_, {"E0Shift", E0Shift}));
  }

  // Sets the state on the impurities to | 01 > + |1 0>
  void finiteT_solver_core::ResetPurifiedTensors(ForkTPS &psi_, ThermalForkSites const &sites_, std::vector<int> const &doubledBath_) {
    //reset the impurity site tensors if they are purified
    if (sites_.ImpPurified()) {
      for (auto imp : range1(sites_.NArms())) {
        int site = psi_.ImpSite(imp);
        if (imp == 1 || imp == sites_.NArms()) {
          auto dir    = (imp == 1) ? Downwards : Upwards;
          Index ilink = psi_.GetImpLink(imp, dir);
          Index blink = psi_.GetLink(site, site + 1);
          Index s     = sites_.si(site);
          auto &A     = psi_.Anc(site);

          A.set(ilink(1), blink(1), s(2), 1. / sqrt(2));
          A.set(ilink(1), blink(1), s(3), 1. / sqrt(2));
        } else {
          Index ilink = psi_.GetImpLink(imp, Upwards);
          Index jlink = psi_.GetImpLink(imp, Downwards);
          Index blink = psi_.GetLink(site, site + 1);
          Index s     = sites_.si(site);
          auto &A     = psi_.Anc(site);

          A.set(ilink(1), jlink(1), blink(1), s(2), 1. / sqrt(2));
          A.set(ilink(1), jlink(1), blink(1), s(3), 1. / sqrt(2));
        }
      }
    }

    // bath sites that site at the leaves
    std::vector<int> lastBathSites;
    for (int iarm : range1(sites_.NArms())) { lastBathSites.push_back(sites_.ArmToSite(iarm, 1)); };
    if (sites_.NArms() != lastBathSites.size()) { throw ITError("ResetPurifiedTensors, NArms() != #num of leaves"); }
    //    ReportOnce(lastBathSites);

    for (auto site : doubledBath_) {
      if (!std::count(lastBathSites.begin(), lastBathSites.end(), site)) {
        Index ilink = psi_.GetLink(site, site - 1);
        Index jlink = psi_.GetLink(site, site + 1);
        Index s     = sites_.si(site);
        auto &A     = psi_.Anc(site);
        A.set(ilink(1), jlink(1), s(2), 1. / sqrt(2));
        A.set(ilink(1), jlink(1), s(3), 1. / sqrt(2));
      } else {
        Index ilink = psi_.GetLink(site, site - 1);
        Index s     = sites_.si(site);
        auto &A     = psi_.Anc(site);
        A.set(ilink(1), s(2), 1. / sqrt(2));
        A.set(ilink(1), s(3), 1. / sqrt(2));
      }
    }
  };

  // project one site tensor to the outcome 0 or 1 state
  void finiteT_solver_core::ProjectSite(InitState &init) {
    Aold = state.A(currSite);
    // decide where to project
    DecideOutcome(init);
    // project Aold and merge it to neighbor if not last site
    Aold *= siteProjector * 1. / std::sqrt(prob);
    Aold.noPrime();
    state.Anc(currSite) = Aold;
  }

  // Decides on an outcome for a single site
  void finiteT_solver_core::DecideOutcome(InitState &init) {

    int outcome(0);
    std::string Op = "N";
    auto n         = std::real((Aold * state.sites().op(Op, currSite) * dag(prime(Aold, "Site"))).cplx());
    std::random_device rd;
    std::mt19937 RNG(rd()); //
    std::uniform_real_distribution<double> Uniform(0., 1.);
    auto randomNumber = Uniform(RNG);
    if (n > randomNumber) {
      //std::cout << "N = " << n << " RNG = " << randomNumber << "   -->   Chose Occupied\n";
      prob    = n;
      outcome = 1;
      init.set(currSite, "Occ");
    } else {
      prob    = 1 - n;
      outcome = 0;
      //std::cout << "N = " << n << " RNG = " << randomNumber << "   -->   Chose Empty.\n";
      init.set(currSite, "Emp");
    }

    // generate projector
    Index s       = dag(state.sites().si(currSite));
    Index sp      = sites.siP(currSite);
    siteProjector = ITensor(s, sp);
    siteProjector.set(s(outcome + 1), sp(outcome + 1), 1.);

    return;
  }

  // project the state to a product state with probability |<i|psi>|^2
  void finiteT_solver_core::Project(finiteT_params_t const &params_) {
    auto state_in = state;
    InitState init(sites, "Emp");

    //place the orthogonality center at the last site
    state.position(state.N());
    //project the last arm
    int NArms             = state.NArms();
    auto firstBathThisArm = state.ArmToSite(NArms, state.NBath(NArms));
    auto lastBathThisArm  = state.ArmToSite(NArms, 1);
    for (int site = lastBathThisArm; site >= firstBathThisArm; --site) {
      currSite = site;
      if (!std::count(doubledBath.begin(), doubledBath.end(), currSite)) {
        state.position(currSite);
        ProjectSite(init);
      } else {
        state.position(currSite);
        init.set(currSite, "01");
      }
      //printfln("--- position is at %.12f", currSite);
    }
    if (params_.impPurified) {
      currSite = state.ImpSite(NArms);
      state.position(currSite);
      init.set(state.ImpSite(NArms), "01");
    } else {
      currSite = state.ImpSite(NArms);
      state.position(currSite);
      ProjectSite(init);
    }

    //project the rest arms
    for (int iArm = NArms - 1; iArm >= 1; --iArm) {
      if (!params_.impPurified) {
        currSite = state.ImpSite(iArm);
        state.position(currSite);
        ProjectSite(init);
      }

      firstBathThisArm = state.ArmToSite(iArm, state.NBath(iArm));
      lastBathThisArm  = state.ArmToSite(iArm, 1);
      for (int site = firstBathThisArm; site <= lastBathThisArm; ++site) {
        currSite = site;
        if (!std::count(doubledBath.begin(), doubledBath.end(), currSite)) {
          state.position(currSite);
          ProjectSite(init);
        } else {
          state.position(currSite);
          init.set(currSite, "01");
        }
      }
      //init.set(state.ImpSite(iArm), "01");
      if (params_.impPurified) {
        currSite = state.ImpSite(iArm);
        state.position(currSite);
        init.set(state.ImpSite(iArm), "01");
      };
    }
    //set the tensors on the impurity sites
    state = ForkTPS(init, sites.NArms());
    ResetPurifiedTensors(state, sites, doubledBath);
    //state.PrintOccs();
    auto tPro_ = pow(abs(overlap(state, state_in)), 2.);
    transitionProb.push_back(tPro_);
    if (params_.verbose >= 1) {
      ReportOnce("--- Transition probability |<i|phi>| = \n");
      if (world.rank() == 0) { std::cout << std::setprecision(10) << tPro_ << "\n" << std::endl; }
    }
    if (params_.verbose >= 2) {
      ReportOnce("--- new configuation ::\n");
      if (world.rank() == 0) { state.PrintOccs(); }
    }
  }

  // project the state to a product state with probability |<i|psi>|^2 with restriction of fixed bath sites
  void finiteT_solver_core::ProjectRestric(finiteT_params_t const &params_, int const &fixSites_) {
    auto state_in = state;
    InitState init(sites, "Emp");

    //place the orthogonality center at the last site
    state.position(state.N());
    //project the last arm
    int NArms             = state.NArms();
    auto firstBathThisArm = state.ArmToSite(NArms, state.NBath(NArms));
    auto lastBathThisArm  = state.ArmToSite(NArms, 1);
    for (int site = lastBathThisArm; site >= firstBathThisArm; --site) {
      currSite = site;
      if (!std::count(doubledBath.begin(), doubledBath.end(), currSite)) {
        state.position(currSite);
        ProjectSite(init);
      } else {
        state.position(currSite);
        init.set(currSite, "01");
      }
    }
    if (params_.impPurified) {
      currSite = state.ImpSite(NArms);
      state.position(currSite);
      init.set(state.ImpSite(NArms), "01");
    } else {
      currSite = state.ImpSite(NArms);
      state.position(currSite);
      ProjectSite(init);
    }

    //project the rest arms
    for (int iArm = NArms - 1; iArm >= 1; --iArm) {
      if (!params_.impPurified) {
        currSite = state.ImpSite(iArm);
        state.position(currSite);
        ProjectSite(init);
      }

      firstBathThisArm = state.ArmToSite(iArm, state.NBath(iArm));
      lastBathThisArm  = state.ArmToSite(iArm, 1);
      for (int site = firstBathThisArm; site <= lastBathThisArm; ++site) {
        currSite = site;
        if (!std::count(doubledBath.begin(), doubledBath.end(), currSite)) {
          state.position(currSite);
          ProjectSite(init);
        } else {
          state.position(currSite);
          init.set(currSite, "01");
        }
      }
      //init.set(state.ImpSite(iArm), "01");
      if (params_.impPurified) {
        currSite = state.ImpSite(iArm);
        state.position(currSite);
        init.set(state.ImpSite(iArm), "01");
      };
    }
    //set the tensors on the impurity sites
    state = ForkTPS(init, sites.NArms());
    ResetPurifiedTensors(state, sites, doubledBath);
    //state.PrintOccs();
    auto tPro_ = pow(abs(overlap(state, state_in)), 2.);
    transitionProb.push_back(tPro_);
    if (params_.verbose >= 1) {
      ReportOnce("--- Transition probability |<i|phi>| = \n");
      if (world.rank() == 0) { std::cout << std::setprecision(10) << tPro_ << "\n" << std::endl; }
      ReportOnce("--- new configuation ::\n");
      if (world.rank() == 0) { state.PrintOccs(); }
    }
  }

  // convert a product state to a filling vector
  std::vector<double> finiteT_solver_core::fillingFromProductState(ForkTPS &psi_) {
    std::vector<double> filling;
    for (int site = 1; site <= psi_.N(); ++site) {
      psi_.position(site);
      double fillingsite = std::real((psi_.A(site) * psi_.sites().op("N", site) * dag(prime(psi_.A(site), "Site"))).cplx());
      filling.push_back(fillingsite);
    }
    psi_.position(1);
    return filling;
  }

  // convert a filling vector to a product state
  ForkTPS finiteT_solver_core::productStateFromFilling(std::vector<double> const &filling_, ThermalForkSites const &sites_,
                                                       std::vector<int> const &doubledBath_) {
    InitState init_(sites_, "Emp");
    std::vector<int> purified_;
    for (int site = 1; site <= filling_.size(); ++site) {
      if (abs(filling_.at(site - 1) - 0.0) < 0.1) {
        init_.set(site, "Emp");
      } else if (abs(filling_.at(site - 1) - 1.0) < 0.1) {
        init_.set(site, "Occ");
      } else if (abs(filling_.at(site - 1) - 0.5) < 0.1) {
        init_.set(site, "01");
        purified_.push_back(site);
      }
    }

    ForkTPS psi_;
    psi_ = ForkTPS(init_, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi_, sites_, doubledBath_);
    psi_.position(1);
    return psi_;
  };

  // generate a label for the product state from its filling
  std::string finiteT_solver_core::generateLabel(ForkTPS &psi, finiteT_params_t const &params_) {
    std::string label;
    for (int site = 1; site <= psi.N(); ++site) {
      psi.position(site);
      if (params_.impPurified) {
        if (!psi.IsImp(site) && !std::count(doubledBath.begin(), doubledBath.end(), site)) {
          double filling = std::real((psi.A(site) * psi.sites().op("N", site) * dag(prime(psi.A(site), "Site"))).cplx());
          std::stringstream stream;
          stream << std::fixed << std::setprecision(0) << filling;
          label += stream.str();
        }
      } else {
        if (!std::count(doubledBath.begin(), doubledBath.end(), site)) {
          double filling = std::real((psi.A(site) * psi.sites().op("N", site) * dag(prime(psi.A(site), "Site"))).cplx());
          std::stringstream stream;
          stream << std::fixed << std::setprecision(0) << filling;
          label += stream.str();
        }
      }
    }
    if (params_.impPurified && (doubledBath.size() == (psi.N() - psi.NArms()))) { label = "FullyPurifiedState"; }
    return label;
  }

  // generate a label for the product state from its filling with a given UniEvoType
  std::string finiteT_solver_core::generateLabel(ForkTPS &psi, finiteT_params_t const &params_, UniEvoType const &uniType_) {
    std::string label;
    for (int site = 1; site <= psi.N(); ++site) {
      psi.position(site);
      if (params_.impPurified) {
        if (!psi.IsImp(site) && !std::count(doubledBath.begin(), doubledBath.end(), site)) {
          double filling = std::real((psi.A(site) * psi.sites().op("N", site) * dag(prime(psi.A(site), "Site"))).cplx());
          std::stringstream stream;
          stream << std::fixed << std::setprecision(0) << filling;
          label += stream.str();
        }
      } else {
        if (!std::count(doubledBath.begin(), doubledBath.end(), site)) {
          double filling = std::real((psi.A(site) * psi.sites().op("N", site) * dag(prime(psi.A(site), "Site"))).cplx());
          std::stringstream stream;
          stream << std::fixed << std::setprecision(0) << filling;
          label += stream.str();
        }
      }
    }
    if (uniType_ == UniEvoType::Even) {
      label += "Even";
    } else if (uniType_ == UniEvoType::Odd) {
      label += "Odd";
    }

    if (params_.impPurified && (doubledBath.size() == (psi.N() - psi.NArms()))) { label = "FullyPurifiedState"; }
    return label;
  }

  // check if a product state is already registered
  bool finiteT_solver_core::isRegistered(ForkTPS &psi, finiteT_params_t const &params_) {
    auto label = generateLabel(psi, params_);
    std::map<std::string, MettsData>::iterator it;
    it = statesPool.find(label);
    return it == statesPool.end() ? false : true;
  }

  // check if a product state is already registered with a given UniEvoType
  bool finiteT_solver_core::isRegistered(ForkTPS &psi, finiteT_params_t const &params_, UniEvoType const &uniType_) {
    auto label = generateLabel(psi, params_, uniType_);
    std::map<std::string, MettsData>::iterator it;
    it = statesPool.find(label);
    return it == statesPool.end() ? false : true;
  }

  // collect the sampling info from all the nodes
  void finiteT_solver_core::CollectSamplingInfo() {
    Energy = mpi::gather(Energy);
    //Occs    = mpi::gather(Occs, world);
    BigNorm = mpi::gather(BigNorm);
  }

  // write the sampling info to a file
  void finiteT_solver_core::WriteSamplingInfo(std::string const &fileName_, std::string const &label_) {
    auto arch = h5::file(fileName_, 'a');
    //h5_write(arch, "RepeatedTimes", RepeatedTimes.at(world.rank()));
    h5_write(arch, "TimeGrid", TimeGrid);
    h5_write(arch, "Repeated", statesPool[label_].repeated);
    h5_write(arch, "G_tau", statesPool[label_].g_tau);
    h5_write(arch, "G_t", statesPool[label_].g_t);
    h5_write(arch, "Energy", statesPool[label_].energy);
    h5_write(arch, "QuantumNumber", statesPool[label_].quantumNumber);
    h5_write(arch, "BigNorm", statesPool[label_].bigNorm);
    h5_write(arch, "ImpOcc", statesPool[label_].state.ImpOccs());
    h5_write(arch, "bondGrowth", statesPool[label_].bondGrowth);
    h5_write(arch, "bondGrowthGt", statesPool[label_].bondGrowthGt);
    h5_write(arch, "transitionProb", transitionProb);
    //std::cout << " transition prob on " << world.rank() << " is " << transitionProb << std::endl;

    arch.close();
  };

  // generatre N unique configurations from a given state
  std::tuple<std::vector<std::size_t>, std::vector<int>, std::vector<std::vector<int>>>
  finiteT_solver_core::GenerateUniqueConfs(ForkTPS const &psi_, finiteT_params_t const &params_, std::vector<int> purifiedSites_, int const &N_) {
    std::vector<std::size_t> confs(N_);
    std::vector<int> counts(N_);
    std::vector<std::vector<int>> filling(N_);
    int totalNew = 0;

    int accumulate = 0;
    while (totalNew != N_ && accumulate <= 2000) {
      state = psi_;
      Project(params_);
      auto label_this_rank      = generateLabel(state, params_);
      auto label_hash_this_rank = std::hash<std::string>{}(label_this_rank);
      auto it                   = std::find(confs.begin(), confs.end(), label_hash_this_rank);
      if (it == confs.end()) {
        confs.at(totalNew)  = label_hash_this_rank;
        counts.at(totalNew) = 1;
        //save the filling of this new generated product state
        std::vector<int> fillingThisState;
        double occupation;
        for (int site = 1; site <= state.N(); ++site) {
          state.position(site);
          if (params_.impPurified) {
            if (!state.IsImp(site) && !std::count(purifiedSites_.begin(), purifiedSites_.end(), site)) {
              occupation = std::real((state.A(site) * state.sites().op("N", site) * dag(prime(state.A(site), "Site"))).cplx());
              fillingThisState.push_back(std::round(occupation));
            }
          } else {
            if (!std::count(purifiedSites_.begin(), purifiedSites_.end(), site)) {
              occupation = std::real((state.A(site) * state.sites().op("N", site) * dag(prime(state.A(site), "Site"))).cplx());
              fillingThisState.push_back(std::round(occupation));
            }
          }
        }
        filling.at(totalNew) = fillingThisState;
        totalNew += 1;
      } else {
        counts.at(it - confs.begin()) += 1;
      }
      accumulate += 1;
    }
    ReportOnce("--- ", totalNew, " different conf. are generated", "\n");
    //if we can't generate so many unqique conf
    while (totalNew != N_) {
      state = psi_;
      Project(params_);
      auto label_this_rank      = generateLabel(state, params_);
      auto label_hash_this_rank = std::hash<std::string>{}(label_this_rank);
      confs.at(totalNew)        = label_hash_this_rank;
      counts.at(totalNew)       = 1;
      //save the filling of this new generated product state
      std::vector<int> fillingThisState;
      double occupation;
      for (int site = 1; site <= state.N(); ++site) {
        state.position(site);
        if (params_.impPurified) {
          if (!state.IsImp(site) && !std::count(purifiedSites_.begin(), purifiedSites_.end(), site)) {
            occupation = std::real((state.A(site) * state.sites().op("N", site) * dag(prime(state.A(site), "Site"))).cplx());
            fillingThisState.push_back(std::round(occupation));
          }
        } else {
          if (!std::count(purifiedSites_.begin(), purifiedSites_.end(), site)) {
            occupation = std::real((state.A(site) * state.sites().op("N", site) * dag(prime(state.A(site), "Site"))).cplx());
            fillingThisState.push_back(std::round(occupation));
          }
        }
      }
      filling.at(totalNew) = fillingThisState;
      totalNew += 1;
    }
    return std::make_tuple(confs, counts, filling);
  }

  // construct a product state from a given filling
  ForkTPS finiteT_solver_core::ConstructProductState(std::vector<int> const &filling_, std::vector<int> const &purifiedSites_,
                                                     ThermalForkSites const &sites_, finiteT_params_t const &params_) {
    if (!params_.impPurified) { Error("---@ConstructProductState, the imp has to be purified!"); };
    InitState init_(sites_, "Emp");
    int place = 0;
    for (int site = 1; site <= b.N(); ++site) {
      if (!sites_.IsImp(site) && !std::count(purifiedSites_.begin(), purifiedSites_.end(), site)) {
        if (filling_.at(place) == 0) {
          init_.set(site, "Emp");
        } else if (filling_.at(place) == 1) {
          init_.set(site, "Occ");
        } else {
          Error("---@ConstructProductState, the filling is not 0 or 1");
        }
        place += 1;
      }
    }
    for (int arm = 1; arm <= b.NArms(); arm++) { init_.set(sites_.ImpSite(arm), "01"); }
    for (auto const &site : purifiedSites_) { init_.set(site, "01"); };

    ForkTPS psi = ForkTPS(init_, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi, sites_, purifiedSites_);
    return psi;
  };

  //helper
  template <typename T, typename... Types> void finiteT_solver_core::ReportOnce(const T var1, const Types... var2) {
    int oldIndent = 0;
    if (indent != 0) {
      std::cout << std::string(indent, ' ');
      oldIndent = indent;
      indent    = 0;
    }
    reportOnceNoIndent(var1);
    ReportOnce(var2...);

    // this works always
    indent = oldIndent;
  }
  template <typename T> void finiteT_solver_core::reportOnceNoIndent(T s) {
    if (world.rank() == 0) { std::cout << s; }
  }

  template <typename T> void finiteT_solver_core::ReportOnce(T s) {
    if (world.rank() == 0) { std::cout << std::string(indent, ' ') << s; }
  };

  void finiteT_solver_core::Measure(std::string const &label, bool const &reg) {
    std::vector<double> occs;
    //auto sites = state.sites();
    auto N = state.N();
    state.position(1);
    if (reg) { statesPool[label].quantumNumber = div(state.A(1)).val("Nf"); }

    for (auto site : range1(N)) {
      state.position(site);
      auto n = state.A(site) * sites.op("N", site) * dag(prime(state.A(site), "Site"));
      occs.push_back(std::real(n.cplx()));
    }
    if (reg) { statesPool[label].occs = occs; }

    ForkLocalOp Heff(H);
    state.position(1);
    Heff.position(1, state);

    if (reg) { statesPool[label].energy = std::real(Heff.ContractAll(state)) - E0Shift; }
  };

  // calculate a green function component with a shifted time grid
  g_tau_t finiteT_solver_core::CalcGFShiftedSplit(std::string const &label, finiteT_params_t const &params_, int const &shiftedSteps_,
                                                  std::vector<triqs_indx> const &calc_me_component_) {
    //construct a new time grid which is much more sparse compared to the even grid
    ReportOnce("\n ------ debug, @CalcGFShifted", "\n");
    double originCutoff = args.getReal("Cutoff", -1.0);
    args.add("Cutoff", -1);
    std::vector<double> tListGf;
    std::vector<double> TimeGridGf;
    tListGf.push_back(0.0);
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 1.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 3.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 15.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + 2 * params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 50.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + 0.5);
    }
    while ((tListGf.back() < params_.beta / 2.0) && (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0)) {
      tListGf.push_back(tListGf.back() + 0.5);
    }
    // make the time grid more dense near the beta/2
    while (tListGf.back() > (params_.beta / 2.0 - 1.0)) { tListGf.pop_back(); }
    while (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + params_.tevo.dt); }

    // time grid for the green function
    int evoSteps_ = tListGf.size() - 1;
    TimeGridGf.resize(evoSteps_ * 2 + 1);
    for (int idx(0); idx < evoSteps_; idx++) {
      TimeGridGf.at(idx)       = tListGf.at(idx);
      TimeGridGf.rbegin()[idx] = params_.beta - tListGf.at(idx);
    }
    TimeGridGf.at(evoSteps_) = tListGf.at(evoSteps_);
    if (params_.beta <= 8.0) {
      tListGf    = tListLin;
      TimeGridGf = TimeGrid;
    }

    ReportOnce("\n ------ , @CalcGFShifted, tListGf", tListGf, "\n");

    // check the time grid end point is beta/2
    if (abs(tListGf.back() - params_.beta / 2.0) > 1E-3) {
      Error("---@CalcGfShifted, tListGf.back() != beta/2, inproper time grid !\n");
      PRINT(tListGf);
    }

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGridGf.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    // make shiftedSteps_ forard steps before calculate the Green's function estimator
    // Greater:
    // <i|  e^{-\beta/2}  e^{-shifted * H} e^{\tau H} c e^{-\tau H}   c^d  e^{shifted * H}  * e^{-\beta/2} |i>
    // lesser:
    // <i|  e^{-\beta/2}  e^{shifted * H}  c^d e^{ - \tau H}  c  e^{\tau H}  e^{-shifted * H} e^{-\beta/2} |i>
    if (shiftedSteps_ >= phitau.size() - 1) { throw ITError("@CalcGFShifted, back ward time larger than \beta/2"); }

    double norm_b = 0.0;
    for (int step(0); step < shiftedSteps_; step++) { norm_b -= phitau.at(phitau.size() - 1 - step).normFactor; }
    ForkTPS state_b = phitau.at(phitau.size() - 1 - shiftedSteps_).state;
    HeffState.ForgetContraction();
    args.add("TevoMethod", "TDVPFullSS");
    ReportOnce("---@CalcGFShifted, forward time evolve state ", shiftedSteps_, " steps... \n");
    for (int step(0); step < shiftedSteps_; step++) {
      TDVP(state, HeffState, params_.tevo.dt, args);
      auto norm = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));
      phitau.push_back({state, norm});
      norm_b += norm;
    }
    ReportOnce("---@CalcGFShifted, forward time evolve state ", shiftedSteps_, " steps...DONE \n");
    ReportOnce("---@CalcGFShifted, with norm_b = ", std::exp(norm_b), "\n");
    std::vector<std::vector<triqs_indx>> calc_me_;
    calc_me_.push_back(calc_me_component_);
    for (auto comp : calc_me_) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) {
        ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid, with shifted steps ", shiftedSteps_, "\n");
      }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS ketGr = state_b, braLe = state_b;
      ketGr.position(site_B, args);
      braLe.position(site_B, args);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
      //truncate the excited states, typically it should have lower entanglement compared with the ground state

      auto args_check = args;
      args_check.add("Cutoff", -1.0);
      ketGr.position(site_B, args_check);
      braLe.position(site_B, args_check);

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGridGf.size(), 0.);
      ReportOnce("--- norm(braLe)=", braLe.norm(), "\n");
      ReportOnce("--- norm(ketGr)=", ketGr.norm(), "\n");

      // index at which we take the thermal states stored in phitau
      int phitauIndx = phitau.size() - 1;
      // index of the Green's function entries
      int GfIndx = 0;

      double normGr = std::log(ketGr.normalizeLim());
      double normLe = std::log(braLe.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        auto braGr = phitau.at(phitauIndx).state;
        auto ketLe = phitau.at(phitauIndx).state;

        //Args args_positionBE("Cutoff", -1);
        auto ketGrAct = ketGr;
        auto braLeAct = braLe;

        ketGrAct.position(site_A, args);
        braLeAct.position(site_A, args);

        ketGrAct.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto valGr = (overlap(braGr, ketGrAct) * std::exp(normGr) * std::exp(norm_b));

        braLeAct.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
        auto valLe = (overlap(braLeAct, ketLe) * std::exp(normLe) * std::exp(norm_b));

        // at beta/2 average over greater and lesser
        if (GfIndx == tListGf.size() - 1) {
          gf.at(GfIndx) = 0.5 * (valGr + valLe);
        } else {
          gf.rbegin()[GfIndx] = valLe;
          gf.at(GfIndx)       = valGr;
        }

        return;
      };

      DoMeasure();
      if (params_.verbose >= 2) {
        ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
        ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
        ReportOnce("normGr Value::", normGr, "\n");
        ReportOnce("normLe Value::", normLe, "\n");
      }

      // loop over times
      HeffGr.ForgetContraction();
      HeffLe.ForgetContraction();
      ReportOnce("initial ketGr bonds \n");
      if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
      ReportOnce("initial braLe bonds \n");
      if (world.rank() == 0) { (braLe.PrintImpM(3)); };

      args.add("TevoMethod", "TDVP_2");
      args.add("CutOff", originCutoff);
      double totalT = 0.0;
      for (int step(0); step < tListGf.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        // decide whether to use TDVP or TDVPFullSS for greater
        std::string singleMethod = (totalT >= params_.sampling.minTwoSiteTimeGf) ? "TDVPFullSS" : "TDVP";
        if (args.getString("TevoMethod") != singleMethod && maxI_ == params_.tevo.approx.maxm_i) {
          if (params_.verbose >= 1) { ReportOnce("--- Greater::change to ", singleMethod, " @", totalT, " \n"); };
          args.add("TevoMethod", singleMethod);
          HeffGr.ForgetContraction();
          HeffLe.ForgetContraction();

          if (singleMethod == "TDVP") {
            args.add("CutOff", originCutoff);
          } else if (singleMethod == "TDVPFullSS") {
            args.add("CutOff", -1.0);
          }
        }
        //accumulated norm factor
        int multiFactor_  = round((tListGf.at(step + 1) - tListGf.at(step)) / params_.tevo.dt);
        double multiNorm_ = 0.0;
        for (int idx(0); idx < multiFactor_; idx++) { multiNorm_ += phitau.at(phitauIndx - idx).normFactor; }

        /*
        if (params_.basisExpansion.expand_critical) {
          //std::vector<double> criticalTime;
          //criticalTime.push_back(params_.beta / 6.);
          //criticalTime.push_back(params_.beta / 3.);
          for (auto tcritical : params_.basisExpansion.critical_time) {
            if (tListGf.at(step) <= tcritical && tListGf.at(step + 1) >= tcritical) {
              if (params_.basisExpansion.BEMethod == "ApplyH") {
                HBasis = H;
              } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
                double time_step_ = std::min(0.2, tListGf.at(step + 1) - tListGf.at(step));
                HBasis            = taylorFTPO(params_, b, e0, time_step_);
              }
              addBasis(ketGr, HBasis, args);
              HeffGr.ForgetContraction();
              if (params_.verbose >= 1) { ReportOnce("@CalcGfShifted, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
            }
          }
        }
        */

        TDVP(ketGr, HeffGr, tListGf.at(step + 1) - tListGf.at(step), args);
        normGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        // decide whether to use TDVP or TDVPFullSS for lesser
        if (args.getString("TevoMethod") != singleMethod && maxI_ == params_.tevo.approx.maxm_i) {
          if (params_.verbose >= 1) { ReportOnce("--- Lesser::change to ", singleMethod, "@", totalT, " \n"); };
          args.add("TevoMethod", singleMethod);

          HeffGr.ForgetContraction();
          HeffLe.ForgetContraction();

          if (singleMethod == "TDVP") {
            args.add("CutOff", originCutoff);
          } else if (singleMethod == "TDVPFullSS") {
            args.add("CutOff", -1.0);
          }
        }
        /*
        if (params_.basisExpansion.expand_critical) {
          //std::vector<double> criticalTime;
          //criticalTime.push_back(params_.beta / 6.);
          //criticalTime.push_back(params_.beta / 3.);
          for (auto tcritical : params_.basisExpansion.critical_time) {
            if (tListGf.at(step) <= tcritical && tListGf.at(step + 1) >= tcritical) {
              if (params_.basisExpansion.BEMethod == "ApplyH") {
                HBasis = H;
              } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
                double time_step_ = std::min(0.2, tListGf.at(step + 1) - tListGf.at(step));
                HBasis            = taylorFTPO(params_, b, e0, time_step_);
              }
              addBasis(braLe, HBasis, args);
              HeffLe.ForgetContraction();
              if (params_.verbose >= 1) { ReportOnce("@CalcGfShifted, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
            }
          }
        }
        */
        TDVP(braLe, HeffLe, tListGf.at(step + 1) - tListGf.at(step), args);
        normLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        phitauIndx -= multiFactor_;
        GfIndx++;

        DoMeasure();
        totalT = tListGf.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", tListGf.at(step + 1) - tListGf.at(step), ", multiFactor=", multiFactor_, ") \n");
          ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
          ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
          ReportOnce("normGr Value::", normGr, "\n");
          ReportOnce("normLe Value::", normLe, "\n");

          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
        }
      }

      // fill the Green's function component
      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGridGf.size(); it++) { ReportOnce("@T=", TimeGridGf.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    TimeGrid = TimeGridGf;

    args.add("Cutoff", originCutoff);
    return g_tau;
  };

  // calculate a green function component on a dlr grid
  g_tau_t finiteT_solver_core::CalcGFDLR(std::string const &label, finiteT_params_t const &params_,
                                         std::vector<triqs_indx> const &calc_me_component_) {
    //construct a new time grid which is much more sparse compared to the even grid
    double originCutoff = args.getReal("Cutoff", -1.0);
    args.add("Cutoff", -1);

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau)
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //check that every tau point in TimeGrid exists in tListDLR(beta/2 - tau/2)

    args.add("TevoMethod", "TDVPFullSS");

    std::vector<std::vector<triqs_indx>> calc_me_;
    calc_me_.push_back(calc_me_component_);
    for (auto comp : calc_me_) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);

      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], "> \n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);
      int GfIndex = 0;
      //loop over the dlr time grid
      if (params_.verbose >= 2) { ReportOnce(" The TimeGrid::", TimeGrid, " \n"); }

      for (auto tauDLR_ : TimeGrid) {
        if (tauDLR_ < params_.beta / 2.0) {
          //for each tauDLR point in TimeGrid
          std::vector<double> tListEvo;
          for (auto tau_ : tListDLR) {
            if (tau_ < tauDLR_ / 2.0) { tListEvo.push_back(tau_); }
          }
          tListEvo.push_back(tauDLR_ / 2.0);
          //if (params_.verbose >= 2) { ReportOnce("@tauDLR_::", tauDLR_, "tListEvo: ", tListEvo, "\n"); }

          //find the correct state and norm for the initial state
          ForkTPS state_i;
          double norm_initial = 0;
          int pos_;
          for (int it(0); it < statesPool[label].evoTauList.size(); it++) {
            if (abs(statesPool[label].evoTauList.at(it) - (params_.beta / 2.0 - tauDLR_ / 2)) < 1E-6) {
              state_i = statesPool[label].statesPath.at(it).state;
              pos_    = it;
              break;
            }
          }
          for (int it(pos_ + 1); it < statesPool[label].evoTauList.size(); it++) { norm_initial += statesPool[label].statesPath.at(it).normFactor; }

          ForkTPS braGr = state_i, ketGr = state_i, braLe = state_i, ketLe = state_i;
          braGr.position(site_A, args);
          ketGr.position(site_B, args);
          braLe.position(site_B, args);
          ketLe.position(site_A, args);
          braGr.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
          ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
          braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
          ketLe.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
          //truncate the excited states, typically it should have lower entanglement compared with the ground state

          auto args_check = args;
          args_check.add("Cutoff", -1.0);
          braGr.position(site_A, args_check);
          ketGr.position(site_B, args_check);
          braLe.position(site_B, args_check);
          ketLe.position(site_A, args_check);

          ForkLocalOp HeffbraGr_(H), HeffketGr_(H), HeffbraLe_(H), HeffketLe_(H);
          HeffbraGr_.ForgetContraction();
          HeffketGr_.ForgetContraction();
          HeffbraLe_.ForgetContraction();
          HeffketLe_.ForgetContraction();

          double normbraGr = std::log(braGr.normalizeLim());
          double normketGr = std::log(ketGr.normalizeLim());
          double normbraLe = std::log(braLe.normalizeLim());
          double normketLe = std::log(ketLe.normalizeLim());

          // loop over evolution times

          args.add("TevoMethod", "TDVP_2");
          args.add("CutOff", originCutoff);
          double totalT = 0.0;
          for (int step(0); step < tListEvo.size() - 1; step++) {
            //evolve the Greater one
            long maxI_ = 0, minI_ = 1000000;
            for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
              auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
              maxI_    = std::max(maxI_, dim(ind));
              minI_    = std::min(minI_, dim(ind));
            }
            // decide whether to use TDVP or TDVPFullSS for greater
            std::string singleMethod = (totalT >= params_.sampling.minTwoSiteTimeGf) ? "TDVPFullSS" : "TDVP";
            if (args.getString("TevoMethod") != singleMethod && maxI_ == params_.tevo.approx.maxm_i) {
              if (params_.verbose >= 1) { ReportOnce("--- Greater::change to ", singleMethod, " @", totalT, " \n"); };
              args.add("TevoMethod", singleMethod);
              HeffbraGr_.ForgetContraction();
              HeffketGr_.ForgetContraction();
              HeffbraLe_.ForgetContraction();
              HeffketLe_.ForgetContraction();

              if (singleMethod == "TDVP") {
                args.add("CutOff", originCutoff);
              } else if (singleMethod == "TDVPFullSS") {
                args.add("CutOff", -1.0);
              }
            }

            //evolve the Greater ket one
            TDVP(ketGr, HeffketGr_, tListEvo.at(step + 1) - tListEvo.at(step), args);
            normketGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")));
            //evolve the Greater bra one
            TDVP(braGr, HeffbraGr_, tListEvo.at(step + 1) - tListEvo.at(step), args);
            normbraGr += (std::log(braGr.normalizeLim()) + std::log(args.getReal("totalNorm")));

            //evolve the Lesser ket one
            TDVP(ketLe, HeffketLe_, tListEvo.at(step + 1) - tListEvo.at(step), args);
            normketLe += (std::log(ketLe.normalizeLim()) + std::log(args.getReal("totalNorm")));
            //evolve the Lesser bra one
            TDVP(braLe, HeffbraLe_, tListEvo.at(step + 1) - tListEvo.at(step), args);
            normbraLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")));
            totalT = tListEvo.at(step + 1);
          } // end loop tauDLR in TimeGrid

          // fill the Green's function component

          auto val_Gr          = overlap(braGr, ketGr) * std::exp(normbraGr + normketGr - 2.0 * norm_initial);
          auto val_Le          = overlap(braLe, ketLe) * std::exp(normbraLe + normketLe - 2.0 * norm_initial);
          gf.at(GfIndex)       = val_Gr;
          gf.rbegin()[GfIndex] = val_Le;
          GfIndex += 1;
          if (params_.verbose >= 2) { ReportOnce("@tauDLR=", tauDLR_, ", @pos=", pos_, ", val_Gr=", val_Gr, ", val_Le=", val_Le, "\n"); }
        }; //end if tauDLR < beta/2
      }    // end loop tauDLR in TimeGrid
      // fill the Green's function component
      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) { ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n"); }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };

    args.add("Cutoff", originCutoff);
    return g_tau;
  };

  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------
  // ------------------------------------------------- codes needed tested and not explictlly used ----------------------------------------------

  //solve the impurity proble by METTS sampling on real axis
  void finiteT_solver_core::solveReal(finiteT_solve_params_t const &solve_params_) {
    //combined parameters
    finiteT_params_t params(constr_params, solve_params_);
    //@TODO :: reconstruct the hybridization function
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    if (params.verbose >= 3) { ReportOnce("args::\n", args, "\n"); }
    E0Shift = 0.0;

    //a quick dmrg to check the input Hamiltonian
    if (params.quickDMRG.quickDMRG && world.rank() == 0) { E0Shift = QuickDMRG(params); };
    world.barrier(0);
    mpi::broadcast(E0Shift);

    //generate the time grid exponetial grid has the follow data
    //[0, t0* lam^0, t0 * lam^1, t0 * lam^2, ..., t0*lam^{N-1}] -> N+1 elements
    //with t0*lam^{N-1} = beta/2
    int evoSteps = 0;
    if (params.timeGrid == "Exp") {
      evoSteps      = params.sampling.exp_grid_steps == 0 ? std::min(2000, int(6 * params.beta)) : params.sampling.exp_grid_steps;
      double t0Imag = 0.05;
      tList.resize(evoSteps + 1, 0.);
      tList.at(0) = 0.0;
      double lam  = pow(params.beta / 2. / t0Imag, 1. / (double(evoSteps) - 1.));
      for (int step(0); step < evoSteps; step++) { tList.at(step + 1) = t0Imag * pow(lam, step); };
    } else {
      Error(" Wrong time Grid!!, Currently supported are :: {Even, Exp} time grid");
    }

    //the total time grid for the Green's function
    TimeGrid.resize(params.tevo.time_steps + 1);
    TimeGrid.at(0) = 0.0;
    for (int idx(0); idx < params.tevo.time_steps; idx++) { TimeGrid.at(idx + 1) = double(idx + 1) * params.tevo.dt; }
    //debug
    {
      ReportOnce(" tList:: ", tList, "\n");
      ReportOnce(" TimeGrid:: ", TimeGrid, "\n");
    }

    //check the purification threshold is in [0., 1]
    if (params.sampling.purification_threshold < 0.0 || params.sampling.purification_threshold > 1) {
      Error("The purification threshold SHOULD in [0.0, 1.0] with 0.0 to leave all bath sites unpurified while 1 to purify all bath sites");
    };

    // an initial sites object which will be overwritten if new purificed bath sites are asign
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    doubledBath = DeterminePurificeBathSites(params);

    //reassign the sites and state object
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});

    if (params.verbose >= 1) {
      ReportOnce("bath information :: ", " total bath sites = ", b.N(), ", #num of arms = ", b.NArms(), "\n");
      ReportOnce("\n there are ", doubledBath.size(), " (", b.N() - b.NArms(), ") purified bath sites :: \n");
      for (auto site : doubledBath) { ReportOnce(site, "\t"); }
      ReportOnce("\n");
      ReportOnce("And the imputities are ", params.impPurified ? "Purified " : " not purified\n");
    }

    E0Shift = 0.0;
    if (params.verbose >= 1) { ReportOnce("Rough estimation of E0Shift is ", E0Shift, "\n"); }
    //FTPO
    H         = whichFTPO(params, sites);
    HeffState = ForkLocalOp(H);
    //FTPO for unitary time evolution

    //initialize the bath parameters for unitary time evolution
    bUni    = b;
    auto bw = b.bandwidth();
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      auto bwThisArm = bw.at(ind.first).at(ind.second).second - bw.at(ind.first).at(ind.second).first;
      for (auto k : itertools::range(bUni.NBath(ind))) { // / 2 - int(0.1 * bUni.NBath(ind)), bUni.NBath(ind) / 2 + int(0.1 * bUni.NBath(ind)))) {
        if (abs(b.eps(ind, k)) <= 0.1 * bwThisArm) {
          bUni.b.at(ind.first).at(ind.second).at(k).eps = -b.eps(ind, k); //b.b.at(ind.first).at(ind.second).at(k).eps;
          ReportOnce("--- Unitary Hamiltonain, on-site potential on ", ind.first, ", orb ", ind.second, ", bath ", k, " is reversed\n");
        }
        //b.eps(ind, b.NBath(ind) - 1 - k);
      }
    }

    auto e0Uni = e0;
    for (auto block : params.gf_struct) {
      for (int iorb(0); iorb < block.second; iorb++) {
        for (int jorb(0); jorb < block.second; jorb++) { e0Uni.e.at(block.first)(iorb, jorb) = 0.; }
      }
    }
    auto h_int_uni = H_int(0.001, 0.0, 0.0, true);
    //FTPO for unitary time evolution
    //Huni = whichFTPO(params, sites, bUni, e0Uni, h_int_uni);
    Huni = H;
    //params_tmp.h_int = H_int(0.01, 0.0, 0.0, false);
    //Huni = whichFTPO(params, sites, bUni, e0);

    //initialize a product state with impuritiy sites and
    // bath sites in doubledBath will be in (|01> + |10>)
    InitState init(sites, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty

    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites.ArmToSite(arm, k + 1))) {
          //if (abs(k - b.NBath(ind) / 2) > 0.1 * b.NBath(ind)) {
          if (b.eps(ind, k) < 0) init.set(sites.ArmToSite(arm, k + 1), "Occ");
          //} else {
          //  std::random_device rd;
          //  std::mt19937 RNG(rd()); //
          //  std::uniform_real_distribution<double> Uniform(0., 1.);
          // auto randomNumber = Uniform(RNG);
          // init.set(sites.ArmToSite(arm, k + 1), randomNumber >= 0.5 ? "Occ" : "Emp");
          //}
        }
      }
      //the impurity sites are always purified
      if (params.impPurified) {
        init.set(sites.ImpSite(arm), "01");
      } else {
        std::random_device rd;
        std::mt19937 RNG(rd()); //
        std::uniform_real_distribution<double> Uniform(0., 1.);
        auto randomNumber = Uniform(RNG);
        init.set(sites.ImpSite(arm), randomNumber >= 0.5 ? "Occ" : "Emp");
      }
    }
    for (auto site : doubledBath) { init.set(site, "01"); };

    state = ForkTPS(init, sites.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(state, sites, doubledBath);

    //thermalize
    HeffState = ForkLocalOp(H);

    if (params.sampling.n_thermal > 0) {
      //Thermalize(params);
      //reassign E0Shift base on the thermalization states
      ThermalizeUnitary(params);
      world.barrier(0);
      if (params.verbose >= 1) { ReportOnce("----- E0Shift from thermalization energy is ", E0Shift, "\n"); }
    };
    //sampling
    world.barrier(0);
    //if we use an exponential time grid, the we need to evaluate both e^{-tau H} and e^{tau H}, hence,
    //we should not shift the zero energy position in such case
    //if (params.timeGrid == "Exp") { E0Shift = 0.0; }

    H = whichFTPO(params, sites);

    HeffState = ForkLocalOp(H);
    HeffGr    = ForkLocalOp(H);
    HeffLe    = ForkLocalOp(H);
    HeffGrb   = ForkLocalOp(H);
    HeffLeb   = ForkLocalOp(H);

    SamplingRealUnitary(params);

    //collect G_tau
    //G_tau /= double(1. * params.sampling.n_sampling + RepeatedTimes.at(world.rank()) - 1.);
    world.barrier(0);
    G_t = mpi::all_reduce(G_t, world);
    //int totalSampling = 0;
    //for (int irank(0); irank < world.size(); irank++) { totalSampling += params.sampling.n_sampling + RepeatedTimes.at(irank) - 1.; }
    //for (int irank(0); irank < world.size(); irank++) { totalSampling += params.sampling.n_sampling; }

    //detail debug
    /*
    {
      for (int irank(0); irank < world.size(); irank++) {
        if (irank == world.rank()) { std::cout << " totalCount on rank " << irank << " ::" << totalCount << "\n" << std::endl; }
      }
    }
    */
    totalCount = mpi::all_reduce(totalCount, world);
    ReportOnce(" total count ::", totalCount);
    //G_tau /= double(world.size());
    G_t /= double(totalCount);

    CollectSamplingInfo();
    world.barrier(0);
  };

  //solve the impurity proble by METTS sampling with constructed basis
  void finiteT_solver_core::solveBasis(finiteT_solve_params_t const &solve_params_) {
    //combined parameters
    finiteT_params_t params(constr_params, solve_params_);
    //@TODO :: reconstruct the hybridization function
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    if (params.verbose >= 3) { ReportOnce("args::\n", args, "\n"); }
    E0Shift = 0.0;

    //a quick dmrg to check the input Hamiltonian
    if (params.quickDMRG.quickDMRG && world.rank() == 0) { E0Shift = QuickDMRG(params); };
    world.barrier(0);
    mpi::broadcast(E0Shift);

    //generate the time grid exponetial grid has the follow data
    //[0, t0* lam^0, t0 * lam^1, t0 * lam^2, ..., t0*lam^{N-1}] -> N+1 elements
    //with t0*lam^{N-1} = beta/2
    int evoSteps = 0;
    if (params.timeGrid == "Even") {
      evoSteps = std::round(params.beta / params.tevo.dt / 2.);
      tList.resize(evoSteps + 1, 0.);
      tList.at(0) = 0.0;
      //double lam  = pow(params.beta / 2. / params.tevo.dt, 1. / (double(params.tevo.time_steps) - 1.));
      for (int step(0); step < evoSteps; step++) {
        tList.at(step + 1) = double(step + 1) * params.tevo.dt; //params.tevo.dt * pow(lam, step);
      };
    } else if (params.timeGrid == "Exp") {
      evoSteps = params.tevo.time_steps;
      tList.resize(evoSteps + 1, 0.);
      tList.at(0) = 0.0;
      double lam  = pow(params.beta / 2. / params.tevo.dt, 1. / (double(params.tevo.time_steps) - 1.));
      for (int step(0); step < evoSteps; step++) { tList.at(step + 1) = params.tevo.dt * pow(lam, step); };

      int evoStepsExc = int(params.tevo.time_steps / 2);
      tListExcited.resize(evoStepsExc + 1, 0.);
      tListExcited.at(0) = 0.0;
      auto betaExc       = params.beta / 4.;
      auto lamExc        = pow(betaExc / params.tevo.dt, 1. / (double(evoStepsExc) - 1.));
      for (int step(0); step < evoStepsExc; step++) { tListExcited.at(step + 1) = params.tevo.dt * pow(lamExc, step); };
    } else {
      Error(" Wrong time Grid!!, Currently supported are :: {Even, Exp} time grid");
    }

    //the total time grid for the Green's function has 2*N+1 points
    TimeGrid.resize(evoSteps * 2 + 1);
    for (int idx(0); idx < evoSteps; idx++) {
      TimeGrid.at(idx)       = tList.at(idx);
      TimeGrid.rbegin()[idx] = params.beta - tList.at(idx);
    }
    TimeGrid.at(evoSteps) = tList.at(evoSteps);

    //ReportOnce(" tList:: ", tList, "\n");
    //ReportOnce(" TimeGrid:: ", TimeGrid, "\n");

    //check the purification threshold is in [0., 1]
    if (params.sampling.purification_threshold < 0.0 || params.sampling.purification_threshold > 1) {
      Error("The purification threshold SHOULD in [0.0, 1.0] with 0.0 to leave all bath sites unpurified while 1 to purify all bath sites");
    };

    // an initial sites object which will be overwritten if new purificed bath sites are asign
    doubledBath.empty();
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    doubledBath = DeterminePurificeBathSites(params);
    //reassign the sites and state object
    sites = ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});

    if (params.verbose >= 1) {
      ReportOnce("bath information :: ", " total bath sites = ", b.N(), ", #num of arms = ", b.NArms(), "\n");
      ReportOnce("\n there are ", doubledBath.size(), " (", b.N() - b.NArms(), ") purified bath sites :: \n");
      for (auto site : doubledBath) { ReportOnce(site, "\t"); }
      ReportOnce("\n");
      ReportOnce("And the imputities are ", params.impPurified ? "Purified " : " not purified\n");
    }

    if (params.verbose >= 1) { ReportOnce("Rough estimation of E0Shift is ", E0Shift, "\n"); }
    //FTPO
    H         = whichFTPO(params, sites);
    HeffState = ForkLocalOp(H);
    //FTPO for unitary time evolution
    auto params_tmp = params;
    //params_tmp.h_int = H_int(0.01, 0.0, 0.0, false);
    Huni = H; //whichFTPO(params, sites);

    //initialize a product state with impuritiy sites and
    // bath sites in doubledBath will be in (|01> + |10>)
    InitState init(sites, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init.set(sites.ArmToSite(arm, k + 1), "Occ");
        }
      }
      //the impurity sites are always purified
      if (params.impPurified) {
        init.set(sites.ImpSite(arm), "01");
      } else {
        init.set(sites.ImpSite(arm), arm % 2 == 0 ? "Occ" : "Emp");
      }
    }
    for (auto site : doubledBath) { init.set(site, "01"); };

    state = ForkTPS(init, sites.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(state, sites, doubledBath);

    //debug
    {
      world.barrier(0);
      for (int irank(0); irank < world.size(); irank++) {
        if (irank == world.rank()) {
          std::cout << "\n\n\n\n rank ::" << irank << std::endl;
          state.PrintOccs();
        }
      }
    }

    //thermalize
    HeffState = ForkLocalOp(H);

    //repeated time
    //RepeatedTimes.resize(world.size());
    //RepeatedTimes.at(0) = 1;
    //for (int irank(1); irank < world.size(); irank++) { RepeatedTimes.at(irank) = 0; }
    //debug
    /*
    {
      Index I(3, "i");
      ITensor h_(I, prime(I));
      h_.set(1, 1, 0.35);
      h_.set(2, 2, 0.21);
      h_.set(3, 3, 0.16);

      h_.set(1, 2, 0.878);
      h_.set(2, 1, 0.878);

      h_.set(1, 3, 3.12);
      h_.set(3, 1, 3.12);

      h_.set(2, 3, 0.981);
      h_.set(3, 2, 0.981);

      auto exph_ = ExponentialMatrix(0.18, h_);
      for (int i(1); i < 4; i++) {
        for (int j(1); j < 4; j++) { ReportOnce(" exph::", i, ",", j, "=", eltC(exph_, i, j)); }
      }
    }
    */

    if (params.sampling.n_thermal > 0) {
      Thermalize(params);
      //reassign E0Shift base on the thermalization states
      world.barrier(0);
      if (params.verbose >= 1) { ReportOnce("----- E0Shift from thermalization energy is ", E0Shift, "\n"); }
    };
    //sampling
    world.barrier(0);
    //if we use an exponential time grid, the we need to evaluate both e^{-tau H} and e^{tau H}, hence,
    //we should not shift the zero energy position in such case
    //if (params.timeGrid == "Exp") { E0Shift = 0.0; }
    H = whichFTPO(params, sites);

    HeffState = ForkLocalOp(H);
    HeffGr    = ForkLocalOp(H);
    HeffLe    = ForkLocalOp(H);
    HeffGrb   = ForkLocalOp(H);
    HeffLeb   = ForkLocalOp(H);

    //debug
    /*
    {
      Index I(3, "i_debug"), J(3, "j_debug"), K(3, "j_debug");
      ITensor C(I, J);
      C.set(1, 1, 1.0);
      C.set(2, 2, 1.0);
      C.set(3, 3, 1.0);
      C.set(1, 2, 0.7);
      C.set(2, 1, 0.7);
      C.set(1, 3, 0.3);
      C.set(3, 1, 0.3);

      auto [U, S, V] = svd(C, {I}, {"Cutoff", 1E-1});
      Index Il       = commonIndex(U, S);
      Index Ir       = commonIndex(S, V);

      std::cout << "Truncated size = " << dim(Il) << std::endl;

      ITensor S_sqrt(Il, Ir);
      for (int i(1); i < dim(Il) + 1; i++) { S_sqrt.set(Il = i, Ir = i, pow(eltC(S, Il = i, Ir = i), -0.5)); }

      ITensor R = S_sqrt * V;

      for (int i(1); i < dim(inds(R)(1)) + 1; i++) {
        for (int j(1); j < dim(inds(R)(2)) + 1; j++) {
          std::cout << "R(" << i << "," << j << ")=" << std::setprecision(10) << eltC(R, i, j) << std::endl;
        }
      }

      ITensor R_dag = dag(R);
      R_dag         = R_dag * delta(Il, prime(Il));
      R_dag         = R_dag * delta(J, K);

      ITensor Heff(J, K);
      Heff.set(1, 1, 2.1);
      Heff.set(2, 2, 1.3);
      Heff.set(3, 3, 2.1);
      Heff.set(1, 2, 0.6);
      Heff.set(2, 1, 0.6);
      Heff.set(1, 3, 0.2);
      Heff.set(3, 1, 0.2);

      ITensor Heff_basis = R * Heff * R_dag;

      for (int i(1); i < dim(inds(Heff_basis)(1)) + 1; i++) {
        for (int j(1); j < dim(inds(Heff_basis)(2)) + 1; j++) {
          std::cout << "Heff_R(" << i << "," << j << ")=" << std::setprecision(10) << eltC(Heff_basis, i, j) << std::endl;
        }
      }

      auto expH = ExponentialMatrix(0.31, Heff_basis);
      for (int i(1); i < dim(inds(expH)(1)) + 1; i++) {
        for (int j(1); j < dim(inds(expH)(2)) + 1; j++) {
          std::cout << "exp Heff_R(" << i << "," << j << ")=" << std::setprecision(10) << eltC(expH, i, j) << std::endl;
        }
      }
    }
    */

    SamplingBasis(params);
    //collect G_tau
    //G_tau /= double(1. * params.sampling.n_sampling + RepeatedTimes.at(world.rank()) - 1.);
    world.barrier(0);

    if (world.rank() == 0) {
      GenerateBasisInfos(params, sites);
      /*
      int total  = 0;
      int istate = 1;
      for (auto metts_infos : statesPool) {
        ReportOnce("--- Calculating the ", istate, "/", statesPool.size(), " Green's function");
        //PrintData(basisInfos.Heff);
        auto g_tau = CalcGFBasis(istate, params);
        auto psi_  = basisInfos.states_metts.at(istate - 1);
        psi_.ApplySingleSiteOp(sites.op("N", 1), 1, false);
        auto density = overlap(basisInfos.states_metts.at(istate - 1), psi_);

        auto repeated = metts_infos.second.repeated;

        auto arch = h5::file(fileNameIntermedia + "/gf_" + std::to_string(istate), 'a');
        h5_write(arch, "g_tau_" + std::to_string(istate), g_tau);
        h5_write(arch, "repeated_" + std::to_string(istate), repeated);
        h5_write(arch, "density", density);
        h5_write(arch, "QN", metts_infos.second.quantumNumber);
        arch.close();
        //        repeated = 1;

        if (istate == 1) {
          G_tau = repeated * g_tau;
        } else {
          G_tau += repeated * g_tau;
        }
        total += repeated;
        istate += 1;
      }
      G_tau /= double(total);
      */

      G_tau = CalcGFBasis(params);
    };

    //G_tau             = mpi::all_reduce(G_tau, world);
    //int totalSampling = 0;
    //for (int irank(0); irank < world.size(); irank++) { totalSampling += params.sampling.n_sampling + RepeatedTimes.at(irank) - 1.; }
    //for (int irank(0); irank < world.size(); irank++) { totalSampling += params.sampling.n_sampling; }
    //G_tau /= double(totalSampling);

    //CollectSamplingInfo();
    world.barrier(0);
  };

  //estimate E_infty
  void finiteT_solver_core::EinftyEstimate(finiteT_solve_params_t const &solve_params_) {
    //combined parameters
    finiteT_params_t params(constr_params, solve_params_);
    if (params.verbose >= 1) { ReportOnce(" --------- Estimate E_infty by sampling :: \n"); }

    sites = ThermalForkSites(b.N(), b.NArms(), {}, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", false});
    H     = whichFTPO(params, sites);

    std::vector<std::vector<bool>> confs;
    int totalConfNum = pow(2, b.NArms());
    for (int num(0); num < totalConfNum; num++) {
      std::vector<bool> thisConf;
      int ite = 1;
      for (int iarm(0); iarm < b.NArms(); iarm++) {
        if ((num & ite) != 0) {
          thisConf.push_back(true);
        } else {
          thisConf.push_back(false);
        }
        ite *= 2;
      }
      confs.push_back(thisConf);
    }

    EInfty = 0.0;
    for (auto conf : confs) {
      InitState init(sites, "Emp");
      //site with negative on-site energy will be occupied
      //while site with positive on-site energy will be empty
      for (auto arm : range1(sites.NArms())) {
        triqs_indx ind = ArmToTriqsIndx(arm);

        bool impFilled  = conf.at(arm - 1);
        int numNegative = 0;

        //total number of negative sites
        for (auto k : itertools::range(b.NBath(ind))) {
          if (b.eps(ind, k) <= 0) { numNegative += 1; }
        }

        int it = 0;
        for (auto k : itertools::range(b.NBath(ind))) {
          if (b.eps(ind, k) <= 0) {
            it += 1;
            if (numNegative == it) {
              init.set(sites.ArmToSite(arm, k + 1), impFilled ? "Emp" : "Occ");
            } else {
              init.set(sites.ArmToSite(arm, k + 1), "Occ");
            }
          };
        }

        init.set(sites.ImpSite(arm), impFilled ? "Occ" : "Emp");
      }

      //evalute <H>

      state = ForkTPS(init, sites.NArms());
      if (params.verbose >= 1) { state.PrintOccs(); }
      auto Heff_ = ForkLocalOp(H);
      Heff_.position(1, state);
      EInfty += std::real(Heff_.ContractAll(state));
    }

    EInfty /= float(totalConfNum);
    ReportOnce("#Confs. :: ", totalConfNum, "Einfty=", EInfty, "\n");
  };

  ForkTPS finiteT_solver_core::DirectSum(ForkTPS const &psi_, ForkTPS const &phi_) {
    ForkTPS res = psi_;
    ITensor first, second, first_l, second_l;
    std::vector<ITensor> impTensors_psi(psi_.NArms()), impTensors_phi(phi_.NArms());

    if (psi_.NArms() != phi_.NArms() || psi_.N() != phi_.N()) { Error("@DirectSum, the input states do not have the same fork structure"); }
    //loop over the arms to sum bath tensors
    for (auto iarm : range1(psi_.NArms())) {
      auto impThisArm      = psi_.ImpSite(iarm);
      auto lastBathThisArm = psi_.ArmToSite(iarm, 1);
      //loop from the last site on this arm
      int site      = lastBathThisArm;
      auto link_psi = commonIndex(psi_.A(site), psi_.A(site - 1));
      auto link_phi = commonIndex(phi_.A(site), phi_.A(site - 1));
      auto link_sum = link_psi;
      plussers(link_psi, link_phi, link_sum, first, second);
      res.Anc(site) = psi_.A(site) * first + phi_.A(site) * second;
      for (int site = lastBathThisArm - 1; site > impThisArm; site--) {
        //ReportOnce("arm ", iarm, " bath site ", site, "\n");
        first_l  = first;
        second_l = second;

        link_psi = commonIndex(psi_.A(site), psi_.A(site - 1));
        link_phi = commonIndex(phi_.A(site), phi_.A(site - 1));
        link_sum = link_psi;
        plussers(link_psi, link_phi, link_sum, first, second);
        res.Anc(site) = dag(first_l) * psi_.A(site) * first + dag(second_l) * phi_.A(site) * second;
      }
      //ReportOnce("add imp site ", impThisArm);
      impTensors_psi.at(iarm - 1) = dag(first) * psi_.A(impThisArm);
      impTensors_phi.at(iarm - 1) = dag(second) * phi_.A(impThisArm);
    }
    //sum the impurity tensors
    auto thisImpSite = psi_.ImpSite(1);
    auto nextImpSite = psi_.ImpSite(2);

    auto link_psi = commonIndex(psi_.A(thisImpSite), psi_.A(nextImpSite));
    auto link_phi = commonIndex(phi_.A(thisImpSite), phi_.A(nextImpSite));
    auto link_sum = link_psi;
    plussers(link_psi, link_phi, link_sum, first, second);
    res.Anc(thisImpSite) = impTensors_psi.at(0) * first + impTensors_phi.at(0) * second;
    for (int iarm = 2; iarm < psi_.NArms(); iarm++) {
      first_l  = first;
      second_l = second;

      thisImpSite = psi_.ImpSite(iarm);
      nextImpSite = psi_.ImpSite(iarm + 1);

      link_psi = commonIndex(psi_.A(thisImpSite), psi_.A(nextImpSite));
      link_phi = commonIndex(phi_.A(thisImpSite), phi_.A(nextImpSite));
      link_sum = link_psi;
      plussers(link_psi, link_phi, link_sum, first, second);
      res.Anc(thisImpSite) = dag(first_l) * impTensors_psi.at(iarm - 1) * first + dag(second_l) * impTensors_phi.at(iarm - 1) * second;
    }
    thisImpSite          = psi_.ImpSite(psi_.NArms());
    res.Anc(thisImpSite) = dag(first) * impTensors_psi.at(psi_.NArms() - 1) + dag(second) * impTensors_phi.at(phi_.NArms() - 1);

    return res;
  }

  ForkTPS finiteT_solver_core::ArithmeticOrth(ForkTPS &psi_, std::vector<ForkTPS> &states_) {
    ForkTPS psi = psi_;
    //move the orthogonality center to the first site
    psi.position(1);
    for (auto &state : states_) {
      state.position(1);
      auto overlapVal = overlap(state, psi);
      auto newState   = state;
      newState *= -overlapVal;
      psi = DirectSum(psi, newState);
      if (psi.norm() < ZERONORM) { Error("@ArithmeticOrth, the result state has zero norm"); }
    }
    return psi;
  }

  template <class T>
  std::pair<bool, ForkTPS> finiteT_solver_core::GlobalKrylovTimeEvo(ITensor &heff, std::vector<ForkTPS> &krylovSpace, ForkTPO const &H_, T t,
                                                                    finiteT_params_t params_) {
    if (krylovSpace.size() == 0) { Error("@GlobalKrylovTimeEvo, at least on initial state must be provided"); };
    if (krylovSpace.size() > params_.gKrylov.nKrylov) { Error("@GlobalKrylovTimeEvo, the input krylov vectors exceeds the desired subspace size"); }

    //local variables
    Args args_applyH;
    args_applyH.add("Orthog", false);
    args_applyH.add("Cutoff", MIN_CUT);
    Args args_fit = args;
    args_fit.add("SubspaceMaxm", 50);
    ForkTPS psi_apply_H;
    Args args_rescale = args;
    args_rescale.add(Names::MAXMB, 2 * args.getInt(Names::MAXMB));
    args_rescale.add(Names::MAXMIB, args.getInt(Names::MAXMIB));
    args_rescale.add(Names::MAXMI, args.getInt(Names::MAXMI));
    args_rescale.add(Names::TWB, MIN_CUT);
    args_rescale.add(Names::TWIB, MIN_CUT);
    args_rescale.add(Names::TWI, MIN_CUT);

    int currentSize = krylovSpace.size();
    bool evolved;
    std::vector<std::complex<double>> weights;
    //if krylovSpace.size() == 0, the effective Hamiltonian needs to be generated
    if (krylovSpace.size() == 1) {
      Index I(currentSize, "i");
      Index J = prime(I);
      ITensor heff_(I, J);
      psi_apply_H = krylovSpace.front();
      //psi_apply   = FitApplyMPO(psi_apply, H_, args_fit);
      psi_apply_H = exactApplyMPO(krylovSpace.front(), H_, args_applyH);
      auto dia    = overlap(krylovSpace.front(), psi_apply_H);
      heff_.set(I = 1, J = 1, dia);
      heff = heff_;
    }

    //first check the input heff can converge or not
    auto [U, D]     = diagHermitian(heff);
    ITensor Udagger = dag(U);
    weights.resize(currentSize, 0.0);
    for (int i(0); i < currentSize; i++) {
      weights.at(i) = 0.0;
      for (int j(0); j < currentSize; j++) {
        //weights.at(i) += eltC(Udagger, IndexVal(I, i + 1), IndexVal(ud_d, j + 1)) * std::exp(-t * eltC(D, j + 1, j + 1))
        //   * eltC(U, IndexVal(d_u, j + 1), IndexVal(J, 1));
        weights.at(i) += eltC(Udagger, i + 1, j + 1) * std::exp(-t * eltC(D, j + 1, j + 1)) * eltC(U, 1, j + 1);
      }
    }
    if (params_.verbose >= 4) {
      for (int ik(0); ik < weights.size(); ik++) { ReportOnce("weight:: ", weights.at(ik), "\n"); }
    }
    evolved = ((abs(weights.back()) / abs(weights.front())) < params_.gKrylov.threshold) ? true : false;

    //add new krylov vectors
    while (!evolved && currentSize < params_.gKrylov.nKrylov) {
      currentSize += 1;
      if (params_.verbose >= 3) { ReportOnce("--- generating the ", currentSize, " th krylov vector\n"); };

      //prepare the orthogonal space
      std::vector<ForkTPS> orthoStates;
      for (auto const &state : krylovSpace) {
        orthoStates.push_back(state);
        if (orthoStates.size() > params_.gKrylov.orthoSize) { orthoStates.erase(orthoStates.begin()); }
      }

      ForkTPS psi_new = krylovSpace.back();
      psi_new         = exactApplyMPO(psi_new, H_, args_applyH); //FitApplyMPO(psi_new, H_, args_fit);
      // psi_new.normalize();
      psi_new = ArithmeticOrth(psi_new, orthoStates);
      psi_new.normalize();
      psi_new.position(psi_new.N(), args_rescale);
      psi_new.position(1, args);
      krylovSpace.push_back(psi_new);
      orthoStates.push_back(psi_new);

      if (orthoStates.size() > params_.gKrylov.orthoSize) { orthoStates.erase(orthoStates.begin()); };
      if (params_.verbose >= 4) {
        ReportOnce(currentSize, "th krylov vector generated\n");
        ReportOnce("krylovSpace now has size=", krylovSpace.size(), "\n");
        if (world.rank() == 0) { krylovSpace.at(currentSize - 1).PrintImpM(); };
        ReportOnce("\n");
      }
      //}
      Index I(currentSize, "i");
      Index J = prime(I);
      ITensor heff_(I, J);

      //assign the old data
      for (int ik = 0; ik < currentSize - 1; ik++) {
        auto dia = eltC(heff, ik + 1, ik + 1);
        heff_.set(ik + 1, ik + 1, dia);
        if (ik < currentSize - 2) {
          auto offDia = eltC(heff, ik + 1, ik + 2);
          heff_.set(ik + 1, ik + 2, offDia);
          heff_.set(ik + 2, ik + 1, std::conj(offDia));
        }
      }

      //compute the new element
      //for (int ik = 0; ik < currentSize; ik++) {
      psi_apply_H = krylovSpace.back();
      psi_apply_H = FitApplyMPO(psi_apply_H, H_, args_fit);
      auto dia    = overlap(krylovSpace.back(), psi_apply_H);
      heff_.set(currentSize, currentSize, dia);
      auto offDia = overlap(krylovSpace.at(currentSize - 2), psi_apply_H);

      heff_.set(I = currentSize - 1, J = currentSize, offDia);
      heff_.set(I = currentSize, J = currentSize - 1, std::conj(offDia));

      heff = heff_;

      //if (krylovSpace.size() != params_.gKrylov.nKrylov) { Error("@GlobalKrylovTimeEvo, the krylov space is not equal to nKrylov"); }
      // dag(U) * D * prime(U) = heff
      auto [U, D]     = diagHermitian(heff);
      ITensor Udagger = dag(U);

      //construct the weights
      weights.resize(currentSize, 0.0);
      for (int i(0); i < currentSize; i++) {
        weights.at(i) = 0.0;
        for (int j(0); j < currentSize; j++) {
          //weights.at(i) += eltC(Udagger, IndexVal(I, i + 1), IndexVal(ud_d, j + 1)) * std::exp(-t * eltC(D, j + 1, j + 1))
          //   * eltC(U, IndexVal(d_u, j + 1), IndexVal(J, 1));
          weights.at(i) += eltC(Udagger, i + 1, j + 1) * std::exp(-t * eltC(D, j + 1, j + 1)) * eltC(U, 1, j + 1);
        }
      }
      if (params_.verbose >= 4) {
        for (int ik(0); ik < weights.size(); ik++) { ReportOnce("weight:: ", weights.at(ik), "\n"); }
      }

      evolved = ((abs(weights.back()) / abs(weights.front())) < params_.gKrylov.threshold) ? true : false;
    }

    //generate the evolved state
    ForkTPS psi_evolved = krylovSpace.at(0);
    psi_evolved *= weights.at(0);
    psi_evolved.position(1);

    if (evolved) {
      for (int ik = 1; ik < currentSize; ik++) {
        if (abs(weights.at(ik)) / abs(weights.front()) > params_.gKrylov.threshold) {
          auto phi = krylovSpace.at(ik);
          phi *= weights.at(ik);
          phi.position(1);
          psi_evolved = DirectSum(psi_evolved, phi);
        }
      }
      psi_evolved.position(psi_evolved.N(), args_rescale);
      psi_evolved.position(1, args_rescale);
    } else {
      psi_evolved = krylovSpace.front();
    }
    if (params_.verbose >= 3) {
      ReportOnce("---- the overlap matrix between the krylov vecotrs, make sure that they are orthonormal to each other in this space", "\n");
      if (world.rank() == 0) {
        for (int i(0); i < krylovSpace.size(); i++) {
          for (int j(0); j < krylovSpace.size(); j++) {
            auto val = overlap(krylovSpace.at(i), krylovSpace.at(j));
            if (abs(val) > 1E-5 && i != j) { ReportOnce("Krylov vector overlap (", i, ",", j, ") = ", val, "\n"); }
          }
        }
      }
      if (evolved) {
        ReportOnce("--- Gloabal Krylov evoloved to @", t, "\n");
      } else {
        ReportOnce("--- Gloabal Krylov failed to evoloved to @", t, "\n");
      }
    };

    return std::make_pair(evolved, psi_evolved);
  }

  std::vector<int> finiteT_solver_core::DeterminePurificeBathSites(finiteT_params_t params_) {
    auto sites_ = ThermalForkSites(b.N(), b.NArms(), {}, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params_.impPurified});
    InitState init_(sites_, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (b.eps(ind, k) < 0) init_.set(sites_.ArmToSite(arm, k + 1), "Occ");
      }
      if (params_.impPurified) {
        init_.set(sites_.ImpSite(arm), "01");
      } else {
        init_.set(sites_.ImpSite(arm), "Occ");
      }
    }

    auto psi_ = ForkTPS(init_, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi_, sites_, doubledBath);
    auto H_    = whichFTPO(params_, sites_);
    auto Heff_ = ForkLocalOp(H_);

    std::vector<int> purifiedBath;
    //determine the purified bath sites based on the filling
    // 0 for no bath site purification
    // 1 for all bath site purification
    std::vector<std::pair<int, double>> probList;

    if (params_.sampling.puriMethod == "ImagTime") {
      ReportOnce("--- determine the purified bath sites by imag. evolve the state \n");
      args.add("TevoMethod", "TDVP_2");
      addBasis(psi_, H_, args);
      psi_.normalizeLim();

      double dtauTDVP = params_.tevo.dt;
      auto stepsTotal = 5;

      // do TDVP
      //auto Ops = TEBD_container(hint, b, e0, dtauTDVP, sites);
      for (auto i : range1(0, stepsTotal - 1)) {
        UNUSED_VAR(i);
        TDVP(psi_, Heff_, dtauTDVP, args);
        psi_.normalizeLim();
      };
      args.add("TevoMethod", "TDVP");
      Heff_.ForgetContraction();
      for (auto i : range1(0, 2 * stepsTotal - 1)) {
        UNUSED_VAR(i);
        TDVP(psi_, Heff_, dtauTDVP, args);
        psi_.normalizeLim();
      };

      for (auto site : range1(psi_.N())) {
        psi_.position(site);
        auto n = std::real((psi_.A(site) * sites_.op("N", site) * dag(prime(psi_.A(site), "Site"))).cplx());
        if (!psi_.IsImp(site)) {
          if (n >= 0.5) {
            probList.push_back(std::make_pair(site, 1. - n));
          } else {
            probList.push_back(std::make_pair(site, n));
          }
        }
      }
    } else if (params_.sampling.puriMethod == "Energy" || params_.sampling.puriMethod == "EnergyReverse") {
      ReportOnce("--- determine the purified bath sites by on-site energy \n");
      for (auto arm : range1(sites_.NArms())) {
        triqs_indx ind = ArmToTriqsIndx(arm);
        for (auto k : itertools::range(b.NBath(ind))) {
          int site = sites_.ArmToSite(arm, k + 1);
          if (!psi_.IsImp(site)) { probList.push_back(std::make_pair(site, abs(b.eps(ind, k)))); }
        }
      }
    }

    int numPurifiedSites = int(probList.size() * params_.sampling.purification_threshold);
    for (int ip = 0; ip < numPurifiedSites; ip++) {
      if (params_.sampling.puriMethod == "ImagTime") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return e1.second > e2.second; });
      } else if (params_.sampling.puriMethod == "Energy") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return e1.second < e2.second; });
      } else if (params_.sampling.puriMethod == "EnergyReverse") {
        std::sort(probList.begin(), probList.end(),
                  [](const std::pair<int, double> &e1, const std::pair<int, double> &e2) -> bool { return e1.second > e2.second; });
      } else {
        Error("Wrong purification method");
      }
      purifiedBath.push_back(probList.front().first);
      probList.erase(probList.begin());
    }

    if (params_.verbose >= 1) {
      ReportOnce("--- the reference state has the following Occ.\n");
      if (world.rank() == 0) { psi_.PrintOccs(); };
      ReportOnce("\n--- with purification threshold ", params_.sampling.purification_threshold, "(0-no, 1-full)\n");
      ReportOnce("\n--- which gives the following purified bath sites \n");
      ReportOnce(purifiedBath, "\n");
    }

    //if E0Shift is not estimated by a quick dmrg, make a rough estimation
    if (!params_.quickDMRG.quickDMRG) {
      auto sites_puri =
         ThermalForkSites(b.N(), b.NArms(), purifiedBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params_.impPurified});

      InitState init_product(sites_puri, "Emp");

      for (auto arm : range1(sites_puri.NArms())) {
        triqs_indx ind = ArmToTriqsIndx(arm);
        for (auto k : itertools::range(b.NBath(ind))) {
          if (!std::count(purifiedBath.begin(), purifiedBath.end(), sites_puri.ArmToSite(arm, k + 1))) {
            if (b.eps(ind, k) < 0) init_product.set(sites_puri.ArmToSite(arm, k + 1), "Occ");
          }
        }
        //the impurity sites are always purified
        if (params_.impPurified) {
          init_product.set(sites_puri.ImpSite(arm), "01");
        } else {
          init_product.set(sites_puri.ImpSite(arm), "Occ");
        }
      }
      for (auto site : purifiedBath) { init_product.set(site, "01"); };

      auto psi_porduct = ForkTPS(init_product, sites_puri.NArms());
      ResetPurifiedTensors(psi_porduct, sites_puri, purifiedBath);

      //reset the tensor of the purified sites
      psi_porduct.normalizeLim();
      psi_porduct.position(1);
      auto H_puri    = whichFTPO(params_, sites_puri);
      auto Heff_puri = ForkLocalOp(H_puri);
      Heff_puri.position(1, psi_porduct);

      double energy = std::real(Heff_puri.ContractAll(psi_porduct)) - E0Shift;
      E0Shift       = -energy;
    }
    return purifiedBath;
  };

  void finiteT_solver_core::SamplingBasis(finiteT_params_t const &params_) {
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();

    std::vector<ForkTPS> states_metts;
    int step  = 1;
    int total = 1;
    while (step <= params_.sampling.n_sampling) {
      if (params_.verbose >= 1) { ReportOnce("--- sampling ", step, "/", params_.sampling.n_sampling, "\n"); };
      auto label = generateLabel(state, params_);
      std::string fileNameSample;
      if (isRegistered(state, params_)) {
        //update the product state to the registered Metts
        state = statesPool[label].state;
        statesPool[label].repeated += 1;
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(total) + "State";
        //states_metts.push_back(state);
        //save(fileNameSample, state);
        total += 1;
        // saveGS(fileNameSample, state, sites, 0.0);
      } else {
        //ReportOnce("Debug::", params_.h_int, "\n", params_.tevo, "\n");
        UniEvoType uniEvoType;
        if (params_.sampling.uniEvo) {
          //uniEvoType = UniEvoType::Full;
          if (total % 2 == 0) {
            uniEvoType = UniEvoType::Even;
          } else {
            uniEvoType = UniEvoType::Odd;
          }
        } else {
          uniEvoType = UniEvoType::None;
        }
        GenerateMetts(label, true, params_, uniEvoType);
        Measure(label, true);
        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(total) + "State";
        //if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };
        //states_metts.push_back(state);
        //save(fileNameSample, state);
        //saveGS(fileNameSample, state, sites, 0.0);
        step += 1;
        total += 1;
      }

      Project(params_);
    };
    /*

    int krylobSpaceSize = 3;
    int orthoSize       = 2;
    Args args_applyH;
    args_applyH.add("Orthog", false);
    args_applyH.add("Cutoff", MIN_CUT);
    Args args_fit = args;
    args_fit.add("SubspaceMaxm", 50);
    */
    int count = 0;
    for (auto ele : statesPool) {
      count += 1;
      ReportOnce("--- generating excitated ref. states for the ", count, " metts\n");
      auto psi_ = ele.second.state;
      states_metts.push_back(psi_);
      basisInfos.multiplyFactor = 1;

      //c^\dagger
      std::vector<int> armsToExcite{1};
      for (auto imp : armsToExcite) {
        //act on the impurity site
        int impsite = sites.ImpSite(imp);
        psi_        = ele.second.state;
        psi_.position(impsite);
        psi_.ApplySingleSiteOp(sites.op("CkD", impsite), impsite, true);
        psi_.normalizeLim();
        states_metts.push_back(psi_);
        basisInfos.multiplyFactor += 1;

        /*
        std::vector<ForkTPS> orthoStates, krylovSpace;
        krylovSpace.push_back(psi_);
        Args args_fit = args;
        args_fit.add("SubspaceMaxm", 50);

        for (int size(1); size < params_.gKrylov.nKrylov; size++) {
          for (auto const &state : krylovSpace) {
            orthoStates.push_back(state);
            if (orthoStates.size() > params_.gKrylov.orthoSize) { orthoStates.erase(orthoStates.begin()); }
          }

          ForkTPS psi_new = krylovSpace.back();
          psi_new         = FitApplyMPO(psi_new, H, args_fit);
          // psi_new.normalize();
          psi_new = ArithmeticOrth(psi_new, orthoStates);
          psi_new.normalize();
          psi_new.position(1, args);
          krylovSpace.push_back(psi_new);
          orthoStates.push_back(psi_new);
          states_metts.push_back(psi_new);
        }
        */

        auto HeffEvoCd = ForkLocalOp(H);
        auto args_cd   = args;
        args_cd.add("TevoMethod", "TDVP");
        for (int step = 0; step < tListExcited.size() - 1; step++) {
          ReportOnce("--- @T ", tListExcited.at(step), " \n");
          TDVP(psi_, HeffEvoCd, tListExcited.at(step + 1) - tListExcited.at(step), args_cd);
          psi_.normalize();
          states_metts.push_back(psi_);
        }
      }

      //c
      for (auto imp : armsToExcite) {
        //act on the impurity site
        int impsite = sites.ImpSite(imp);
        psi_        = ele.second.state;
        psi_.position(impsite);
        psi_.ApplySingleSiteOp(sites.op("Ck", impsite), impsite, true);
        psi_.normalizeLim();
        states_metts.push_back(psi_);
        basisInfos.multiplyFactor += 1;

        /*
        std::vector<ForkTPS> orthoStates, krylovSpace;
        krylovSpace.push_back(psi_);
        Args args_fit = args;
        args_fit.add("SubspaceMaxm", 50);

        for (int size(1); size < params_.gKrylov.nKrylov; size++) {
          for (auto const &state : krylovSpace) {
            orthoStates.push_back(state);
            if (orthoStates.size() > params_.gKrylov.orthoSize) { orthoStates.erase(orthoStates.begin()); }
          }

          ForkTPS psi_new = krylovSpace.back();
          psi_new         = FitApplyMPO(psi_new, H, args_fit);
          // psi_new.normalize();
          psi_new = ArithmeticOrth(psi_new, orthoStates);
          psi_new.normalize();
          psi_new.position(1, args);
          krylovSpace.push_back(psi_new);
          orthoStates.push_back(psi_new);
          states_metts.push_back(psi_new);
        }
        */

        auto HeffEvoCd = ForkLocalOp(H);
        auto args_cd   = args;
        args_cd.add("TevoMethod", "TDVP");
        for (int step = 0; step < tListExcited.size() - 1; step++) {
          ReportOnce("--- @T ", tListExcited.at(step), " \n");
          TDVP(psi_, HeffEvoCd, tListExcited.at(step + 1) - tListExcited.at(step), args_cd);
          psi_.normalize();
          states_metts.push_back(psi_);
        }
      }
    }

    basisInfos.states_metts = states_metts;
    basisInfos.stateSize    = states_metts.size();
    for (int i(0); i < states_metts.size(); i++) {
      for (int j(0); j < states_metts.size(); j++) {
        //states_metts.at(i).PrintOccs();
        //states_metts.at(j).PrintOccs();
        //std::cout << "overlap(" << i << "," << j << ")=" << overlap(states_metts.at(i), states_metts.at(j)) << std::endl;
      }
    }
  }

  void finiteT_solver_core::GenerateBasisInfos(finiteT_params_t const &params_, ThermalForkSites const &sites_) {
    //int totalStates = params_.sampling.n_sampling * world.size();
    /*
    std::vector<ForkTPS> states_metts;
    for (int irank(0); irank < world.size(); irank++) {
      for (int isample(1); isample < params_.sampling.n_sampling + 1; isample++) {
        std::string fileNameSample;
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(irank) + "_sample_" + std::to_string(isample) + "State";
        //ReportOnce("--- loading ::", fileNameSample, "\n");
        ForkTPS psi_readin;
        load(fileNameSample, psi_readin, sites_);
        //loadGS(fileNameSample, psi_readin, sites, 0.0);
        //psi_readin.PrintImpOcc();
        states_metts.push_back(psi_readin);
      }
    }
    */
    //basisInfos.states_metts = states_metts;
    //basisInfos.stateSize = states_metts.size();
    int totalStates = basisInfos.states_metts.size(); //params_.sampling.n_sampling * world.size();

    if (params_.verbose >= 1) { ReportOnce("--- constructing the basis with ", basisInfos.states_metts.size(), " states \n"); };
    //evaluate the overlap matrix
    Index I(totalStates, "i"), J(totalStates, "j"), K(totalStates, "k");
    ITensor C(I, J);
#pragma omp parallel for num_threads(omp_get_max_threads()), schedule(dynamic, 1)
    for (int isample = 1; isample < totalStates + 1; isample++) {
      for (int jsample(isample); jsample < totalStates + 1; jsample++) {
        //basisInfos.states_metts.at(isample - 1).position(1);
        //basisInfos.states_metts.at(jsample - 1).position(1);
        //auto qn_i = div(basisInfos.states_metts.at(isample - 1).Anc(1));
        //auto qn_j = div(basisInfos.states_metts.at(jsample - 1).Anc(1));
        //if (qn_i == qn_j) {
        auto val_ = overlap(basisInfos.states_metts.at(isample - 1), basisInfos.states_metts.at(jsample - 1));
        C.set(I = isample, J = jsample, val_);
        C.set(I = jsample, J = isample, conj(val_));

        //} else {
        //  C.set(I = isample, J = jsample, 0.0);
        //}
        //ReportOnce(" C(", isample, ",", jsample, ")=", eltC(C, I = isample, J = jsample));
      }
    }

    basisInfos.C         = C;
    auto [U, S, V]       = svd(C, {I}, {"Cutoff", 1E-6 / norm(C)});
    Index Il             = commonIndex(U, S);
    Index Ir             = commonIndex(S, V);
    basisInfos.basisSize = dim(Il);

    ITensor S_sqrt(Il, Ir);
    for (int i(1); i < dim(Il) + 1; i++) { S_sqrt.set(Il = i, Ir = i, pow(eltC(S, Il = i, Ir = i), -0.5)); }

    ITensor R = S_sqrt * V;
    Index truncInd(dim(Il), "trunc");
    //R            = R * delta(Il, truncInd);
    basisInfos.R = R * delta(Il, truncInd);
    if (params_.verbose >= 1) { ReportOnce("--- truncated basis set size  ", dim(Il), "/", dim(I), " \n"); };

    //evaluate the effective Hamiltonian
    ITensor Heff_metts(J, K);
#pragma omp parallel for num_threads(omp_get_max_threads()), schedule(dynamic, 1)
    for (int isample = 1; isample < totalStates + 1; isample++) {
      for (int jsample(isample); jsample < totalStates + 1; jsample++) {
        Args args_tmp;
        args_tmp.add("Orthog", false);
        //basisInfos.states_metts.at(isample - 1).position(1);
        //basisInfos.states_metts.at(jsample - 1).position(1);
        //auto qn_i = div(basisInfos.states_metts.at(isample - 1).Anc(1));
        //auto qn_j = div(basisInfos.states_metts.at(jsample - 1).Anc(1));
        //if (qn_i == qn_j) {
        auto psi_ = basisInfos.states_metts.at(jsample - 1);
        auto val  = overlap(basisInfos.states_metts.at(isample - 1), exactApplyMPO(psi_, H, args_tmp));
        Heff_metts.set(J = isample, K = jsample, val);
        Heff_metts.set(J = jsample, K = isample, conj(val));

        //} else {
        //  Heff_metts.set(J = isample, K = jsample, 0.0);
        //}
        //ReportOnce(" H(", isample, ",", jsample, ")=", eltC(Heff_metts, I = isample, J = jsample), "\n");
      }
    }
    basisInfos.Heff = Heff_metts;

    ITensor R_dag      = dag(R);
    R_dag              = R_dag * delta(Il, prime(Il));
    R_dag              = R_dag * delta(J, K);
    ITensor Heff_basis = R * Heff_metts * R_dag;
    basisInfos.Heff_R  = Heff_basis;
    //debug
    {
      auto [U_basis, D_basis] = diagHermitian(Heff_basis);
      std::vector<double> eigvals;
      for (int ie(1); ie < dim(Il) + 1; ie++) {
        eigvals.push_back(elt(D_basis, ie, ie));
        ReportOnce("--- eigenvalus of the effective H  ::", eltC(D_basis, ie, ie), "\n");
      }
      auto arch = h5::file(fileNameIntermedia + "/eigvals.h5", 'a');
      h5_write(arch, "eigvals", eigvals);
      arch.close();

      //shift the energy levels

      ReportOnce("--- the effective H is shifte by ::", eltC(D_basis, dim(Il), dim(Il)), "\n");
      for (int ie(1); ie < dim(Il) + 1; ie++) {
        auto e_shift = eltC(basisInfos.Heff_R, ie, ie) - eltC(D_basis, dim(Il), dim(Il));
        basisInfos.Heff_R.set(ie, ie, e_shift);
      }
    }

    //debug
    /*
    {
      for (int j(1); j < dim(J) + 1; j++) {
        for (int k(1); k < dim(K) + 1; k++) {
          std::cout << " H( " << j << "," << k << ")"
                    << "=" << std::setprecision(10) << eltC(Heff_metts, j, k) << std::endl;
        }
      }
      Heff_metts              = Heff_metts * delta(K, prime(J));
      auto [U_metts, D_metts] = diagHermitian(Heff_metts);
      for (int i(1); i < dim(J) + 1; i++) { std::cout << "eigen H_metts " << i << "=" << std::setprecision(10) << eltC(D_metts, i, i) << std::endl; }

      auto [U_basis, D_basis] = diagHermitian(Heff_basis);
      for (int i(1); i < dim(Il) + 1; i++) { std::cout << "eigen H_basis " << i << "=" << std::setprecision(10) << eltC(D_basis, i, i) << std::endl; }
    }
    */
    //debug
    /*
    {
      for (int ialpha(1); ialpha < dim(Il) + 1; ialpha++) {
        for (int ibeta(1); ibeta < dim(Il) + 1; ibeta++) {

          auto val_ = std::complex<double>(0., 0.);
          for (int i(1); i < dim(I) + 1; i++) {
            for (int j(1); j < dim(J) + 1; j++) {
              val_ += eltC(dag(R), ialpha, i) * eltC(R, ibeta, j) * overlap(basisInfos.states_metts.at(i - 1), basisInfos.states_metts.at(j - 1));
            }
          }
          std::cout << "overlap (" << ialpha << "," << ibeta << ")"
                    << "=" << val_;
        }
      }
    }
    */
  };

  std::vector<std::vector<int>> finiteT_solver_core::nonZeroIndices(ITensor const &T_) {
    std::vector<std::vector<int>> nonzeros;
    int dim_row = dim(inds(T_)(1));
    int dim_col = dim(inds(T_)(2));
    for (int i(1); i < dim_row + 1; i++) {
      std::vector<int> this_row;
      for (int j(1); j < dim_col + 1; j++) {
        if (abs(eltC(T_, i, j)) > 1E-8) { this_row.push_back(j); }
      }
      nonzeros.push_back(this_row);
    }
    return nonzeros;
  }

  std::vector<int> finiteT_solver_core::intersection(std::vector<int> &v1_, std::vector<int> &v2_) {
    std::vector<int> v3_;

    std::sort(v1_.begin(), v1_.end());
    std::sort(v2_.begin(), v2_.end());

    std::set_intersection(v1_.begin(), v1_.end(), v2_.begin(), v2_.end(), back_inserter(v3_));
    return v3_;
  }

  ITensor finiteT_solver_core::ExponentialMatrix(double tau_, ITensor const &h_) {
    /*
      auto [U, D]     = diagHermitian(heff);
    ITensor Udagger = dag(U);
    weights.resize(currentSize, 0.0);
    for (int i(0); i < currentSize; i++) {
      weights.at(i) = 0.0;
      for (int j(0); j < currentSize; j++) {
        //weights.at(i) += eltC(Udagger, IndexVal(I, i + 1), IndexVal(ud_d, j + 1)) * std::exp(-t * eltC(D, j + 1, j + 1))
        //   * eltC(U, IndexVal(d_u, j + 1), IndexVal(J, 1));
        weights.at(i) += eltC(Udagger, i + 1, j + 1) * std::exp(-t * eltC(D, j + 1, j + 1)) * eltC(U, 1, j + 1);
      }
    }
    */
    ITensor expH(inds(h_));
    //for (auto ind : inds(H)) { ReportOnce("-- H ", dim(ind)); }
    auto [U, D]     = diagHermitian(h_);
    Index ind       = commonIndex(U, D);
    ITensor Udagger = dag(U);
    for (int i(1); i < dim(ind) + 1; i++) {
      for (int j(1); j < dim(ind) + 1; j++) {
        auto val = std::complex<double>(0., 0.);
        for (int ia(1); ia < dim(ind) + 1; ia++) { val += eltC(Udagger, i, ia) * std::exp(tau_ * eltC(D, ia, ia)) * eltC(U, j, ia); }
        expH.set(i, j, val);
      }
    }
    return expH;
  };

  void finiteT_solver_core::Sampling(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();
    int step   = 0;
    totalCount = 0;
    while (step < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) {
        ReportOnce("--- sampling ", step + 1, "/", params_.sampling.n_sampling, " (total confs.=", totalCount + 1, ")\n");
      };
      /*
      for (int iAuto = 0; iAuto < params_.sampling.measure_every - 1; ++iAuto) {
        auto label = generateLabel(state, params_);
        if (isRegistered(state, params_)) {
          state = statesPool[label].state;
        } else {
          UniEvoType uniEvoType;
          if (params_.sampling.uniEvo) {
            //uniEvoType = UniEvoType::Full;
            if (step % 2 == 0) {
              uniEvoType = UniEvoType::Even;
            } else {
              uniEvoType = UniEvoType::Odd;
            }
          } else {
            uniEvoType = UniEvoType::None;
          }
          GenerateMetts(label, false, params_, uniEvoType);
        }
        Project(params_);
      }
      */
      auto label = generateLabel(state, params_);
      std::string fileNameSample;
      if (isRegistered(state, params_)) {
        totalCount += 1;
        //update the product state to the registered Metts
        state = statesPool[label].state;
        G_tau += statesPool[label].g_tau;
        statesPool[label].repeated += 1;

        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };
      } else {
        step += 1;
        totalCount += 1;
        //ReportOnce("Debug::", params_.h_int, "\n", params_.tevo, "\n");
        UniEvoType uniEvoType;
        if (params_.sampling.uniEvo) {
          //uniEvoType = UniEvoType::Full;
          if (step % 2 == 0) {
            uniEvoType = UniEvoType::Even;
          } else {
            uniEvoType = UniEvoType::Odd;
          }
        } else {
          uniEvoType = UniEvoType::None;
        }
        GenerateMetts(label, true, params_, uniEvoType);
        Measure(label, true);
        g_tau_t g_tau;
        if (params_.timeGrid == "Even") {
          g_tau = CalcGF(label, params_);
        } else if (params_.timeGrid == "Exp") {
          g_tau = CalcGFExponential(label, params_);
        }
        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };

        //acculmulate Green's function
        if (step == 1) {
          G_tau = g_tau; //* RepeatedTimes.at(world.rank());
        } else {
          G_tau += g_tau;
        }
        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
      }

      // restrict the particle number
      /*
      auto state_        = state;
      bool wrongParticle = true;
      while (wrongParticle) {
        state = state_;
        Project();
        if (args.getBool("RestrictParticleNumber")) {
          wrongParticle = !PaticleNumberFluctuation(state);
        } else {
          wrongParticle = false;
        }
      }
      */
      //Project this METTS into a new product state
      Project(params_);
    }
    //G_tau /= float(totalCount);
  };

  void finiteT_solver_core::SamplingUnitaryMPI(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();
    int step               = 0;
    totalCount             = 0;
    int totalCountThisRank = 0;
    double totalNormSq     = 0;
    //generate the states
    while (totalCountThisRank < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) {
        ReportOnce("\n\n\n--- sampling ", totalCountThisRank + 1, "/", params_.sampling.n_sampling, " (unique confs. on this rank=", step + 1, ")\n");
      };
      int uniTypeThisSample = (totalCountThisRank + 1) % 2;
      UniEvoType uniType;
      if (params_.sampling.uniEvoSteps != 0) {
        if (uniTypeThisSample == 0) {
          uniType = UniEvoType::Even;
        } else if (uniTypeThisSample == 1) {
          uniType = UniEvoType::Odd;
        }
      } else {
        uniType = UniEvoType::None;
      }
      if (params_.verbose >= 1) {
        if (world.rank() == 0) { state.PrintOccs(); };
      }
      //{
      //  std::cout << "\n\n @rank " << world.rank() << std::endl;
      //  state.PrintOccs();
      //}
      auto label = generateLabel(state, params_, uniType);
      if (isRegistered(state, params_, uniType)) {
        auto tmp_count_fileName = fileNameIntermedia;
        tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(totalCountThisRank) + ".h5";
        auto psi_                = statesPool[label].productState;
        auto productStateFilling = fillingFromProductState(psi_);
        auto arch                = h5::file(tmp_count_fileName, 'a');
        h5_write(arch, "repeated", 1); //h5_write(arch, "Repeated", statesPool[label_].repeated);
        h5_write(arch, "bigNorm", statesPool[label].bigNorm);
        h5_write(arch, "productStateFilling", productStateFilling);
        h5_write(arch, "uniType", uniTypeThisSample);

        totalCountThisRank += 1;
        //update the product state to the registered Metts
        state = statesPool[label].state;
        statesPool[label].repeated += 1;

      } else {

        //GenerateMettsBasisExpansionSingleSite(label, true, params_, uniType);
        GenerateMettsBE(label, true, params_, uniType, false);

        auto tmp_count_fileName = fileNameIntermedia;
        tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(totalCountThisRank) + ".h5";
        auto psi_                = statesPool[label].productState;
        auto productStateFilling = fillingFromProductState(psi_);
        auto arch                = h5::file(tmp_count_fileName, 'a');
        h5_write(arch, "repeated", 1); //h5_write(arch, "Repeated", statesPool[label_].repeated);
        h5_write(arch, "bigNorm", statesPool[label].bigNorm);
        h5_write(arch, "productStateFilling", productStateFilling);
        h5_write(arch, "uniType", uniTypeThisSample);

        step += 1;
        totalCountThisRank += 1;
      }
      // restricted projection
      //Project(params_);
      bool wrongConf = true;
      auto stateCopy = state;
      std::vector<int> emptySites, occSites;
      for (int iArm = 1; iArm <= sites.NArms(); ++iArm) {
        for (int i(0); i < params_.sampling.fixedSites; i++) {
          int site = sites.ArmToSite(iArm, sites.NBath(iArm) - i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { emptySites.push_back(site); }
          site = sites.ArmToSite(iArm, 1 + i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { occSites.push_back(site); };
        }
      }
      if (params_.verbose >= 1) {
        ReportOnce("---@ThermalizeUnitary, enfored empty bath sites::", emptySites, "\n");
        ReportOnce("---@ThermalizeUnitary, enfored occupied bath sites::", occSites, "\n");
      }
      while (wrongConf) {
        state = stateCopy;
        Project(params_);
        wrongConf = false;
        for (auto site : emptySites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n) > 0.1) { wrongConf = true; }
        }
        for (auto site : occSites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n - 1.0) > 0.1) { wrongConf = true; }
        }
      }
    }
    world.barrier(0);
    // store all calculated configuration information
    //int ic = 0;
    //for (auto const &conf : statesPool) {

    //ic += 1;
    //};
    // count the distribution on the master node
    world.barrier(0);
    statesPool.clear();
    std::vector<std::tuple<ForkTPS, double, int>> configurations;
    int repeated;
    double bigNorm;
    int numSampleToCount = params_.sampling.n_sampling;
    //(params_.sampling.uniEvoSteps == 0) ? params_.sampling.n_sampling : (params_.sampling.n_sampling / 2);

    if (world.rank() == 0) {
      std::vector<double> productStateFilling;
      for (int step(0); step < numSampleToCount; step++) {
        for (int irank(0); irank < world.size(); irank++) {
          auto tmp_count_fileName = fileNameIntermedia;
          //tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(irank) + "_sample_"
          // + std::to_string((params_.sampling.uniEvoSteps == 0) ? step : (2 * step)) + ".h5";

          tmp_count_fileName += "/countAndproductState_rank_" + std::to_string(irank) + "_sample_" + std::to_string(step) + ".h5";
          auto arch = h5::file(tmp_count_fileName, 'r');
          //ReportOnce(" loading :: ", tmp_count_fileName, "\n");
          h5_read(arch, "repeated", repeated);
          h5_read(arch, "bigNorm", bigNorm);
          h5_read(arch, "productStateFilling", productStateFilling);
          ForkTPS psi_read = productStateFromFilling(productStateFilling, sites, doubledBath);

          //store the information
          auto label = generateLabel(psi_read, params_);
          if (isRegistered(psi_read, params_)) {
            statesPool[label].repeated += repeated;
          } else {
            statesPool[label].label        = label;
            statesPool[label].labelHash    = std::hash<std::string>{}(label);
            statesPool[label].productState = psi_read;
            statesPool[label].repeated     = repeated;
            statesPool[label].bigNorm      = bigNorm;
          }
        }
        configurations.clear();
        for (auto const &conf : statesPool) {
          configurations.push_back(std::make_tuple(conf.second.productState, conf.second.bigNorm, conf.second.repeated));
        }
        std::sort(configurations.begin(), configurations.end(),
                  [](const std::tuple<ForkTPS, double, int> &e1, const std::tuple<ForkTPS, double, int> &e2) -> bool {
                    return std::get<2>(e1) > std::get<2>(e2);
                  });

        //write our the intermedie distribution
        auto arch = h5::file(fileNameIntermedia + "/distribution_ite_" + std::to_string(step) + ".h5", 'a');
        std::vector<int> counts;
        std::vector<double> weights;
        for (auto const &conf : configurations) {
          counts.push_back(std::get<2>(conf));
          weights.push_back(std::get<1>(conf));
        }
        h5_write(arch, "counts", counts);
        h5_write(arch, "weights", weights);
      }

      ReportOnce("There are ", statesPool.size(), " unique states", "\n");
      for (int ic(0); ic < configurations.size(); ic++) {
        if (ic < world.size()) { totalNormSq += pow(std::get<1>(configurations.at(ic)), 2.); }
        //ReportOnce(" --- count :: ", std::get<2>(ele), ", bigNorm :: ", std::get<1>(ele), "\n");
      }

      //save conf information
      for (int ic(0); ic < configurations.size(); ic++) {
        auto fileConf = fileNameIntermedia;
        fileConf += "/conf_" + std::to_string(ic) + ".h5";
        auto productStateFilling = fillingFromProductState(std::get<0>(configurations.at(ic)));
        auto arch                = h5::file(fileConf, 'a');
        h5_write(arch, "bigNorm", std::get<1>(configurations.at(ic)));
        h5_write(arch, "repeated", std::get<2>(configurations.at(ic)));
        h5_write(arch, "productStateFilling", productStateFilling);
      }
    }
    world.barrier(0);
    // distribute the jobs and calculate Gf
    int numUniqueStates;
    if (world.rank() == 0) { numUniqueStates = configurations.size(); }
    mpi::broadcast(numUniqueStates);
    mpi::broadcast(totalNormSq);
    ReportOnce("--- calculating ", numUniqueStates, " Gfs on ", world.size(), " nodes \n");
    int numGfEachRank = std::min(numUniqueStates / world.size() + (numUniqueStates % world.size() == 0 ? 0 : 1), params_.sampling.minNumGfEachRank);
    ReportOnce("--- ", numGfEachRank, " different Gfs will be calculated on each rank...\n");
    std::vector<std::tuple<ForkTPS, int>> jobsThisRank;
    for (int irank(0); irank < world.size(); irank++) {
      if (world.rank() == irank) {
        for (int ite(0); ite < numGfEachRank; ite++) {
          int ic = ite * world.size() + irank;
          if (ic < numUniqueStates) {
            auto fileConf = fileNameIntermedia;
            fileConf += "/conf_" + std::to_string(ic) + ".h5";
            std::vector<double> productStateFilling;
            auto arch = h5::file(fileConf, 'r');
            h5_read(arch, "bigNorm", bigNorm);
            h5_read(arch, "repeated", totalCount);
            h5_read(arch, "productStateFilling", productStateFilling);
            state = productStateFromFilling(productStateFilling, sites, doubledBath);
            //std::cout << " on rank " << world.rank() << " has " << totalCount << std::endl;
            jobsThisRank.push_back(std::make_tuple(state, totalCount));

          } else {
            auto fileConf = fileNameIntermedia;
            fileConf += "/conf_" + std::to_string(0) + ".h5";
            std::vector<double> productStateFilling;
            auto arch = h5::file(fileConf, 'r');
            h5_read(arch, "productStateFilling", productStateFilling);
            state      = productStateFromFilling(productStateFilling, sites, doubledBath);
            totalCount = 0;
            bigNorm    = 0.0;
            jobsThisRank.push_back(std::make_tuple(state, totalCount));
          }
        }
      }
    }
    world.barrier(0);
    //calculate the Gfs
    totalCount = 0;
    for (int iteGf(0); iteGf < numGfEachRank; iteGf++) {
      state         = std::get<0>(jobsThisRank.at(iteGf));
      auto repeated = std::get<1>(jobsThisRank.at(iteGf));
      ReportOnce("--- Starting to calculate the ( ", iteGf + 1, "/", numGfEachRank, " )th Gfs which repeated ", repeated, " times ... \n");
      ReportOnce("--- with inital configuaration:: \n");
      if (world.rank() == 0) { state.PrintOccs(); }

      //note that if unitary gate is used, only gfs in the new basis will be calculated
      UniEvoType uniEvoType = UniEvoType::None;
      /*
      if (params_.sampling.uniEvoSteps != 0) {
        uniEvoType = UniEvoType::None;
      } else {
        uniEvoType = UniEvoType::None;
      }
      */

      auto label = generateLabel(state, params_);
      //an even grid is used to generate the metts information in calculating Gfs
      tList = tListLin;
      //params_.sampling.TSTime = params_.sampling.minTwoSiteTimeGf;
      GenerateMettsBE(label, true, params_, uniEvoType, true);

      g_tau_t g_tau;
      //g_tau = CalcGF(label, params_); //CalcGFWholeImagTimeGrid(label, params_); //;
      g_tau = CalcGFShifted(label, params_, params_.sampling.shiftedSteps);
      //G_tau_by_norm = G_tau;

      //save the Green's function
      if (params_.sampling.saveIntermedia) {
        auto fileNameGf = fileNameIntermedia;
        fileNameGf += "/Gf_" + std::to_string(iteGf * world.size() + world.rank()) + ".h5";
        auto arch = h5::file(fileNameGf, 'a');
        h5_write(arch, "G_tau", g_tau);
        h5_write(arch, "repeated", repeated);
        h5_write(arch, "bondGrowth", statesPool[label].bondGrowth);
      }
      if (iteGf == 0) {
        G_tau = (repeated * g_tau);
        for (auto ele : statesPool[label].bondGrowth) { BondGrowthAve.push_back((double(repeated * ele))); }
        totalCount = repeated;
      } else {
        G_tau += (repeated * g_tau);
        for (int i(0); i < BondGrowthAve.size(); i++) { BondGrowthAve.at(i) += (double(repeated * statesPool[label].bondGrowth.at(i))); }
        totalCount += repeated;
      };
      g_tau_list_info.push_back(std::make_pair(repeated, g_tau));
      //G_tau_by_norm *= pow(bigNorm, 2.) / totalNormSq;
    }
    world.barrier(0);

    //remove the tmp files
    if (world.rank() == 0) {
      for (int ic(0); ic < params_.sampling.n_sampling; ic++) {
        for (int irank(0); irank < world.size(); irank++) {
          auto tmpFileNames = fileNameIntermedia;
          tmpFileNames += "/countAndproductState_rank_" + std::to_string(irank) + "_sample_" + std::to_string(ic) + ".h5";
          std::filesystem::remove(tmpFileNames);
        }
      }

      for (int ic(0); ic < configurations.size(); ic++) {
        auto tmpFileNames = fileNameIntermedia;
        tmpFileNames += "/conf_" + std::to_string(ic) + ".h5";
        std::filesystem::remove(tmpFileNames);
      }
    }
  };

  void finiteT_solver_core::SamplingUnitary(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();
    int step   = 0;
    totalCount = 0;
    while (step < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) {
        ReportOnce("--- sampling ", step + 1, "/", params_.sampling.n_sampling, " (total confs.=", totalCount + 1, ")\n");
      };

      tList = tListLin;

      auto label = generateLabel(state, params_);
      std::string fileNameSample;
      if (isRegistered(state, params_)) {
        totalCount += 1;
        //update the product state to the registered Metts
        state = statesPool[label].state;
        G_tau += statesPool[label].g_tau;
        statesPool[label].repeated += 1;

        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
        //write out the intermedia infos
        //fileNameSample = fileNameIntermedia;
        //fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        //if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };
      } else {
        step += 1;
        totalCount += 1;
        //ReportOnce("Debug::", params_.h_int, "\n", params_.tevo, "\n");
        //GenerateMettsBasisExpansion(label, true, params_, (step - 1) % 2 == 0 ? UniEvoType::Even : UniEvoType::Odd); // UniEvoType::None); //
        //GenerateMetts(label, true, params_, UniEvoType::None);
        GenerateMettsBasisExpansionSingleSite(label, true, params_, UniEvoType::None);

        Measure(label, true);
        g_tau_t g_tau;

        g_tau = CalcGF(label, params_); //CalcGFWholeImagTimeGrid(label, params_); //;

        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };

        //acculmulate Green's function
        if (step == 1) {
          G_tau = g_tau; //* RepeatedTimes.at(world.rank());
        } else {
          G_tau += g_tau;
        }
        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
      }
      Project(params_);
      /*
      //Project(params_);
      bool wrongConf = true;
      auto stateCopy = state;
      std::vector<int> emptySites, occSites;
      for (int iArm = 1; iArm <= sites.NArms(); ++iArm) {
        for (int i(0); i < params_.sampling.fixedSites; i++) {
          int site = sites.ArmToSite(iArm, sites.NBath(iArm) - i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { emptySites.push_back(site); }
          site = sites.ArmToSite(iArm, 1 + i);
          if (!std::count(doubledBath.begin(), doubledBath.end(), site)) { occSites.push_back(site); };
        }
      }
      ReportOnce("---@SamplingUnitary, enfored empty bath sites::", emptySites, "\n");
      ReportOnce("---@SamplingUnitary, enfored occupied bath sites::", occSites, "\n");

      while (wrongConf) {
        state = stateCopy;
        Project(params_);
        wrongConf = false;
        for (auto site : emptySites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n) > 0.1) { wrongConf = true; }
        }
        for (auto site : occSites) {
          state.position(site);
          auto At = state.A(site);
          auto n  = std::real((At * state.sites().op("N", site) * dag(prime(At, "Site"))).cplx());
          if (abs(n - 1.0) > 0.1) { wrongConf = true; }
        }
      }
      //end restrict conf.
      */
    }
    //G_tau /= float(totalCount);
  };

  void finiteT_solver_core::SamplingReal(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();
    int step   = 0;
    totalCount = 0;
    while (step < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) {
        ReportOnce("--- sampling ", step + 1, "/", params_.sampling.n_sampling, " (total confs.=", totalCount + 1, ")\n");
      };

      auto label = generateLabel(state, params_);
      std::string fileNameSample;
      if (isRegistered(state, params_)) {
        totalCount += 1;
        //update the product state to the registered Metts
        state = statesPool[label].state;
        G_t += statesPool[label].g_t;
        statesPool[label].repeated += 1;

        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };
      } else {
        step += 1;
        totalCount += 1;
        //ReportOnce("Debug::", params_.h_int, "\n", params_.tevo, "\n");
        UniEvoType uniEvoType;
        if (params_.sampling.uniEvo) {
          //uniEvoType = UniEvoType::Full;
          if (step % 2 == 0) {
            uniEvoType = UniEvoType::Even;
          } else {
            uniEvoType = UniEvoType::Odd;
          }
        } else {
          uniEvoType = UniEvoType::None;
        }
        GenerateMetts(label, true, params_, uniEvoType);
        Measure(label, true);
        g_t_t g_t;
        g_t = CalcGFReal(label, params_);

        //write out the intermedia infos
        fileNameSample = fileNameIntermedia;
        fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
        if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };

        //acculmulate Green's function
        if (step == 1) {
          G_t = g_t; //* RepeatedTimes.at(world.rank());
        } else {
          G_t += g_t;
        }
        Energy.push_back(statesPool[label].energy);
        Occs.push_back(statesPool[label].occs);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
        BigNorm.push_back(statesPool[label].bigNorm);
        Label.push_back(statesPool[label].label);
        LabelHash.push_back(statesPool[label].labelHash);
      }

      //Project this METTS into a new product state
      Project(params_);
    }
  };

  void finiteT_solver_core::SamplingRealUnitary(finiteT_params_t const &params_) {
    //here, we will forget all data geneated during the thermalization
    Energy.clear();
    Occs.clear();
    //Gfs.clear();
    QuantumNumber.clear();
    BigNorm.clear();
    Label.clear();
    LabelHash.clear();
    statesPool.clear();
    int step   = 0;
    totalCount = 0;
    while (step < params_.sampling.n_sampling) {
      if (params_.verbose >= 1) {
        ReportOnce("--- sampling ", step + 1, "/", params_.sampling.n_sampling, " (total confs.=", totalCount + 1, ")\n");
      };

      auto label = generateLabel(state, params_);
      std::string fileNameSample;

      step += 1;
      totalCount += 1;
      /*
        //ReportOnce("Debug::", params_.h_int, "\n", params_.tevo, "\n");
        UniEvoType uniEvoType;
        if (params_.sampling.uniEvo) {
          //uniEvoType = UniEvoType::Full;
          if (step % 2 == 0) {
            uniEvoType = UniEvoType::Even;
          } else {
            uniEvoType = UniEvoType::Odd;
          }
        } else {
          uniEvoType = UniEvoType::None;
        }
        */
      //uniEvoType = UniEvoType::None;
      GenerateMettsBasisExpansion(label, true, params_, UniEvoType::None);
      Measure(label, true);
      ReportOnce("--- Energy of this measured METTS::", statesPool[label].energy, "\n");

      g_t_t g_t;
      g_t = CalcGFReal(label, params_);

      //write out the intermedia infos
      fileNameSample = fileNameIntermedia;
      fileNameSample += "/rank_" + std::to_string(world.rank()) + "_sample_" + std::to_string(step) + ".h5";
      if (params_.sampling.saveIntermedia) { WriteSamplingInfo(fileNameSample, label); };

      //acculmulate Green's function
      if (step == 1) {
        G_t = g_t; //* RepeatedTimes.at(world.rank());
      } else {
        G_t += g_t;
      }
      Energy.push_back(statesPool[label].energy);
      Occs.push_back(statesPool[label].occs);
      QuantumNumber.push_back(statesPool[label].quantumNumber);
      BigNorm.push_back(statesPool[label].bigNorm);
      Label.push_back(statesPool[label].label);
      LabelHash.push_back(statesPool[label].labelHash);
      //Project this METTS into a new product state
      Project(params_);
    }
  };

  void finiteT_solver_core::Thermalize(finiteT_params_t const &params_) {
    for (auto step : range1(params_.sampling.n_thermal)) {
      if (params_.verbose >= 1) { ReportOnce("--- thermalizing ", step, "/", params_.sampling.n_thermal, "\n"); }
      HeffState.ForgetContraction();
      auto label = generateLabel(state, params_);

      if (isRegistered(state, params_)) {
        state = statesPool[label].state;
        Energy.push_back(statesPool[label].energy);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
      } else {
        UniEvoType uniEvoType;
        if (params_.sampling.uniEvo) {
          if (step % 2 == 0) {
            uniEvoType = UniEvoType::Even;
          } else {
            uniEvoType = UniEvoType::Odd;
          }
        } else {
          uniEvoType = UniEvoType::None;
        }
        GenerateMetts(label, true, params_, uniEvoType);
        Measure(label, true);
        Energy.push_back(statesPool[label].energy);
        QuantumNumber.push_back(statesPool[label].quantumNumber);
      }
      //if (step != params_.sampling.n_thermal) { Project(params_); }
      Project(params_);
    }
  }

  void finiteT_solver_core::GenerateMetts(std::string const &label, bool const &reg, finiteT_params_t const &params_, UniEvoType const &uniEvoType) {
    args.add("TevoMethod", "TDVP_2");
    HeffState.ForgetContraction();
    phitau.resize(tList.size());

    //make a forward real time evolution in a measure step
    //double evoSign;
    //if (uniEvoType != UniEvoType::None) { evoSign = (uniEvoType == UniEvoType::Even) ? 1.0 : -1.0; }

    if (uniEvoType == UniEvoType::Even) {
      auto Heff_uni = ForkLocalOp(Huni);
      Heff_uni.ForgetContraction();
      for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
        if (i == 0) {
          /*
          std::vector<ForkTPS> krylovSpace_;
          krylovSpace_.push_back(state);
          ITensor heff_;
          double dt_small = params_.sampling.uniEvodt / 10.0;
          auto evoInfo    = GlobalKrylovTimeEvo(heff_, krylovSpace_, Huni, -Complex_i * dt_small, params_);

          state = evoInfo.second;
          //followed by two site tdvo
          Heff_uni.ForgetContraction();
          double t_now = dt_small;
          while (abs(t_now - params_.sampling.uniEvodt) > 1E-4) {
            TDVP(state, Heff_uni, -Complex_i * dt_small, args);
            t_now += dt_small;
            if (params_.verbose >= 3) { ReportOnce("--- inner tdvp @T=", t_now, "\n"); }
          }
          */
          if (world.rank() == 0) {
            if (params_.verbose >= 4) {
              args.add("verbose", true);
            } else {
              args.add("verbose", false);
            };
          }
          addBasis(state, Huni, args);
          Heff_uni.ForgetContraction();
          TDVP(state, Heff_uni, -Complex_i * params_.sampling.uniEvodt, args);
        } else {
          TDVP(state, Heff_uni, -Complex_i * params_.sampling.uniEvodt, args);
        }
        if (params_.verbose >= 4) {
          ReportOnce("Generating unitary forward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
          if (world.rank() == 0) {
            //state.PrintImpM(3);
            auto psi = state;
            psi.PrintOccs();
          };
          //          ReportOnce("\n\n");
        }
      };
    }

    double norm = std::log(state.normalizeLim());
    phitau[0]   = {state, norm};
    if (params_.verbose >= 3) {
      ReportOnce("--- the initial norm is ", norm, "\n");
      Args args_tmp;
      args_tmp.add("Orthog", false);
      ForkTPS psi_ini     = state;
      auto energy_initial = (overlap(psi_ini, exactApplyMPO(psi_ini, H, args_tmp)));
      ReportOnce("--- the initial energy is ", energy_initial, "\n");
    }

    double totalT = 0;
    //do globlal krylov
    std::vector<ForkTPS> krylovSpace;
    krylovSpace.push_back(state);
    ITensor heff;
    bool globalKrylov = params_.gKrylov.gKrylov && uniEvoType != UniEvoType::Even;
    std::vector<int> bondGrowth;
    // do TDVP
    //auto Ops = TEBD_container(hint, b, e0, dtauTDVP, sites);
    for (int step = 0; step < tList.size() - 1; step++) {
      //only the first step will potentially perform global krylov time evolution
      if (step > 0) { globalKrylov = false; };
      if (globalKrylov && uniEvoType != UniEvoType::Even) {
        double dt_small = tList.at(step + 1) / 10.0;
        auto evoInfo    = GlobalKrylovTimeEvo(heff, krylovSpace, H, dt_small, params_);
        globalKrylov    = evoInfo.first;
        if (globalKrylov) {
          state = evoInfo.second;
          //followed by two site tdvo
          HeffState.ForgetContraction();
          double t_now = dt_small;
          while (abs(t_now - tList.at(step + 1)) > 1E-4) {
            TDVP(state, HeffState, dt_small, args);
            t_now += dt_small;
            if (params_.verbose >= 3) { ReportOnce("--- inner tdvp @T=", t_now, "\n"); }
          }
          HeffState.ForgetContraction();
        }
      }
      if (step == 0 && !globalKrylov && (uniEvoType == UniEvoType::None || uniEvoType == UniEvoType::Odd)) {
        ReportOnce(
           "@GenerateMetts, the global krylov time evolution failed (or not active) at the initial time, using addBasis to expand the basis...\n");
        if (world.rank() == 0) {
          if (params_.verbose >= 4) {
            args.add("verbose", true);
          } else {
            args.add("verbose", false);
          };
          addBasis(state, HBasis, args);
          HeffState.ForgetContraction();
          ReportOnce(
             "@GenerateMetts, the global krylov time evolution failed (or not active) at the initial time, using addBasis to expand the basis...Done\n");
        }
      }

      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }

      //if (step % params_.basisExpansion.expand_every == 0 && minI_ < int(params_.tevo.approx.maxm_i / 2) && params_.tevo.time_steps <= 1) {
      //  addBasis(state, H, args);
      //  if (params_.verbose >= 2) { ReportOnce("--- Added basis @", totalT, "  \n"); };
      //printfln("------ basis extension at i equals %.12f to %.12f", i, state.MaxM());
      //  HeffState.ForgetContraction();
      //}

      long maxI_ = 0;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        maxI_    = std::max(maxI_, dim(ind));
      }
      //      ReportOnce(minI_, ", ", maxI_, "\n");
      //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
      //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
      if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStep && args.getString("TevoMethod") != "TDVP") {
        if (params_.verbose >= 2) { ReportOnce("--- GenerateMetts:: Change to single site TDVP @", totalT, "  \n"); };
        args.add("TevoMethod", "TDVP");
        HeffState.ForgetContraction();
      }
      if (!globalKrylov) { TDVP(state, HeffState, tList.at(step + 1) - tList.at(step), args); }

      totalT = tList[step + 1];
      norm   = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));
      if (globalKrylov) {
        for (int ic(0); ic <= step; ic++) { norm -= phitau.at(ic).normFactor; }
      }

      if (params_.verbose >= 3) {
        ReportOnce(globalKrylov ? "Global Krylov" : args.getString("TevoMethod"), ":: Generating Metts Imaginary time @ ", totalT,
                   "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
        if (world.rank() == 0) { state.PrintImpM(3); };
        ReportOnce("\n");
        ReportOnce("And norm ::", norm, ", current norm :: ", state.norm(), "\n");
        ReportOnce("\n\n");
      }

      //make a backward real time evolution

      if (step == (tList.size() - 2) && uniEvoType == UniEvoType::Odd) {
        auto Heff_uni = ForkLocalOp(Huni);
        for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
          TDVP(state, Heff_uni, Complex_i * params_.sampling.uniEvodt, args);
          if (params_.verbose >= 3) {
            ReportOnce("Generating unitary backward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
            if (world.rank() == 0) {
              //state.PrintImpM(3);
              auto psi = state;
              psi.PrintOccs();
            };
            ReportOnce("\n\n");
          }
        };
      }

      //debug
      if (world.rank() == 0 && params_.verbose >= 3) { PrintBigDensity(); };
      phitau[step + 1] = {state, norm};
      auto psi_        = state;
      bondGrowth.push_back(psi_.MaxM());
    }

    if (abs(totalT - params_.beta / 2.) > 1E-6) {
      PRINT(totalT);
      PRINT(params_.beta / 2.);
      PRINT(totalT - params_.beta / 2.);
      Error("Missmatch in time steps");
    }

    //register this metts
    //std::cout << "Register the new product state configuration " << label << std::endl;
    if (reg) {
      statesPool[label].repeated = 1;
      //statesPool[label].statesPath = phitau;
      statesPool[label].state     = state;
      statesPool[label].label     = label;
      statesPool[label].labelHash = std::hash<std::string>{}(label);
      double bigNorm              = 0.0;
      for (int i(0); i < phitau.size(); ++i) { bigNorm += phitau.at(i).normFactor; };
      statesPool[label].bigNorm    = bigNorm;
      statesPool[label].bondGrowth = bondGrowth;
    }
    if (params_.verbose >= 1) {
      ReportOnce("--- Big norm of this METTS::", statesPool[label].bigNorm, "\n");
      ReportOnce("--- Filling of this METTS::\n");
      if (world.rank() == 0) { state.PrintOccs(); };
      ReportOnce("\n\n");
      state.position(1);
      ReportOnce("--- Particle Number of this METTS::", div(state.A(1)).val("Nf"), "\n");
      //print out the occupation matrix
      if (world.rank() == 0) {
        for (auto block : params_.gf_struct) {
          std::cout << "Impurity Occupation Matrix <c_i^d c_j > for block " << block.first << "\n";
          for (int iorb(0); iorb < block.second; iorb++) {
            std::cout << std::endl;
            for (int jorb(0); jorb < block.second; jorb++) {
              triqs_indx ind_i = {block.first, iorb}, ind_j = {block.first, jorb};
              auto arm_i  = TriqsIndxToArm(ind_i);
              auto arm_j  = TriqsIndxToArm(ind_j);
              auto site_i = sites.ImpSite(arm_i);
              auto site_j = sites.ImpSite(arm_j);
              ForkTPS bra = state, ket = state;
              bra.position(site_i);
              ket.position(site_j);
              bra.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
              ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
              auto val = overlap(bra, ket);
              std::cout << std::setprecision(4) << val << "      ";
            }
          }
          std::cout << std::endl;
        }
      } //end print density matrix
    }   //end print out information
  }

  void finiteT_solver_core::GenerateMettsBasisExpansion(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                                                        UniEvoType const &uniEvoType) {
    args.add("TevoMethod", "TDVP_2");
    HeffState.ForgetContraction();
    phitau.resize(tList.size());

    //expand the basis
    if (params_.verbose >= 6) { args.add("verbose", true); }
    ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...\n");
    addBasis(state, HBasis, args);
    HeffState.ForgetContraction();
    //since tdvp will start by moving the orthogonality center to the first impurity site with the
    //given truncation, we need to move the OC to this site with no truncation first, otherwise
    //the added basis states will be truncated entially.
    Args args_check("Cutoff", -1);
    state.position(1, args_check);
    //state.PrintImpM(3);
    ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...Done\n");
    {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }
      if (minI_ == 1) { Error(" @GenerateettsBasisExpansion, the smallest bond dimension is 1 perform another basis expansion"); }
    }

    //make a forward real time evolution in a measure step
    if (uniEvoType == UniEvoType::Even) {
      auto Heff_uni = ForkLocalOp(Huni);
      Heff_uni.ForgetContraction();
      for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
        TDVP(state, Heff_uni, -Complex_i * params_.sampling.uniEvodt, args);
        if (params_.verbose >= 4) {
          ReportOnce("Generating unitary forward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
          if (world.rank() == 0) {
            auto psi = state;
            psi.PrintOccs();
          };
        }
      };
    };

    double norm   = std::log(state.normalizeLim());
    phitau[0]     = {state, norm};
    double totalT = 0;
    std::vector<int> bondGrowth;
    // do TDVP
    //auto Ops = TEBD_container(hint, b, e0, dtauTDVP, sites);
    //args.add("TevoMethod", "TDVP");
    for (int step = 0; step < tList.size() - 1; step++) {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }
      //if (step % params_.basisExpansion.expand_every == 0 && minI_ < int(params_.tevo.approx.maxm_i / 2) && params_.tevo.time_steps <= 1) {
      //  addBasis(state, H, args);
      //  if (params_.verbose >= 2) { ReportOnce("--- Added basis @", totalT, "  \n"); };
      //printfln("------ basis extension at i equals %.12f to %.12f", i, state.MaxM());
      //  HeffState.ForgetContraction();
      //}

      long maxI_ = 0;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        maxI_    = std::max(maxI_, dim(ind));
      }
      //      ReportOnce(minI_, ", ", maxI_, "\n");
      //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
      //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
      if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStep && args.getString("TevoMethod") != "TDVP") {
        if (params_.verbose >= 2) { ReportOnce("--- GenerateMetts:: Change to single site TDVP @", totalT, "  \n"); };
        args.add("TevoMethod", "TDVP");
        HeffState.ForgetContraction();
      }

      auto oriMethod = args.getString("TevoMethod");
      if (step % params_.basisExpansion.expand_every == 0 && step != 0) {
        //args.add("TevoMethod", "TDVP_2");
        ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...@T::", totalT, "\n");
        addBasis(state, HBasis, args);
        HeffState.ForgetContraction();
        ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...DONE! @T::", totalT, "\n");
      }
      TDVP(state, HeffState, tList.at(step + 1) - tList.at(step), args);
      if (step % params_.basisExpansion.expand_every == 0) { args.add("TevoMethod", oriMethod); }

      totalT = tList[step + 1];
      norm   = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));

      if (params_.verbose >= 3) {
        ReportOnce("BasisExansion ", args.getString("TevoMethod"), ":: Generating Metts Imaginary time @ ", totalT,
                   "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
        if (world.rank() == 0) { state.PrintImpM(3); };
        ReportOnce("\n");
        ReportOnce("And norm ::", norm, ", current norm :: ", state.norm(), "\n");
        ReportOnce("\n\n");
      }

      //make a backward real time evolution

      if (step == (tList.size() - 2) && uniEvoType == UniEvoType::Odd) {
        auto Heff_uni = ForkLocalOp(Huni);
        for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
          TDVP(state, Heff_uni, Complex_i * params_.sampling.uniEvodt, args);
          if (params_.verbose >= 3) {
            ReportOnce("Generating unitary backward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
            if (world.rank() == 0) {
              auto psi = state;
              psi.PrintOccs();
            };
          }
        };
      }

      //debug
      if (world.rank() == 0 && params_.verbose >= 3) { PrintBigDensity(); };
      phitau[step + 1] = {state, norm};
      auto psi_        = state;
      bondGrowth.push_back(psi_.MaxM());
    }

    if (abs(totalT - params_.beta / 2.) > 1E-6) {
      PRINT(totalT);
      PRINT(params_.beta / 2.);
      PRINT(totalT - params_.beta / 2.);
      Error("Missmatch in time steps");
    }

    //register this metts
    //std::cout << "Register the new product state configuration " << label << std::endl;
    if (reg) {
      statesPool[label].repeated = 1;
      //statesPool[label].statesPath = phitau;
      statesPool[label].state     = state;
      statesPool[label].label     = label;
      statesPool[label].labelHash = std::hash<std::string>{}(label);
      double bigNorm              = 0.0;
      for (int i(0); i < phitau.size(); ++i) { bigNorm += phitau.at(i).normFactor; };
      statesPool[label].bigNorm    = bigNorm;
      statesPool[label].bondGrowth = bondGrowth;
    }
    if (params_.verbose >= 1) {
      ReportOnce("--- Big norm of this METTS::", statesPool[label].bigNorm, "\n");
      ReportOnce("--- Filling of this METTS::\n");
      if (world.rank() == 0) { state.PrintOccs(); };
      ReportOnce("\n\n");
      state.position(1);
      ReportOnce("--- Particle Number of this METTS::", div(state.A(1)).val("Nf"), "\n");
      //print out the occupation matrix
      if (world.rank() == 0) {
        for (auto block : params_.gf_struct) {
          std::cout << "Impurity Occupation Matrix <c_i^d c_j > for block " << block.first << "\n";
          for (int iorb(0); iorb < block.second; iorb++) {
            std::cout << std::endl;
            for (int jorb(0); jorb < block.second; jorb++) {
              triqs_indx ind_i = {block.first, iorb}, ind_j = {block.first, jorb};
              auto arm_i  = TriqsIndxToArm(ind_i);
              auto arm_j  = TriqsIndxToArm(ind_j);
              auto site_i = sites.ImpSite(arm_i);
              auto site_j = sites.ImpSite(arm_j);
              ForkTPS bra = state, ket = state;
              bra.position(site_i);
              ket.position(site_j);
              bra.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
              ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
              auto val = overlap(bra, ket);
              std::cout << std::setprecision(4) << val << "      ";
            }
          }
          std::cout << std::endl;
        }
      } //end print density matrix
    }   //end print out information
  }

  void finiteT_solver_core::GenerateMettsHybrid(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                                                UniEvoType const &uniEvoType) {

    ReportOnce("---@GenerateMettsBasisHybrid, time evolution is performed by hybrid BE + Two site\n");

    HeffState.ForgetContraction();
    phitau.resize(tList.size());
    if (reg) { statesPool[label].productState = state; }
    //ReportOnce("@GenerateMettsBasisExpansionSingleSite, input product state...\n");
    // if (world.rank() == 0) { state.PrintOccs(); };
    //{
    //  std::cout << "\n\n @rank " << world.rank() << std::endl;
    //  state.PrintOccs();
    //}

    //expand the basis
    if (params_.verbose >= 6) { args.add("verbose", true); }
    //ReportOnce("@GenerateMettsBasisExpansionSingleSite, using addBasis to expand the basis @inital time...\n");
    args.add("nKrylovBE", params_.basisExpansion.nKrylovBE);

    ReportOnce("@GenerateMettsBasisHybrid, using addBasis to expand the basis (with OffDia) @inital time...\n");
    addBasis(state, HBasis, args);

    HeffState.ForgetContraction();
    //since tdvp will start by moving the orthogonality center to the first impurity site with the
    //given truncation, we need to move the OC to this site with no truncation first, otherwise
    //the added basis states will be truncated entially.
    Args args_check("Cutoff", -1);
    state.position(1, args_check);
    //state.PrintImpM(3);
    ReportOnce("@GenerateMettsBasisHybrid, using addBasis to expand the basis @inital time...Done\n");
    {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }
      if (minI_ == 1) { Error(" @GenerateMettsBasisHybrid, the smallest bond dimension is 1 perform another basis expansion"); }
    }

    //make a forward real time evolution in a measure step

    double norm   = std::log(state.normalizeLim());
    phitau[0]     = {state, norm};
    double totalT = 0;
    std::vector<int> bondGrowth;
    // do TDVP
    //auto Ops = TEBD_container(hint, b, e0, dtauTDVP, sites);
    args.add("TevoMethod", "TDVP");
    for (int step = 0; step < tList.size() - 1; step++) {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }

      long maxI_ = 0;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        maxI_    = std::max(maxI_, dim(ind));
      }

      //auto oriMethod = args.getString("TevoMethod");
      //|| minI_ <= int(params_.tevo.approx.maxm_i / 2)
      if (step != 0 && (step) % params_.basisExpansion.expand_every == 0 && totalT < params_.sampling.BETime) {
        if (params_.verbose >= 1) { ReportOnce("@GenerateMettsHyrid, using addBasis to expand the basis...@T::", totalT, "\n"); }
        addBasis(state, HBasis, args);
        HeffState.ForgetContraction();
        if (params_.verbose >= 1) { ReportOnce("@GenerateMettsHyrid, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
      } else if (totalT >= params_.sampling.BETime && totalT <= params_.sampling.TSTime && args.getString("TevoMethod") != "TDVP_2") {
        args.add("TevoMethod", "TDVP_2");
        HeffState.ForgetContraction();
        if (params_.verbose >= 1) { ReportOnce("@GenerateMettsHyrid, change to two-site tdvp @T::", totalT, "\n"); }
      } else if (totalT > params_.sampling.TSTime && maxI_ >= params_.tevo.approx.maxm_i && args.getString("TevoMethod") != "TDVP") {
        args.add("TevoMethod", "TDVP");
        HeffState.ForgetContraction();
        if (params_.verbose >= 1) { ReportOnce("@GenerateMettsHyrid, change to single-site tdvp @T::", totalT, "\n"); }
      }

      TDVP(state, HeffState, tList.at(step + 1) - tList.at(step), args);
      //if (step % params_.basisExpansion.expand_every == 0) { args.add("TevoMethod", oriMethod); }

      totalT = tList[step + 1];
      norm   = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));

      if (params_.verbose >= 3) {
        ReportOnce("BasisExansion ", args.getString("TevoMethod"), ":: Generating Metts Imaginary time @ ", totalT,
                   "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
        if (world.rank() == 0) { state.PrintImpM(3); };
        ReportOnce("\n");
        ReportOnce("And norm ::", norm, ", current norm :: ", state.norm(), "\n");
        ReportOnce("\n\n");
      }

      //make a backward real time evolution

      //debug
      if (world.rank() == 0 && params_.verbose >= 3) { PrintBigDensity(); };
      phitau[step + 1] = {state, norm};
      auto psi_        = state;
      bondGrowth.push_back(psi_.MaxM());
    }

    if (abs(totalT - params_.beta / 2.) > 1E-6) {
      PRINT(totalT);
      PRINT(params_.beta / 2.);
      PRINT(totalT - params_.beta / 2.);
      Error("Missmatch in time steps");
    }

    //register this metts
    //std::cout << "Register the new product state configuration " << label << std::endl;
    if (reg) {
      statesPool[label].repeated = 1;
      //statesPool[label].statesPath = phitau;
      statesPool[label].state     = state;
      statesPool[label].label     = label;
      statesPool[label].labelHash = std::hash<std::string>{}(label);
      double bigNorm              = 0.0;
      for (int i(0); i < phitau.size(); ++i) { bigNorm += phitau.at(i).normFactor; };
      statesPool[label].bigNorm    = bigNorm;
      statesPool[label].bondGrowth = bondGrowth;
    }
    if (params_.verbose >= 1) {
      ReportOnce("--- Big norm of this METTS::", statesPool[label].bigNorm, "\n");
      ReportOnce("--- Filling of this METTS::\n");
      if (world.rank() == 0) {
        state.PrintOccs();
        state.PrintImpM();
      };
      ReportOnce("\n\n");
      state.position(1);
      ReportOnce("--- Particle Number of this METTS::", div(state.A(1)).val("Nf"), "\n");
      //print out the occupation matrix
      if (world.rank() == 0) {
        for (auto block : params_.gf_struct) {
          std::cout << "Impurity Occupation Matrix <c_i^d c_j > for block " << block.first << "\n";
          for (int iorb(0); iorb < block.second; iorb++) {
            std::cout << std::endl;
            for (int jorb(0); jorb < block.second; jorb++) {
              triqs_indx ind_i = {block.first, iorb}, ind_j = {block.first, jorb};
              auto arm_i  = TriqsIndxToArm(ind_i);
              auto arm_j  = TriqsIndxToArm(ind_j);
              auto site_i = sites.ImpSite(arm_i);
              auto site_j = sites.ImpSite(arm_j);
              ForkTPS bra = state, ket = state;
              bra.position(site_i);
              ket.position(site_j);
              bra.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
              ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
              auto val = overlap(bra, ket);
              std::cout << std::setprecision(4) << val << "      ";
            }
          }
          std::cout << std::endl;
        }
      } //end print density matrix
    }   //end print out information
  }

  void finiteT_solver_core::GenerateMettsBasisExpansionSingleSite(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                                                                  UniEvoType const &uniEvoType) {

    if (params_.basisExpansion.useBE) {
      ReportOnce("---@GenerateMettsBasisExpansionSingleSite, time evolution is performed by BE\n");
      args.add("TevoMethod", "TDVP");
    } else {
      ReportOnce("---@GenerateMettsBasisExpansionSingleSite, time evolution is performed by TWOSITE\n");
      args.add("TevoMethod", "TDVP_2");
    }
    HeffState.ForgetContraction();
    phitau.resize(tList.size());
    if (reg) { statesPool[label].productState = state; }
    //ReportOnce("@GenerateMettsBasisExpansionSingleSite, input product state...\n");
    // if (world.rank() == 0) { state.PrintOccs(); };
    //{
    //  std::cout << "\n\n @rank " << world.rank() << std::endl;
    //  state.PrintOccs();
    //}

    //expand the basis
    if (params_.verbose >= 6) { args.add("verbose", true); }
    //ReportOnce("@GenerateMettsBasisExpansionSingleSite, using addBasis to expand the basis @inital time...\n");
    args.add("nKrylovBE", params_.basisExpansion.nKrylovBE);

    ReportOnce("@GenerateMettsBasisExpansionSingleSite, using addBasis to expand the basis (with OffDia) @inital time...\n");
    addBasis(state, HBasis, args);

    HeffState.ForgetContraction();
    //since tdvp will start by moving the orthogonality center to the first impurity site with the
    //given truncation, we need to move the OC to this site with no truncation first, otherwise
    //the added basis states will be truncated entially.
    Args args_check("Cutoff", -1);
    state.position(1, args_check);
    //state.PrintImpM(3);
    ReportOnce("@GenerateMettsBasisExpansionSingleSite, using addBasis to expand the basis @inital time...Done\n");
    {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }
      if (minI_ == 1) { Error(" @GenerateettsBasisExpansion, the smallest bond dimension is 1 perform another basis expansion"); }
    }

    //make a forward real time evolution in a measure step
    if (uniEvoType == UniEvoType::Even) {
      ReportOnce(args.getString("TevoMethod"), "::Even, Generating unitary FORWARD real time (with dt=", params_.sampling.uniEvodt, ") \n");
      auto Heff_uni = ForkLocalOp(Huni);
      for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
        if (params_.basisExpansion.useBE) {
          //if (params_.h_int.dd_only) {
          addBasis(state, HBasis, args);
          //} else {
          //  addBasis(state, HBasis, HOffDia, args);
          //}
          Heff_uni.ForgetContraction();
        }
        TDVP(state, Heff_uni, Complex_i * params_.sampling.uniEvodt, args);
        if (params_.verbose >= 4) {
          ReportOnce("Generating unitary forward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
          if (world.rank() == 0) {
            auto psi = state;
            psi.PrintOccs();
            psi.PrintImpM(3);
          };
        }
      };
      if (world.rank() == 0) {
        auto psi = state;
        psi.PrintOccs();
        psi.PrintImpM(3);
      };
    };

    double norm   = std::log(state.normalizeLim());
    phitau[0]     = {state, norm};
    double totalT = 0;
    std::vector<int> bondGrowth;
    // do TDVP
    //auto Ops = TEBD_container(hint, b, e0, dtauTDVP, sites);
    //args.add("TevoMethod", "TDVP");
    for (int step = 0; step < tList.size() - 1; step++) {
      long minI_ = 1000000;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
      }

      long maxI_ = 0;
      for (int iArm = 1; iArm < state.NArms(); ++iArm) {
        auto ind = commonIndex(state.A(state.ImpSite(iArm)), state.A(state.ImpSite(iArm + 1)));
        maxI_    = std::max(maxI_, dim(ind));
      }

      //auto oriMethod = args.getString("TevoMethod");
      //|| minI_ <= int(params_.tevo.approx.maxm_i / 2)
      if (params_.basisExpansion.useBE) {
        if (step != 0 && (step) % params_.basisExpansion.expand_every == 0
            && (totalT <= params_.sampling.minTwoSiteTime || maxI_ < params_.tevo.approx.maxm_i)) {
          //args.add("TevoMethod", "TDVP_2");
          if (params_.verbose >= 3) { ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...@T::", totalT, "\n"); }
          //if (params_.h_int.dd_only) {
          addBasis(state, HBasis, args);
          //} else {
          // addBasis(state, HBasis, HOffDia, args);
          //}
          HeffState.ForgetContraction();
          if (params_.verbose >= 3) { ReportOnce("@GenerateMettsBasisExpansion, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
        }
      } else {
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 4)
        if (maxI_ >= params_.tevo.approx.maxm_i && totalT >= params_.sampling.minTwoSiteTime && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 1) { ReportOnce("--- GenerateMettsBasisExpansion:: Change to single site TDVP @", totalT, "  \n"); };
          args.add("TevoMethod", "TDVP");
          HeffState.ForgetContraction();
        }
      }
      TDVP(state, HeffState, tList.at(step + 1) - tList.at(step), args);
      //if (step % params_.basisExpansion.expand_every == 0) { args.add("TevoMethod", oriMethod); }

      totalT = tList[step + 1];
      norm   = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));

      if (params_.verbose >= 3) {
        ReportOnce("BasisExansion ", args.getString("TevoMethod"), ":: Generating Metts Imaginary time @ ", totalT,
                   "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
        if (world.rank() == 0) { state.PrintImpM(3); };
        ReportOnce("\n");
        ReportOnce("And norm ::", norm, ", current norm :: ", state.norm(), "\n");
        ReportOnce("\n\n");
      }

      //make a backward real time evolution
      if (step == (tList.size() - 2) && uniEvoType == UniEvoType::Odd) {
        ReportOnce(args.getString("TevoMethod"), "::Odd, Generating unitary BACKWARD real time (with dt=", params_.sampling.uniEvodt, ") \n");
        auto Heff_uni = ForkLocalOp(Huni);
        for (int i(0); i < params_.sampling.uniEvoSteps; i++) {
          TDVP(state, Heff_uni, -Complex_i * params_.sampling.uniEvodt, args);
          if (params_.verbose >= 4) {
            ReportOnce("Generating unitary backward real time step @ ", i, "(with dt=", params_.sampling.uniEvodt, ") \n");
            if (world.rank() == 0) {
              auto psi = state;
              psi.PrintOccs();
              psi.PrintImpM(3);
            };
          }
        };
        if (world.rank() == 0) {
          auto psi = state;
          psi.PrintOccs();
          psi.PrintImpM(3);
        };
      }

      //debug
      if (world.rank() == 0 && params_.verbose >= 3) { PrintBigDensity(); };
      phitau[step + 1] = {state, norm};
      auto psi_        = state;
      bondGrowth.push_back(psi_.MaxM());
    }

    if (abs(totalT - params_.beta / 2.) > 1E-6) {
      PRINT(totalT);
      PRINT(params_.beta / 2.);
      PRINT(totalT - params_.beta / 2.);
      Error("Missmatch in time steps");
    }

    //register this metts
    //std::cout << "Register the new product state configuration " << label << std::endl;
    if (reg) {
      statesPool[label].repeated = 1;
      //statesPool[label].statesPath = phitau;
      statesPool[label].state     = state;
      statesPool[label].label     = label;
      statesPool[label].labelHash = std::hash<std::string>{}(label);
      double bigNorm              = 0.0;
      for (int i(0); i < phitau.size(); ++i) { bigNorm += phitau.at(i).normFactor; };
      statesPool[label].bigNorm    = bigNorm;
      statesPool[label].bondGrowth = bondGrowth;
    }
    if (params_.verbose >= 1) {
      ReportOnce("--- Big norm of this METTS::", statesPool[label].bigNorm, "\n");
      ReportOnce("--- Filling of this METTS::\n");
      if (world.rank() == 0) {
        state.PrintOccs();
        state.PrintImpM();
      };
      ReportOnce("\n\n");
      state.position(1);
      ReportOnce("--- Particle Number of this METTS::", div(state.A(1)).val("Nf"), "\n");
      //print out the occupation matrix
      if (world.rank() == 0) {
        for (auto block : params_.gf_struct) {
          std::cout << "Impurity Occupation Matrix <c_i^d c_j > for block " << block.first << "\n";
          for (int iorb(0); iorb < block.second; iorb++) {
            std::cout << std::endl;
            for (int jorb(0); jorb < block.second; jorb++) {
              triqs_indx ind_i = {block.first, iorb}, ind_j = {block.first, jorb};
              auto arm_i  = TriqsIndxToArm(ind_i);
              auto arm_j  = TriqsIndxToArm(ind_j);
              auto site_i = sites.ImpSite(arm_i);
              auto site_j = sites.ImpSite(arm_j);
              ForkTPS bra = state, ket = state;
              bra.position(site_i);
              ket.position(site_j);
              bra.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
              ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
              auto val = overlap(bra, ket);
              std::cout << std::setprecision(4) << val << "      ";
            }
          }
          std::cout << std::endl;
        }
      } //end print density matrix
    }   //end print out information
  }

  g_tau_t finiteT_solver_core::CalcGFBasis(finiteT_params_t const &params_) {
    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      //the indices
      Index alphaInd(basisInfos.basisSize, "alpha"), betaInd(basisInfos.basisSize, "beta"), gammaInd(basisInfos.basisSize, "gamma"),
         deltaInd(basisInfos.basisSize, "delta");
      Index iInd(basisInfos.stateSize, "i"), jInd(basisInfos.stateSize, "j");

      //evaluate the operator matrix
      ITensor Amatrix(iInd, jInd), Bmatrix(iInd, jInd);
#pragma omp parallel for num_threads(omp_get_max_threads()), schedule(dynamic, 1)
      for (int i = 1; i < dim(iInd) + 1; i++) {
        for (int j(1); j < dim(jInd) + 1; j++) {
          ForkTPS psi_A = basisInfos.states_metts.at(j - 1);
          psi_A.position(site_A);
          psi_A.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
          Amatrix.set(i, j, overlap(basisInfos.states_metts.at(i - 1), psi_A));
        }
      }
#pragma omp parallel for num_threads(omp_get_max_threads()), schedule(dynamic, 1)
      for (int i = 1; i < dim(iInd) + 1; i++) {
        for (int j(1); j < dim(jInd) + 1; j++) {
          ForkTPS psi_B = basisInfos.states_metts.at(j - 1);
          psi_B.position(site_B);
          psi_B.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
          Bmatrix.set(i, j, overlap(basisInfos.states_metts.at(i - 1), psi_B));
        }
      }

      //rotate the tensors into orthonormalized basis
      auto R_inds    = inds(basisInfos.R);
      Index truncInd = hasTags(R_inds(1), "trunc") ? R_inds(1) : R_inds(2);
      Index stateInd = hasTags(R_inds(1), "trunc") ? R_inds(2) : R_inds(1);

      auto R_tmp = basisInfos.R;

      //rotate A operator matrix
      auto R_A_L = R_tmp * delta(truncInd, betaInd);
      R_A_L      = R_A_L * delta(stateInd, iInd);

      auto R_A_R = R_tmp * delta(truncInd, gammaInd);
      R_A_R      = R_A_R * delta(stateInd, jInd);

      Amatrix = dag(R_A_L) * Amatrix * R_A_R;

      //rotate B operator matrix
      auto R_B_L = R_tmp * delta(truncInd, deltaInd);
      R_B_L      = R_B_L * delta(stateInd, iInd);

      auto R_B_R = R_tmp * delta(truncInd, alphaInd);
      R_B_R      = R_B_R * delta(stateInd, jInd);

      Bmatrix = dag(R_B_L) * Bmatrix * R_B_R;

      //partition function
      ReportOnce("--- calculating partion function\n");
      auto Hbeta = basisInfos.Heff_R;
      //auto inds_    = inds(Hbeta);
      //Hbeta         = Hbeta * delta(inds_(2), prime(inds_(1)));
      auto [U_, E_] = diagHermitian(Hbeta);
      auto Z        = std::complex<double>(0.0, 0.0);
      for (int ie(1); ie < dim(inds(E_)(1)) + 1; ie++) {
        ReportOnce("--- eigen values ( ", ie, " )= ", eltC(E_, ie, ie), "\n");
        Z += std::exp(-params_.beta * eltC(E_, ie, ie));
      }
      ReportOnce("--- Partition function::", Z, "\n");

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);

      double totalT = 0.0;
      for (int it(0); it < TimeGrid.size(); it++) {
        totalT = TimeGrid.at(it);

        auto expHPositive = ExponentialMatrix(totalT - params_.beta, basisInfos.Heff_R);
        auto expHNegative = ExponentialMatrix(-totalT, basisInfos.Heff_R);

        auto indics  = inds(expHPositive);
        expHPositive = expHPositive * delta(indics(1), alphaInd);
        expHPositive = expHPositive * delta(indics(2), betaInd);

        indics       = inds(expHNegative);
        expHNegative = expHNegative * delta(indics(1), gammaInd);
        expHNegative = expHNegative * delta(indics(2), deltaInd);

        auto val_ = expHPositive * Amatrix * expHNegative * Bmatrix;
        //PrintData(val_);

        gf.at(it) = eltC(val_) / Z;

        if (params_.verbose >= 10) {
          ReportOnce("Calculating G(tau) Imaginary time @ ", totalT, " \n");
          ReportOnce("Value:: ", -gf.at(it), "\n");
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 10) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_tau;
  };

  g_tau_t finiteT_solver_core::CalcGFBasis(int const &metts_i, finiteT_params_t const &params_) {
    //double beta = params_.beta;
    int stateSize = basisInfos.stateSize;
    int basisSize = basisInfos.basisSize;

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      //the indices
      Index alphaInd(basisInfos.basisSize, "alpha"), betaInd(basisInfos.basisSize, "beta"), gammaInd(basisInfos.basisSize, "gamma"),
         deltaInd(basisInfos.basisSize, "delta");
      Index jInd(basisInfos.stateSize, "j"), kInd(basisInfos.stateSize, "k"), lInd(basisInfos.stateSize, "l"), nInd(basisInfos.stateSize, "n");
      Index iInd(basisInfos.stateSize, "i");

      //evaluate the operator matrix
      ITensor Amatrix(kInd, lInd), Bvec(nInd), Cvec(jInd);
      ForkTPS psi_B = basisInfos.states_metts.at(metts_i * basisInfos.multiplyFactor - 1);
      psi_B.position(site_B);
      psi_B.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);

      for (int n(1); n < dim(nInd) + 1; n++) {
        Bvec.set(n, overlap(basisInfos.states_metts.at(n - 1), psi_B));
        //std::cout << "Bvec :: " << std::setprecision(15) << std::scientific << eltC(Bvec, n) << "\n" << std::endl;
      }
      for (int k(1); k < dim(kInd) + 1; k++) {
        for (int l(1); l < dim(lInd) + 1; l++) {
          ForkTPS psi_A = basisInfos.states_metts.at(l - 1);
          psi_A.position(site_A);
          psi_A.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
          Amatrix.set(k, l, overlap(basisInfos.states_metts.at(k - 1), psi_A));
        }
      }
      for (int j(1); j < dim(jInd) + 1; j++) { Cvec.set(j, eltC(basisInfos.C, metts_i * basisInfos.multiplyFactor, j)); }

      //rotate the tensors into orthonormalized basis
      auto R_inds    = inds(basisInfos.R);
      Index truncInd = hasTags(R_inds(1), "trunc") ? R_inds(1) : R_inds(2);
      Index stateInd = hasTags(R_inds(1), "trunc") ? R_inds(2) : R_inds(1);

      auto R_tmp  = basisInfos.R;
      auto R_Bvec = R_tmp * delta(truncInd, deltaInd);
      R_Bvec      = R_Bvec * delta(stateInd, nInd);

      auto R_Cvec = R_tmp * delta(truncInd, alphaInd);
      R_Cvec      = R_Cvec * delta(stateInd, jInd);

      auto R_A_L = R_tmp * delta(truncInd, betaInd);
      R_A_L      = R_A_L * delta(stateInd, kInd);

      auto R_A_R = R_tmp * delta(truncInd, gammaInd);
      R_A_R      = R_A_R * delta(stateInd, lInd);

      Bvec    = dag(R_Bvec) * Bvec;
      Cvec    = R_Cvec * Cvec;
      Amatrix = dag(R_A_L) * Amatrix * R_A_R;

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);

      double totalT = 0.0;
      for (int it(0); it < TimeGrid.size(); it++) {
        totalT = TimeGrid.at(it);

        auto expHPositive = ExponentialMatrix(totalT, basisInfos.Heff_R);
        auto expHNegative = ExponentialMatrix(-totalT, basisInfos.Heff_R);

        auto indics  = inds(expHPositive);
        expHPositive = expHPositive * delta(indics(1), alphaInd);
        expHPositive = expHPositive * delta(indics(2), betaInd);

        indics       = inds(expHNegative);
        expHNegative = expHNegative * delta(indics(1), gammaInd);
        expHNegative = expHNegative * delta(indics(2), deltaInd);

        auto val_ = Cvec * expHPositive * Amatrix * expHNegative * Bvec;
        //PrintData(val_);

        /*
        auto val = std::complex<double>(0., 0.);
        for (int ialpha(1); ialpha < basisSize + 1; ialpha++) {
          for (int ibeta(1); ibeta < basisSize + 1; ibeta++) {
            for (int igamma(1); igamma < basisSize + 1; igamma++) {
              for (int idelta(1); idelta < basisSize + 1; idelta++) {
                val += eltC(CoeffTensor, ialpha, ibeta, igamma, idelta) * eltC(expHPositive, ialpha, ibeta) * eltC(expHNegative, igamma, idelta);
              }
            }
          }
        }
        */

        gf.at(it) = eltC(val_);

        if (params_.verbose >= 4) {
          ReportOnce("Calculating G(tau) Imaginary time @ ", totalT, " \n");
          ReportOnce("Value:: ", -gf.at(it), "\n");
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 10) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_tau;
  };

  g_tau_t finiteT_solver_core::CalcGF(std::string const &label, finiteT_params_t const &params_) {
    //double beta = params_.beta;

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS ketGr = state, braLe = state;
      ketGr.position(site_B);
      braLe.position(site_B);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
      //truncate the excited states, typically it should have lower entanglement compared with the ground state
      ketGr.position(site_B, args);
      braLe.position(site_B, args);
      ReportOnce("initial ketGr bonds \n");
      if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
      ReportOnce("initial braLe bonds \n");
      if (world.rank() == 0) { (braLe.PrintImpM(3)); };

      HeffLe.ForgetContraction();
      HeffGr.ForgetContraction();

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);
      ReportOnce("--- norm(braLe)=", braLe.norm(), "\n");
      ReportOnce("--- norm(ketGr)=", ketGr.norm(), "\n");

      //if (std::abs(ketGr.norm()) < 1E-15 || std::abs(braLe.norm()) < 1E-15) {
      //Error("0-norm of ketGr or braLe, most likely because of Sz projection ... this is not implemented in fullSymm!!!");
      //}

      // index at which we take the thermal states stored in phitau
      int phitauIndx = phitau.size() - 1;
      // index of the Green's function entries
      int GfIndx = 0;

      double normGr = std::log(ketGr.normalizeLim());
      double normLe = std::log(braLe.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        auto braGr = phitau.at(phitauIndx).state;
        auto ketLe = phitau.at(phitauIndx).state;

        //Args args_positionBE("Cutoff", -1);
        auto ketGrAct = ketGr;
        auto braLeAct = braLe;

        ketGrAct.position(site_A);
        braLeAct.position(site_A);

        ketGrAct.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto valGr = (overlap(braGr, ketGrAct) * std::exp(normGr));

        braLeAct.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
        auto valLe = (overlap(braLeAct, ketLe) * std::exp(normLe));

        // at beta/2 average over greater and lesser
        if (GfIndx == tList.size() - 1) {
          gf.at(GfIndx) = 0.5 * (valGr + valLe);
        } else {
          gf.rbegin()[GfIndx] = valLe;
          gf.at(GfIndx)       = valGr;
        }

        return;
      };

      DoMeasure();

      ReportOnce("@CalcGF, using addBasis to expand the basis for initial ketGr...\n");
      addBasis(ketGr, HBasis, args);
      ReportOnce("@CalcGF, using addBasis to expand the basis for initial braLe...\n");
      addBasis(braLe, HBasis, args);
      // loop over times
      args.add("TevoMethod", "TDVP_2");
      double totalT = 0.0;
      for (int step(0); step < tList.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffGr.ForgetContraction();
        }
        /*
        if (step < params_.sampling.minTwoSiteStepGf) {
          HeffGr.ForgetContraction();
          double dt_small = 0.02;
          double t_now    = tList.at(step);
          while (abs(t_now - tList.at(step + 1)) > 1E-6) {
            if (params_.verbose >= 3) { ReportOnce("--- inner tdvp @T=", t_now, "\n"); }
            TDVP(ketGr, HeffGr, dt_small, args);
            t_now += dt_small;
            ReportOnce("ketGr bonds \n");
            if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          }
          HeffGr.ForgetContraction();
        } else {
          TDVP(ketGr, HeffGr, tList.at(step + 1) - tList.at(step), args);
        }
        */
        TDVP(ketGr, HeffGr, tList.at(step + 1) - tList.at(step), args);
        normGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")) - phitau.at(phitauIndx).normFactor);

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffLe.ForgetContraction();
        }
        /*
        if (step < params_.sampling.minTwoSiteStepGf) {
          HeffLe.ForgetContraction();
          double dt_small = 0.02;
          double t_now    = tList.at(step);
          while (abs(t_now - tList.at(step + 1)) > 1E-6) {
            if (params_.verbose >= 3) { ReportOnce("--- inner tdvp @T=", t_now, "\n"); }
            TDVP(braLe, HeffLe, dt_small, args);
            t_now += dt_small;
            ReportOnce("braLe bonds \n");
            if (world.rank() == 0) { (braLe.PrintImpM(3)); };
          }
          HeffLe.ForgetContraction();
        } else {
          TDVP(braLe, HeffLe, tList.at(step + 1) - tList.at(step), args);
        };
        */
        TDVP(braLe, HeffLe, tList.at(step + 1) - tList.at(step), args);
        normLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")) - phitau.at(phitauIndx).normFactor);

        phitauIndx--;
        GfIndx++;

        DoMeasure();
        totalT = tList.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
          ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
          ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_tau;
  };

  std::pair<double, ForkTPS> finiteT_solver_core::pickState(double const &dt_, double const &time_, std::vector<ImagTimeState> phiList_) {
    std::vector<double> tList_;
    int it = 0;
    for (auto const &ele : phiList_) {
      tList_.push_back(it * dt_);
      it += 1;
    }

    if (tList_.size() != phiList_.size()) { Error("@pickState, tList_.size() != phiList_size()"); }
    if (time_ > tList_.back()) { Error("@pickState, time_ larger than tList_.back()"); }

    //find time position
    int pos_ = 0;
    for (int it(0); it < tList_.size(); it++) {
      if (abs(tList_.at(it) - time_) < dt_ / 3.0) { pos_ = it; }
    }
    if (abs(tList_.at(pos_) - time_) > dt_ / 3.0) { Error("@pickState, wrong pos_"); }
    //accumulate the norm
    double normAccu_ = 0.0;
    for (int it(tList_.size() - 1); it != pos_; it--) { normAccu_ -= phiList_.at(it).normFactor; }
    return std::make_pair(normAccu_, phiList_.at(pos_).state);
  }

  g_tau_t finiteT_solver_core::CalcGFShifted(std::string const &label, finiteT_params_t const &params_, int const &shiftedSteps_) {
    //double beta = params_.beta;
    //construct a new time grid which is much more sparse compared to the even grid
    ReportOnce("\n ------ debug, @CalcGFShifted", "\n");
    double originCutoff = args.getReal("Cutoff", -1.0);
    args.add("Cutoff", -1);
    std::vector<double> tListGf;
    std::vector<double> TimeGridGf;
    tListGf.push_back(0.0);
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 1.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 3.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 15.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + 2 * params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && abs(tListGf.back() - std::min(params_.beta / 2.0, 50.0)) > params_.tevo.dt / 2.0) {
      tListGf.push_back(tListGf.back() + 5 * params_.tevo.dt);
    }
    while ((tListGf.back() < params_.beta / 2.0) && (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0)) {
      tListGf.push_back(tListGf.back() + 10 * params_.tevo.dt);
    }

    while (tListGf.back() > (params_.beta / 2.0 - 1.0)) { tListGf.pop_back(); }
    while (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + params_.tevo.dt); }

    ReportOnce("\n ------ debug, @CalcGFShifted, tListGf", tListGf, "\n");

    int evoSteps_ = tListGf.size() - 1;
    TimeGridGf.resize(evoSteps_ * 2 + 1);
    for (int idx(0); idx < evoSteps_; idx++) {
      TimeGridGf.at(idx)       = tListGf.at(idx);
      TimeGridGf.rbegin()[idx] = params_.beta - tListGf.at(idx);
    }
    TimeGridGf.at(evoSteps_) = tListGf.at(evoSteps_);

    if (params_.beta <= 8.0) {
      tListGf    = tListLin;
      TimeGridGf = TimeGrid;
    }

    ReportOnce("\n ------ debug, @CalcGFShifted, tListGf", tListGf, "\n");

    //for (auto ele : TimeGridGf) { ReportOnce("--- @TimeGridGf ::", ele, "\n"); }
    if (abs(tListGf.back() - params_.beta / 2.0) > 1E-3) {
      Error("---@CalcGfShifted, tListGf.back() != beta/2, inproper time grid !\n");
      PRINT(tListGf);
    }

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGridGf.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    // make shiftedSteps_ forard steps before calculate the Green's function estimator
    // Greater:
    // <i|  e^{-\beta/2}  e^{-shifted * H} e^{\tau H} c e^{-\tau H}   c^d  e^{shifted * H}  * e^{-\beta/2} |i>
    // lesser:
    // <i|  e^{-\beta/2}  e^{shifted * H}  c^d e^{ - \tau H}  c  e^{\tau H}  e^{-shifted * H} e^{-\beta/2} |i>
    if (shiftedSteps_ >= phitau.size() - 1) { throw ITError("@CalcGFShifted, back ward time larger than \beta/2"); }

    double norm_b = 0.0;
    for (int step(0); step < shiftedSteps_; step++) { norm_b -= phitau.at(phitau.size() - 1 - step).normFactor; }
    ForkTPS state_b = phitau.at(phitau.size() - 1 - shiftedSteps_).state;
    HeffState.ForgetContraction();
    args.add("TevoMethod", "TDVPFullSS");
    ReportOnce("---@CalcGFShifted, forward time evolve state ", shiftedSteps_, " steps... \n");
    for (int step(0); step < shiftedSteps_; step++) {
      TDVP(state, HeffState, params_.tevo.dt, args);
      auto norm = std::log(state.normalizeLim()) + std::log(args.getReal("totalNorm"));
      phitau.push_back({state, norm});
      norm_b += norm;
    }
    ReportOnce("---@CalcGFShifted, forward time evolve state ", shiftedSteps_, " steps...DONE \n");
    ReportOnce("---@CalcGFShifted, with norm_b = ", std::exp(norm_b), "\n");
    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) {
        ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid, with shifted steps ", shiftedSteps_, "\n");
      }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS ketGr = state_b, braLe = state_b;
      ketGr.position(site_B, args);
      braLe.position(site_B, args);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
      //truncate the excited states, typically it should have lower entanglement compared with the ground state

      auto args_check = args;
      args_check.add("Cutoff", -1.0);
      ketGr.position(site_B, args_check);
      braLe.position(site_B, args_check);

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGridGf.size(), 0.);
      ReportOnce("--- norm(braLe)=", braLe.norm(), "\n");
      ReportOnce("--- norm(ketGr)=", ketGr.norm(), "\n");

      //if (std::abs(ketGr.norm()) < 1E-15 || std::abs(braLe.norm()) < 1E-15) {
      //Error("0-norm of ketGr or braLe, most likely because of Sz projection ... this is not implemented in fullSymm!!!");
      //}

      // index at which we take the thermal states stored in phitau
      int phitauIndx = phitau.size() - 1;
      // index of the Green's function entries
      int GfIndx = 0;

      double normGr = std::log(ketGr.normalizeLim());
      double normLe = std::log(braLe.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        auto braGr = phitau.at(phitauIndx).state;
        auto ketLe = phitau.at(phitauIndx).state;

        //Args args_positionBE("Cutoff", -1);
        auto ketGrAct = ketGr;
        auto braLeAct = braLe;

        ketGrAct.position(site_A, args);
        braLeAct.position(site_A, args);

        ketGrAct.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto valGr = (overlap(braGr, ketGrAct) * std::exp(normGr) * std::exp(norm_b));

        braLeAct.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
        auto valLe = (overlap(braLeAct, ketLe) * std::exp(normLe) * std::exp(norm_b));

        // at beta/2 average over greater and lesser
        if (GfIndx == tListGf.size() - 1) {
          gf.at(GfIndx) = 0.5 * (valGr + valLe);
        } else {
          gf.rbegin()[GfIndx] = valLe;
          gf.at(GfIndx)       = valGr;
        }

        return;
      };

      DoMeasure();
      if (params_.verbose >= 2) {
        ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
        ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
        ReportOnce("normGr Value::", normGr, "\n");
        ReportOnce("normLe Value::", normLe, "\n");
      }

      //basis expansion
      /*
      auto HbasisGf = taylorFTPO(params_, b, e0, tListGf.at(1) - tListGf.at(0));
      addBasis(ketGr, HbasisGf, args);
      addBasis(braLe, HbasisGf, args);
      ketGr.position(site_B, args_check);
      braLe.position(site_B, args_check);
      */

      // loop over times
      HeffGr.ForgetContraction();
      HeffLe.ForgetContraction();
      ReportOnce("initial ketGr bonds \n");
      if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
      ReportOnce("initial braLe bonds \n");
      if (world.rank() == 0) { (braLe.PrintImpM(3)); };

      args.add("TevoMethod", "TDVP_2");
      args.add("CutOff", originCutoff);
      double totalT = 0.0;
      for (int step(0); step < tListGf.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        std::string singleMethod = (totalT >= params_.sampling.minTwoSiteTimeGf) ? "TDVPFullSS" : "TDVP";
        //auto singleMethod = "TDVPFullSS";
        if (args.getString("TevoMethod") != singleMethod && maxI_ == params_.tevo.approx.maxm_i) {
          if (params_.verbose >= 1) { ReportOnce("--- Greater::change to ", singleMethod, " @", totalT, " \n"); };
          args.add("TevoMethod", singleMethod);
          HeffGr.ForgetContraction();
          HeffLe.ForgetContraction();

          if (singleMethod == "TDVP") {
            args.add("CutOff", originCutoff);
          } else if (singleMethod == "TDVPFullSS") {
            args.add("CutOff", -1.0);
          }
        }
        //accumulated norm factor
        int multiFactor_  = round((tListGf.at(step + 1) - tListGf.at(step)) / params_.tevo.dt);
        double multiNorm_ = 0.0;
        for (int idx(0); idx < multiFactor_; idx++) { multiNorm_ += phitau.at(phitauIndx - idx).normFactor; }

        /*
        if (params_.basisExpansion.expand_critical) {
          //std::vector<double> criticalTime;
          //criticalTime.push_back(params_.beta / 6.);
          //criticalTime.push_back(params_.beta / 3.);
          for (auto tcritical : params_.basisExpansion.critical_time) {
            if (tListGf.at(step) <= tcritical && tListGf.at(step + 1) >= tcritical) {
              if (params_.basisExpansion.BEMethod == "ApplyH") {
                HBasis = H;
              } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
                double time_step_ = std::min(0.2, tListGf.at(step + 1) - tListGf.at(step));
                HBasis            = taylorFTPO(params_, b, e0, time_step_);
              }
              addBasis(ketGr, HBasis, args);
              HeffGr.ForgetContraction();
              if (params_.verbose >= 1) { ReportOnce("@CalcGfShifted, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
            }
          }
        }
        */

        TDVP(ketGr, HeffGr, tListGf.at(step + 1) - tListGf.at(step), args);
        normGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (args.getString("TevoMethod") != singleMethod && maxI_ == params_.tevo.approx.maxm_i) {
          if (params_.verbose >= 1) { ReportOnce("--- Lesser::change to ", singleMethod, "@", totalT, " \n"); };
          args.add("TevoMethod", singleMethod);

          HeffGr.ForgetContraction();
          HeffLe.ForgetContraction();

          if (singleMethod == "TDVP") {
            args.add("CutOff", originCutoff);
          } else if (singleMethod == "TDVPFullSS") {
            args.add("CutOff", -1.0);
          }
        }
        /*
        if (params_.basisExpansion.expand_critical) {
          //std::vector<double> criticalTime;
          //criticalTime.push_back(params_.beta / 6.);
          //criticalTime.push_back(params_.beta / 3.);
          for (auto tcritical : params_.basisExpansion.critical_time) {
            if (tListGf.at(step) <= tcritical && tListGf.at(step + 1) >= tcritical) {
              if (params_.basisExpansion.BEMethod == "ApplyH") {
                HBasis = H;
              } else if (params_.basisExpansion.BEMethod == "ApplyExp") {
                double time_step_ = std::min(0.2, tListGf.at(step + 1) - tListGf.at(step));
                HBasis            = taylorFTPO(params_, b, e0, time_step_);
              }
              addBasis(braLe, HBasis, args);
              HeffLe.ForgetContraction();
              if (params_.verbose >= 1) { ReportOnce("@CalcGfShifted, using addBasis to expand the basis...DONE! @T::", totalT, "\n"); }
            }
          }
        }
        */
        TDVP(braLe, HeffLe, tListGf.at(step + 1) - tListGf.at(step), args);
        normLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        phitauIndx -= multiFactor_;
        GfIndx++;

        DoMeasure();
        totalT = tListGf.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", tListGf.at(step + 1) - tListGf.at(step), ", multiFactor=", multiFactor_, ") \n");
          ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
          ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
          ReportOnce("normGr Value::", normGr, "\n");
          ReportOnce("normLe Value::", normLe, "\n");

          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGridGf.size(); it++) { ReportOnce("@T=", TimeGridGf.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    TimeGrid = TimeGridGf;

    args.add("Cutoff", originCutoff);
    return g_tau;
  };

  g_tau_t finiteT_solver_core::CalcGFShiftedCombined(std::string const &label, finiteT_params_t const &params_, double const &shiftedTime_) {
    //double beta = params_.beta;
    //construct a new time grid which is much more sparse compared to the even grid
    std::vector<double> tListGf;
    std::vector<double> TimeGridGf;
    tListGf.push_back(0.0);
    while (abs(tListGf.back() - 1.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + params_.tevo.dt); }
    while (abs(tListGf.back() - 5.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + 2 * params_.tevo.dt); }
    while (abs(tListGf.back() - 25.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + 5 * params_.tevo.dt); }
    while (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + 5 * params_.tevo.dt); }
    while (tListGf.back() > (params_.beta / 2.0 - 1.0)) { tListGf.pop_back(); }
    while (abs(tListGf.back() - params_.beta / 2.0) > params_.tevo.dt / 2.0) { tListGf.push_back(tListGf.back() + params_.tevo.dt); }

    int evoSteps_ = tListGf.size() - 1;
    TimeGridGf.resize(evoSteps_ * 2 + 1);
    for (int idx(0); idx < evoSteps_; idx++) {
      TimeGridGf.at(idx)       = tListGf.at(idx);
      TimeGridGf.rbegin()[idx] = params_.beta - tListGf.at(idx);
    }
    TimeGridGf.at(evoSteps_) = tListGf.at(evoSteps_);

    if (params_.beta <= 8.0) {
      tListGf    = tListLin;
      TimeGridGf = TimeGrid;
    }
    //for (auto ele : TimeGridGf) { ReportOnce("--- @TimeGridGf ::", ele, "\n"); }
    if (abs(tListGf.back() - params_.beta / 2.0) > 1E-3) { Error("---@CalcGfShifted, tListGf.back() != beta/2, inproper time grid !"); }

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGridGf.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    // make shiftedSteps_ forard steps before calculate the Green's function estimator
    // Greater:
    // <i|  e^{-\beta/2}  e^{-shifted * H} e^{\tau H} c e^{-\tau H}   c^d  e^{shifted * H}  * e^{-\beta/2} |i>
    // lesser:
    // <i|  e^{-\beta/2}  e^{shifted * H}  c^d e^{ - \tau H}  c  e^{\tau H}  e^{-shifted * H} e^{-\beta/2} |i>
    if (shiftedTime_ >= params_.beta / 2.0) { throw ITError("@CalcGFShifted, back ward time larger than \beta/2"); }

    double norm_f = 0.0, norm_b = 0.0;

    ReportOnce("---@CalcGFShiftedCombined, forward time evolve state ", shiftedTime_, " ... \n");
    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) {
        ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid, with shifted steps ", shiftedTime_, "\n");
      }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS ketGr = state, braLe = state;
      ketGr.position(site_B);
      braLe.position(site_B);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
      //truncate the excited states, typically it should have lower entanglement compared with the ground state
      ketGr.position(site_B, args);
      braLe.position(site_B, args);
      ReportOnce("initial ketGr bonds \n");
      if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
      ReportOnce("initial braLe bonds \n");
      if (world.rank() == 0) { (braLe.PrintImpM(3)); };

      HeffLe.ForgetContraction();
      HeffGr.ForgetContraction();

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGridGf.size(), 0.);
      ReportOnce("--- norm(braLe)=", braLe.norm(), "\n");
      ReportOnce("--- norm(ketGr)=", ketGr.norm(), "\n");

      //if (std::abs(ketGr.norm()) < 1E-15 || std::abs(braLe.norm()) < 1E-15) {
      //Error("0-norm of ketGr or braLe, most likely because of Sz projection ... this is not implemented in fullSymm!!!");
      //}

      // index at which we take the thermal states stored in phitau
      int phitauIndx = phitau.size() - 1;
      // index of the Green's function entries
      int GfIndx = 0;

      double normGr = std::log(ketGr.normalizeLim());
      double normLe = std::log(braLe.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        auto braGr = phitau.at(phitauIndx).state;
        auto ketLe = phitau.at(phitauIndx).state;

        //Args args_positionBE("Cutoff", -1);
        auto ketGrAct = ketGr;
        auto braLeAct = braLe;

        ketGrAct.position(site_A);
        braLeAct.position(site_A);

        ketGrAct.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto valGr = (overlap(braGr, ketGrAct) * std::exp(normGr) * std::exp(norm_b));

        braLeAct.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
        auto valLe = (overlap(braLeAct, ketLe) * std::exp(normLe) * std::exp(norm_b));

        // at beta/2 average over greater and lesser
        if (GfIndx == tListGf.size() - 1) {
          gf.at(GfIndx) = 0.5 * (valGr + valLe);
        } else {
          gf.rbegin()[GfIndx] = valLe;
          gf.at(GfIndx)       = valGr;
        }

        return;
      };

      DoMeasure();

      // loop over times
      args.add("TevoMethod", "TDVP_2");
      double totalT = 0.0;
      for (int step(0); step < tListGf.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (totalT >= params_.sampling.minTwoSiteTimeGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffGr.ForgetContraction();
        }
        //accumulated norm factor
        int multiFactor_  = round((tListGf.at(step + 1) - tListGf.at(step)) / params_.tevo.dt);
        double multiNorm_ = 0.0;
        for (int idx(0); idx < multiFactor_; idx++) { multiNorm_ += phitau.at(phitauIndx - idx).normFactor; }

        TDVP(ketGr, HeffGr, tListGf.at(step + 1) - tListGf.at(step), args);
        normGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (totalT >= params_.sampling.minTwoSiteTimeGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffLe.ForgetContraction();
        }

        TDVP(braLe, HeffLe, tListGf.at(step + 1) - tListGf.at(step), args);
        normLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")) - multiNorm_);

        phitauIndx -= multiFactor_;
        GfIndx++;

        DoMeasure();
        totalT = tListGf.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", tListGf.at(step + 1) - tListGf.at(step), ", multiFactor=", multiFactor_, ") \n");
          ReportOnce("Greater Value:: ", -gf.at(GfIndx), "\n");
          ReportOnce("Leasser Value:: ", -gf.rbegin()[GfIndx], "\n");
          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGridGf.size(); it++) { ReportOnce("@T=", TimeGridGf.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    TimeGrid = TimeGridGf;
    return g_tau;
  };

  g_tau_t finiteT_solver_core::CalcGFWholeImagTimeGrid(std::string const &label, finiteT_params_t const &params_) {
    //double beta = params_.beta;

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    auto HeffKet = ForkLocalOp(H);
    auto HeffBra = ForkLocalOp(H);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS ket = state, bra = state;
      ket.position(site_B);
      ket.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      HeffKet.ForgetContraction();
      HeffBra.ForgetContraction();

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);
      ReportOnce("--- norm(bra)=", bra.norm(), "\n");
      ReportOnce("--- norm(ket)=", ket.norm(), "\n");

      //if (std::abs(ketGr.norm()) < 1E-15 || std::abs(braLe.norm()) < 1E-15) {
      //Error("0-norm of ketGr or braLe, most likely because of Sz projection ... this is not implemented in fullSymm!!!");
      //}

      // index of the Green's function entries
      int GfIndx = 0;

      double normKet = std::log(ket.normalizeLim());
      double normBra = std::log(bra.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        //Args args_positionBE("Cutoff", -1);
        auto ketAct = ket;

        ketAct.position(site_A);

        ketAct.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto val      = (overlap(bra, ketAct) * std::exp(normBra + normKet));
        gf.at(GfIndx) = val;
        ReportOnce("--- normKet::", normKet, ", normBra::", normBra, ", total::", normKet + normBra, "\n");

        return;
      };

      DoMeasure();

      // loop over times
      args.add("TevoMethod", "TDVP_2");
      double totalT = 0.0;
      for (int step(0); step < TimeGrid.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ket.NArms(); ++iArm) {
          auto ind = commonIndex(ket.A(ket.ImpSite(iArm)), ket.A(ket.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffKet.ForgetContraction();
        }

        TDVP(ket, HeffKet, (TimeGrid.at(step + 1) - TimeGrid.at(step)), args);
        normKet += (std::log(ket.normalizeLim()) + std::log(args.getReal("totalNorm")));

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < bra.NArms(); ++iArm) {
          auto ind = commonIndex(bra.A(bra.ImpSite(iArm)), bra.A(bra.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }

        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffBra.ForgetContraction();
        }

        TDVP(bra, HeffBra, -(TimeGrid.at(step + 1) - TimeGrid.at(step)), args);
        normBra += (std::log(bra.normalizeLim()) + std::log(args.getReal("totalNorm")));

        GfIndx++;

        DoMeasure();
        totalT = TimeGrid.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", TimeGrid.at(step + 1) - TimeGrid.at(step), ") \n");
          ReportOnce("Value:: ", -gf.at(GfIndx), "\n");
          ReportOnce("ket bonds \n");
          if (world.rank() == 0) { (ket.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("bra bonds \n");
          if (world.rank() == 0) { (bra.PrintImpM(3)); };
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_A, "(tau) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_tau;
  };

  g_t_t finiteT_solver_core::CalcGFReal(std::string const &label, finiteT_params_t const &params_) {
    //double beta = params_.beta;

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<retime> meshReT{0., TimeGrid.back(), params_.tevo.time_steps + 1};
    g_t_t g_t(meshReT, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());
    std::vector<int> bondGrowthGt;
    for (auto comp : params_.calc_me) {
      auto arm_A  = TriqsIndxToArm(comp[0]);
      auto arm_B  = TriqsIndxToArm(comp[1]);
      auto site_A = sites.ImpSite(arm_A);
      auto site_B = sites.ImpSite(arm_B);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">, on even grid\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_A, ", and arm ", arm_B, "\n");
        ReportOnce("acting on site ", site_A, " and site ", site_B, "\n");
      }

      ForkTPS timeState = state, ketGr = state, braLe = state;
      ketGr.position(site_B);
      braLe.position(site_B);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_B), site_B, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_B), site_B, true);
      HeffLe.ForgetContraction();
      HeffGr.ForgetContraction();
      HeffState.ForgetContraction();

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);

      // index of the Green's function entries
      int GfIndx = 0;
      // Measurement function
      auto DoMeasure = [&]() {
        auto braGr = timeState;
        auto ketLe = timeState;

        braGr.position(site_A);
        ketLe.position(site_A);

        braGr.ApplySingleSiteOp(sites.op("CkD", site_A), site_A, true);
        auto valGr = (overlap(braGr, ketGr));

        ketLe.ApplySingleSiteOp(sites.op("Ck", site_A), site_A, true);
        auto valLe = (overlap(braLe, ketLe));

        gf.at(GfIndx) = -Complex_i * (valGr + valLe);
        ReportOnce("--- valGr =", valGr, "\n");
        ReportOnce("--- valLe =", valLe, "\n");
        ReportOnce("--- Retarded =", gf.at(GfIndx), "\n");

        return;
      };

      DoMeasure();

      // loop over times
      args.add("TevoMethod", "TDVP_2");
      double totalT = 0.0;
      for (int step(0); step < TimeGrid.size() - 1; step++) {
        //evolve the Greater one
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffGr.ForgetContraction();
        }
        TDVP(ketGr, HeffGr, Complex_i * (TimeGrid.at(step + 1) - TimeGrid.at(step)), args);

        //evolve the Lesser one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffLe.ForgetContraction();
        }
        TDVP(braLe, HeffLe, Complex_i * (TimeGrid.at(step + 1) - TimeGrid.at(step)), args);

        //evolve the metts one
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < timeState.NArms(); ++iArm) {
          auto ind = commonIndex(timeState.A(timeState.ImpSite(iArm)), timeState.A(timeState.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffState.ForgetContraction();
        }
        TDVP(timeState, HeffState, Complex_i * (TimeGrid.at(step + 1) - TimeGrid.at(step)), args);

        GfIndx++;

        DoMeasure();
        totalT = TimeGrid.at(step + 1);
        if (params_.verbose >= 2) {
          ReportOnce(args.getString("TevoMethod") + ":: Calculating G(t) real time @ ", totalT,
                     "(with dt=", TimeGrid.at(step + 1) - TimeGrid.at(step), ") \n");
          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          //ReportOnce("\n\n");
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
          ReportOnce("\n");
          ReportOnce("timeState bonds \n");
          if (world.rank() == 0) { (timeState.PrintImpM(3)); };
          ReportOnce("\n");
        }

        bondGrowthGt.push_back(std::max(std::max(ketGr.MaxM(), braLe.MaxM()), timeState.MaxM()));
      }

      int it            = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto t : meshReT) {
        g_t[blockNameIdx][t](comp[0].second, comp[1].second) = gf[it];
        it += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("-i <c_", site_A, "(t) c^+_", site_B, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_t          = g_t;
    statesPool[label].bondGrowthGt = bondGrowthGt;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_t;
  };

  g_tau_t finiteT_solver_core::CalcGFExponential(std::string const &label, finiteT_params_t const &params_) {
    //double beta = params_.beta;
    auto HeffBraGr = ForkLocalOp(H);
    auto HeffKetGr = ForkLocalOp(H);
    auto HeffBraLe = ForkLocalOp(H);
    auto HeffKetLe = ForkLocalOp(H);

    //the frequency mesh and green's function
    gf_mesh<imfreq> meshImFreq(params_.beta, Fermion, params_.n_iw);
    g_iw_t g_iw(meshImFreq, params_.gf_struct);

    //a containor for G(tau), although, the time grid might be different
    gf_mesh<imtime> meshImTau(params_.beta, Fermion, TimeGrid.size());
    g_tau_t g_tau(meshImTau, params_.gf_struct);

    //initialize the raw data containor
    //statesPool[label].GfRaw.resize(params_.calc_me.size(), TimeGrid.size());

    for (auto comp : params_.calc_me) {
      auto arm_C   = TriqsIndxToArm(comp[0]);
      auto arm_CD  = TriqsIndxToArm(comp[1]);
      auto site_C  = sites.ImpSite(arm_C);
      auto site_CD = sites.ImpSite(arm_CD);
      if (params_.verbose >= 1) { ReportOnce("Calculating <c_", comp[0], "c^+_", comp[1], ">\n"); }
      if (params_.verbose >= 2) {
        ReportOnce("acting on arm ", arm_C, ", and arm ", arm_CD, "\n");
        ReportOnce("acting on site ", site_C, " and site ", site_CD, "\n");
      }

      ForkTPS ketGr = state, braGr = state, ketLe = state, braLe = state;
      ketGr.position(site_CD);
      braLe.position(site_CD);
      ketGr.ApplySingleSiteOp(sites.op("CkD", site_CD), site_CD, true);
      braLe.ApplySingleSiteOp(sites.op("Ck", site_CD), site_CD, true);

      HeffKetGr.ForgetContraction();
      HeffBraGr.ForgetContraction();
      HeffKetLe.ForgetContraction();
      HeffBraLe.ForgetContraction();

      //containor for this component Green's function
      std::vector<std::complex<double>> gf;
      gf.resize(TimeGrid.size(), 0.);

      //if (std::abs(ketGr.norm()) < 1E-15 || std::abs(braLe.norm()) < 1E-15) {
      //Error("0-norm of ketGr or braLe, most likely because of Sz projection ... this is not implemented in fullSymm!!!");
      //}

      // index at which we take the thermal states stored in phitau
      //int phitauIndx = phitau.size() - 1;
      // index of the Green's function entries
      int GfIndx = 0;

      double normKetGr = std::log(ketGr.normalizeLim());
      double normBraGr = std::log(braGr.normalizeLim());
      double normKetLe = std::log(ketLe.normalizeLim());
      double normBraLe = std::log(braLe.normalizeLim());

      // Measurement function
      auto DoMeasure = [&]() {
        auto braGrC = braGr;
        //Args args_positionBE("Cutoff", -1);
        braGrC.position(site_C);
        braGrC.ApplySingleSiteOp(sites.op("CkD", site_C), site_C, true);

        auto ketLeC = ketLe;
        //Args args_positionBE("Cutoff", -1);
        ketLeC.position(site_C);
        ketLeC.ApplySingleSiteOp(sites.op("Ck", site_C), site_C, true);
        if (params_.verbose >= 3) {
          ReportOnce("--- norm(ketGr)::", normKetGr, "\n");
          ReportOnce("--- norm(braGr)::", normBraGr, "\n");
          ReportOnce("--- norm(ketLe)::", normKetLe, "\n");
          ReportOnce("--- norm(braLe)::", normBraLe, "\n");
          ReportOnce("--- factor Gr::", std::exp(normKetGr + normBraGr), "\n");
          ReportOnce("--- factor Le::", std::exp(normKetLe + normBraLe), "\n");
        }

        auto valGr = (overlap(braGrC, ketGr) * std::exp(normKetGr + normBraGr));
        auto valLe = (overlap(braLe, ketLeC) * std::exp(normKetLe + normBraLe));
        if (GfIndx == tList.size() - 1) {
          gf.at(GfIndx) = 0.5 * (valGr + valLe);
        } else {
          gf.at(GfIndx)       = valGr;
          gf.rbegin()[GfIndx] = valLe;
        }

        return;
      };

      DoMeasure();

      // loop over times, we have to evolve all states on the exponetial grid
      args.add("TevoMethod", "TDVP_2");
      double totalT = 0.0;
      for (int step(0); step < tList.size() - 1; step++) {
        //evolve the Greater one ket --> -tau
        long maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketGr.NArms(); ++iArm) {
          auto ind = commonIndex(ketGr.A(ketGr.ImpSite(iArm)), ketGr.A(ketGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffKetGr.ForgetContraction();
        }
        TDVP(ketGr, HeffKetGr, tList.at(step + 1) - tList.at(step), args);
        normKetGr += (std::log(ketGr.normalizeLim()) + std::log(args.getReal("totalNorm")));

        //evolve the Greater one bra --> tau
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braGr.NArms(); ++iArm) {
          auto ind = commonIndex(braGr.A(braGr.ImpSite(iArm)), braGr.A(braGr.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Greater::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffBraGr.ForgetContraction();
        }
        TDVP(braGr, HeffBraGr, -(tList.at(step + 1) - tList.at(step)), args);
        normBraGr += (std::log(braGr.normalizeLim()) + std::log(args.getReal("totalNorm")));

        //evolve the Lesser one ket --> tau
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < ketLe.NArms(); ++iArm) {
          auto ind = commonIndex(ketLe.A(ketLe.ImpSite(iArm)), ketLe.A(ketLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffKetLe.ForgetContraction();
        }

        TDVP(ketLe, HeffKetLe, -(tList.at(step + 1) - tList.at(step)), args);
        normKetLe += (std::log(ketLe.normalizeLim()) + std::log(args.getReal("totalNorm")));

        //evolve the Lesser one bra --> -tau
        maxI_ = 0, minI_ = 1000000;
        for (int iArm = 1; iArm < braLe.NArms(); ++iArm) {
          auto ind = commonIndex(braLe.A(braLe.ImpSite(iArm)), braLe.A(braLe.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
          minI_    = std::min(minI_, dim(ind));
        }
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 2)
        //&& minI_ >= int(params_.tevo.approx.maxm_i / 5)
        if (maxI_ >= params_.tevo.approx.maxm_i && step >= params_.sampling.minTwoSiteStepGf && args.getString("TevoMethod") != "TDVP") {
          if (params_.verbose >= 2) { ReportOnce("--- Lesser::change to single site TDVP @", totalT, " \n"); };
          args.add("TevoMethod", "TDVP");
          HeffBraLe.ForgetContraction();
        }

        TDVP(braLe, HeffBraLe, (tList.at(step + 1) - tList.at(step)), args);
        normBraLe += (std::log(braLe.normalizeLim()) + std::log(args.getReal("totalNorm")));

        GfIndx++;

        DoMeasure();
        totalT = tList.at(step + 1);
        if (params_.verbose >= 3) {
          ReportOnce(args.getString("TevoMethod") + "::Calculating G(tau) Imaginary time @ ", totalT,
                     "(with dt=", tList.at(step + 1) - tList.at(step), ") \n");
          ReportOnce("Value Gr:: ", -gf.at(GfIndx), "\n");
          ReportOnce("Value Le:: ", -gf.rbegin()[GfIndx], "\n");
          ReportOnce("ketGr bonds \n");
          if (world.rank() == 0) { (ketGr.PrintImpM(3)); };
          ReportOnce("braGr bonds \n");
          if (world.rank() == 0) { (braGr.PrintImpM(3)); };
          ReportOnce("ketLe bonds \n");
          if (world.rank() == 0) { (ketLe.PrintImpM(3)); };
          ReportOnce("braLe bonds \n");
          if (world.rank() == 0) { (braLe.PrintImpM(3)); };
          //ReportOnce("\n\n");
        }
      }

      int itau          = 0;
      auto blockNameIdx = BlockNameIndx(comp[0], params_);
      for (auto tau : meshImTau) {
        g_tau[blockNameIdx][tau](comp[0].second, comp[1].second) = -1. * gf[itau];
        itau += 1;
      }

      if (params_.verbose >= 1) {
        ReportOnce("<c_", site_C, "(tau) c^+_", site_CD, "> has been calculated\n");
        if (params_.verbose >= 4) {
          if (world.rank() == 0) {
            for (int it(0); it < TimeGrid.size(); it++) { ReportOnce("@T=", TimeGrid.at(it), ", gf=", gf.at(it), "\n"); }
          }
        };
      }
    } //end loop over components
    statesPool[label].g_tau = g_tau;
    if (params_.verbose >= 1) { ReportOnce(" Block Green's function has been calculated \n"); };
    return g_tau;
  };

  void finiteT_solver_core::testProject(finiteT_solve_params_t const &solve_params_) {
    ReportOnce("----- test projection function ------\n");
    finiteT_params_t params(constr_params, solve_params_);
    //@TODO :: reconstruct the hybridization function
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    E0Shift           = 0.0;
    std::string pType = "reverse";
    // 1  2  3  4
    // 5  6  7  8
    // 9 10 11 12
    // 13 14 15 16
    // 17 18 19 20
    // 21 22 23 24
    ReportOnce("--- tot sites ", b.N(), "\n");
    ReportOnce("--- tot arms ", b.NArms(), "\n");
    if (params.impPurified) {
      if (pType == "normal") {
        doubledBath = {2, 6, 10, 14, 18, 22, 3, 7, 11, 15, 19, 23};
      } else {
        doubledBath = {2, 6, 10, 14, 18, 22, 4, 8, 12, 16, 20, 24}; //{3, 7, 11, 15, 19, 23};}
      }
    } else {
      doubledBath = {};
    }
    auto sites_ =
       ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    InitState init_(sites_, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites_.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init_.set(sites_.ArmToSite(arm, k + 1), "Occ");
        }
      }
      if (params.impPurified) {
        init_.set(sites_.ImpSite(arm), "01");
      } else {
        init_.set(sites_.ImpSite(arm), "Occ");
      }
    }
    for (auto site : doubledBath) { init_.set(site, "01"); };

    auto psi_ = ForkTPS(init_, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi_, sites_, doubledBath);
    ReportOnce("--- initial occ.\n");
    psi_.PrintOccs();

    auto H_    = whichFTPO(params, sites_);
    auto Heff_ = ForkLocalOp(H_);

    args.add("TevoMethod", "TDVP_2");
    //addBasis(psi_, H_, args);
    //psi_.normalizeLim();

    double dtauTDVP = params.tevo.dt;
    auto stepsTotal = 25;
    double e_ac     = 0.0;
    double totT     = 0.0;
    sites           = sites_;
    int numS        = 30;
    std::vector<double> e_list(numS);
    for (int is = 1; is < numS + 1; is++) {
      //generate a metts
      ReportOnce("---- sample ", is, "\n");

      Heff_.ForgetContraction();
      totT = 0.0;

      addBasis(psi_, H_, args);
      for (auto i : range1(0, stepsTotal - 1)) {
        UNUSED_VAR(i);
        TDVP(psi_, Heff_, dtauTDVP, args);
        psi_.normalizeLim();
        totT += dtauTDVP;
        ReportOnce("@T=", totT, ", maxM=", psi_.MaxM(), "\n");
      };

      Heff_.ForgetContraction();
      psi_.position(1);
      Heff_.position(1, psi_);

      double energy = std::real(Heff_.ContractAll(psi_)) - E0Shift;
      e_ac += energy;
      e_list.at(is - 1) = energy / 6.0;
      ReportOnce("--- E0 = ", energy, " <E>/6.0=", e_ac / (6. * is), "\n");
      ReportOnce("--- ref :: ", -2.0856946216569208, "\n");
      psi_.PrintOccs();
      state = psi_;
      Project(params);
      psi_ = state;
    }

    auto arch = h5::file(pType + "25.h5", 'a');
    h5_write(arch, "e_list", e_list);
    arch.close();
    /*
    double energy_ac = 0.0, n1_ac = 0;
    std::complex<double> ov_old = 0.0, ov_new = 0.0;
    for (int is = 1; is < 5000; is++) {
      //ReportOnce("i=", i, "\n");
      state = psi_;
      sites = sites_;
      Project(params);
      auto phi = state;
      phi.ApplySingleSiteOp(sites_.op("N", 1), 1, false);
      //ReportOnce("appied\n");
      ov_new  = overlap(state, psi_);
      auto n1 = real(overlap(phi, psi_) / overlap(state, psi_));
      if (ov_new != ov_old) { ReportOnce(overlap(phi, psi_), ",  ", overlap(state, psi_), ", ", n1, "\n"); }
      ov_old = ov_new;

      n1_ac += n1;
      //ReportOnce("accumulated ", n1_ac, "\n");

      if (is % 10 == 0) { ReportOnce("--- ( ", occ.at(0), ")::", is, " samples, <n1>=", n1_ac / (1.0 * is), "\n"); }
    }
    */
  }

  void finiteT_solver_core::testsum(finiteT_solve_params_t const &solve_params_) {
    ReportOnce("----- test sum of ftps function ------\n");
    finiteT_params_t params(constr_params, solve_params_);
    //@TODO :: reconstruct the hybridization function
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    args.add("totalNorm", 1.0);
    E0Shift = 0.0;
    // 1  2  3  4
    // 5  6  7  8
    // 9 10 11 12
    // 13 14 15 16
    // 17 18 19 20
    // 21 22 23 24
    ReportOnce("--- tot sites ", b.N(), "\n");
    ReportOnce("--- tot arms ", b.NArms(), "\n");
    if (params.impPurified) { doubledBath = {2, 6, 10, 14, 18, 22, 3, 7, 11, 15, 19, 23}; }
    auto sites_ =
       ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    InitState init_1(sites_, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites_.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init_1.set(sites_.ArmToSite(arm, k + 1), "Occ");
        }
      }
      if (params.impPurified) {
        init_1.set(sites_.ImpSite(arm), "01");
      } else {
        init_1.set(sites_.ImpSite(arm), "Occ");
      }
    }
    for (auto site : doubledBath) { init_1.set(site, "01"); };

    auto psi_1 = ForkTPS(init_1, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi_1, sites_, doubledBath);
    auto psi_2 = psi_1;
    auto H_    = whichFTPO(params, sites_);

    psi_1 = exactApplyMPO(psi_1, H_, args);
    psi_1.normalize();

    psi_2 = exactApplyMPO(psi_1, H_, args);
    psi_2.normalize();

    ReportOnce("--- initial occ.\n");
    psi_1.PrintOccs();
    psi_2.PrintOccs();
    psi_1.position(1);
    psi_2.position(1);
    auto psi_sum = DirectSum(psi_1, psi_2);

    Args args_tmp;
    args_tmp.add("Orthog", false);
    auto energy_1    = (overlap(psi_1, exactApplyMPO(psi_1, H_, args_tmp)));
    auto energy_2    = (overlap(psi_2, exactApplyMPO(psi_2, H_, args_tmp)));
    auto energy_off1 = (overlap(psi_1, exactApplyMPO(psi_2, H_, args_tmp)));
    auto energy_off2 = (overlap(psi_2, exactApplyMPO(psi_1, H_, args_tmp)));

    auto energy_3 = (overlap(psi_sum, exactApplyMPO(psi_sum, H_, args_tmp)));

    ReportOnce("-- e1 = ", energy_1, "\n");
    ReportOnce("-- e2 = ", energy_2, "\n");
    ReportOnce("-- e1+e2 + 2 eoff = ", energy_1 + energy_2 + energy_off1 + energy_off2, "\n");
    ReportOnce("-- e3 = ", energy_3, "\n");

    psi_1.PrintImpM();
    psi_2.PrintImpM();
    psi_sum.PrintImpM();
  }

  void finiteT_solver_core::testKrylov(finiteT_solve_params_t const &solve_params_) {
    ReportOnce("----- test krylov time evolution function ------\n");
    finiteT_params_t params(constr_params, solve_params_);
    //@TODO :: reconstruct the hybridization function
    //set up args
    SetArgs(args, params.basisExpansion);
    SetArgs(args, params.tevo);
    args.add("TrackNorm", false);
    //    args.add("totalNorm", 1.0);
    ReportOnce("args::\n", args, "\n");
    E0Shift = 0.0;
    // 1  2  3  4
    // 5  6  7  8
    // 9 10 11 12
    // 13 14 15 16
    // 17 18 19 20
    // 21 22 23 24
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) { E0Shift += b.eps(ind, k); }
    }

    ReportOnce("--- tot sites ", b.N(), "\n");
    ReportOnce("--- tot arms ", b.NArms(), "\n");
    if (params.impPurified) { doubledBath = {2, 6, 10, 14, 18, 22, 3, 7, 11, 15, 19, 23}; }
    auto sites_ =
       ThermalForkSites(b.N(), b.NArms(), doubledBath, {"conserveN", true, "conserveSz", !b.isSpinOrbit(), "impPurified", params.impPurified});
    InitState init_(sites_, "Emp");
    //site with negative on-site energy will be occupied
    //while site with positive on-site energy will be empty
    for (auto arm : range1(sites_.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(b.NBath(ind))) {
        if (!std::count(doubledBath.begin(), doubledBath.end(), sites_.ArmToSite(arm, k + 1))) {
          if (b.eps(ind, k) < 0) init_.set(sites_.ArmToSite(arm, k + 1), "Occ");
        }
      }
      if (params.impPurified) {
        init_.set(sites_.ImpSite(arm), "01");
      } else {
        init_.set(sites_.ImpSite(arm), "Occ");
      }
    }
    for (auto site : doubledBath) { init_.set(site, "01"); };

    auto psi_ = ForkTPS(init_, sites_.NArms());
    //reset the tensor of the purified sites
    ResetPurifiedTensors(psi_, sites_, doubledBath);
    ReportOnce("--- initial occ.\n");
    psi_.PrintOccs();
    auto H_ = whichFTPO(params, sites_);
    //prepare the initial state
    Args args_applyH;
    args_applyH.add("Orthog", false);
    psi_ = exactApplyMPO(psi_, H_, args_applyH);
    psi_.normalize();
    psi_.PrintOccs();

    double t = 0.1;

    //krylov
    std::vector<ForkTPS> krylovSpace;
    krylovSpace.push_back(psi_);
    ITensor heff;
    auto evoInfo      = GlobalKrylovTimeEvo(heff, krylovSpace, H_, t, params);
    auto psi_t_krylov = evoInfo.second;

    //tdvp
    auto psi_t_tdvp = psi_;
    auto Heff_tdvp  = ForkLocalOp(H_);
    args.add("TevoMethod", "TDVP_2");
    TDVP(psi_t_tdvp, Heff_tdvp, t, args);

    ReportOnce(" overlap from krylov::", overlap(psi_, psi_t_krylov), "with norm ", psi_t_krylov.normalizeLim(), "\n");
    ReportOnce(" overlap from tdvp::", overlap(psi_, psi_t_tdvp), "with norm ", psi_t_tdvp.normalizeLim(), "\n");

    //psi_t_krylov.normalizeLim();
    //psi_t_tdvp.normalizeLim();
    psi_t_krylov.PrintOccs();
    psi_t_tdvp.PrintOccs();

    /*
    //glabal krylov time evolution
    int nKrylov = 10;
    double err  = 1E-3;
    Args args_applyH;
    args_applyH.add("Orthog", false);

    auto psi_new = psi_;
    std::vector<ForkTPS> krylov_space;
    krylov_space.push_back(psi_new);
    krylov_space.back().position(1);

    for (int ik = 1; ik < nKrylov; ik++) {
      psi_new = exactApplyMPO(krylov_space.back(), H_, args_applyH);
      psi_new.normalizeLim();
      psi_new.position(1);
      auto overlapOff  = overlap(krylov_space.back(), psi_new);
      ForkTPS psi_orth = krylov_space.back();
      psi_orth *= -overlapOff;
      psi_new = DirectSum(psi_new, psi_orth);
      psi_new.position(1);
      krylov_space.push_back(psi_new);
      ReportOnce("----  the ", ik, " th krylov vectors been generated with max bond dimension \n");
      psi_new.PrintImpM();
    }

    Index I(nKrylov, "i"), J(nKrylov, "j");
    ITensor Heff(I, J);
    for (int is(0); is < krylov_space.size(); is++) {
      auto dia_ = overlap(krylov_space.at(is), exactApplyMPO(krylov_space.at(is), H_, args_applyH));
      Heff.set(I = is + 1, J = is + 1, dia_);
    }
    PrintData(Heff);

    */
  }

}; // namespace forktps
