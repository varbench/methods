/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************************************/
#pragma once
#include "./types.hpp"

namespace forktps {

  /// The collection of all output containers in solver_core
  struct container_set {

    /// Greater single particle Greens functions in real time $G_{ij}^{>}(t) = e^{i E_0 t} \langle  c_i e^{-iHt} c_j^\dagger \rangle$
    std::optional<g_t_t> G_gr;
    /// Lesser single particle Greens functions in real time $G_{ij}^{<}(t) = e^{-i E_0 t} \langle  c_j^\dagger e^{iHt} c_i \rangle$
    std::optional<g_t_t> G_le;
    /// Retarded single particle Greens functions in real time $G_{ij}^{ret}(t) = -i \Theta(t) \left( G_{ij}^{>}(t) + G_{ij}^{<}(t) \right)$
    std::optional<g_t_t> G_ret;

    /// Greater Green's function $F_{ij}^{>}(t) = e^{i E_0 t} \langle  [H_{int}, c_i] e^{-iHt} c_j^\dagger \rangle$
    std::optional<g_t_t> F_gr;
    /// Lesser Green's function $F_{ij}^{<}(t) = e^{-i E_0 t} \langle  c_j^\dagger e^{iHt}  [H_{int}, c_i]  \rangle$
    std::optional<g_t_t> F_le;
    /// Retarded Green's function $F_{ij}^{ret}(t) = -i \Theta(t) \left( F_{ij}^{>}(t) + F_{ij}^{<}(t) \right)$. Calculate self energy using $\Sigma(\omega) = \frac{-F(\omega)}{G(\omega)}$
    std::optional<g_t_t> F_ret;

    // note density-density GFs do not follow block structure "up"-"dn", but are full matrices.
    /// Greater density Greens functions in real time $N_{ij}^{>}(t) = e^{i E_0 t} \langle  n_i e^{-iHt} n_j^\dagger \rangle$
    std::optional<n_t_t> N_t;

    /// Single particle Greens function in energy $G(\omega) = /int G^{ret} exp( i \omega t ) dt$
    std::optional<g_w_t> G_w;

    /// Greens function in energy $F(\omega) = /int F^{ret} exp( i \omega t ) dt$. Self energy is given by $\Sigma(\omega) = -\frac{F(\omega)}{G(\omega)}$.
    std::optional<g_w_t> F_w;

    /// Greens function in energy $F(\omega) = /int F^{ret} exp( i \omega t ) dt$. Self energy is given by $\Sigma(\omega) = -\frac{F(\omega)}{G(\omega)}$.
    std::optional<n_w_t> N_w;

    /// Self-energy $\Sigma(\omega)$
    std::optional<g_w_t> Sigma_w;

    /** Write container set to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param c:              container set to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, container_set const &c);

    /** Read container set from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param c:              container set to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, container_set &c);
  };

} // namespace forktps
