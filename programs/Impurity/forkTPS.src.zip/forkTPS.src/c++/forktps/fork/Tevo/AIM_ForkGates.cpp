#include "forktps/fork/Tevo/AIM_ForkGates.hpp"
#include "forktps/fork/typenames.hpp"
#include <itensor/global.h>
#include <itensor/itensor.h>
#include <tuple>
#include <utility>
#include <vector>

namespace forktps {

  template <typename T> std::vector<ForkGate> createAIMGates(const T dt, const bath &b, const hloc &e0, const AIM_ForkSites &sites) {

    if (b.isOffDiag()) Error("createAIMGates: Bath cannot be off-diagonal.");

    std::vector<ForkGate> gates(0);
    auto NArms = sites.NArms();

    // loop over all arms
    for (auto arm : range1(NArms)) {
      int NBath = sites.NBath(arm);

      auto bN = (arm % 2 == 1) ? b.blockNameUp() : b.blockNameDn();
      auto bI = (arm % 2 == 1) ? int((arm - 1) / 2) : int(arm / 2) - 1;

      triqs_indx I{bN, bI};

      {
        int indx = NBath;
        int i    = sites.ImpSite(arm);
        int j    = sites.ArmToSite(arm, indx);

        auto amp = b.V(I, indx - 1);

        // impurity is at site i
        ITensor HH = b.eps(I, indx - 1) * sites.op("Id", i) * sites.op("N", j);
        HH += e0(I) * sites.op("N", i) * sites.op("Id", j);
        HH += sites.op("CkD*p", i) * sites.op("Ck", j) * amp;
        HH += sites.op("Ck*p", i) * sites.op("CkD", j) * -std::conj(amp);

        //create gate
        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        //add swapgate
        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        g *= swap;
        gates.emplace_back(std::move(g));
      }

      for (int indx = NBath - 1; indx >= 1; indx--) {
        int i    = sites.ArmToSite(arm, indx + 1);
        int j    = sites.ArmToSite(arm, indx);
        auto amp = b.V(I, indx - 1);

        // impurity is at site i
        ITensor HH = b.eps(I, indx - 1) * sites.op("Id", i) * sites.op("N", j);
        HH += sites.op("CkD*p", i) * sites.op("Ck", j) * amp;
        HH += sites.op("Ck*p", i) * sites.op("CkD", j) * -std::conj(amp);

        ForkGate g(HH, i, j);
        if (indx != 1) {
          g.expGate(dt / 2, sites);
          ForkGate swap;
          swap.MakeSwap(i, j, sites);
          g *= swap;
        } else {
          g.expGate(dt, sites);
        } //no swap gate needed at laste gate and time evolution is with dt not dt/2
        gates.emplace_back(std::move(g));
      }

      for (int indx = 2; indx <= NBath - 1; indx++) {
        int i    = sites.ArmToSite(arm, indx + 1);
        int j    = sites.ArmToSite(arm, indx);
        auto amp = b.V(I, indx - 1);

        // impurity is at site i
        ITensor HH = b.eps(I, indx - 1) * sites.op("Id", i) * sites.op("N", j);
        HH += sites.op("CkD*p", i) * sites.op("Ck", j) * amp;
        HH += sites.op("Ck*p", i) * sites.op("CkD", j) * -std::conj(amp);

        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        swap *= g; //first swap then tevo!!

        gates.emplace_back(swap);
      }

      { //terms at Impurity site
        int indx = NBath;
        int i    = sites.ImpSite(arm);
        int j    = sites.ArmToSite(arm, indx);
        auto amp = b.V(I, indx - 1);

        // impurity is at site i
        ITensor HH = b.eps(I, indx - 1) * sites.op("Id", i) * sites.op("N", j);
        HH += e0(I) * sites.op("N", i) * sites.op("Id", j);
        HH += sites.op("CkD*p", i) * sites.op("Ck", j) * amp;
        HH += sites.op("Ck*p", i) * sites.op("CkD", j) * -std::conj(amp);

        //create gate
        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        //add swapgate
        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        swap *= g; //swap before tevo!!
        gates.emplace_back(std::move(swap));
      }
    }

    return gates;
  }

  // explicit instantiations
  template std::vector<ForkGate> createAIMGates<double>(const double dt, const bath &b, const hloc &e0, const AIM_ForkSites &sites);
  template std::vector<ForkGate> createAIMGates<Complex>(const Complex dt, const bath &b, const hloc &e0, const AIM_ForkSites &sites);

  // Creates the unit tensor on the impurites and the DD-hamiltonian for 2 bands
  std::pair<ITensor, ITensor> DD_MPO1Band(const H_int hint, const AIM_ForkSites &sites) {
    if (std::fabs(hint.Up) > 1e-15 || std::fabs(hint.J) > 1E-15) {
      std::cout << hint << std::endl;
      Error("U' and J must be zero in one-orbital case.");
    }

    double U   = hint.U;
    auto NArms = sites.NArms();
    std::string NopName("N"); //defines if "N" or "Nsym" is taken as interaction operator

    ITensor tevo;

    std::vector<ITensor> IDs(NArms + 1), Ns(NArms + 1);
    for (auto i : range1(NArms)) {
      IDs[i] = sites.op("Id", sites.ImpSite(i));
      Ns[i]  = sites.op(NopName, sites.ImpSite(i));
    }

    tevo = Ns[1] * Ns[2] * U;

    ITensor unit = IDs[1] * IDs[2];

    return std::make_pair(unit, tevo);
  }

  // Creates the unit tensor on the impurites and the DD-hamiltonian for 2 bands
  std::pair<ITensor, ITensor> DD_MPO2Band(const H_int hint, const AIM_ForkSites &sites) {
    double U = hint.U, J = hint.J, Uprime = hint.Up;
    auto NArms = sites.NArms();
    std::string NopName("N"); //defines if "N" or "Nsym" is taken as interaction operator

    ITensor tevo;

    std::vector<ITensor> IDs(NArms + 1), Ns(NArms + 1);
    for (auto i : range1(NArms)) {
      IDs[i] = sites.op("Id", sites.ImpSite(i));
      Ns[i]  = sites.op(NopName, sites.ImpSite(i));
    }

    tevo = Ns[1] * Ns[2] * IDs[3] * IDs[4] * U;
    tevo += IDs[1] * IDs[2] * Ns[3] * Ns[4] * U;

    tevo += Ns[1] * IDs[2] * IDs[3] * Ns[4] * Uprime;
    tevo += IDs[1] * Ns[2] * Ns[3] * IDs[4] * Uprime;

    tevo += Ns[1] * IDs[2] * Ns[3] * IDs[4] * (Uprime - J);
    tevo += IDs[1] * Ns[2] * IDs[3] * Ns[4] * (Uprime - J);

    // exponentiate whole operator using product formula of exponential
    ITensor unit = IDs[1] * IDs[2] * IDs[3] * IDs[4];

    return std::make_pair(unit, tevo);
  }

  // Creates the unit tensor on the impurites and the DD-hamiltonian for 3 bands
  std::pair<ITensor, ITensor> DD_MPO3Band(const H_int hint, const AIM_ForkSites &sites) {

    auto NArms = sites.NArms();
    double U = hint.U, J = hint.J, Uprime = hint.Up;
    std::string NopName("N"); //defines if "Nsym" or "N" is taken as interaction operator

    ITensor tevo;

    std::vector<ITensor> IDs(NArms + 1), Ns(NArms + 1);
    for (auto i : range1(NArms)) {
      IDs[i] = sites.op("Id", sites.ImpSite(i));
      Ns[i]  = sites.op(NopName, sites.ImpSite(i));
    }

    tevo = Ns[1] * Ns[2] * IDs[3] * IDs[4] * IDs[5] * IDs[6] * U;
    tevo += IDs[1] * IDs[2] * Ns[3] * Ns[4] * IDs[5] * IDs[6] * U;
    tevo += IDs[1] * IDs[2] * IDs[3] * IDs[4] * Ns[5] * Ns[6] * U;

    tevo += Ns[1] * IDs[2] * IDs[3] * Ns[4] * IDs[5] * IDs[6] * Uprime;
    tevo += Ns[1] * IDs[2] * IDs[3] * IDs[4] * IDs[5] * Ns[6] * Uprime;

    tevo += IDs[1] * Ns[2] * Ns[3] * IDs[4] * IDs[5] * IDs[6] * Uprime;
    tevo += IDs[1] * IDs[2] * Ns[3] * IDs[4] * IDs[5] * Ns[6] * Uprime;

    tevo += IDs[1] * Ns[2] * IDs[3] * IDs[4] * Ns[5] * IDs[6] * Uprime;
    tevo += IDs[1] * IDs[2] * IDs[3] * Ns[4] * Ns[5] * IDs[6] * Uprime;

    tevo += Ns[1] * IDs[2] * Ns[3] * IDs[4] * IDs[5] * IDs[6] * (Uprime - J);
    tevo += Ns[1] * IDs[2] * IDs[3] * IDs[4] * Ns[5] * IDs[6] * (Uprime - J);
    tevo += IDs[1] * IDs[2] * Ns[3] * IDs[4] * Ns[5] * IDs[6] * (Uprime - J);

    tevo += IDs[1] * Ns[2] * IDs[3] * Ns[4] * IDs[5] * IDs[6] * (Uprime - J);
    tevo += IDs[1] * Ns[2] * IDs[3] * IDs[4] * IDs[5] * Ns[6] * (Uprime - J);
    tevo += IDs[1] * IDs[2] * IDs[3] * Ns[4] * IDs[5] * Ns[6] * (Uprime - J);

    ITensor unit = IDs[1] * IDs[2] * IDs[3] * IDs[4] * IDs[5] * IDs[6];

    return std::make_pair(unit, tevo);
  }

  // Creates the unit tensor on the impurites and the DD-hamiltonian for 5 bands
  std::pair<ITensor, ITensor> DD_MPO5Band(const H_int hint, const AIM_ForkSites &sites) {
    //exp(- dt * DD-terms)
    auto NArms = sites.NArms();
    double U = hint.U, J = hint.J, Uprime = hint.Up;
    std::string NopName("N"); //defines if "Nsym" or "N" is taken as interaction operator
    QN qn0 = -div(sites.op("Id", sites.ImpSite(1)));
    std::vector<ITensor> MPO(NArms + 1);

    std::vector<Index> Sis(NArms + 1), SiPs(NArms + 1);
    for (auto i : range1(NArms)) {
      Sis[i]  = sites.si(sites.ImpSite(i));
      SiPs[i] = prime(Sis[i]);
    }

    std::vector<ITensor> IDs(NArms + 1), Ns(NArms + 1);
    for (auto i : range1(NArms)) {
      IDs[i] = sites.op("Id", sites.ImpSite(i));
      Ns[i]  = sites.op(NopName, sites.ImpSite(i));
    }

    std::vector<Index> ImpLinks(NArms + 1);
    std::vector<int> LinkDim(NArms);
    LinkDim = {0, 2, 4, 5, 4, 5, 4, 5, 4, 5};

    for (auto imp : range1(NArms - 1)) ImpLinks.at(imp) = Index(qn0, LinkDim[imp], Out, Names::TAGSI);

    //first Impurity site
    {
      int impIndx = 1;
      int site    = sites.ImpSite(impIndx);
      ITensor &W  = MPO.at(impIndx);

      Index ILink = ImpLinks.at(impIndx);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ILink);

      W = sites.op("Id", site) * setElt(ILink(1));
      W += sites.op(NopName, site) * setElt(ILink(2));
    }

    //second
    {
      int impIndx = 2;
      int site    = sites.ImpSite(impIndx);
      ITensor &W  = MPO.at(impIndx);

      Index ILinkUp = dag(ImpLinks.at(impIndx - 1));
      Index ILinkDn = ImpLinks.at(impIndx);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ILinkUp, ILinkDn);

      //Ids
      W = sites.op("Id", site) * setElt(ILinkUp(1), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ILinkUp(2), ILinkDn(3));

      //Nk for other Impurities
      W += sites.op(NopName, site) * setElt(ILinkUp(1), ILinkDn(4));

      //finish density density interactions:
      W += sites.op(NopName, site) * setElt(ILinkUp(2), ILinkDn(1)) * U; //with nA_up
    }

    //third to 9th
    for (int impIndx = 3; impIndx <= NArms - 1; impIndx++) {
      int site   = sites.ImpSite(impIndx);
      ITensor &W = MPO.at(impIndx);

      Index ILinkUp = dag(ImpLinks.at(impIndx - 1));
      Index ILinkDn = ImpLinks.at(impIndx);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ILinkUp, ILinkDn);

      //Ids
      W = sites.op("Id", site) * setElt(ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ILinkUp(3), ILinkDn(3));
      W += sites.op("Id", site) * setElt(ILinkUp(4), ILinkDn(4));

      if (impIndx % 2 == 0) {
        //down site
        W += sites.op(NopName, site) * setElt(ILinkUp(3), ILinkDn(1)) * (Uprime);
        W += sites.op(NopName, site) * setElt(ILinkUp(4), ILinkDn(1)) * (Uprime - J);
        W += sites.op(NopName, site) * setElt(ILinkUp(5), ILinkDn(1)) * (U);

        W += sites.op("Id", site) * setElt(ILinkUp(5), ILinkDn(3));
        W += sites.op(NopName, site) * setElt(ILinkUp(2), ILinkDn(4));
      } else {
        //up site
        W += sites.op(NopName, site) * setElt(ILinkUp(3), ILinkDn(1)) * (Uprime - J);
        W += sites.op(NopName, site) * setElt(ILinkUp(4), ILinkDn(1)) * (Uprime);

        W += sites.op(NopName, site) * setElt(ILinkUp(2), ILinkDn(5));
      }
    }

    //last impurity nE_dn
    {
      int impIndx = NArms;
      int site    = sites.ImpSite(impIndx);
      ITensor &W  = MPO.at(impIndx);

      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ILinkUp);

      W = sites.op("Id", site) * setElt(ILinkUp(1));

      //density interactions
      W += sites.op(NopName, site) * setElt(ILinkUp(3)) * (Uprime);
      W += sites.op(NopName, site) * setElt(ILinkUp(4)) * (Uprime - J);
      W += sites.op(NopName, site) * setElt(ILinkUp(5)) * (U);
    }

    ITensor tevo = MPO.at(1);
    ITensor unit = IDs.at(1);

    for (int i = 2; i <= NArms; i++) {
      tevo *= MPO.at(i);
      unit *= IDs.at(i);
    }

    return std::make_pair(unit, tevo);
  }

  //
  template <typename T> std::vector<ITensor> DD_MPO(const T dt, const H_int &hint, const AIM_ForkSites &sites) {
    auto NArms = sites.NArms();

    ITensor tevo, unit;
    if (sites.NArms() == 2)
      std::tie(unit, tevo) = DD_MPO1Band(hint, sites);
    else if (sites.NArms() == 4)
      std::tie(unit, tevo) = DD_MPO2Band(hint, sites);
    else if (sites.NArms() == 6)
      std::tie(unit, tevo) = DD_MPO3Band(hint, sites);
    else if (sites.NArms() == 10)
      std::tie(unit, tevo) = DD_MPO5Band(hint, sites);
    else {
      Error("CreateImpurityMPO not supported for NArms != 4 or NArms != 6 or NArms != 10");
      return {};
    }

    // exponentiate tensor
    ITensor hh   = -dt * tevo;
    ITensor term = hh;

    hh.mapPrime(1, 2);
    hh.mapPrime(0, 1);

    for (int ord = 100; ord >= 1; --ord) {
      term /= ord;
      tevo = unit + term;
      term = tevo * hh;
      term.mapPrime(2, 1);
    }

    // get MPO tensor using svd
    std::vector<ITensor> MPO(NArms + 1);
    std::vector<Index> Sis(NArms + 1), SiPs(NArms + 1);
    for (auto i : range1(NArms)) {
      Sis[i]  = sites.si(sites.ImpSite(i));
      SiPs[i] = prime(Sis[i]);
    }
    ITensor W(Sis[1], SiPs[1]), VV, DD, AA = tevo;

    for (auto i : range1(NArms - 1)) {
      svd(AA, W, DD, VV, {"Cutoff", MIN_CUT});
      MPO[i] = W;
      AA     = DD * VV;
      W      = ITensor(commonIndex(DD, W), Sis[i + 1], SiPs[i + 1]);
    }

    MPO[NArms] = AA;

    return MPO;
  }

  //explicit instantiations
  template std::vector<ITensor> DD_MPO<double>(const double dt, const H_int &hint, const AIM_ForkSites &sites);
  template std::vector<ITensor> DD_MPO<Complex>(const Complex dt, const H_int &hint, const AIM_ForkSites &sites);

} // namespace forktps
