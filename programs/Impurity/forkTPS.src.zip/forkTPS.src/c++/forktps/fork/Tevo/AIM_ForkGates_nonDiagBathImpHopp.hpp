
#include "itensor/mps/siteset.h"
#include "itensor/iqtensor.h"

using namespace itensor;

namespace itensor {

  template <typename T>
  void createImpurityMPO3Band(T dt, ForkTPO &H, double U, double Uprime, double J, Cmat e0, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites);

  template <typename T>
  void createImpurityMPO2Band(T dt, ForkTPO &H, double U, double Uprime, double J, Cmat e0, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites);

  template <typename T>
  void createAIMGates(T dt, ForkTPO &H, Dmat eps, Cmat V, double U, double Uprime, double J, Cmat e0, std::vector<ForkGate> &gates,
                      const AIM_ForkSites &sites) {

    //preparations
    int NArms = H.NArms();
    int NBath = H.NBath();

    if (NArms == 4) { Error("createAIMGates: Convention for definition of VK changed NArms =4 not supported anymore!"); }

    gates.resize(0);

    //gates between arm and imp
    for (int arm = 1; arm <= NArms; arm++) {
      int Voffset = NBath * ((arm + arm % 2) / 2 - 1);
      int e0Indx  = (arm + arm % 2) / 2;
      {
        int indx = NBath;
        int i    = H.ImpSite(arm);
        int j    = H.ArmToSite(arm, indx);

        IQTensor HH = eps.at(arm).at(indx) * sites.op("Id", i) * sites.op("N", j);
        HH += e0.at(e0Indx).at(e0Indx) * sites.op("N", i) * sites.op("Id", j); //tevo of impurity with eps.at(0)
        HH += V.at(arm).at(indx + Voffset) * sites.op("CkD", i) * sites.op("Ck", j);
        HH += std::conj(V.at(arm).at(indx + Voffset)) * sites.op("Ck", i) * sites.op("CkD", j);

        //create gate
        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        //add swapgate
        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        g *= swap;
        g.setSwap(true);
        gates.push_back(g);
      }

      for (int indx = NBath - 1; indx >= 1; indx--) {
        int i = H.ArmToSite(arm, indx);
        int j = H.ArmToSite(arm, indx + 1);

        IQTensor HH = eps.at(arm).at(indx) * sites.op("N", i) * sites.op("Id", j); //at site j is the swaped impurity -> act with Id operator
        HH += std::conj(V.at(arm).at(indx + Voffset)) * sites.op("CkD", i) * sites.op("Ck", j);
        HH += V.at(arm).at(indx + Voffset) * sites.op("Ck", i) * sites.op("CkD", j);

        ForkGate g(HH, i, j);
        if (indx != 1) {
          g.expGate(dt / 2, sites);
          ForkGate swap;
          swap.MakeSwap(i, j, sites);
          g.setSwap(true);
          g *= swap;
        } else {
          g.expGate(dt, sites);
        } //no swap gate needed at laste gate and time evolution is with dt not dt/2
        gates.push_back(g);
      }

      for (int indx = 2; indx <= NBath - 1; indx++) {
        int i = H.ArmToSite(arm, indx);
        int j = H.ArmToSite(arm, indx + 1);

        IQTensor HH = eps.at(arm).at(indx) * sites.op("N", i) * sites.op("Id", j); //at site j is the swaped impurity -> act with Id operator
        HH += std::conj(V.at(arm).at(indx + Voffset)) * sites.op("CkD", i) * sites.op("Ck", j);
        HH += V.at(arm).at(indx + Voffset) * sites.op("Ck", i) * sites.op("CkD", j);

        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        swap *= g; //first swap then time evo!!

        gates.push_back(swap);
      }

      {
        int indx = NBath;
        int i    = H.ImpSite(arm);
        int j    = H.ArmToSite(arm, indx);

        IQTensor HH = eps.at(arm).at(indx) * sites.op("Id", i) * sites.op("N", j); //site i is impurity
        HH += e0.at(e0Indx).at(e0Indx) * sites.op("N", i) * sites.op("Id", j);     //tevo of impurity with eps.at(0)
        HH += V.at(arm).at(indx + Voffset) * sites.op("CkD", i) * sites.op("Ck", j);
        HH += std::conj(V.at(arm).at(indx + Voffset)) * sites.op("Ck", i) * sites.op("CkD", j);

        //create gate
        ForkGate g(HH, i, j);
        g.expGate(dt / 2, sites);

        //add swapgate
        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        swap *= g; //swap before time evo!!
        gates.push_back(swap);
      }
    }

    return;
  }

  template <typename T>
  void createNonDiagAIMGates(T dt, ForkTPO &H, Cmat V, int Imp, int atImp, std::vector<ForkGate> &gates, const AIM_ForkSites &sites) {

    //preparations
    int NArms = H.NArms();
    int NBath = H.NBath();

    if (NArms != 4 && NArms != 6) {
      Print(NArms);
      Error("createNonDiagAIMGates: Only NArms = 4 or NArms = 6 supported!");
    }
    if (NArms == 4) {
      Print(NArms);
      Error("createNonDiagAIMGates: Convention for definition of VK changed NArms =4 not supported anymore!");
    }

    gates.resize(0);

    //gates between arm and imp
    int arm     = atImp;
    int VIndex  = Imp;
    int Voffset = NBath * ((atImp + atImp % 2) / 2 - 1);

    // std::cout<<"Start Creating non diag bath gates. at arm "<<arm<< ", with Vindex: "<<VIndex<<std::endl;
    {
      int indx = NBath;
      int i    = H.ImpSite(arm); //i is the impurity
      int j    = H.ArmToSite(arm, indx);

      // std::cout<<"add gate site i: "<<i << ", j: "<<j<<", with strength"<< V.at(VIndex).at(indx+Voffset)  <<std::endl;

      IQTensor HH = V.at(VIndex).at(indx + Voffset) * sites.op("CkD", i) * sites.op("Ck", j);
      HH += std::conj(V.at(VIndex).at(indx + Voffset)) * sites.op("Ck", i) * sites.op("CkD", j);

      //create gate
      ForkGate g(HH, i, j);
      g.expGate(dt / 2, sites);

      //add swapgate
      ForkGate swap;
      swap.MakeSwap(i, j, sites);
      g *= swap;
      g.setSwap(true);
      gates.push_back(g);
    }

    for (int indx = NBath - 1; indx >= 1; indx--) {
      int i = H.ArmToSite(arm, indx);
      int j = H.ArmToSite(arm, indx + 1); //j is the impurity

      // std::cout<<"add gate site i: "<<i << ", j: "<<j<<", with strength"<< V.at(VIndex).at(indx+Voffset)  <<std::endl;

      IQTensor HH = std::conj(V.at(VIndex).at(indx + Voffset)) * sites.op("CkD", i) * sites.op("Ck", j);
      HH += V.at(VIndex).at(indx + Voffset) * sites.op("Ck", i) * sites.op("CkD", j);

      ForkGate g(HH, i, j);
      if (indx != 1) {
        g.expGate(dt / 2, sites);
        ForkGate swap;
        swap.MakeSwap(i, j, sites);
        g.setSwap(true);
        g *= swap;
      } else {
        g.expGate(dt, sites);
      } //no swap gate needed at laste gate and time evolution is with dt not dt/2
      gates.push_back(g);
    }

    for (int indx = 2; indx <= NBath - 1; indx++) {
      int i = H.ArmToSite(arm, indx);
      int j = H.ArmToSite(arm, indx + 1); //j is the impurity since we swap before tevo

      // std::cout<<"add gate site i: "<<i << ", j: "<<j<<", with strength"<< V.at(VIndex).at(indx+Voffset)  <<std::endl;

      IQTensor HH = std::conj(V.at(VIndex).at(indx + Voffset)) * sites.op("CkD", i) * sites.op("Ck", j);
      HH += V.at(VIndex).at(indx + Voffset) * sites.op("Ck", i) * sites.op("CkD", j);

      ForkGate g(HH, i, j);
      g.expGate(dt / 2, sites);

      ForkGate swap;
      swap.MakeSwap(i, j, sites);
      swap *= g; //first swap then time evo!!

      gates.push_back(swap);
    }

    {
      int indx = NBath;
      int i    = H.ImpSite(arm);
      int j    = H.ArmToSite(arm, indx);

      // std::cout<<"add gate site i: "<<i << ", j: "<<j<<", with strength"<< V.at(VIndex).at(indx+Voffset)  <<std::endl;
      //impurity is at site j so reverse conj
      IQTensor HH = V.at(VIndex).at(indx + Voffset) * sites.op("CkD", i) * sites.op("Ck", j);
      HH += std::conj(V.at(VIndex).at(indx + Voffset)) * sites.op("Ck", i) * sites.op("CkD", j);

      //create gate
      ForkGate g(HH, i, j);
      g.expGate(dt / 2, sites);

      //add swapgate
      ForkGate swap;
      swap.MakeSwap(i, j, sites);
      swap *= g; //swap before time evo!!
      gates.push_back(swap);
    }

    return;
  }

  void createImpuritySwapperWSign(ForkTPO &H, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites, int ImpI, int ImpJ) {
    //this function creates an MPO in form of a vector of IQTensors "MPO" that swaps impurity site ImpI
    //with impurity site ImpJ. Note that this function assumes that the fermionic order is swaped already
    //so that ImpI is directly before ImpJ in the fermionic order!!!!!!

    int NArms = H.NArms();
    if (NArms != 6 && NArms != 4 && NArms != 2) {
      Print(NArms);
      Error("createImpuritySwapper:: create impurity MPO only supported for NArms=6,4,2");
    }
    if (ImpI == ImpJ) {
      Print(ImpI);
      Error("createImpuritySwapper:: ImpI cannot be equal to ImpJ");
    }
    if (ImpI > ImpJ) { std::swap(ImpI, ImpJ); }

    MPO.resize(NArms + 1);
    int firstId;
    IQTensor ID;
    std::vector<IQIndex> Sis, SiPs;
    Sis.resize(NArms + 1);
    SiPs.resize(NArms + 1);

    for (int i = 1; i <= NArms; i++) {
      Sis.at(i)  = sites.si(H.ImpSite(i));
      SiPs.at(i) = prime(Sis.at(i));
    }

    if (ImpI != 1) {
      firstId = 1;
    } else if (ImpJ != 2) {
      firstId = 2;
    } else {
      firstId = 3;
    }

    //get Ids at all sites execpt ImpI and ImpJ
    ID = sites.op("Id", H.ImpSite(firstId));
    for (int i = firstId + 1; i <= NArms; i++) {
      if (i != ImpI && i != ImpJ) { ID *= sites.op("Id", H.ImpSite(i)); }
    }

    IQTensor swapper = ID * dag(Sis.at(ImpI)(1)) * SiPs.at(ImpI)(1) * dag(Sis.at(ImpJ)(1)) * SiPs.at(ImpJ)(1);
    swapper += ID * dag(Sis.at(ImpI)(2)) * SiPs.at(ImpI)(2) * dag(Sis.at(ImpJ)(2)) * SiPs.at(ImpJ)(2) * (-1.);
    swapper += ID * dag(Sis.at(ImpI)(1)) * SiPs.at(ImpI)(2) * dag(Sis.at(ImpJ)(2)) * SiPs.at(ImpJ)(1);
    swapper += ID * dag(Sis.at(ImpI)(2)) * SiPs.at(ImpI)(1) * dag(Sis.at(ImpJ)(1)) * SiPs.at(ImpJ)(2);

    IQTensor W(Sis.at(1), SiPs.at(1)), VV, DD, UU, WW, AA = swapper;

    for (int i = 1; i < NArms; i++) {
      svd(AA, W, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i) = W;
      AA        = DD * VV;
      W         = IQTensor(commonIndex(DD, W), Sis.at(i + 1), SiPs.at(i + 1));
    }

    MPO.at(NArms) = AA;

    //normalize it to site one (to use zipUp algorithm)
    for (int i = NArms; i > 1; i--) {
      WW = MPO.at(i) * MPO.at(i - 1);
      UU = MPO.at(i);
      svd(WW, UU, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i)     = UU;
      MPO.at(i - 1) = VV * DD;
    }

    return;
  }

  void createImpuritySwapperWOSign(ForkTPO &H, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites, int ImpI, int ImpJ) {
    //this function creates an MPO in form of a vector of IQTensors "MPO" that swaps impurity site ImpI
    //with impurity site ImpJ. Note that this function assumes that the fermionic order is swaped already
    //so that ImpI is directly before ImpJ in the fermionic order!!!!!!

    int NArms = H.NArms();
    if (NArms != 6 && NArms != 4 && NArms != 2) {
      Print(NArms);
      Error("createImpuritySwapper:: create impurity MPO only supported for NArms=6,4,2");
    }
    if (ImpI == ImpJ) {
      Print(ImpI);
      Error("createImpuritySwapper:: ImpI cannot be equal to ImpJ");
    }
    if (ImpI > ImpJ) { std::swap(ImpI, ImpJ); }

    MPO.resize(NArms + 1);
    int firstId;
    IQTensor ID;
    std::vector<IQIndex> Sis, SiPs;
    Sis.resize(NArms + 1);
    SiPs.resize(NArms + 1);

    for (int i = 1; i <= NArms; i++) {
      Sis.at(i)  = sites.si(H.ImpSite(i));
      SiPs.at(i) = prime(Sis.at(i));
    }

    if (ImpI != 1) {
      firstId = 1;
    } else if (ImpJ != 2) {
      firstId = 2;
    } else {
      firstId = 3;
    }

    //get Ids at all sites execpt ImpI and ImpJ
    ID = sites.op("Id", H.ImpSite(firstId));
    for (int i = firstId + 1; i <= NArms; i++) {
      if (i != ImpI && i != ImpJ) { ID *= sites.op("Id", H.ImpSite(i)); }
    }

    IQTensor swapper = ID * dag(Sis.at(ImpI)(1)) * SiPs.at(ImpI)(1) * dag(Sis.at(ImpJ)(1)) * SiPs.at(ImpJ)(1);
    swapper += ID * dag(Sis.at(ImpI)(2)) * SiPs.at(ImpI)(2) * dag(Sis.at(ImpJ)(2)) * SiPs.at(ImpJ)(2);
    swapper += ID * dag(Sis.at(ImpI)(1)) * SiPs.at(ImpI)(2) * dag(Sis.at(ImpJ)(2)) * SiPs.at(ImpJ)(1);
    swapper += ID * dag(Sis.at(ImpI)(2)) * SiPs.at(ImpI)(1) * dag(Sis.at(ImpJ)(1)) * SiPs.at(ImpJ)(2);

    IQTensor W(Sis.at(1), SiPs.at(1)), VV, DD, UU, WW, AA = swapper;

    for (int i = 1; i < NArms; i++) {
      svd(AA, W, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i) = W;
      AA        = DD * VV;
      W         = IQTensor(commonIndex(DD, W), Sis.at(i + 1), SiPs.at(i + 1));
    }

    MPO.at(NArms) = AA;

    //normalize it to site one (to use zipUp algorithm)
    for (int i = NArms; i > 1; i--) {
      WW = MPO.at(i) * MPO.at(i - 1);
      UU = MPO.at(i);
      svd(WW, UU, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i)     = UU;
      MPO.at(i - 1) = VV * DD;
    }

    return;
  }

  template <typename T>
  void createImpurityMPO3Band(T dt, ForkTPO &H, double U, double Uprime, double J, Cmat e0, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites) {

    int NArms = H.NArms();
    std::string NopName("N"); //defines if "Nsym" or "N" is taken as interaction operator
    if (NArms != 6) { Error("create impurity MPO only supported for NArms=6"); }

    MPO.resize(NArms + 1);

    std::vector<IQIndex> Sis, SiPs;
    Sis.resize(NArms + 1);
    SiPs.resize(NArms + 1);
    for (int i = 1; i <= NArms; i++) {
      Sis.at(i)  = sites.si(H.ImpSite(i));
      SiPs.at(i) = prime(Sis.at(i));
    }

    IQTensor tevo;

    std::vector<IQTensor> IDs, Ns, Cs, CDs, ps;
    IDs.resize(NArms + 1);
    Ns.resize(NArms + 1);
    Cs.resize(NArms + 1);
    CDs.resize(NArms + 1);
    ps.resize(NArms + 1);
    for (int i = 1; i <= NArms; i++) {
      IDs.at(i) = sites.op("Id", H.ImpSite(i));
      Ns.at(i)  = sites.op(NopName, H.ImpSite(i));

      Cs.at(i)  = sites.op("Ck", H.ImpSite(i));
      CDs.at(i) = sites.op("CkD", H.ImpSite(i));

      ps.at(i) = sites.op("p", H.ImpSite(i));
    }

    tevo = Ns.at(1) * Ns.at(2) * IDs.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6) * U;
    tevo += IDs.at(1) * IDs.at(2) * Ns.at(3) * Ns.at(4) * IDs.at(5) * IDs.at(6) * U;
    tevo += IDs.at(1) * IDs.at(2) * IDs.at(3) * IDs.at(4) * Ns.at(5) * Ns.at(6) * U;

    tevo += Ns.at(1) * IDs.at(2) * IDs.at(3) * Ns.at(4) * IDs.at(5) * IDs.at(6) * Uprime;
    tevo += Ns.at(1) * IDs.at(2) * IDs.at(3) * IDs.at(4) * IDs.at(5) * Ns.at(6) * Uprime;

    tevo += IDs.at(1) * Ns.at(2) * Ns.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6) * Uprime;
    tevo += IDs.at(1) * IDs.at(2) * Ns.at(3) * IDs.at(4) * IDs.at(5) * Ns.at(6) * Uprime;

    tevo += IDs.at(1) * Ns.at(2) * IDs.at(3) * IDs.at(4) * Ns.at(5) * IDs.at(6) * Uprime;
    tevo += IDs.at(1) * IDs.at(2) * IDs.at(3) * Ns.at(4) * Ns.at(5) * IDs.at(6) * Uprime;

    tevo += Ns.at(1) * IDs.at(2) * Ns.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6) * (Uprime - J);
    tevo += Ns.at(1) * IDs.at(2) * IDs.at(3) * IDs.at(4) * Ns.at(5) * IDs.at(6) * (Uprime - J);
    tevo += IDs.at(1) * IDs.at(2) * Ns.at(3) * IDs.at(4) * Ns.at(5) * IDs.at(6) * (Uprime - J);

    tevo += IDs.at(1) * Ns.at(2) * IDs.at(3) * Ns.at(4) * IDs.at(5) * IDs.at(6) * (Uprime - J);
    tevo += IDs.at(1) * Ns.at(2) * IDs.at(3) * IDs.at(4) * IDs.at(5) * Ns.at(6) * (Uprime - J);
    tevo += IDs.at(1) * IDs.at(2) * IDs.at(3) * Ns.at(4) * IDs.at(5) * Ns.at(6) * (Uprime - J);

    //impurity hoppings:
    tevo += CDs.at(1) * ps.at(2) * Cs.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6) * e0.at(1).at(2);
    tevo += Cs.at(1) * ps.at(2) * CDs.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6) * e0.at(2).at(1);

    tevo += CDs.at(1) * ps.at(2) * ps.at(3) * ps.at(4) * Cs.at(5) * IDs.at(6) * e0.at(1).at(3);
    tevo += Cs.at(1) * ps.at(2) * ps.at(3) * ps.at(4) * CDs.at(5) * IDs.at(6) * e0.at(3).at(1);

    tevo += IDs.at(1) * IDs.at(2) * CDs.at(3) * ps.at(4) * Cs.at(5) * IDs.at(6) * e0.at(2).at(3);
    tevo += IDs.at(1) * IDs.at(2) * Cs.at(3) * ps.at(4) * CDs.at(5) * IDs.at(6) * e0.at(3).at(2);

    tevo += IDs.at(1) * CDs.at(2) * ps.at(3) * Cs.at(4) * IDs.at(5) * IDs.at(6) * e0.at(1).at(2);
    tevo += IDs.at(1) * Cs.at(2) * ps.at(3) * CDs.at(4) * IDs.at(5) * IDs.at(6) * e0.at(2).at(1);

    tevo += IDs.at(1) * CDs.at(2) * ps.at(3) * ps.at(4) * ps.at(5) * Cs.at(6) * e0.at(1).at(3);
    tevo += IDs.at(1) * Cs.at(2) * ps.at(3) * ps.at(4) * ps.at(5) * CDs.at(6) * e0.at(3).at(1);

    tevo += IDs.at(1) * IDs.at(2) * IDs.at(3) * CDs.at(4) * ps.at(5) * Cs.at(6) * e0.at(2).at(3);
    tevo += IDs.at(1) * IDs.at(2) * IDs.at(3) * Cs.at(4) * ps.at(5) * CDs.at(6) * e0.at(3).at(2);

    IQTensor unit = IDs.at(1) * IDs.at(2) * IDs.at(3) * IDs.at(4) * IDs.at(5) * IDs.at(6);
    IQTensor hh   = -dt * tevo;
    IQTensor term = hh;

    hh.mapprime(1, 2);
    hh.mapprime(0, 1);

    for (int ord = 100; ord >= 1; --ord) {
      term /= ord;
      tevo = unit + term;
      term = tevo * hh;
      term.mapprime(2, 1);
    }

    //PrintDat(tevo);

    IQTensor W(Sis.at(1), SiPs.at(1)), VV, DD, UU, WW, AA = tevo;

    for (int i = 1; i < NArms; i++) {
      svd(AA, W, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i) = W;
      AA        = DD * VV;
      W         = IQTensor(commonIndex(DD, W), Sis.at(i + 1), SiPs.at(i + 1));
    }

    MPO.at(NArms) = AA;

    //normalize it to site one (to use zipUp algorithm)
    for (int i = NArms; i > 1; i--) {
      WW = MPO.at(i) * MPO.at(i - 1);
      UU = MPO.at(i);
      svd(WW, UU, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i)     = UU;
      MPO.at(i - 1) = VV * DD;
    }

    return;
  }

  template <typename T>
  void createImpurityMPO2Band(T dt, ForkTPO &H, double U, double Uprime, double J, Cmat e0, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites) {
    Error("Impurity MPO2Band not implemented");
    int NArms = H.NArms();
    std::string NopName("N"); //defines if "N" or "Nsym" is taken as interaction operator
    if (NArms != 4) { Error("create impurity MPO only supported for NArms=4"); }
    MPO.resize(NArms + 1);

    std::vector<IQIndex> Sis, SiPs;
    Sis.resize(NArms + 1);
    SiPs.resize(NArms + 1);
    for (int i = 1; i <= NArms; i++) {
      Sis.at(i)  = sites.si(H.ImpSite(i));
      SiPs.at(i) = prime(Sis.at(i));
    }

    IQTensor tevo;

    std::vector<IQTensor> IDs, Ns;
    IDs.resize(NArms + 1);
    Ns.resize(NArms + 1);
    for (int i = 1; i <= NArms; i++) {
      IDs.at(i) = sites.op("Id", H.ImpSite(i));
      Ns.at(i)  = sites.op(NopName, H.ImpSite(i));
    }

    tevo = Ns.at(1) * Ns.at(2) * IDs.at(3) * IDs.at(4) * U;
    tevo += IDs.at(1) * IDs.at(2) * Ns.at(3) * Ns.at(4) * U;

    tevo += Ns.at(1) * IDs.at(2) * IDs.at(3) * Ns.at(4) * Uprime;
    tevo += IDs.at(1) * Ns.at(2) * Ns.at(3) * IDs.at(4) * Uprime;

    tevo += Ns.at(1) * IDs.at(2) * Ns.at(3) * IDs.at(4) * (Uprime - J);
    tevo += IDs.at(1) * Ns.at(2) * IDs.at(3) * Ns.at(4) * (Uprime - J);

    IQTensor unit = IDs.at(1) * IDs.at(2) * IDs.at(3) * IDs.at(4);
    IQTensor hh   = -dt * tevo;
    IQTensor term = hh;

    hh.mapprime(1, 2);
    hh.mapprime(0, 1);

    for (int ord = 100; ord >= 1; --ord) {
      term /= ord;
      tevo = unit + term;
      term = tevo * hh;
      term.mapprime(2, 1);
    }

    //PrintDat(tevo);

    IQTensor W(Sis.at(1), SiPs.at(1)), VV, DD, UU, AA = tevo;

    for (int i = 1; i < NArms; i++) {
      svd(AA, W, DD, VV);
      MPO.at(i) = W;
      AA        = DD * VV;
      W         = IQTensor(commonIndex(DD, W), Sis.at(i + 1), SiPs.at(i + 1));
    }

    MPO.at(NArms) = AA;

    for (int i = NArms; i > 1; i--) {
      W  = MPO.at(i) * MPO.at(i - 1);
      UU = MPO.at(i);
      svd(W, UU, DD, VV, {"Cutoff", 1E-16});
      MPO.at(i)     = UU;
      MPO.at(i - 1) = VV * DD;
    }

    return;
  }

  template <typename T>
  void createImpurityMPO(T dt, ForkTPO &H, double U, double Uprime, double J, Cmat e0, std::vector<IQTensor> &MPO, const AIM_ForkSites &sites) {
    if (H.NArms() == 4) {
      createImpurityMPO2Band(dt, H, U, Uprime, J, e0, MPO, sites);
    } else if (H.NArms() == 6) {
      createImpurityMPO3Band(dt, H, U, Uprime, J, e0, MPO, sites);
    } else {
      Error("CreateImpurityMPO not supported for NArms != 4 or NArms !=6");
    }
  }

  // class AIM_SpinflipTevo
  // {
  //   public:
  //
  //   AIM_SpinflipTevo(const SiteSet& sites,double J, double dt, int NArms, int version, int orb1=1, int orb2=2 );
  //
  //
  //
  //   operator ForkTPO () { init_(); return H; }
  //
  //   void MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks);
  //
  //   //defines the time evolution operator of e^{-i*H*dt} for the
  //   //spinflip and pairhopping terms - note that giving the constructor
  //   //a positive dt means time evolution forward in time with e^{-i*H*dt}
  //
  //
  //   void MakeTwoOrbitalMPOv1  ( const std::vector<IQIndex>& ArmImpLinks );
  //   void MakeTwoOrbitalMPOv2  ( const std::vector<IQIndex>& ArmImpLinks );
  //
  //
  //   //For each orbital combination the MPO looks very similar to the
  //   //2 band case:
  //   //AB: has the operators on 1-4 and then identities on orbital 5 and 6
  //   //BC: has the operators on 3-6 and identities on orbitals 1 and 2
  //   //AC: has operator on 1-2 and 5-6 while having identities in between
  //
  //   //v1 is for the spinflip terms while v2 is for the pair-hopping terms
  //   void MakeThreeOrbitalMPO_AB_v1( const std::vector<IQIndex>& ArmImpLinks );
  //   void MakeThreeOrbitalMPO_BC_v1( const std::vector<IQIndex>& ArmImpLinks );
  //   void MakeThreeOrbitalMPO_AC_v1( const std::vector<IQIndex>& ArmImpLinks );
  //
  //   void MakeThreeOrbitalMPO_AB_v2( const std::vector<IQIndex>& ArmImpLinks );
  //   void MakeThreeOrbitalMPO_BC_v2( const std::vector<IQIndex>& ArmImpLinks );
  //   void MakeThreeOrbitalMPO_AC_v2( const std::vector<IQIndex>& ArmImpLinks );
  //
  //
  //   private:
  //
  //   //////////////////
  //   //
  //   // Data Members
  //
  //   const SiteSet& sites_;
  //
  //   int NArms_;
  //   int version_;
  //
  //   int orb1_;
  //   int orb2_;
  //
  //   double J_;
  //   double dt_;
  //   bool initted_;
  //
  //   ForkTPO H;
  //
  //   //
  //   //////////////////
  //
  //   void
  //   init_();
  //
  // };
  //
  // inline AIM_SpinflipTevo::
  // AIM_SpinflipTevo(const SiteSet& sites,double J,double dt, int NArms, int version, int orb1, int orb2 )
  // :
  // sites_(sites),
  // initted_(false)
  // {
  //   J_=J;
  //   dt_ = dt;
  //   NArms_=NArms;
  //   version_ = version;
  //   orb1_ = orb1;
  //   orb2_ = orb2;
  //
  // }
  //
  //
  //
  // void inline AIM_SpinflipTevo:: init_() {
  //   if(initted_) return;
  //
  //   H = ForkTPO(sites_,NArms_);
  //
  //   //const int N = sites_.N();
  //   const int NBath = H.NBath();
  //
  //
  //   std::vector<IQIndex> ArmImpLinks; ArmImpLinks.resize(0);
  //   std::vector<IQIndex> ImpImpLinks; ImpImpLinks.resize(0);
  //
  //   //the combination AB etc stands for which orbitals are time evolved AB means first and second orbital ....
  //   //v1 and v2 define if the spinflip or the pairhopping term is used.
  //
  //   MakeArmMPOs(ArmImpLinks);
  //   if(version_==1){
  //     if	    ( NArms_ == 4 ) { MakeTwoOrbitalMPOv1(ArmImpLinks); }
  //     else if	( NArms_ == 6 ) {
  //       if(orb1_==1 && orb2_ ==2){
  //         MakeThreeOrbitalMPO_AB_v1(ArmImpLinks);
  //       }
  //       else if(orb1_ == 1 && orb2_ == 3 ) {
  //         MakeThreeOrbitalMPO_AC_v1(ArmImpLinks);
  //       }
  //       else if(orb1_ == 2 && orb2_ == 3 ){
  //         MakeThreeOrbitalMPO_BC_v1(ArmImpLinks);
  //       }
  //       else{
  //         Print(orb1_); Print(orb2_); Error("Cant produce spinflip tevo with this orbital combination");
  //       }
  //     }
  //     else		                  { Print(NArms_); Error("AIM_ForkTPO: Cannot create AIM_ForkTPO with this number of orbitals"); }
  //   }
  //   else if(version_==2){
  //     if	    ( NArms_ == 4 ) { MakeTwoOrbitalMPOv2(ArmImpLinks); }
  //     else if	( NArms_ == 6 ) {
  //       if(orb1_==1 && orb2_ ==2){
  //         MakeThreeOrbitalMPO_AB_v2(ArmImpLinks);
  //       }
  //       else if(orb1_ == 1 && orb2_ == 3 ) {
  //         MakeThreeOrbitalMPO_AC_v2(ArmImpLinks);
  //       }
  //       else if(orb1_ == 2 && orb2_ == 3 ){
  //         MakeThreeOrbitalMPO_BC_v2(ArmImpLinks);
  //       }
  //       else{
  //         Print(orb1_); Print(orb2_); Error("Cant produce spinflip tevo with this orbital combination");
  //       }
  //     }
  //     else		                  { Print(NArms_); Error("AIM_ForkTPO: Cannot create AIM_ForkTPO with this number of orbitals"); }
  //   }
  //   else {
  //     Print(version_);
  //     Error("init AIM_SpinflipTevo error in version!");
  //   }
  //
  //   initted_ = true;
  // }
  //
  //
  // void AIM_SpinflipTevo:: MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks){
  //
  //
  //   ArmImpLinks.resize(0); ArmImpLinks.push_back(IQIndex());
  //
  //   const int NBath =H.NBath();
  //   std::vector<IQIndex> InterArmLinks(NBath+1);
  //
  //   for(int arm = 1; arm <= NArms_; arm++) {
  //
  //     int dimArmLink=arm%2+1;
  //     for(int l=1;l<=NBath;l++){
  //
  //       std::stringstream s, sId, sC, sCD;
  //       s<<"H ARM "<<arm<<" l "<<l;
  //       sId<<"Diag arm"<<arm<<" l"<<l;
  //
  //       InterArmLinks.at(l) = IQIndex( s.str(), Index(sId.str() ,dimArmLink), QN( 0,0) );
  //
  //     }
  //
  //     for(int n=1; n<=1; n++){
  //       int site = H.ArmToSite(arm,n);
  //       IQTensor& W =H.Anc(site);
  //       IQIndex left=InterArmLinks.at(n);
  //       W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left);
  //
  //       W += sites_.op("Id"  ,site)*left(1);
  //       if(arm%2==1) { W += sites_.op("p"  ,site)*left(2); }
  //     }
  //     for(int n=2; n<=NBath; n++){
  //
  //       int site = H.ArmToSite(arm,n);
  //       IQTensor& W =H.Anc(site);
  //
  //       IQIndex right =dag(InterArmLinks.at(n-1));
  //       IQIndex left  =    InterArmLinks.at(n)   ;
  //
  //       W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left,right);
  //
  //       W += sites_.op("Id",site)*right(1)*left(1);
  //       if(arm%2==1) { W += sites_.op("p"  ,site)*left(2)*right(2); }
  //     }
  //
  //     //store last link for Impurity tensors
  //     ArmImpLinks.push_back(InterArmLinks.at(NBath));
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeTwoOrbitalMPOv1( const std::vector<IQIndex>& ArmImpLinks ){
  //
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_Ad  c_Bu   cBdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_AdD c_BuD  cBd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //
  //     if(imp==1)		{ Flip1 = QN(-1,-1); Flip2 = QN(1, 1); }
  //     else if(imp == 2) 	{ Flip1 = QN(-2, 0); Flip2 = QN(2, 0); }
  //     else if(imp == 3) 	{ Flip1 = QN(-1, 1); Flip2 = QN(1,-1); }
  //
  //     ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //     Index("m ILink ",3), QN( 0,0),
  //     Index("mflip 1" ,1), Flip1,
  //     Index("mflip 2" ,1), Flip2	  );
  //   }
  //
  //   //first Impurity site
  //   for(int impIndx=1;impIndx<=1;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site) * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second and third Impurity site
  //   for(int impIndx=2;impIndx<=3;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     if(impIndx==2){
  //       W += sites_.op("Ck",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)* ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("Ck*p",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)* ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //last impurity
  //   for(int impIndx=NArms_; impIndx<=NArms_; impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(2);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5);
  //
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_AB_v1( const std::vector<IQIndex>& ArmImpLinks ){
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_Ad  c_Bu   cBdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_AdD c_BuD  cBd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //
  //     if(imp==1)		{ Flip1 = QN(-1,-1); Flip2 = QN(1, 1); }
  //     else if(imp == 2) 	{ Flip1 = QN(-2, 0); Flip2 = QN(2, 0); }
  //     else if(imp == 3) 	{ Flip1 = QN(-1, 1); Flip2 = QN(1,-1); }
  //
  //     if(imp<=4){
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //         Index("m ILink ",3), QN( 0,0),
  //         Index("mflip 1" ,1), Flip1,
  //         Index("mflip 2" ,1), Flip2	  );
  //     }
  //     else {
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp), Index("mIlink",1),QN(0,0));
  //     }
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site)   * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second and third Impurity site
  //   for(int impIndx=2;impIndx<=3;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     if(impIndx==2){
  //       W += sites_.op("Ck",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)* ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("Ck*p",site)* ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site) * ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //fourth impurity
  //   {
  //     int impIndx=4;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(2)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3)*ILinkDn(1);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4)*ILinkDn(1);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5)*ILinkDn(1);
  //
  //   }
  //
  //   //fifth impurity
  //   {
  //     int impIndx=5;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //   }
  //
  //   //sixth impurity
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_BC_v1( const std::vector<IQIndex>& ArmImpLinks ){
  //
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_BuD  c_Bd  c_Cu   cCdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
  //     //flip 2 contains QNs of c_Bu   c_BdD c_CuD  cCd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //
  //     if(imp==3)		      { Flip1 = QN(-1,-1); Flip2 = QN(1, 1); }
  //     else if(imp == 4) 	{ Flip1 = QN(-2, 0); Flip2 = QN(2, 0); }
  //     else if(imp == 5) 	{ Flip1 = QN(-1, 1); Flip2 = QN(1,-1); }
  //
  //     if(imp>2){
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //         Index("m ILink ",3), QN( 0,0),
  //         Index("mflip 1" ,1), Flip1,
  //         Index("mflip 2" ,1), Flip2	  );
  //     }
  //     else {
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp), Index("mIlink",1),QN(0,0));
  //     }
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //
  //     W += sites_.op("Id",site)* ALink(1)*ILink(1);
  //   }
  //
  //   //second Impurity site
  //   {
  //     int impIndx=2;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag(ImpLinks.at(impIndx-1));
  //     IQIndex ILinkDn = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W += sites_.op("Id",site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
  //   }
  //
  //   //third Impurity site
  //   {
  //     int impIndx=3;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx) );
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILinkDn(1)*ILinkUp(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILinkDn(2)*ILinkUp(1)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkDn(3)*ILinkUp(1)*c1;
  //
  //     W += sites_.op("CkD",site)   * ALink(2)*ILinkDn(4)*ILinkUp(1)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILinkDn(5)*ILinkUp(1)*c2;
  //   }
  //
  //   //fourth and fifth Impurity site
  //   for(int impIndx=4;impIndx<=5;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     if(impIndx==4){
  //       W += sites_.op("Ck",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)* ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("Ck*p",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)  * ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //sixth impurity site
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(2);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5);
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_AC_v1( const std::vector<IQIndex>& ArmImpLinks ){
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_Ad  c_Cu   cCdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_AdD c_CuD  cCd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //
  //     if(imp==1)		                          { Flip1 = QN(-1,-1); Flip2 = QN(1, 1); }
  //     else if(imp == 2 || imp ==3 || imp==4) 	{ Flip1 = QN(-2, 0); Flip2 = QN(2, 0); }
  //     else if(imp == 5) 	                    { Flip1 = QN(-1, 1); Flip2 = QN(1,-1); }
  //
  //
  //     ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //       Index("m ILink ",3), QN( 0,0),
  //       Index("mflip 1" ,1), Flip1,
  //       Index("mflip 2" ,1), Flip2	  );
  //
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site)   * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second Impurity site
  //   {
  //     int impIndx=2;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //   }
  //
  //   //third and fourth impurity
  //   for(int impIndx=3; impIndx<=4; ++impIndx){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site) * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //
  //   }
  //
  //   //fifth impurity site
  //   {
  //     int impIndx=5;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("CkD",site)   * ALink(2)*ILinkUp(5)*ILinkDn(5);
  //
  //   }
  //
  //   //sixth impurity site
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(2);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5);
  //
  //   }
  //
  // }
  //
  //
  //
  // void AIM_SpinflipTevo:: MakeTwoOrbitalMPOv2( const std::vector<IQIndex>& ArmImpLinks ){
  //
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)
  //
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //
  //     if(imp==1)	      	{ Flip1 = QN(-1,-1); Flip2 = QN( 1, 1); }
  //     else if(imp == 2) 	{ Flip1 = QN( 0,-2); Flip2 = QN( 0, 2); }
  //     else if(imp == 3) 	{ Flip1 = QN( 1,-1); Flip2 = QN(-1, 1); }
  //
  //     ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //     Index("m ILink ",3), QN( 0,0),
  //     Index("mflip 1" ,1), Flip1,
  //     Index("mflip 2" ,1), Flip2	  );
  //   }
  //
  //   //first Impurity site
  //   for(int impIndx=1;impIndx<=1;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 =  Complex_i*sin(dt_*J_);
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site) * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second and third Impurity site
  //   for(int impIndx=2;impIndx<=3;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     if(impIndx==2){
  //       W += sites_.op("N",site)    * ALink(1)       *ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("One-N",site)* ALink(1)       *ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("CkD",site)  * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("Ck",site)   * ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("One-N",site)* ALink(1)       *ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("N",site)    * ALink(1)       *ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("Ck*p",site) * ALink(maxAlink)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)  * ALink(maxAlink)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //last impurity
  //   for(int impIndx=NArms_; impIndx<=NArms_; impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3);
  //     W += sites_.op("Ck",site)   * ALink(1)*ILinkUp(4);
  //     W += sites_.op("CkD",site)    * ALink(1)*ILinkUp(5);
  //
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_AB_v2( const std::vector<IQIndex>& ArmImpLinks ){
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)
  //
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //     if(imp==1)	      	{ Flip1 = QN(-1,-1); Flip2 = QN( 1, 1); }
  //     else if(imp == 2) 	{ Flip1 = QN( 0,-2); Flip2 = QN( 0, 2); }
  //     else if(imp == 3) 	{ Flip1 = QN( 1,-1); Flip2 = QN(-1, 1); }
  //
  //     if(imp<=4){
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //         Index("m ILink ",3), QN( 0,0),
  //         Index("mflip 1" ,1), Flip1,
  //         Index("mflip 2" ,1), Flip2	  );
  //     }
  //     else {
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp), Index("mIlink",1),QN(0,0));
  //     }
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 =  Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site)   * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second and third Impurity site
  //   for(int impIndx=2;impIndx<=3;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     if(impIndx==2){
  //       W += sites_.op("N",site)     * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("Ck*p",site)  * ALink(2)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)   * ALink(2)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //fourth impurity
  //   {
  //     int impIndx=4;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(1);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(4)*ILinkDn(1);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(5)*ILinkDn(1);
  //
  //   }
  //
  //   //fifth impurity
  //   {
  //     int impIndx=5;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //   }
  //
  //   //sixth impurity
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_BC_v2( const std::vector<IQIndex>& ArmImpLinks ){
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)
  //
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //     if(imp==3)		      { Flip1 = QN(-1,-1); Flip2 = QN( 1, 1); }
  //     else if(imp == 4) 	{ Flip1 = QN( 0,-2); Flip2 = QN( 0, 2); }
  //     else if(imp == 5) 	{ Flip1 = QN( 1,-1); Flip2 = QN(-1, 1); }
  //
  //     if(imp>2){
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //         Index("m ILink ",3), QN( 0,0),
  //         Index("mflip 1" ,1), Flip1,
  //         Index("mflip 2" ,1), Flip2	  );
  //     }
  //     else {
  //       ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp), Index("mIlink",1),QN(0,0));
  //     }
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //
  //     W += sites_.op("Id",site)* ALink(1)*ILink(1);
  //   }
  //
  //   //second Impurity site
  //   {
  //     int impIndx=2;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1)) ;
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)   ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W += sites_.op("Id",site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
  //   }
  //
  //   //third Impurity site
  //   {
  //     int impIndx=3;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx) );
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILinkDn(1)*ILinkUp(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILinkDn(2)*ILinkUp(1)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkDn(3)*ILinkUp(1)*c1;
  //     W += sites_.op("CkD",site)   * ALink(2)*ILinkDn(4)*ILinkUp(1)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILinkDn(5)*ILinkUp(1)*c2;
  //   }
  //
  //   //fourth and fifth Impurity site
  //   for(int impIndx=4;impIndx<=5;impIndx++){
  //     int site = H.ImpSite(impIndx);
  //     int maxAlink = impIndx%2+1;       //this is the index of Alink for the spinfilp operators, since they need fermi operators
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)      * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     if(impIndx==4){
  //       W += sites_.op("N",site)     * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //     }
  //     else {
  //       W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //       W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //       W += sites_.op("Ck*p",site)  * ALink(2)*ILinkUp(4)*ILinkDn(4);
  //       W += sites_.op("CkD",site)   * ALink(2)*ILinkUp(5)*ILinkDn(5);
  //     }
  //   }
  //
  //   //sixth impurity site
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(4);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(5);
  //   }
  //
  // }
  //
  // void AIM_SpinflipTevo:: MakeThreeOrbitalMPO_AC_v2( const std::vector<IQIndex>& ArmImpLinks ){
  //   std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);
  //
  //   for(int imp=1;imp< NArms_;imp++){
  //     QN Flip1,Flip2;
  //     //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
  //     //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)
  //
  //     //c_up^D: has a change in bond indices by (-1,-1)
  //     //c_up  : has a change in bond indices by ( 1, 1)
  //
  //     //c_dn^D: has a change in bond indices by ( 1,-1)
  //     //c_dn  : has a change in bond indices by (-1, 1)
  //
  //     if(imp==1)		                          { Flip1 = QN(-1,-1); Flip2 = QN( 1, 1); }
  //     else if(imp == 2 || imp ==3 || imp==4) 	{ Flip1 = QN( 0,-2); Flip2 = QN( 0, 2); }
  //     else if(imp == 5) 	                    { Flip1 = QN( 1,-1); Flip2 = QN(-1, 1); }
  //
  //
  //     ImpLinks.at(imp) = IQIndex( nameint("M ILink ",imp),
  //       Index("m ILink ",3), QN( 0,0),
  //       Index("mflip 1" ,1), Flip1,
  //       Index("mflip 2" ,1), Flip2	  );
  //
  //   }
  //
  //   //first Impurity site
  //   {
  //     int impIndx=1;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILink = ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );
  //     Complex c1 = cos(dt_*J_)-1. , c2 = -Complex_i*sin(dt_*J_);
  //
  //     W += sites_.op("Id",site)    * ALink(1)*ILink(1);
  //     W += sites_.op("N" ,site)    * ALink(1)*ILink(2)*c1;
  //     W += sites_.op("One-N",site) * ALink(1)*ILink(3)*c1;
  //
  //     W += sites_.op("CkD",site)   * ALink(2)*ILink(4)*c2;
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILink(5)*c2;
  //   }
  //
  //   //second and third Impurity site
  //   {
  //     int impIndx=2;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag(ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx);
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //
  //
  //     //Ids
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //   }
  //
  //   //third and fourth impurity
  //   for(int impIndx=3; impIndx<=4; ++impIndx){
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site) * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("Id",site) * ALink(1)*ILinkUp(5)*ILinkDn(5);
  //
  //   }
  //
  //   //fifth
  //   {
  //     int impIndx=5;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //     IQIndex ILinkDn =      ImpLinks.at(impIndx)    ;
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1)*ILinkDn(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2)*ILinkDn(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3)*ILinkDn(3);
  //     W += sites_.op("Ck*p",site)  * ALink(2)*ILinkUp(4)*ILinkDn(4);
  //     W += sites_.op("CkD",site)   * ALink(2)*ILinkUp(5)*ILinkDn(5);
  //
  //   }
  //
  //   //sixth impurity
  //   {
  //     int impIndx=6;
  //     int site = H.ImpSite(impIndx);
  //     IQTensor& W= H.Anc(site);
  //
  //     IQIndex ALink   = dag( ArmImpLinks.at(impIndx));
  //     IQIndex ILinkUp = dag( ImpLinks.at(impIndx-1) );
  //
  //     W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );
  //
  //     W  = sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
  //     W += sites_.op("One-N",site) * ALink(1)*ILinkUp(2);
  //     W += sites_.op("N",site)     * ALink(1)*ILinkUp(3);
  //     W += sites_.op("Ck",site)    * ALink(1)*ILinkUp(4);
  //     W += sites_.op("CkD",site)   * ALink(1)*ILinkUp(5);
  //
  //   }
  //
  // }
  //
  //
  //
  //

}; //namespace itensor
