#include "forktps/fork/Tevo/SFTevo.hpp"
#include <cmath>
#include <complex>
#include <itensor/arrow.h>
#include <itensor/itensor_impl.h>
#include <utility>

using namespace itensor;

namespace forktps {

  std::string to_string(SFPH sfph) {
    if (sfph == SFPH::SF)
      return "spin-flip";
    else
      return "pair-hopping";
  }

  // generates the two coefficients needed for the time evolution of the SFPH terms
  // for a time evolution operator e(-i*H*dt) (note "-" sign). Also note that the
  // pair hopping terms have -J when ftps fermionic order is taken into account (see PRX 7,031013 )
  std::pair<Complex, Complex> SFPH_coefficients(Complex dt, double J, SFPH sfph) {
    if (sfph == SFPH::PH) J = -J;

    if (std::abs(std::imag(dt)) > 1E-15) {
      //real time evolution
      double dtval = -std::imag(dt);
      return std::make_pair(cos(dtval * J) - 1, Complex_i * sin(dtval * J));
    } else {
      double dtval = -std::real(dt);
      return std::make_pair(cosh(dtval * J) - 1., sinh(dtval * J));
    }
  }

  SFPH_TevoMPO::SFPH_TevoMPO(Complex dt, double J, SFPH sfph, std::pair<int, int> ij, const AIM_ForkSites &sites)
     : sites(sites), sfph(sfph), J(J), dt(dt), ij(std::move(ij)), H(sites, sites.NBathVec()) {
    // check if dt is purely imaginary or purely real
    if (std::abs(std::imag(dt)) > 1E-15 && std::abs(std::real(dt)) > 1E-15) Error("SFPH_TevoMPO: dt must be either purely real or purely imaginary");

    auto Norbs = std::round(H.NArms() / 2);
    // check valid values of ij
    if (ij.first > Norbs || ij.first <= 0 || ij.second > Norbs || ij.second <= 0 || ij.first == ij.second) {
      std::cout << ij.first << " " << ij.second << std::endl;
      Error("SFPH_TevoMPO: Invalid values for ij ");
    }

    // swap ij if i > j
    if (ij.first > ij.second) std::swap(ij.first, ij.second);
  }

  void SFPH_TevoMPO::init_() {
    //the combination AB etc stands for which orbitals are time evolved AB means first and second orbital ....
    //v1 and v2 define if the spinflip or the pairhopping term is used.

    auto ArmImpLinks = MakeArmMPOs();
    //currently this only works for NArms == 10

    if (sfph == SFPH::SF)
      MPO_SF(ArmImpLinks);
    else
      MPO_PH(ArmImpLinks);

    return;
  }

  std::vector<Index> SFPH_TevoMPO::MakeArmMPOs() {
    std::vector<Index> ArmImpLinks(1);
    int firstUp  = 2 * ij.first - 1;
    int secondDn = 2 * ij.second;

    for (auto arm : range1(H.NArms())) {
      int NBath = H.NBath(arm);
      std::vector<Index> ArmLinks(NBath + 1);

      bool nonTrivialArm = (arm % 2 == 1 && arm >= firstUp && arm <= secondDn);
      int dimArmLink     = nonTrivialArm ? 2 : 1;
      QN qn0             = -div(sites.op("Id", H.ImpSite(1)));

      // create links
      for (auto l : range1(NBath)) {
        auto indxName  = (l == NBath) ? Names::TAGSIB : Names::TAGSB;
        ArmLinks.at(l) = Index(qn0, dimArmLink, indxName);
      }

      {
        int n      = 1;
        int site   = H.ArmToSite(arm, n);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(n);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);

        W += sites.op("Id", site) * setElt(left(1));
        if (nonTrivialArm) W += sites.op("p", site) * setElt(left(2));
      }

      for (int n = 2; n <= NBath; n++) {

        int site   = H.ArmToSite(arm, n);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(n - 1));
        Index left  = ArmLinks.at(n);

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);

        W += sites.op("Id", site) * setElt(left(1), right(1));

        if (nonTrivialArm) W += sites.op("p", site) * setElt(left(2), right(2));
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;
  }

  void SFPH_TevoMPO::MPO_SF(const std::vector<Index> &ArmImpLinks) {
    auto ImpLinks = MakeImpLinks();
    // coefficients
    auto [c1, c2] = SFPH_coefficients(dt, J, sfph);

    int firstUp  = 2 * ij.first - 1;
    int firstDn  = firstUp + 1;
    int secondUp = 2 * ij.second - 1;
    int secondDn = secondUp + 1;

    // all sites before orbital i
    for (auto imp : range1(firstUp - 1)) {

      int site = H.ImpSite(imp);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkDn = ImpLinks[imp];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkDn);
      W += sites.op("Id", site) * setElt(ALink(1), ILinkDn(1));

      if (imp != 1) {
        Index ILinkUp = dag(ImpLinks[imp - 1]);
        W *= setElt(ILinkUp(1));
      }
    }

    // orb i spin up
    {
      int site = H.ImpSite(firstUp);

      Index ALink   = dag(ArmImpLinks[firstUp]);
      Index ILinkDn = ImpLinks[firstUp];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkDn(1));
      W += sites.op("N", site) * setElt(ALink(1), ILinkDn(2)) * c1;
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkDn(3)) * c1;

      W += sites.op("CkD", site) * setElt(ALink(2), ILinkDn(4)) * c2;
      W += sites.op("Ck*p", site) * setElt(ALink(2), ILinkDn(5)) * c2;

      if (firstUp != 1) {
        auto ILinkUp = dag(ImpLinks[firstUp - 1]);
        W *= setElt(ILinkUp(1));
      }
    }

    // orbital i spin down
    {
      int site = H.ImpSite(firstDn);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[firstDn]);
      Index ILinkUp = dag(ImpLinks[firstDn - 1]);
      Index ILinkDn = ImpLinks[firstDn];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(2));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(3), ILinkDn(3));
      W += sites.op("Ck", site) * setElt(ALink(1), ILinkUp(4), ILinkDn(4));
      W += sites.op("CkD", site) * setElt(ALink(1), ILinkUp(5), ILinkDn(5));
    }

    // all sites in between (if i > j+1)
    for (int imp = firstDn + 1; imp < secondUp; ++imp) {

      int site = H.ImpSite(imp);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkUp = dag(ImpLinks[imp - 1]);
      Index ILinkDn = ImpLinks[imp];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);
      for (auto i : range1(5)) W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(i), ILinkDn(i));
    }

    // orbital j spin up
    {
      int site = H.ImpSite(secondUp);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[secondUp]);
      Index ILinkUp = dag(ImpLinks[secondUp - 1]);
      Index ILinkDn = ImpLinks[secondUp];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(2));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(3), ILinkDn(3));
      //C - terms need p here -> ALink(2)
      W += sites.op("Ck*p", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(4));
      W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(5));
    }

    // orbital j spin down
    {
      int site = H.ImpSite(secondDn);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[secondDn]);
      Index ILinkUp = dag(ImpLinks[secondDn - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(2));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(3));
      W += sites.op("CkD", site) * setElt(ALink(1), ILinkUp(4));
      W += sites.op("Ck", site) * setElt(ALink(1), ILinkUp(5));

      // add link downwards if it is not the last site
      if (secondDn != H.NArms()) {
        auto ILinkDn = ImpLinks[secondDn];
        W *= setElt(ILinkDn(1));
      }
    }

    // all other links
    for (int imp = secondDn + 1; imp <= H.NArms(); ++imp) {

      int site   = H.ImpSite(imp);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkUp = dag(ImpLinks[imp - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);
      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1));

      if (imp != H.NArms()) {
        auto ILinkDn = ImpLinks[imp];
        W *= setElt(ILinkDn(1));
      }
    }
  }

  void SFPH_TevoMPO::MPO_PH(const std::vector<Index> &ArmImpLinks) {
    auto ImpLinks = MakeImpLinks();

    // coefficients
    auto [c1, c2] = SFPH_coefficients(dt, J, sfph);

    int firstUp  = 2 * ij.first - 1;
    int firstDn  = firstUp + 1;
    int secondUp = 2 * ij.second - 1;
    int secondDn = secondUp + 1;

    // all sites before orbital i
    for (auto imp : range1(firstUp - 1)) {

      int site = H.ImpSite(imp);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkDn = ImpLinks[imp];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkDn);
      W += sites.op("Id", site) * setElt(ALink(1), ILinkDn(1));

      if (imp != 1) {
        Index ILinkUp = dag(ImpLinks[imp - 1]);
        W *= setElt(ILinkUp(1));
      }
    }

    // orb i spin up
    {
      int site = H.ImpSite(firstUp);

      Index ALink   = dag(ArmImpLinks[firstUp]);
      Index ILinkDn = ImpLinks[firstUp];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkDn(1));
      W += sites.op("N", site) * setElt(ALink(1), ILinkDn(2)) * c1;
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkDn(3)) * c1;

      W += sites.op("CkD", site) * setElt(ALink(2), ILinkDn(4)) * c2;
      W += sites.op("Ck*p", site) * setElt(ALink(2), ILinkDn(5)) * c2;

      if (firstUp != 1) {
        auto ILinkUp = dag(ImpLinks[firstUp - 1]);
        W *= setElt(ILinkUp(1));
      }
    }

    // orbital i spin down
    {
      int site = H.ImpSite(firstDn);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[firstDn]);
      Index ILinkUp = dag(ImpLinks[firstDn - 1]);
      Index ILinkDn = ImpLinks[firstDn];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(2));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(3), ILinkDn(3));
      W += sites.op("CkD", site) * setElt(ALink(1), ILinkUp(4), ILinkDn(4));
      W += sites.op("Ck", site) * setElt(ALink(1), ILinkUp(5), ILinkDn(5));
    }

    // all sites in between (if i > j+1)
    for (int imp = firstDn + 1; imp < secondUp; ++imp) {

      int site = H.ImpSite(imp);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkUp = dag(ImpLinks[imp - 1]);
      Index ILinkDn = ImpLinks[imp];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);
      for (auto i : range1(5)) W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(i), ILinkDn(i));
    }

    // orbital j spin up
    {
      int site = H.ImpSite(secondUp);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[secondUp]);
      Index ILinkUp = dag(ImpLinks[secondUp - 1]);
      Index ILinkDn = ImpLinks[secondUp];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(2));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(3), ILinkDn(3));
      //C - terms need p here -> ALink(2)
      W += sites.op("Ck*p", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(4));
      W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(5));
    }

    // orbital j spin down
    {
      int site = H.ImpSite(secondDn);

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[secondDn]);
      Index ILinkUp = dag(ImpLinks[secondDn - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1));
      W += sites.op("One-N", site) * setElt(ALink(1), ILinkUp(2));
      W += sites.op("N", site) * setElt(ALink(1), ILinkUp(3));
      W += sites.op("Ck", site) * setElt(ALink(1), ILinkUp(4));
      W += sites.op("CkD", site) * setElt(ALink(1), ILinkUp(5));

      // add link downwards if it is not the last site
      if (secondDn != H.NArms()) {
        auto ILinkDn = ImpLinks[secondDn];
        W *= setElt(ILinkDn(1));
      }
    }

    // all other links
    for (int imp = secondDn + 1; imp <= H.NArms(); ++imp) {

      int site   = H.ImpSite(imp);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[imp]);
      Index ILinkUp = dag(ImpLinks[imp - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);
      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1));

      if (imp != H.NArms()) {
        auto ILinkDn = ImpLinks[imp];
        W *= setElt(ILinkDn(1));
      }
    }
  }

  std::vector<Index> SFPH_TevoMPO::MakeImpLinks() {
    std::vector<Index> ImpLinks(H.NArms() + 1);

    QN qn0  = -div(sites.op("Id", H.ImpSite(1)));
    QN cup  = -div(sites.op("Ck", H.ImpSite(1)));
    QN cupD = -div(sites.op("CkD", H.ImpSite(1)));
    QN cdn  = -div(sites.op("Ck", H.ImpSite(2)));
    QN cdnD = -div(sites.op("CkD", H.ImpSite(2)));

    int firstUp  = 2 * ij.first - 1;
    int firstDn  = firstUp + 1;
    int secondUp = 2 * ij.second - 1;
    int secondDn = secondUp + 1;

    // all links before first orbital
    for (auto imp : range1(firstUp - 1)) { ImpLinks.at(imp) = Index(qn0, 1, Out, "ImpLink"); }

    // link between i spin up and i spin dn is the same for sf and ph
    ImpLinks.at(firstUp) = Index(qn0, 3, cupD, 1, cup, 1, Out, Names::TAGSI);

    if (sfph == SFPH::SF) {

      // link between i spin down and the next site
      ImpLinks.at(firstDn) = Index(qn0, 3, cupD + cdn, 1, cup + cdnD, 1, Out, Names::TAGSI);

      // all links in between (if i > j+1)
      for (int imp = firstDn + 1; imp < secondUp; ++imp) { ImpLinks.at(imp) = Index(qn0, 3, cupD + cdn, 1, cup + cdnD, 1, Out, Names::TAGSI); }

      // link between j spin up and j spin down
      ImpLinks.at(secondUp) = Index(qn0, 3, cupD + cdn + cup, 1, cup + cdnD + cupD, 1, Out, Names::TAGSI);

    } else { //sfph == PH

      // link between i spin down and the next site
      ImpLinks.at(firstDn) = Index(qn0, 3, cupD + cdnD, 1, cup + cdn, 1, Out, Names::TAGSI);

      // all links in between (if i > j+1)
      for (int imp = firstDn + 1; imp < secondUp; ++imp) { ImpLinks.at(imp) = Index(qn0, 3, cupD + cdnD, 1, cup + cdn, 1, Out, Names::TAGSI); }

      // link between j spin up and j spin down
      ImpLinks.at(secondUp) = Index(qn0, 3, cupD + cdnD + cup, 1, cup + cdn + cupD, 1, Out, Names::TAGSI);
    }

    // all other links
    for (int imp = secondDn; imp < H.NArms(); ++imp) { ImpLinks.at(imp) = Index(qn0, 1, Out, Names::TAGSI); }

    return ImpLinks;
  }
  //

} //namespace forktps
