
#include "itensor/mps/siteset.h"
//#include "itensor/mps/mps.h"
#include "itensor/iqtensor.h"

#include "../typenames.h"

using namespace itensor;

namespace itensor {

  class AIM_SpinflipTevo {
    public:
    AIM_SpinflipTevo(const SiteSet &sites, double J, double dt, int NArms, int version, int orb1, int orb2, ivec Nbath = ivec(0));
    //this function produces the MPO for orbital orb with all orbitals below (o>orb)
    AIM_SpinflipTevo(const SiteSet &sites, double J, double dt, int NArms, int version, int orb, ivec Nbath = ivec(0));

    operator ForkTPO() {
      init_();
      return H;
    }

    void MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks);

    //defines the time evolution operator of e^{-i*H*dt} for the
    //spinflip and pairhopping terms - note that giving the constructor
    //a positive dt means time evolution forward in time with e^{-i*H*dt}

    void MakeTwoOrbitalMPOv1(const std::vector<IQIndex> &ArmImpLinks);
    void MakeTwoOrbitalMPOv2(const std::vector<IQIndex> &ArmImpLinks);

    //For each orbital combination the MPO looks very similar to the
    //2 band case:
    //AB: has the operators on 1-4 and then identities on orbital 5 and 6
    //BC: has the operators on 3-6 and identities on orbitals 1 and 2
    //AC: has operator on 1-2 and 5-6 while having identities in between

    //v1 is for the spinflip terms while v2 is for the pair-hopping terms
    void MakeThreeOrbitalMPO_AB_v1(const std::vector<IQIndex> &ArmImpLinks);
    void MakeThreeOrbitalMPO_BC_v1(const std::vector<IQIndex> &ArmImpLinks);
    void MakeThreeOrbitalMPO_AC_v1(const std::vector<IQIndex> &ArmImpLinks);

    void MakeThreeOrbitalMPO_AB_v2(const std::vector<IQIndex> &ArmImpLinks);
    void MakeThreeOrbitalMPO_BC_v2(const std::vector<IQIndex> &ArmImpLinks);
    void MakeThreeOrbitalMPO_AC_v2(const std::vector<IQIndex> &ArmImpLinks);

    //for 5 orbitals I currently use a different strategy:
    //I produce the time evolutin operator from one orbital
    //to all orbitals below in one go
    void MakeFiveOrbitalMPO_v1(const std::vector<IQIndex> &ArmImpLinks);
    void MakeFiveOrbitalMPO_v2(const std::vector<IQIndex> &ArmImpLinks);

    private:
    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;
    int version_;

    int orb1_;
    int orb2_;

    double J_;
    double dt_;
    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

  inline AIM_SpinflipTevo::AIM_SpinflipTevo(const SiteSet &sites, double J, double dt, int NArms, int version, int orb1, int orb2, ivec Nbath)
     : sites_(sites), initted_(false) {
    J_       = J;
    dt_      = dt;
    NArms_   = NArms;
    version_ = version;
    orb1_    = orb1;
    orb2_    = orb2;

    if (Nbath.size() == 0) {
      H = ForkTPO(sites_, NArms_);
    } else {
      H = ForkTPO(sites_, NArms_, Nbath);
    }
  }

  inline AIM_SpinflipTevo::AIM_SpinflipTevo(const SiteSet &sites, double J, double dt, int NArms, int version, int orb, ivec Nbath)
     : sites_(sites), initted_(false) {
    J_       = J;
    dt_      = dt;
    NArms_   = NArms;
    version_ = version;
    orb1_    = orb;
    orb2_    = 0;

    int Norbs = int(NArms / 2);
    if (orb > Norbs - 1) {
      std::cout << " Number of chains: " << NArms << ", therefore there are " << Norbs << " Orbitals and orb = " << orb << std::endl;
      Error("AIM_SpinflipTevo: orb must be smaller than total number of orbitals");
    }

    if (Nbath.size() == 0) {
      H = ForkTPO(sites_, NArms_);
    } else {
      H = ForkTPO(sites_, NArms_, Nbath);
    }
  }

  void inline AIM_SpinflipTevo::init_() {
    if (initted_) return;

    std::vector<IQIndex> ArmImpLinks;
    ArmImpLinks.resize(0);

    //the combination AB etc stands for which orbitals are time evolved AB means first and second orbital ....
    //v1 and v2 define if the spinflip or the pairhopping term is used.

    MakeArmMPOs(ArmImpLinks);
    //currently this only works for NArms == 10
    if (orb2_ == 0) {
      if (NArms_ != 10) { Print("SF-tevo MPO not written for NArms != 10, it should work tough! So take care!!"); }
      if (version_ == 1) {
        MakeFiveOrbitalMPO_v1(ArmImpLinks);
      } else {
        MakeFiveOrbitalMPO_v2(ArmImpLinks);
      }
      return;
    }

    if (version_ == 1) {
      if (NArms_ == 4) {
        MakeTwoOrbitalMPOv1(ArmImpLinks);
      } else if (NArms_ == 6) {
        if (orb1_ == 1 && orb2_ == 2) {
          MakeThreeOrbitalMPO_AB_v1(ArmImpLinks);
        } else if (orb1_ == 1 && orb2_ == 3) {
          MakeThreeOrbitalMPO_AC_v1(ArmImpLinks);
        } else if (orb1_ == 2 && orb2_ == 3) {
          MakeThreeOrbitalMPO_BC_v1(ArmImpLinks);
        } else {
          Print(orb1_);
          Print(orb2_);
          Error("Cant produce spinflip tevo with this orbital combination");
        }
      } else {
        Print(NArms_);
        Error("AIM_ForkTPO: Cannot create AIM_ForkTPO with this number of orbitals");
      }
    } else if (version_ == 2) {
      if (NArms_ == 4) {
        MakeTwoOrbitalMPOv2(ArmImpLinks);
      } else if (NArms_ == 6) {
        if (orb1_ == 1 && orb2_ == 2) {
          MakeThreeOrbitalMPO_AB_v2(ArmImpLinks);
        } else if (orb1_ == 1 && orb2_ == 3) {
          MakeThreeOrbitalMPO_AC_v2(ArmImpLinks);
        } else if (orb1_ == 2 && orb2_ == 3) {
          MakeThreeOrbitalMPO_BC_v2(ArmImpLinks);
        } else {
          Print(orb1_);
          Print(orb2_);
          Error("Cant produce spinflip tevo with this orbital combination");
        }
      } else {
        Print(NArms_);
        Error("AIM_ForkTPO: Cannot create AIM_ForkTPO with this number of orbitals");
      }
    } else {
      Print(version_);
      Error("init AIM_SpinflipTevo error in version!");
    }

    initted_ = true;
  }

  void AIM_SpinflipTevo::MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks) {

    ArmImpLinks.resize(0);
    ArmImpLinks.push_back(IQIndex());

    for (int arm = 1; arm <= NArms_; arm++) {
      int NBath = H.NBath(arm);
      std::vector<IQIndex> InterArmLinks(NBath + 1);
      int dimArmLink = arm % 2 + 1;
      for (int l = 1; l <= NBath; l++) {

        std::stringstream s, sId, sC, sCD;
        s << "H ARM " << arm << " l " << l;
        sId << "Diag arm" << arm << " l" << l;

        InterArmLinks.at(l) = IQIndex(s.str(), Index(sId.str(), dimArmLink), QN(0, 0));
      }

      for (int n = 1; n <= 1; n++) {
        int site     = H.ArmToSite(arm, n);
        IQTensor &W  = H.Anc(site);
        IQIndex left = InterArmLinks.at(n);
        W            = IQTensor(dag(sites_.si(site)), sites_.siP(site), left);

        W += sites_.op("Id", site) * left(1);
        if (arm % 2 == 1) { W += sites_.op("p", site) * left(2); }
      }
      for (int n = 2; n <= NBath; n++) {

        int site    = H.ArmToSite(arm, n);
        IQTensor &W = H.Anc(site);

        IQIndex right = dag(InterArmLinks.at(n - 1));
        IQIndex left  = InterArmLinks.at(n);

        W = IQTensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        W += sites_.op("Id", site) * right(1) * left(1);
        if (arm % 2 == 1) { W += sites_.op("p", site) * left(2) * right(2); }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }
  }

  void AIM_SpinflipTevo::MakeTwoOrbitalMPOv1(const std::vector<IQIndex> &ArmImpLinks) {

    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_Ad  c_Bu   cBdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_AdD c_BuD  cBd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2) {
        Flip1 = QN(-2, 0);
        Flip2 = QN(2, 0);
      } else if (imp == 3) {
        Flip1 = QN(-1, 1);
        Flip2 = QN(1, -1);
      }

      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
    }

    //first Impurity site
    for (int impIndx = 1; impIndx <= 1; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second and third Impurity site
    for (int impIndx = 2; impIndx <= 3; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      if (impIndx == 2) {
        W += sites_.op("Ck", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("Ck*p", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //last impurity
    for (int impIndx = NArms_; impIndx <= NArms_; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_AB_v1(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_Ad  c_Bu   cBdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_AdD c_BuD  cBd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2) {
        Flip1 = QN(-2, 0);
        Flip2 = QN(2, 0);
      } else if (imp == 3) {
        Flip1 = QN(-1, 1);
        Flip2 = QN(1, -1);
      }

      if (imp <= 4) {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
      } else {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("mIlink", 1), QN(0, 0));
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second and third Impurity site
    for (int impIndx = 2; impIndx <= 3; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      if (impIndx == 2) {
        W += sites_.op("Ck", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("Ck*p", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //fourth impurity
    {
      int impIndx = 4;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(1);
    }

    //fifth impurity
    {
      int impIndx = 5;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //sixth impurity
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_BC_v1(const std::vector<IQIndex> &ArmImpLinks) {

    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_BuD  c_Bd  c_Cu   cCdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
      //flip 2 contains QNs of c_Bu   c_BdD c_CuD  cCd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 3) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 4) {
        Flip1 = QN(-2, 0);
        Flip2 = QN(2, 0);
      } else if (imp == 5) {
        Flip1 = QN(-1, 1);
        Flip2 = QN(1, -1);
      }

      if (imp > 2) {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
      } else {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("mIlink", 1), QN(0, 0));
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //third Impurity site
    {
      int impIndx = 3;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);
      double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILinkDn(1) * ILinkUp(1);
      W += sites_.op("N", site) * ALink(1) * ILinkDn(2) * ILinkUp(1) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILinkDn(3) * ILinkUp(1) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILinkDn(4) * ILinkUp(1) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkDn(5) * ILinkUp(1) * c2;
    }

    //fourth and fifth Impurity site
    for (int impIndx = 4; impIndx <= 5; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      if (impIndx == 4) {
        W += sites_.op("Ck", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("Ck*p", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //sixth impurity site
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_AC_v1(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_Ad  c_Cu   cCdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_AdD c_CuD  cCd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2 || imp == 3 || imp == 4) {
        Flip1 = QN(-2, 0);
        Flip2 = QN(2, 0);
      } else if (imp == 5) {
        Flip1 = QN(-1, 1);
        Flip2 = QN(1, -1);
      }

      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
    }

    //third and fourth impurity
    for (int impIndx = 3; impIndx <= 4; ++impIndx) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
    }

    //fifth impurity site
    {
      int impIndx = 5;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
    }

    //sixth impurity site
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeTwoOrbitalMPOv2(const std::vector<IQIndex> &ArmImpLinks) {

    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)

      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2) {
        Flip1 = QN(0, -2);
        Flip2 = QN(0, 2);
      } else if (imp == 3) {
        Flip1 = QN(1, -1);
        Flip2 = QN(-1, 1);
      }

      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
    }

    //first Impurity site
    for (int impIndx = 1; impIndx <= 1; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

      W = sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second and third Impurity site
    for (int impIndx = 2; impIndx <= 3; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      if (impIndx == 2) {
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("Ck", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("Ck*p", site) * ALink(maxAlink) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(maxAlink) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //last impurity
    for (int impIndx = NArms_; impIndx <= NArms_; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_AB_v2(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)

      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2) {
        Flip1 = QN(0, -2);
        Flip2 = QN(0, 2);
      } else if (imp == 3) {
        Flip1 = QN(1, -1);
        Flip2 = QN(-1, 1);
      }

      if (imp <= 4) {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
      } else {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("mIlink", 1), QN(0, 0));
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second and third Impurity site
    for (int impIndx = 2; impIndx <= 3; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      if (impIndx == 2) {
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //fourth impurity
    {
      int impIndx = 4;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5) * ILinkDn(1);
    }

    //fifth impurity
    {
      int impIndx = 5;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //sixth impurity
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_BC_v2(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)

      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 3) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 4) {
        Flip1 = QN(0, -2);
        Flip2 = QN(0, 2);
      } else if (imp == 5) {
        Flip1 = QN(1, -1);
        Flip2 = QN(-1, 1);
      }

      if (imp > 2) {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
      } else {
        ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("mIlink", 1), QN(0, 0));
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //third Impurity site
    {
      int impIndx = 3;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);
      double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILinkDn(1) * ILinkUp(1);
      W += sites_.op("N", site) * ALink(1) * ILinkDn(2) * ILinkUp(1) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILinkDn(3) * ILinkUp(1) * c1;
      W += sites_.op("CkD", site) * ALink(2) * ILinkDn(4) * ILinkUp(1) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkDn(5) * ILinkUp(1) * c2;
    }

    //fourth and fifth Impurity site
    for (int impIndx = 4; impIndx <= 5; impIndx++) {
      int site     = H.ImpSite(impIndx);
      int maxAlink = impIndx % 2 + 1; //this is the index of Alink for the spinfilp operators, since they need fermi operators
      IQTensor &W  = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      if (impIndx == 4) {
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
      } else {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      }
    }

    //sixth impurity site
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeThreeOrbitalMPO_AC_v2(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    for (int imp = 1; imp < NArms_; imp++) {
      QN Flip1, Flip2;
      //flip 1 contains QNs of c_AuD  c_AdD  c_Bu   cBd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
      //flip 2 contains QNs of c_Au   c_Ad   c_BuD  cBdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)

      //c_up^D: has a change in bond indices by (-1,-1)
      //c_up  : has a change in bond indices by ( 1, 1)

      //c_dn^D: has a change in bond indices by ( 1,-1)
      //c_dn  : has a change in bond indices by (-1, 1)

      if (imp == 1) {
        Flip1 = QN(-1, -1);
        Flip2 = QN(1, 1);
      } else if (imp == 2 || imp == 3 || imp == 4) {
        Flip1 = QN(0, -2);
        Flip2 = QN(0, 2);
      } else if (imp == 5) {
        Flip1 = QN(1, -1);
        Flip2 = QN(-1, 1);
      }

      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 3), QN(0, 0), Index("mflip 1", 1), Flip1, Index("mflip 2", 1), Flip2);
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W         = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);
      double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(1) * ILink(2) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILink(3) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILink(4) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILink(5) * c2;
    }

    //second
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
    }

    //third and fourth impurity
    for (int impIndx = 3; impIndx <= 4; ++impIndx) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
    }

    //fifth
    {
      int impIndx = 5;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
    }

    //sixth impurity
    {
      int impIndx = 6;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5);
    }
  }

  void AIM_SpinflipTevo::MakeFiveOrbitalMPO_v1(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    int startIndex = 2 * (orb1_ - 1) + 1;
    if (orb1_ >= NArms_ - 2) {
      Print(orb_1);
      Print(NArms_);
      Error("AIM_SpinflipTevo::MakeFiveOrbitalMPO_v1: orb1_ <= NArms-2 must be fullfiled!");
    }

    //links for all the Ids until 2*orb_1
    for (int imp = 1; imp < startIndex; imp++) { ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 1), QN(0, 0)); }
    //c_uD  c_d  c_u   cdD  (0,0) -> (-1,-1) -> (-2,0) -> (-1, 1) -> (0,0)
    //c_u   c_dD c_uD  cd   (0,0) -> ( 1, 1) -> ( 2,0) -> ( 1,-1) -> (0,0)
    //c_up^D: has a change in bond indices by (-1,-1)
    //c_up  : has a change in bond indices by ( 1, 1)

    //c_dn^D: has a change in bond indices by ( 1,-1)
    //c_dn  : has a change in bond indices by (-1, 1)

    {
      int imp          = startIndex;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cD ", 1), QN(-1, -1), Index("c ", 1), QN(1, 1));
    }

    {
      int imp          = startIndex + 1;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink", 4), QN(0, 0), Index("cDc", 1), QN(-2, 0), Index("ccD", 1), QN(2, 0));
    }

    for (int imp = startIndex + 2; imp < NArms_ - 1; imp += 2) {
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDcc", 1), QN(-1, 1), Index("ccDcD", 1), QN(1, -1),
                                 Index("Ns", 2), QN(0, 0), Index("cDc", 1), QN(-2, 0), Index("ccD", 1), QN(2, 0));
    }

    for (int imp = startIndex + 3; imp < NArms_; imp += 2) {
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDc", 1), QN(-2, 0), Index("ccD", 1), QN(2, 0));
    }

    {
      int imp          = NArms_ - 1;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDcc", 1), QN(-1, 1), Index("ccDcD", 1), QN(1, -1));
    }

    //first MPO distinguish whether first impurity site is already non-trivial or not
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      if (orb1_ == 1) {
        //note the minus sign in c2
        double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

        W += sites_.op("Id", site) * ALink(1) * ILink(2);
        W += sites_.op("N", site) * ALink(1) * ILink(3) * c1;
        W += sites_.op("One-N", site) * ALink(1) * ILink(4) * c1;

        W += sites_.op("CkD", site) * ALink(2) * ILink(5) * c2;
        W += sites_.op("Ck*p", site) * ALink(2) * ILink(6) * c2;

      } else {
        W += sites_.op("Id", site) * ALink(1) * ILink(1);
      }
    }

    //add all trivial IDs for the inactive orbitals
    for (int impIndx = 2; impIndx < startIndex; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //if orb1_ != 1 add it
    if (orb1_ != 1) {
      int impIndx = startIndex;
      int site    = H.ImpSite(impIndx);
      double c1 = cosh(dt_ * J_) - 1., c2 = -sinh(dt_ * J_);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(1) * ILinkDn(3) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(1) * ILinkDn(4) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(1) * ILinkDn(5) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(1) * ILinkDn(6) * c2;
    }

    //second nontrivial MPO
    {
      int impIndx = startIndex + 1;
      int site    = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);

      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(6) * ILinkDn(6);
    }

    //third, fifth , ... nontrivial MPO, note they are always the same
    for (int impIndx = startIndex + 2; impIndx < NArms_ - 1; impIndx += 2) {
      int site = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      //C - terms need p here -> ALink(2)
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(6) * ILinkDn(6);

      //keeps the terms from orb1_ since they are needed again below
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(3) * ILinkDn(7);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(4) * ILinkDn(8);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(5) * ILinkDn(9);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(6) * ILinkDn(10);
    }

    //fourth, sixth , ... nontrivial MPO, note they are always the same
    for (int impIndx = startIndex + 3; impIndx < NArms_; impIndx += 2) {
      int site = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //finish interactions and put them to ILinkDn(1)
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5) * ILinkDn(1);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(6) * ILinkDn(1);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(7) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(8) * ILinkDn(4);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(9) * ILinkDn(5);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(10) * ILinkDn(6);
    }

    //last but one impurity
    {
      int impIndx = NArms_ - 1;
      int site    = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      //C - terms need p here -> ALink(2), Ck needs on-site p as well
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(6) * ILinkDn(6);
    }

    //last impurity
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      //finish all terms, note second ID in ILinkUp(2)
      //it gives the 1+... from time evolution
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(6);
    }
  }

  void AIM_SpinflipTevo::MakeFiveOrbitalMPO_v2(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    int startIndex = 2 * (orb1_ - 1) + 1;

    //links for all the Ids until 2*orb_1
    for (int imp = 1; imp < startIndex; imp++) { ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 1), QN(0, 0)); }
    //c_uD  c_dD  c_u   cd  (0,0) -> (-1,-1) -> (0,-2) -> ( 1,-1) -> (0,0)
    //c_u   c_d   c_uD  cdD (0,0) -> ( 1, 1) -> (0, 2) -> (-1, 1) -> (0,0)
    //c_up^D: has a change in bond indices by (-1,-1)
    //c_up  : has a change in bond indices by ( 1, 1)
    //c_dn^D: has a change in bond indices by ( 1,-1)
    //c_dn  : has a change in bond indices by (-1, 1)

    {
      int imp          = startIndex;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cD ", 1), QN(-1, -1), Index("c ", 1), QN(1, 1));
    }

    {
      int imp          = startIndex + 1;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink", 4), QN(0, 0), Index("cDc", 1), QN(0, -2), Index("ccD", 1), QN(0, 2));
    }

    for (int imp = startIndex + 2; imp < NArms_ - 1; imp += 2) {
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDcc", 1), QN(1, -1), Index("ccDcD", 1), QN(-1, 1),
                                 Index("Ns", 2), QN(0, 0), Index("cDc", 1), QN(0, -2), Index("ccD", 1), QN(0, 2));
    }

    for (int imp = startIndex + 3; imp < NArms_; imp += 2) {
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDc", 1), QN(0, -2), Index("ccD", 1), QN(0, 2));
    }

    {
      int imp          = NArms_ - 1;
      ImpLinks.at(imp) = IQIndex(nameint("M ILink ", imp), Index("m ILink ", 4), QN(0, 0), Index("cDcc", 1), QN(1, -1), Index("ccDcD", 1), QN(-1, 1));
    }

    //first MPO distinguish whether first impurity site is already non-trivial or not
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      if (orb1_ == 1) {
        double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

        W += sites_.op("Id", site) * ALink(1) * ILink(2);
        W += sites_.op("N", site) * ALink(1) * ILink(3) * c1;
        W += sites_.op("One-N", site) * ALink(1) * ILink(4) * c1;

        W += sites_.op("CkD", site) * ALink(2) * ILink(5) * c2;
        W += sites_.op("Ck*p", site) * ALink(2) * ILink(6) * c2;

      } else {
        W += sites_.op("Id", site) * ALink(1) * ILink(1);
      }
    }

    //add all trivial IDs for the inactive orbitals
    for (int impIndx = 2; impIndx < startIndex; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);
      W = sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
    }

    //if orb1_ != 1 add it
    if (orb1_ != 1) {
      int impIndx = startIndex;
      int site    = H.ImpSite(impIndx);
      double c1 = cosh(dt_ * J_) - 1., c2 = +sinh(dt_ * J_);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(1) * ILinkDn(3) * c1;
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(1) * ILinkDn(4) * c1;

      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(1) * ILinkDn(5) * c2;
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(1) * ILinkDn(6) * c2;
    }

    //second nontrivial MPO
    {
      int impIndx = startIndex + 1;
      int site    = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);

      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(6) * ILinkDn(6);
    }

    //third, fifth , ... nontrivial MPO, note they are always the same
    for (int impIndx = startIndex + 2; impIndx < NArms_ - 1; impIndx += 2) {
      int site = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      //C - terms need p here -> ALink(2)
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(6) * ILinkDn(6);

      //keeps the terms from orb1_ since they are needed again below
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(3) * ILinkDn(7);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(4) * ILinkDn(8);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(5) * ILinkDn(9);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(6) * ILinkDn(10);
    }

    //fourth, sixth , ... nontrivial MPO, note they are always the same
    for (int impIndx = startIndex + 3; impIndx < NArms_; impIndx += 2) {
      int site = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //finish interactions and put them to ILinkDn(1)
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5) * ILinkDn(1);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(6) * ILinkDn(1);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(7) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(8) * ILinkDn(4);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(9) * ILinkDn(5);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(10) * ILinkDn(6);
    }

    //last but one impurity
    {
      int impIndx = NArms_ - 1;
      int site    = H.ImpSite(impIndx);

      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(4);
      //C - terms need p here -> ALink(2), Ck needs on-site p as well
      W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(5) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(6) * ILinkDn(6);
    }

    //last impurity
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      //finish all terms, note second ID in ILinkUp(2)
      //it gives the 1+... from time evolution
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
      W += sites_.op("N", site) * ALink(1) * ILinkUp(4);
      W += sites_.op("Ck", site) * ALink(1) * ILinkUp(5);
      W += sites_.op("CkD", site) * ALink(1) * ILinkUp(6);
    }
  }

}; //namespace itensor
