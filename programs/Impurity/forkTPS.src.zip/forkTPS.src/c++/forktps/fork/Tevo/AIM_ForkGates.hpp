#include "forktps/fork/Bath.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/Gates.hpp"

#include "forktps/params.hpp"
#include "itensor/mps/siteset.h"
#include "itensor/itensor.h"
#undef Print

using namespace itensor;

namespace forktps {

  /** Generates a vector of time evolution gates for the bath hybridization, the bath on-site 
  *   energies as well as the impurity on-site energies. Works for diagonal hybridazations only.
  *   The gates generated are calculated from a second order suzuki-trotter decomposition and
  *   swap gates are used, as discussed in arXiv:1906.09077.
  * @param dt       template (double or Complex)
  *                 Time step, each operator G is exponentiated: $e^{-dt G}$ (note the sign).
  * @param b        forktps::bath
  *                 Bath object containing the on-site energies as well as the hybridization terms.
  * @param e0       forktps::hloc
  *                 Impurity on-site energies.
  * @param sites    AIM_ForkSites
  *                 ITensor SiteSet for the operators.
  */
  template <typename T> std::vector<ForkGate> createAIMGates(const T dt, const bath &b, const hloc &e0, const AIM_ForkSites &sites);

  /** Creates a one-indexed vector of Tensors storing the time evolution operator of 
  * the density-density interactions of an Anderson Impurity Model in MPO-format.
  * @param dt       template (double or Complex)
  *                 Time step, the operator H is exponentiated: $e^{-dt H}$ (note the sign).
  * @param hint     forktps::H_int
  *                 Interaction parameters.
  * @param sites    AIM_ForkSites
  *                 ITensor SiteSet for the operators.
  */
  template <typename T> std::vector<ITensor> DD_MPO(const T dt, const H_int &hint, const AIM_ForkSites &sites);

} // namespace forktps
