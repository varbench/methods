#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/fork/ForkTPO.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>
#include <utility>

using namespace itensor;

namespace forktps {

  /// Enum to distinguish spin-flip (SF) from pair-hopping (PH) terms. Use strong enum, since confusion with int is possible.
  enum class SFPH { SF, PH };

  /// Converter SFPH to string.
  std::string to_string(SFPH sfph);

  /** Creates an MPO representing the exponential of the spin-flip or pair-hopping terms.*/
  class SFPH_TevoMPO {
    public:
    /** Creates the MPO for the spin-flip (*sfph == SF*) or pair-hopping (*sfph == PH*) terms
    *   with time step *dt* and Hund's coupling *J*.
    * @param dt     Complex
    *               Time step, the operator H is exponentiated: $e^{-i dt H}$ (note the sign).
    * @param J      double
    *               Hunds coupling.
    * @param sfph   forktps::SFPH  
    *               Determines whether the exponential of the spin-flip or pair-hopping are created.
    * @param sites  AIM_ForkSites
    *               SiteSet providing the local operators at each site.
    */
    SFPH_TevoMPO(Complex dt, double J, SFPH sfph, std::pair<int, int> ij, const AIM_ForkSites &sites);

    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    /// Creates the MPOs on all arms. Here only either 1x1 Ids or 2x2 Ids and "p" i.e. Fermi Sign operators.
    std::vector<Index> MakeArmMPOs();
    std::vector<Index> MakeImpLinks();

    /// Impurity tensors for the spin-flip terms.
    void MPO_SF(const std::vector<Index> &ArmImpLinks);
    /// Impurity tensors for the pair-hopping terms.
    void MPO_PH(const std::vector<Index> &ArmImpLinks);

    //////////////////
    //
    // Data Members

    const SiteSet &sites;

    SFPH sfph;

    double J;
    Complex dt;
    // the two sites on which the operator acts on
    std::pair<int, int> ij;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

} // namespace forktps
