#ifndef __FORK__
#define __FORK__

#include "Arm.hpp"
#include "typenames.hpp"

#include <vector>

using namespace itensor;

namespace forktps {

  /**
*Implementation of the Fork class used for the management of indices for the forktps. A Fork consists of several impurity sites with an arm attached to each
* impurity. Each arm represents a NBath bath sites. The impurity with its arm makes up a
* chain. Each chain is then connected to the next (and or previous) chain only via connections over
* the impurity.
*
* A fork with 4 impurities, therefore 4 arms, and 6 sites per arm looks like:
* O -- o -- o -- o -- o -- o -- o 
* |     
* O -- o -- o -- o -- o -- o -- o 
* |				
* O -- o -- o -- o -- o -- o -- o 
* | 
* O -- o -- o -- o -- o -- o -- o  
*
* We use two ways of labeling sites. The first is to just enumerate them:
*  1 -- 2 -- 3 -- 4 -- 5 -- 6 -- 7 
*  |
*  8 -- 9 -- 10-- 11-- 12-- 13-- 14
*  |
*  15-- 16-- 17-- 18-- 19-- 20-- 21
*  |
*  22-- 23-- 24-- 25-- 26-- 27-- 28
*
* The second way is to label each impurity by a number and each bath site by its arm and an additional bath index.
* It is convention to start counting the sites of each arm starting from the right, i.e.: away from the impurity: 
* I1 -- A1,6 -- A1,5 -- A1,4 -- A1,3 -- A1,2 -- A1,1
* |
* I2 -- A2,6 -- A2,5 -- A2,4 -- A2,3 -- A2,2 -- A2,1  
* |
* I3 -- A3,6 -- A3,5 -- A3,4 -- A3,3 -- A3,2 -- A3,1
* |
* I4 -- A4,6 -- A4,5 -- A4,4 -- A4,3 -- A4,2 -- A4,1
*
* Ai,j means the jth site (counting from the rightmost site) on arm i.
* The purpose of the fork class is mostly to translate between these 2 ways of labeling sites.
*/

  class Fork {
    public:
    /// Default constructor.
    Fork();

    /// Constructor with *NArms* arms and a total of *N* sites.
    Fork(int N, int NArms);

    /// Constructor *Nbath[m]* bath sites at arm m. Nbath is one-indexed!
    Fork(const std::vector<int> &Nbath);

    /// Overwrites the parameters of the Fork to *NArms* arms and a total of *N* sites.
    void constructFork(int N, int NArms);
    /// Overwrites the parameters of the Fork *NArms* arms and on each arm *m*, *Nbath[m]* bath sites. Nbath is one-indexed!
    void constructFork(const std::vector<int> &Nbath);

    /// Returns the total number of sites.
    [[nodiscard]] int N() const;

    /// Returns the number of arms.
    [[nodiscard]] int NArms() const;

    /// Returns the number of bath sites on arm *arm*.
    [[nodiscard]] int NBath(int arm = 1) const;

    /// Returns a vector containing the number of bath sites for each orbital (one indexed!).
    [[nodiscard]] std::vector<int> NBathVec() const;

    /// Returns true if *site* is an impurity site, false otherwise.
    [[nodiscard]] bool IsImp(const int site) const;

    /// Returns the site of the impurity on arm *arm*.
    [[nodiscard]] int ImpSite(const int arm) const;

    /// Returns the arm of *site* (*site* can also be an impurity).
    [[nodiscard]] int GetArm(const int site) const;

    /// Returns the arm of the impurity site *site*. Same result as GetArm(site), but fails if *site* is not an impurity.
    [[nodiscard]] int ImpIndx(const int site) const;

    /// Returns the site index of the bath-site on *arm* with index *indx*.
    [[nodiscard]] int ArmToSite(const int arm, const int indx) const;

    /// Returns the arm-index on whatever arm the bath-site *site* is located.
    [[nodiscard]] std::pair<int, int> SiteToArm(const int site) const;

    /// Returns true if *site* has a neighbor in direction dir, otherwise returns false.
    [[nodiscard]] bool HasNeighbor(const int site, const OrthoState dir) const;

    /// Returns whether *siteI* and *siteJ* are neighbors.
    [[nodiscard]] bool AreNeighbors(const int siteI, const int siteJ) const;

    /// Returns the neighbor of *site* in direction *dir*.
    [[nodiscard]] int Neighbor(const int site, OrthoState dir) const;

    public:
    /// Write to stream *s*.
    void read(std::istream &s);

    /// Read from stream *s*.
    void write(std::ostream &s) const;

    private:
    /// Total number of sites.
    int N_;
    /// Number of arms.
    int NArms_;

    /// Vector containing the number of bath sites of each orbial (one-indexed).
    std::vector<int> NBath_;
    /// Vector containing the site indices of the impurity sites of each orbial (one-indexed).
    std::vector<int> NImp_;
  };

} // namespace forktps

#endif
