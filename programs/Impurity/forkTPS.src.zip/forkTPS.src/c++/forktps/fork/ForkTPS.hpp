#ifndef __FORKMPS__
#define __FORKMPS__

#include "ForkTN.hpp"

#include "itensor/itensor.h"
#undef Print

#include <vector>
//

//#include "typenames.hpp"

/////////////////
////////////////
////////////////

namespace forktps {

  /*
 * This class represents a quantum mechanical state in forktps form. Its
 * implementation shares many similarities to the ITensor MPS class which it is based on.
 */

  class ForkTPS : public ForkTN {
    public:
    // Constructors

    /// Default constructor
    ForkTPS() = default;

    /** Constructs a forktps with *NArms* arms using the site indices from *sites*. It is initialized in a product state formed by the first site-index entry on each site.
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param NArms    int
    *                 Number of arms.
    */
    ForkTPS(const SiteSet &sites, int NArms);

    /** Constructs a forktps with *NArms* arms and initializes it in a product state defined by *initState*.
    * @param initState  itensor::InitState
    *                   Defines the basis state on each site in which the forktps is initialized (usually either empty or occupied).
    * @param NArms      int
    *                   Number of arms.
    */
    ForkTPS(const InitState &initState, int NArms);

    /** Constructs a forktps with *Nbath[m]* bath sites on arm *m* and initializes it in a product state defined by *initState*.
    * @param initState  itensor::InitState
    *                   Defines the basis state on each site in which the forktps is initialized (usually either empty or occupied).
    * @param NBath      std::vector<int>
    *                   Vector containing the number of bath sites for each arm (one-indexed, i.e, Nbath[1] is the number of bath sites of the first arm).
    */
    ForkTPS(const InitState &initState, std::vector<int> NBath);

    /** Constructs a forktps with *Nbath[m]* bath sites on arm *m* using the site indices from *sites*. 
    * The forktps is initialized in a product state formed by the first site-index entry on each site.
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param Nbath    std::vector<int>
    *                 Vector containing the number of bath sites for each arm (one-indexed, i.e, Nbath[1] is the number of bath sites of the first arm).
    */
    ForkTPS(const SiteSet &sites, std::vector<int> NBath);

    private:
    /** Called by the constructors, this function actually fills the tensors. The main work it performs is to figure out what quantum numbers to use on each link.
    * @param initState  itensor::InitState
    *                   Defines the basis state on each site in which the forktps is initialized (usually either empty or occupied).
    */
    void init_tensors(const InitState &initState);

    public:
    /** Initilizes the forktps with random tensors of dimension *dim*. Only implemented for cases without QN conservation.
    * @param dim        int 
    *                   Bond dimension used on each site.
    */
    void randomize(int dim);

    /// Returns the norm of the forktps
    double norm() const;

    /// Normalizes the state.
    double normalize();

    /// Normalizes the state with limits.
    double normalizeLim();

    ITensor UTensor(int site, OrthoState towards) const override;

    /** Applies the operator *Op* acting on *site*. If *sign* is true, this operator is considered 
    *   to be fermionic, i.e also Fermi operators "p" are applied on all sites $i : i < \text{*site*}$.
    * @param Op     ITensor
    *               Operator that is applied.
    * @param site   int
    *               Site onto which *Op* is applied.
    * @param sign   bool (default: false)
    *               If true also apply Fermi-operators on all sites < *site*.
    */
    void ApplySingleSiteOp(const ITensor &Op, int site, bool sign = false);

    /** Exactly applies an MPO acting non-trivially only on the impurity and truncates after the application.
    * @param Ops    std::vector<ITensor>
    *               MPO stored as a vector of tensors such that Ops[i] acts on the i-th impurity. Note that this MPO is one-indexed, i.e, Ops[1] is the first entry used.   
    * @param args   itensor::Args
    *               Stores the relevant approximation parameters like truncated weight and maximum bond dimension.
    */
    void ApplyImpurityMPO(const std::vector<ITensor> &Ops, Args &args);

    // void ApprApplyImpurityMPO(
    // const std::vector<ITensor>& Ops, ForkTPS &psi0, Args &args);
    // Approximately applies an operator that acts only on
    // impurity sites and which is given in MPO-form. It uses
    // the variational principle and updates FTPS tensors in a
    // "right-left sweep" through all impurity tensors.
    // Currently not used.

    /** Uses the zip-up method (New J. Phys.12 055026) to apply an MPO acting non-trivially only 
    *   on the impurity. The Zip-Up algorithm is approximate in that it truncates already during 
    *   the application of the operator, where there is no exact left and right basis.
    *   
    * @param Ops    std::vector<ITensor>
    *               MPO stored as a vector of tensors such that Ops[i] acts on the i-th impurity. Note that this MPO is one-indexed, i.e, Ops[1] is the first entry used.   
    * @param args   itensor::Args
    *               Stores the relevant approximation parameters like truncated weight and maximum bond dimension.
    */
    void ZipUpImpurityMPO(const std::vector<ITensor> &Ops, Args &args);

    // Other functions

    /// Returns the impurity occupation of the state as a zero-indexed vector.
    std::vector<double> ImpOccs();

    /// Prints the impurity occupation of the state.
    void PrintImpOcc(int numSpaces = 0);

    /// Prints all occupations of the forktps
    void PrintOccs();
  };

  /// Overlap between two states *psi* and *phi* $\langle \psi | \phi \rangle$.
  Complex overlap(const ForkTPS &psi, const ForkTPS &phi);

} // namespace forktps

#endif
