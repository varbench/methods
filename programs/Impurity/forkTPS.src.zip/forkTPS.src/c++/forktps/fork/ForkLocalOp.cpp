#include "ForkLocalOp.hpp"
#include "HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"

#include <forktps/fork/ForkTPS.hpp>
#include <itensor/itensor.h>
#include <itensor/util/error.h>

#include <string>
#include <utility>

namespace forktps {

  ForkLocalOp::ForkLocalOp(const ForkTPO &H) : Fork(H.NBathVec()), ProjHArm(NArms() + 1), ProjHImp(NArms() + 1), ImpOrtho(NArms() + 1), H(H) {
    for (auto arm : range1(NArms())) {
      ImpOrtho[arm] = Nonewards;

      std::vector<ITensor> A(NBath(arm) + 1);
      ProjHArm[arm] = {false, NBath(arm) + 1, 0, NBath(arm), A};
    }
  }

  void ForkLocalOp::position(int i, int j, const ForkTPS &bra, const ForkTPS &ket) {
    if (!AreNeighbors(i, j)) throw ITError("ForkLocalOp::position: the two sites are not neighbors: " + std::to_string(i) + " " + std::to_string(j));

    if (i >= j) std::swap(i, j);
    int armI = GetArm(i), armJ = GetArm(j);

    // fully contract arms except armI
    for (auto arm : range1(NArms())) {
      bool doArm = (arm != armI || armI != armJ); // armI != armJ means two impurites
      if (doArm) { FullContractArm(arm, bra, ket); }
    }

    // contract impurities above current arm
    for (auto arm : range1(armI - 1)) { ContractImp(arm, Downwards, bra, ket); }
    // contract impurities below current arm
    for (auto arm : itertools::range(NArms(), armJ, -1)) { ContractImp(arm, Upwards, bra, ket); }

    if (!IsImp(i)) { ContractImp(armI, Rightwards, bra, ket); }
    if (armI == armJ) { ContractArm(i, j, armI, bra, ket); }

    // Contraction done, set remaining variables
    NOpen = 2;
    IOpen = i;
    JOpen = j;
    if (IsImp(IOpen)) { ImpOrtho[armI] = Nonewards; }
    if (IsImp(JOpen)) { ImpOrtho[armJ] = Nonewards; }

    SetTwoSiteEnv();

    return;
  }

  void ForkLocalOp::position(int i, int j, const ForkTPS &psi) { position(i, j, psi, psi); }

  void ForkLocalOp::position(int i, const ForkTPS &bra, const ForkTPS &ket) {
    int ArmI = GetArm(i);

    if (IsImp(i)) {
      for (auto arm : range1(NArms())) { FullContractArm(arm, bra, ket); }                // contract all arms
      for (auto arm : range1(ArmI - 1)) { ContractImp(arm, Downwards, bra, ket); }        // contract impurities above current ArmI
      for (int arm = NArms(); arm > ArmI; arm--) { ContractImp(arm, Upwards, bra, ket); } // contract impurities below current ArmI

      ImpOrtho[ArmI] = Nonewards;

    } else {
      for (auto arm : range1(NArms())) {
        if (arm != ArmI) FullContractArm(arm, bra, ket);
      }
      for (auto arm : range1(ArmI - 1)) ContractImp(arm, Downwards, bra, ket);                  // contract impurities above current ArmI
      for (auto arm : itertools::range(NArms(), ArmI, -1)) ContractImp(arm, Upwards, bra, ket); // contract impurities below current ArmI

      ContractImp(ArmI, Rightwards, bra, ket);
      ContractArm(i, ArmI, bra, ket);
    }
    NOpen = 1;
    IOpen = i;
    JOpen = -1;
    SetSingleSiteEnv();
  }

  void ForkLocalOp::position(int i, const ForkTPS &psi) { position(i, psi, psi); }

  void ForkLocalOp::position_0site(int i, int j, const ForkTPS &bra, const ForkTPS &ket) {
    if (!AreNeighbors(i, j)) throw ITError("ForkLocalOp::position: the two sites are not neighbors: " + std::to_string(i) + " " + std::to_string(j));

    if (i >= j) std::swap(i, j);

    int armI = GetArm(i), armJ = GetArm(j);

    // contract all arms which are not the current arm
    for (auto arm : range1(NArms())) {
      if (arm != armI || armI != armJ) { FullContractArm(arm, bra, ket); }
    }

    // contract impurities above current arm
    for (auto arm : range1(armI - 1)) { ContractImp(arm, Downwards, bra, ket); }

    // contract impurities below current arm
    for (auto arm : itertools::range(NArms(), armJ, -1)) { ContractImp(arm, Upwards, bra, ket); }

    if (IsImp(i) && IsImp(j)) {
      // contract impurities
      ContractImp(armI, Downwards, bra, ket);
      ContractImp(armJ, Upwards, bra, ket);
    } else {
      ContractImp(armI, Rightwards, bra, ket);
      IsImp(i) ? FullContractArm(armI, bra, ket) : ContractArm_0site(i, j, armI, bra, ket);
    }

    NOpen = 0;
    IOpen = i;
    JOpen = j;

    SetLinkEnv();
    return;
  }

  void ForkLocalOp::position_0site(int i, int j, const ForkTPS &psi) { position_0site(i, j, psi, psi); }

  int ForkLocalOp::i() { return IOpen; }

  int ForkLocalOp::j() { return JOpen; }

  void ForkLocalOp::FullContractArm(int arm, const ForkTPS &bra, const ForkTPS &ket) {
    if (ProjHArm[arm].outer_ortho_lim == NBath(arm)) { return; } // do nothing since its already up2date

    auto start = ProjHArm[arm].outer_ortho_lim + 1;
    for (auto indx : range1(start, NBath(arm))) { ContractLeft(arm, indx, bra, ket); }

    // Set Limits
    ProjHArm[arm].CompOrtho();
    ImpOrtho[arm] = Nonewards; // Impurity at arm needs to know it has to update its tensors
    return;
  }

  void ForkLocalOp::ContractArm(int i, int j, int arm, const ForkTPS &bra, const ForkTPS &ket) {
    if (i >= j) {
      std::cout << "i: " << i << " j: " << j << "\n";
      Error("ContractArm: i>=j");
    }

    int indxI = IsImp(i) ? NBath(arm) + 1 : SiteToArm(i).second;
    int indxJ = SiteToArm(j).second;

    auto start = ProjHArm[arm].outer_ortho_lim + 1;

    // range-based loop not working because cases like range1(3,2)
    // occur which do not work properly
    for (int indx = start; indx < indxJ; ++indx)
    //for (auto indx : range1(start, indxJ-1))
    {
      ContractLeft(arm, indx, bra, ket);
    }

    start = ProjHArm[arm].inner_ortho_lim - 1;
    for (int indx = start; indx > indxI; --indx) { ContractRight(arm, indx, bra, ket); }

    ProjHArm[arm].TSOrtho(indxI, indxJ);

    return;
  }

  void ForkLocalOp::ContractArm(int i, int arm, const ForkTPS &bra, const ForkTPS &ket) {
    if (IsImp(i)) { Error("ForkLocalOp:ContractArm called for an impurity Site: " + std::to_string(i)); }
    int ArmIndx = SiteToArm(i).second;

    auto start = ProjHArm[arm].outer_ortho_lim + 1;
    for (int indx = start; indx < ArmIndx; indx++) { ContractLeft(arm, indx, bra, ket); }

    start = ProjHArm[arm].inner_ortho_lim - 1;
    for (int indx = start; indx > ArmIndx; indx--) { ContractRight(arm, indx, bra, ket); }

    ProjHArm[arm].SSOrtho(ArmIndx);

    return;
  }

  void ForkLocalOp::ContractArm_0site(int i, int j, int arm, const ForkTPS &bra, const ForkTPS &ket) {

    if (i >= j) { Error("ContractArm_0site: i>=j"); }

    int indxI = IsImp(i) ? NBath(arm) + 1 : SiteToArm(i).second;
    int indxJ = SiteToArm(j).second;

    // use indx<= indxJ since this is zero site Heff
    auto start = ProjHArm[arm].outer_ortho_lim + 1;
    for (int indx = start; indx <= indxJ; indx++) { ContractLeft(arm, indx, bra, ket); }

    start = ProjHArm[arm].inner_ortho_lim - 1;
    for (int indx = start; indx >= indxI; indx--) { ContractRight(arm, indx, bra, ket); }

    ProjHArm[arm].LinkOrtho(indxI, indxJ);

    return;
  }

  void ForkLocalOp::ContractLeft(int arm, int indx, const ForkTPS &bra, const ForkTPS &ket) {
    int site = ArmToSite(arm, indx);

    if (indx == 1) {
      ProjHArm[arm].A_[indx] = dag(prime(bra.A(site))) * H.A(site) * ket.A(site);
    } else {
      ProjHArm[arm].A_[indx] = ProjHArm[arm].A_[indx - 1] * ket.A(site);
      ProjHArm[arm].A_[indx] *= H.A(site);
      ProjHArm[arm].A_[indx] *= dag(prime(bra.A(site)));
    }
  }

  void ForkLocalOp::ContractRight(int arm, int indx, const ForkTPS &bra, const ForkTPS &ket) {
    int site = ArmToSite(arm, indx);

    if (indx == NBath(arm)) {
      ProjHArm[arm].A_[indx] = ProjHImp[arm] * ket.A(site);
      ProjHArm[arm].A_[indx] *= H.A(site);
      ProjHArm[arm].A_[indx] *= dag(prime(bra.A(site)));
    } else {
      ProjHArm[arm].A_[indx] = ProjHArm[arm].A_[indx + 1] * ket.A(site);
      ProjHArm[arm].A_[indx] *= H.A(site);
      ProjHArm[arm].A_[indx] *= dag(prime(bra.A(site)));
    }
  }

  void ForkLocalOp::ContractImp(int indx, OrthoState dir, const ForkTPS &bra, const ForkTPS &ket) {

    if (indx == 1 && dir == Upwards) {
      std::cout << to_string(dir) << "\n";
      Error("ContractImp: cant contract impurity 1 upwards.");
    }
    if (indx == NArms() && dir == Downwards) {
      std::cout << to_string(dir) << "\n";
      Error("ContractImp: cant contract last impurity downwards.");
    }
    if (dir != Rightwards && ProjHArm[indx].outer_ortho_lim != NBath(indx)) {
      std::cout << to_string(dir) << "\n";
      std::cout << ProjHArm[indx].outer_ortho_lim << "\n";
      Error("ContractImp: Trying to contract UP/DOWN altough arm isnt contracted!");
    }
    if (dir == Downwards && indx != 1) {
      if (ImpOrtho[indx - 1] != Downwards) {
        std::cout << to_string(dir) << "\n";
        std::cout << to_string(ImpOrtho[indx - 1]) << "\n";
        Error(
           "ContractImp: Trying to contract DOWN altough prev. Imp isnt "
           "contracted!");
      }
    }
    if (dir == Upwards && indx != NArms()) {
      if (ImpOrtho[indx + 1] != Upwards) {
        std::cout << to_string(dir) << "\n";
        std::cout << to_string(ImpOrtho[indx + 1]) << "\n";
        Error(
           "ContractImp: Trying to contract UP altough prev. Imp isnt "
           "contracted!");
      }
    }
    if (dir == Rightwards) {
      if (indx == 1) {
        if (ImpOrtho[indx + 1] != Upwards) {
          std::cout << indx << "\n";
          std::cout << to_string(ImpOrtho[indx + 1]) << "\n";
          Error(
             "ContractImp: Trying to contract Right altough prev. Imp isnt "
             "contracted!");
        }
      } else if (indx == NArms()) {
        if (ImpOrtho[indx - 1] != Downwards) {
          std::cout << indx << "\n";
          std::cout << to_string(ImpOrtho[indx - 1]) << "\n";
          Error(
             "ContractImp: Trying to contract Right altough prev. Imp isnt "
             "contracted!");
        }
      } else {
        if (ImpOrtho[indx + 1] != Upwards || ImpOrtho[indx - 1] != Downwards) {
          std::cout << to_string(ImpOrtho[indx - 1]) << "\n";
          std::cout << to_string(ImpOrtho[indx + 1]) << "\n";
          Error(
             "ContractImp: Trying to contract Right altough prev. Imp isnt "
             "contracted!");
        }
      }
    }

    if (ImpOrtho[indx] == dir) return; // tensor already up2date

    int site = ImpSite(indx);

    // std::cout<<"Start Contracting Imp "<< indx << ", which is site "<< site<< "
    // in direction "<<to_string(dir)<<std::endl;

    if (dir == Rightwards) {
      if (indx == 1) {
        ProjHImp[indx] = ProjHImp[indx + 1] * ket.A(site); // take lower proj.
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      } else if (indx == NArms()) { // take upper proj
        ProjHImp[indx] = ProjHImp[indx - 1] * ket.A(site);
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      } else {
        ProjHImp[indx] = ProjHImp[indx - 1] * ket.A(site);
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= ProjHImp[indx + 1];
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      }
    } else if (dir == Downwards) {
      if (indx == 1) {
        ProjHImp[indx] = ProjHArm[indx].A_[NBath(indx)] * ket.A(site); // take arm projH
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      } else {
        ProjHImp[indx] = ProjHImp[indx - 1] * ket.A(site);
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= ProjHArm[indx].A_[NBath(indx)];
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      }
    } else {
      if (indx == NArms()) {
        ProjHImp[indx] = ProjHArm[indx].A_[NBath(indx)] * ket.A(site); // take arm projH
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      } else {
        ProjHImp[indx] = ProjHImp[indx + 1] * ket.A(site); // take proj of lower IMP
        ProjHImp[indx] *= H.A(site);
        ProjHImp[indx] *= ProjHArm[indx].A_[NBath(indx)]; // add arm
        ProjHImp[indx] *= dag(prime(bra.A(site)));
      }
    }

    ImpOrtho[indx] = dir;
    if (dir == Upwards) { ImpOrtho[indx - 1] = Nonewards; }
    if (dir == Downwards) { ImpOrtho[indx + 1] = Nonewards; }
    if (dir == Rightwards) { ProjHArm[indx].inner_ortho_lim = NBath(indx) + 1; }
    return;
  }

  void ForkLocalOp::SetTwoSiteEnv() {
    for (auto n : NBathVec()) {
      if (n == 1) { Error("Error Nbath=1 is NOT supported!!!"); }
    }

    if (IsImp(IOpen) && IsImp(JOpen)) {
      // store tensor armI in R and tensor armJ in L
      int ImpI = ImpIndx(IOpen), ImpJ = ImpIndx(JOpen);
      if (ImpI == 1) {
        U = ITensor();
        if (NArms() > 2)
          D = ProjHImp[ImpJ + 1];
        else
          D = ITensor();
      } else if (ImpJ == NArms()) {
        U = ProjHImp[ImpI - 1];
        D = ITensor();
      } else {
        U = ProjHImp[ImpI - 1];
        D = ProjHImp[ImpJ + 1];
      }
      R = ProjHArm[ImpI].A_[NBath(ImpI)];
      L = ProjHArm[ImpJ].A_[NBath(ImpJ)];
    } else if (IsImp(IOpen)) {
      // IOpen is impurity JOpen is bath
      L       = ITensor();
      int Imp = ImpIndx(IOpen);
      if (Imp == 1) {
        U = ITensor();
        D = ProjHImp[Imp + 1];
        R = ProjHArm[Imp].A_[NBath(Imp) - 1];
      } else if (Imp == NArms()) {
        D = ITensor();
        U = ProjHImp[Imp - 1];
        R = ProjHArm[Imp].A_[NBath(Imp) - 1];
      } else {
        D = ProjHImp[Imp + 1];
        U = ProjHImp[Imp - 1];
        R = ProjHArm[Imp].A_[NBath(Imp) - 1];
      }
    } else {
      // Both are bath only L and R
      U                  = ITensor();
      D                  = ITensor();
      auto [armI, indxI] = SiteToArm(IOpen);
      auto [arm, indxJ]  = SiteToArm(JOpen);

      if (indxI == NBath(arm)) {
        L = ProjHImp[arm];
        R = ProjHArm[arm].A_[indxJ - 1];
      } else if (indxJ == 1) {
        L = ProjHArm[arm].A_[indxI + 1];
        R = ITensor();
      } else {
        L = ProjHArm[arm].A_[indxI + 1];
        R = ProjHArm[arm].A_[indxJ - 1];
      }
    }
  }

  void ForkLocalOp::SetSingleSiteEnv() {

    if (NOpen != 1) { Error("SetSingleSiteEnv: NOpen != 1"); }

    if (IsImp(IOpen)) {
      L       = ITensor();
      int Imp = ImpIndx(IOpen);
      if (Imp == 1) {
        U = ITensor();
        D = ProjHImp[Imp + 1];
      } else if (Imp == NArms()) {
        U = ProjHImp[Imp - 1];
        D = ITensor();
      } else {
        U = ProjHImp[Imp - 1];
        D = ProjHImp[Imp + 1];
      }

      R = ProjHArm[Imp].A_[NBath(Imp)];
    } else {
      U                = ITensor();
      D                = ITensor();
      auto [arm, indx] = SiteToArm(IOpen);

      if (indx == NBath(arm)) {
        L = ProjHImp[arm];
        R = ProjHArm[arm].A_[indx - 1];
      } else if (indx == 1) {
        L = ProjHArm[arm].A_[indx + 1];
        R = ITensor();
      } else {
        L = ProjHArm[arm].A_[indx + 1];
        R = ProjHArm[arm].A_[indx - 1];
      }
    }

    return;
  }

  void ForkLocalOp::SetLinkEnv() {
    if (NOpen != 0) Error("SetLinkEnv: NOpen != 0");

    for (auto n : NBathVec()) {
      if (n == 1) Error("Attention Nbath=1 is NOT supported!!!");
    }

    U = ITensor();
    D = ITensor();

    if (IsImp(IOpen) && IsImp(JOpen)) {
      // imp-imp link
      int ImpI = ImpIndx(IOpen);
      int ImpJ = ImpIndx(JOpen);

      L = ProjHImp[ImpI];
      R = ProjHImp[ImpJ];
    } else if (IsImp(IOpen)) {
      // imp-bath link
      int ImpI = ImpIndx(IOpen);
      L        = ProjHImp[ImpI];
      R        = ProjHArm[ImpI].A_[NBath(ImpI)];
    } else {
      // bath-bath link
      auto [armI, indxI] = SiteToArm(IOpen);
      auto [arm, indxJ]  = SiteToArm(JOpen);

      L = ProjHArm[arm].A_[indxI];
      R = ProjHArm[arm].A_[indxJ];
    }

    return;
  }

  const ITensor &ForkLocalOp::GetEnvironment(OrthoState dir) const {
    // just checking if there is a neighbor in this direction
    if (!HasNeighbor(IOpen, dir)) { Error("ForkLocalOp::GetEnvironment: The current open index has no neighbor in direction " + to_string(dir)); }

    if (NOpen != 1) Error("GetEnvironment: Implemented only in single-site mode!");

    if (dir == Rightwards)
      return R;
    else if (dir == Leftwards)
      return L;
    else if (dir == Upwards)
      return U;
    else
      return D;
  }

  std::pair<ITensor, Index> ForkLocalOp::ExpansionTensor(OrthoState dir, const ForkTPS &psi) const {
    if (NOpen != 1) Error("ExpansionTensor: Implemented only in single-site mode!");

    auto i = IOpen;
    auto j = Neighbor(i, dir);
    auto P = psi.A(i);

    // calculate tensor
    if (IsImp(i)) {
      if (j == i + 1) {
        // impurity - bath link rightwards
        if (U) P *= U;
        P *= H.A(i);
        if (D) P *= D;
      } else if (i < j) {
        // impurity impurity link downwards
        if (U) P *= U;
        P *= H.A(i);
        P *= R;
      } else {
        // impurity impurity link upwards
        if (D) P *= D;
        P *= H.A(i);
        P *= R;
      }
    } else {
      if (j == i + 1) {
        // bath - bath link rightwards
        P *= L;
        P *= H.A(i);
      } else {
        //impurity - bath link leftwards or bath - bath link leftwards
        if (R) P *= R;
        P *= H.A(i);
      }
    }

    //tensor calculated, combine indices
    auto indw   = commonIndex(H.A(i), H.A(j));
    auto indpsi = commonIndex(psi.A(i), psi.A(j));

    auto [combP, c] = LinkCombiner(indpsi, indw);
    P *= combP;
    P.noPrime();

    return std::make_pair(P, c);
  }

  void ForkLocalOp::product(const ITensor &x, ITensor &res) const {

    if (NOpen == 0) {
      res = x * L;
      if (R) { res *= R; }
      res.mapPrime(1, 0);
      return;
    }

    if (U) {
      if (!IsImp(IOpen)) {
        std::cout << IOpen << "\n";
        Error("product: U exists altough IOpen is no impurity");
      }

      res = x * U;
      res *= H.A(IOpen);

      if (NOpen == 2) {
        if (IsImp(JOpen)) {
          if (R) { res *= R; }
          res *= H.A(JOpen);
          if (L) { res *= L; }
          if (D) { res *= D; }
        } else {
          if (D) { res *= D; }
          res *= H.A(JOpen);
          if (R) { res *= R; }
          if (L) { Error("product: Only IOpen is impurity index, but L exists"); }
        }
      } else {
        if (D) { res *= D; }
        if (R) { res *= R; }
        if (L) { res *= L; }
      }

    } else if (D) {
      res = x * D;
      res *= H.A(IOpen);
      if (L) { res *= L; }
      if (NOpen != 1) { res *= H.A(JOpen); }
      if (R) { res *= R; }
    } else {
      // L exists always, R might not
      res = L * x;
      res *= H.A(IOpen);
      if (NOpen != 1) { res *= H.A(JOpen); }
      if (R) { res *= R; }
    }

    res.mapPrime(1, 0);

    return;
  }

  /*
  void ForkLocalOp::product(const ITensor &Ai, const ITensor &Aj, ITensor &res) const {
    if (NOpen != 2) Error("product: If product with two tensors is called, NOpen must be 2 as well.");

    if (U) {
      if (!IsImp(IOpen)) {
        std::cout<<IOpen<<"\n";
        Error("product: U exists altough IOpen is no impurity");
      }

      res = Ai * U;
      res *= H.A(IOpen);

      if (IsImp(JOpen)) {
        if (R) { res *= R; }
        res *= Aj;
        res *= H.A(JOpen);
        if (L) { res *= L; }
        if (D) { res *= D; }
      } else {
        if (D) { res *= D; }
        res *= Aj;
        res *= H.A(JOpen);
        if (R) { res *= R; }
      }
    } else if (D) {
      res = Ai * D;
      res *= H.A(IOpen);
      res *= Aj;
      res *= H.A(JOpen);
      if (R) { res *= R; }
    } else {
      // L exists always, R might not
      res = L * Ai;
      res *= H.A(IOpen);

      res *= Aj;
      res *= H.A(JOpen);

      if (R) { res *= R; }
    }

    res.mapPrime(1, 0);

    return;
  }
  */

  unsigned long ForkLocalOp::size() const {
    unsigned long size = 1;
    // TODO: make size a member and only calculate it once

    // loop over all environment tensors and multiply primed index dimension
    for (const auto &T : {U, D, L, R}) {
      if (!T) continue;
      for (const auto &I : T.inds()) {
        if (I.primeLevel() > 0) {
          size *= dim(I);
          break;
        }
      }
    }

    auto sites = H.sites();

    if (NOpen > 0) size *= dim(sites(IOpen));
    if (NOpen > 1) size *= dim(sites(JOpen));

    return size;
  }

  Complex ForkLocalOp::ContractAll(const ForkTPS &bra, const ForkTPS &ket) {
    if (NOpen != 1) Error("ForkLocalOp energy() not implemented for NOpen=2");

    auto A = ket.A(IOpen);
    if (IsImp(IOpen)) {
      if (U) A *= U;
      A *= H.A(IOpen);
      A *= R;
      if (D) A *= D;
    } else {
      A *= L;
      A *= H.A(IOpen);
      if (R) A *= R;
    }

    return (A * dag(prime(bra.A(IOpen)))).cplx();
  }

  Complex ForkLocalOp::ContractAll(const ForkTPS &psi) { return ContractAll(psi, psi); }

  double ForkLocalOp::energy(const ForkTPS &psi) { return std::real(ContractAll(psi)); }

  void ForkLocalOp::ForgetContraction() {
    for (int indx = 1; indx <= NArms(); indx++) {
      ImpOrtho[indx] = Nonewards;
      ProjHArm[indx].ForgetOrtho();
    }

    NOpen = -1;
    IOpen = -1;
    JOpen = -1;

    return;
  }

  void ForkLocalOp::UpdateMe(int site) {
    if (IsImp(site)) {
      int Imp       = ImpIndx(site);
      ImpOrtho[Imp] = Nonewards;
    } else {
      auto [arm, indx] = SiteToArm(site);
      // set ortho lims
      ProjHArm[arm].TouchOrtho(indx);
    }
  }

  void ForkLocalOp::UpdateMe(int sitei, int sitej) {
    UpdateMe(sitei);
    UpdateMe(sitej);
  }

  void ForkLocalOp::PrintEnvironment() const {
    ITENSOR_Print(L);
    ITENSOR_Print(R);
    ITENSOR_Print(U);
    ITENSOR_Print(D);

    if (NOpen > 0) ITENSOR_Print(H.A(IOpen));
    if (NOpen > 1) ITENSOR_Print(H.A(JOpen));
    return;
  }

} // namespace forktps
