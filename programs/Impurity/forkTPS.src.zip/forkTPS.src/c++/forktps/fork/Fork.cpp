#include "Fork.hpp"
#include "HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include <utility>
#include <vector>

using namespace itensor;

namespace forktps {

  Fork::Fork() : N_(0), NArms_(0), NBath_(0), NImp_(0) {} // default constructor

  Fork::Fork(int N, int NArms) : N_(N), NArms_(NArms), NBath_(NArms + 1), NImp_(NArms_ + 1) {

    if (NArms % 2 != 0) {
      std::cout << NArms << "\n";
      throw ITError("Fork(): NArms must be an even number.");
    }

    int NBath = (N_ - NArms_) / NArms_;
    if (N != NArms_ * NBath + NArms_) {
      std::cout << N << "\n";
      std::cout << NArms << "\n";
      throw ITError("Fork: Cannot create a fork with those parameters.");
    }

    for (int k = 1; k <= NArms_; k++) {
      NImp_.at(k)  = (k - 1) * (NBath + 1) + 1;
      NBath_.at(k) = NBath;
    }
  }

  Fork::Fork(const std::vector<int> &NBath) : NArms_(NBath.size() - 1), NBath_(NBath), NImp_(NBath.size()) {
    if (NArms_ % 2 != 0) {
      std::cout << NArms_ << "\n";
      throw ITError("Fork(): NArms must be an even number.");
    }

    NImp_.at(1) = 1;
    for (auto k : range1(2, NArms_)) { NImp_.at(k) = NImp_.at(k - 1) + NBath.at(k - 1) + 1; }
    N_ = NImp_.at(NArms_) + NBath_.at(NArms_);
  }

  void Fork::constructFork(int N, int NArms) { *this = Fork(N, NArms); }

  void Fork::constructFork(const std::vector<int> &NBath) { *this = Fork(NBath); }

  int Fork::N() const { return N_; }

  int Fork::NArms() const { return NArms_; }

  int Fork::NBath(int arm) const { return NBath_.at(arm); }

  std::vector<int> Fork::NBathVec() const { return NBath_; }

  int Fork::ImpSite(const int arm) const {
    if (arm < 1 || arm > NArms()) throw ITError("ImpSite: invalid value of arm: " + std::to_string(arm));
    return NImp_[arm];
  }

  bool Fork::IsImp(const int site) const {
    for (auto j : range1(NArms()))
      if (site == NImp_[j]) return true;

    return false;
  }

  int Fork::GetArm(const int site) const {
    if (site < 1 || site > N()) throw ITError("GetArm: invalid value of site: " + std::to_string(site));

    int arm = 1, lastSite = NBath_.at(arm) + 1;
    while (true) {
      if (site <= lastSite) {
        return arm;
      } else {
        arm++;
        lastSite += NBath_.at(arm) + 1;
      }
    }
  }

  int Fork::ImpIndx(const int site) const {

    for (auto j : range1(NArms())) {
      if (NImp_[j] == site) { return j; }
    }

    std::cout << site << "\n";
    throw ITError("ImpIndx: site is not an impurity site");
    return 0;
  }

  int Fork::ArmToSite(const int arm, const int indx) const {

    if (arm > NArms_ || arm < 1) {
      std::cout << arm << "\n";
      throw ITError("ArmToSite: arm out of bounds arm<1 or arm > NArms");
    }
    if (indx > int(NBath_.at(arm)) || indx < 1) {
      std::cout << indx << "\n";
      throw ITError("ArmToSite: indx out of bounds indx<1 or arm > NBath");
    }
    int site = 0;

    for (auto a : range1(arm)) { site += NBath_.at(a) + 1; }

    return site - indx + 1;
  }

  std::pair<int, int> Fork::SiteToArm(const int site) const {
    if (site > N_ || site < 1) {
      std::cout << site << "\n";
      throw ITError("SiteToArm: site out of bounds");
    }
    if (IsImp(site)) {
      std::cout << site << "\n";
      throw ITError("SiteToArm: Impurity site has no Arm index!");
    }

    int arm = GetArm(site), endOfArm = ImpSite(arm) + NBath(arm);

    return std::make_pair(arm, endOfArm - site + 1);
  }

  bool Fork::AreNeighbors(const int siteI, const int siteJ) const {
    auto armI = GetArm(siteI);
    auto armJ = GetArm(siteJ);

    if (armI == armJ) {
      // same arm
      return (siteI == siteJ + 1 || siteI == siteJ - 1) ? true : false;
    } else {
      // different arms so both must be impurity tensors
      if (!IsImp(siteI) || !IsImp(siteJ)) return false;
      // and both must be on neighboring arms
      return (armI == armJ + 1 || armI == armJ - 1) ? true : false;
    }
  }

  bool Fork::HasNeighbor(const int site, const OrthoState dir) const {

    if (IsImp(site)) {
      if (dir == Rightwards)
        return true;
      else if (dir == Upwards)
        return (ImpIndx(site) == 1) ? false : true;
      else if (dir == Downwards)
        return (ImpIndx(site) == NArms()) ? false : true;
      else
        return false;
    } else {
      if (dir == Leftwards)
        return true;
      else if (dir == Rightwards && SiteToArm(site).second != 1)
        return true;
      else
        return false;
    }
  }

  int Fork::Neighbor(const int site, OrthoState dir) const {

    if (!HasNeighbor(site, dir)) throw ITError("Neighbor: site " + std::to_string(site) + " has no neighbor in direction " + to_string(dir));

    if (dir == Rightwards)
      return site + 1;
    else if (dir == Leftwards)
      return site - 1;
    else if (dir == Upwards)
      return ImpSite(GetArm(site) - 1);
    else if (dir == Downwards)
      return ImpSite(GetArm(site) + 1);
    else
      throw ITError("Neighbor: Nonewards not a valid dir.");

    return 0;
  }

  void Fork::read(std::istream &s) {
    int NArms = 0;
    itensor::read(s, NArms);

    std::vector<int> Nb(NArms + 1);
    for (auto &val : Nb) { itensor::read(s, val); }

    constructFork(Nb);
  }

  void Fork::write(std::ostream &s) const {
    itensor::write(s, NArms());

    for (auto val : NBathVec()) { itensor::write(s, val); }
  }

} // namespace forktps
