#ifndef __FORKLOCALOP__
#define __FORKLOCALOP__

#include "Fork.hpp"
#include "ForkTPO.hpp"
#include "ForkTPS.hpp"
#include "forktps/fork/typenames.hpp"

#include <itensor/itensor.h>
#undef Print

#include <optional>

/////////////////
////////////////
////////////////

using namespace itensor;

namespace forktps {

  /**
 * Class defining the effective Hamiltonians used by DMRG, TDVP and other algorithms. 
 * It works very similar to its ITensor equivalent. It uses 4 tensors L, R, U and D 
 * to represent the contracted part of $\langle \phi | H | \psi \rangle$ 
 * (the tensor network without the sites, where the FTPS tensors are missing on 
 * some sites). As in the ITensor library, the position function is used
 * to change which sites are currently optimized and the product function to
 * calculate $H_{eff} \cdot v$. To avoid recalculating the contractions each 
 * time, it stores old contractions and uses them to calculate the new ones. 
 * This means that during a calculation one must not change the tensors (or even 
 * the indices) of the state without telling Heff using the UpdateMe() functions. \n \n
 *
 *
 * -----------------------------------------------------------------------------
 * -------------------------- Two Site Algorithms ------------------------------
 * -----------------------------------------------------------------------------
 *
 * For two site algorithms, there are 3 possibilities of how the contracted tensor network looks like and
 * which part of the contraction the four tensors L, R, U and D describe. \n
 *
 * 1. Both sites are Impurity sites, note that the arm tensors are stored in L
 * and R, altough technically they are both to the right of the impurity (Wi
 * and Wj denote for the open FTPO tensors)  \n. 
 * 
 *    U
 *    |
 *  -----
 *  | | |
 *   
 *    |    --|
 *    Wi-  --|-- R
 *    |    --|
 *    
 *    |    --|
 *    Wj-  --|-- L
 *    |    --|
 *
 *  | | |
 *  -----
 *    |
 *    D
 *
 *
 * 2. One site is an impurity site, while the other is a bath site: \n
 *
 *   U
 *   |
 *  -----
 *  | | |
 *
 *    |       |    --|
 *    Wi-    -Wj-  --|-- R
 *    |       |    --|
 *
 *  | | |
 *  -----
 *    |
 *    D
 *
 *
 * 3. Both sites are bath sites (normal DMRG case):\n
 *
 *      |--     |     |    --|
 * L ---|--    -Wi-  -Wj-  --|-- R
 *      |--     |     |    --|
 *
 *
 *
 *
 * -----------------------------------------------------------------------------
 * ------------------------- Single Site Algorithms ----------------------------
 * -----------------------------------------------------------------------------
 * For single site algorithms, there are 2 possibilities of how the contracted tensor network looks like and
 * which part of the contraction the four tensors L, R, U and D describe.  \n
 *
 * 1. The site is an impurity site: \n.
 * 
 *    U
 *    |
 *  -----
 *  | | |
 *
 *    |    --|
 *    Wi-  --|-- R
 *    |    --|
 *
 *  | | |
 *  -----
 *    |
 *    D
 *
 *
 *
 * 2. The site is an bath site (normal DMRG case):\n
 *
 *      |--        --|
 * L ---|--  -Wi-  --|-- R
 *      |--        --|
 *
 *
 *
 * -----------------------------------------------------------------------------
 * -------------------------- Zero Site Algorithms -----------------------------
 * -----------------------------------------------------------------------------
 * For zero site effective Hamiltonians, there are 2 possibilities of how the 
 * contracted tensor network looks like.
 * In this case only R and L tensors are used although technically the tensors 
 * are above (below) if Heff is for an impurity-impurity link. \n
 *
 * 1. The link is an impurity-impurity link: \n.
 *
 *    L
 *    |
 *  -----
 *  | | |
 *
 *
 *  | | |
 *  -----
 *    |
 *    R
 *
 *
 *
 * 2. The link is a link involving at least one bath tensor (normal MPS case):\n
 *
 *     |--     --|
 * L --|--     --|-- R
 *     |--     --|
 *
 */

  class ForkLocalOp : public Fork {
    public:
    /// Default constructor
    ForkLocalOp() = default;

    /**
    * The usual constructor used to calculate the effective Hamiltonian of <psi|H|psi>. 
    * @param H    ForkTPO
    *             Operator of the contraction.
    */
    ForkLocalOp(const ForkTPO &H);

    /**
     * Contracts the tensor network with FTPS *psi* that the effective Hamiltonian
     * acts on the two sites *i* and *j*.
     * @param i     int
     *              One of the sites $H_{eff}$ acts.
     * @param j     int
     *              One of the sites $H_{eff}$ acts.
     * @param psi   ForkTPS
     *              State with which to perform the contraction.
    */
    void position(int i, int j, const ForkTPS &psi);

    /**
     * Contracts the tensor network with FTPS *bra* and *ket* for the bra- and
     * ket-vector respectively such that the effective Hamiltonian
     * acts on the two sites *i* and *j*.
     * @param i     int
     *              One of the sites $H_{eff}$ acts.
     * @param j     int
     *              One of the sites $H_{eff}$ acts.
     * @param bra   ForkTPS
     *              Bra-vector with which to perform the contraction.
     * @param ket   ForkTPS
     *              Ket-vector with which to perform the contraction.
    */
    void position(int i, int j, const ForkTPS &bra, const ForkTPS &ket);

    /**
     * Contracts the tensor network with FTPS *psi* that the effective Hamiltonian
     * acts on site *i*.
     * @param i     int
     *              The site $H_{eff}$ acts.
     * @param psi   ForkTPS
     *              State with which to perform the contraction.
    */
    void position(int i, const ForkTPS &psi);

    /**
     * Contracts the tensor network with FTPS *bra* and *ket* for the bra- and
     * ket-vector respectiviely such that the effective Hamiltonian acts on site *i*.
     * @param i     int
     *              The site $H_{eff}$ acts.
     * @param bra   ForkTPS
     *              Bra-vector with which to perform the contraction.
     * @param ket   ForkTPS
     *              Ket-vector with which to perform the contraction.
    */
    void position(int i, const ForkTPS &bra, const ForkTPS &ket);

    /** 
     * Contracts the tensor network with FTPS *psi* that the effective Hamiltonian
     * acts on the link between the two sites *i* and *j*.
     * @param i     int
     *              One of the sites defining the link on which $H_{eff}$ acts.
     * @param j     int
     *              One of the sites defining the link on which $H_{eff}$ acts.
     * @param psi   ForkTPS
     *              State with which to perform the contraction.
    */
    void position_0site(int i, int j, const ForkTPS &psi);

    /** 
     * Contracts the tensor network with FTPS *bra* and *ket* for the bra- and
     * ket-vector respectiviely such that the effective Hamiltonian
     * acts on the link between the two sites *i* and *j*.
     * @param i     int
     *              One of the sites defining the link on which $H_{eff}$ acts.
     * @param j     int
     *              One of the sites defining the link on which $H_{eff}$ acts.
     * @param bra   ForkTPS
     *              Bra-vector with which to perform the contraction.
     * @param ket   ForkTPS
     *              Ket-vector with which to perform the contraction.
    */
    void position_0site(int i, int j, const ForkTPS &bra, const ForkTPS &ket);

    /// Returns site *i* the effective Hamiltonian acts on.
    int i();

    /// Returns site *j* the effective Hamiltonian acts on. *j=-1* if single-site effective H.
    int j();

    private:
    /**
    * Fully contracts arm *arm* with the two states *bra* and *ket* for the bra- and
    * ket vector respectively.
    */
    void FullContractArm(int arm, const ForkTPS &bra, const ForkTPS &ket);

    /** Contracts arm *arm*, so that the effective Hamiltonian acts on sites *i* 
     *  and *j* using FTPS *bra* and *ket* for the bra-and ket-vector respectively.
     *  If *i* is an impurity site it contracts up to 
     *  Nbath-1 starting from the rightmost bathsite. This function is used by the two
     *  position functions.
    */
    void ContractArm(int i, int j, int arm, const ForkTPS &bra, const ForkTPS &ket);

    /** Contracts arm *arm*, so that the effective Hamiltonian acts on site *i*,
     *  using FTPS *bra* and *ket* for the bra- and ket-vector respectively.
     *  If *i* is an impurity site it contracts up to Nbath-1
     *  starting from the rightmost bathsite. This function is used by the two
     *  position functions.
    */
    void ContractArm(int i, int arm, const ForkTPS &bra, const ForkTPS &ket);

    /** Contracts the *arm* such that the link between sites *i* and *j* is active,
    *   using FTPS *bra* and *ket* for the bra- and ket-vector respectively.
    */
    void ContractArm_0site(int i, int j, int arm, const ForkTPS &bra, const ForkTPS &ket);

    /** Contracts the impurity with *indx* towards direction *dir* using
     *  *bra* and *ket* fro the bra- and ket-vector.
    */
    void ContractImp(int indx, OrthoState dir, const ForkTPS &bra, const ForkTPS &ket);

    /** Stores the correct tensors in L, R, D and U, after the contraction
     *  calculated. This version is used for two-site algorithms. Note that if both sites
     *  are impurity sites, L and R are used to store the bath contractions altough
     *  they are both to the right.
    */
    void SetTwoSiteEnv();

    /** Stores the correct tensors in L, R, D and U, after the contraction
     *  calculated. This version is used for single-site algorithms.
    */
    void SetSingleSiteEnv();

    /**
      * Stores the correct environment tensors in L, R, of the zero-site Heff used in TDVP
    */
    void SetLinkEnv();

    /** Performs a single leftwards contraction step (towards the impurity)
    *   on arm *arm* and index *indx* using state *bra* and *ket* for the bra-
    *   and ket-vector respectively.
    */
    void ContractLeft(int arm, int indx, const ForkTPS &bra, const ForkTPS &ket);

    /** Performs a single rightwards contraction step (away from the impurity)
    *   on arm *arm* and index *indx* using state *bra* and *ket* for the bra-
    *   and ket-vector respectively.
    */
    void ContractRight(int arm, int indx, const ForkTPS &bra, const ForkTPS &ket);

    public:
    /** Returns the environment tensor the current site in direction *dir*. Only works if
    *   local MPO is in its single-site state and if site *i* is the open index.
    */
    const ITensor &GetEnvironment(OrthoState dir) const;

    /** Calculates the expansion tensor used in the subspace expansion (PRB 91, 155115).
    *   It is computed for the currently active site in direction *dir*, 
    *   using state *psi* for the MPS tensor. Returns the expansion
    *   tensor itself and the index that resulted from combining the indices from
    *   the state and the operator.
    * @param dir  OrthoState
    *             Direction in which to expand, defines the link that is enlarged.
    * @param psi  ForkTPS
    *             State to perform to multiply.
    */
    std::pair<ITensor, Index> ExpansionTensor(OrthoState dir, const ForkTPS &psi) const;

    /** Implementation of the matrix-vector product *res* = Heff *x* 
     *  used in sparse eigenvalue solvers like lanzcos and davidson.
     * @param x     ITensor
     *              Tensor multiplied by $H_{eff}$.
     * @param res   ITensor
     *              Resulting tensor.
    */
    void product(const ITensor &x, ITensor &res) const;

    /** Implementation of the matrix-vector product *res* = Heff Ai*Aj 
     *  used in sparse eigenvalue solvers like lanzcos and davidson. 
     *  Has the same effect as product(Ai*Aj, res), but is cheaper if *Ai* and *Aj* are known.
     * @param Ai    ITensor
     *              Tensor multiplied by $H_{eff}$.
     * @param Aj    ITensor
     *              Tensor multiplied by $H_{eff}$.
     * @param res   ITensor
     *              Resulting tensor.
    */
    //void product(const ITensor &Ai, const ITensor &Aj, ITensor &res) const;

    /** Based on the current contraction of Heff, calculates the full-tensor
    *   network contraction of <psi|H|psi> and returns the result. Note that
    *   this only works if the previous contractions were also computed with *psi*.
    *   When used during DMRG, the real part of the result is the energy and the 
    *   imaginary part zero.
    * @param psi   ForkTPS
    *              State to contract the tensor network with.
    */
    Complex ContractAll(const ForkTPS &psi);

    /** Based on the current contraction of Heff, calculates the full-tensor
    *   network contraction of <bra|H|ket> and returns the result.
    * @param bra   ForkTPS
    *              Bra-vector to contract the tensor network with.
    * @param ket   ForkTPS
    *              Ket-vector to contract the tensor network with.
    */
    Complex ContractAll(const ForkTPS &bra, const ForkTPS &ket);

    /** Calculates the energy of state *psi*, given that all previous contractions
    *   were already performed with *psi*.
    * @param psi   ForkTPS
    *              State to calculate the energy with.
    */
    double energy(const ForkTPS &psi);

    /** Tells the effective Hamiltonian that *site* changed and needs to be contracted again. 
    * @param site  int
    *              Site to be contracted again.
    */
    void UpdateMe(int site);

    /** Tells the effective Hamiltonian that *sitei* and *sitej* changed and need to be contracted again. 
    * @param sitei  int
    *               Site to be contracted again.
    * @param sitej  int
    *               Site to be contracted again.
    */
    void UpdateMe(int sitei, int sitej);

    /**
     * Deletes any knowledge of the current contraction. If position
     * is called after this the whole tensor network is contracted again
    */
    void ForgetContraction();

    /**
     * Returns the matrix size of Heff, needed by the davidson algorithm.
    */
    unsigned long size() const;

    /**
     * Writes all contracted tensors L, R, U and D to the console. Used for debugging to check
     * if the correct tensor are contracded etc.
    */
    void PrintEnvironment() const;

    private:
    /// Stores the L and R tensors for each Arm, inner and outerOrthoLim are used to find out how far the network is contracted
    std::vector<Arm> ProjHArm;

    /// Stores contracted tensors for the impurity sites
    std::vector<ITensor> ProjHImp;

    /// Defines orthogonality conditions of impurity sites.
    std::vector<OrthoState> ImpOrtho;

    /// Number of open sites
    int NOpen = -1;

    /// Site Index of the first open site
    int IOpen = -1;
    /// Site Index of the second open site (not defined in single-site version)
    int JOpen = -1;

    public:
    /// Operator on which Heff is based
    ForkTPO H;

    /// Environment tensor Leftwards of currently open indices
    ITensor L;
    /// Environment tensor Rightwards of currently open indices
    ITensor R;
    /// Environment tensor Upwards of currently open indices
    ITensor U;
    /// Environment tensor Downwards of currently open indices
    ITensor D;
  };

} // namespace forktps

#endif
