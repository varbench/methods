#ifndef __FORK_TYPEDEFS__
#define __FORK_TYPEDEFS__

#include "forktps/types.hpp"

#include <complex>
#include <itensor/global.h>
#include <itensor/real.h>
#include <itensor/types.h>
#include <string>

namespace forktps {

  /// triqs index type corresponding to the block structure of GFs
  using triqs_indx = std::pair<std::string, int>;

  /// Double matrix
  using Dmat = std::vector<std::vector<double>>;
  /// Complex matrix
  using Cmat = std::vector<std::vector<itensor::Complex>>;
  /// Integer matrix
  using Imat = std::vector<std::vector<int>>;

  /// Vector of integers
  using ivec = std::vector<int>;
  /// Vector of doubles
  using dvec = std::vector<double>;
  /// Vector of complex
  using cvec = std::vector<itensor::Complex>;

  /** Types of Green's functions for single particle (singlePart_greater and singlePart_lesser) as
  * well as for the greater and lesser component of the Green's function $\langle { [H_{int},c_i] , c_j^\dagger } \rangle$
  * used in the self-energy trick.
  */
  enum GFtype {
    singlePart_greater,
    singlePart_lesser, // < c(t) * c^dag > , <c^dag * c(t)>
    selfEnergy_greater,
    selfEnergy_lesser,     // < [Hint, c](t) * c^dag > , < c^dag * [Hint, c](t)>
    density,               // < ni(t) nj > , note no greater or lesser state needed to time evolve
    custom,                // For general GF < A(t) B >
    NUM_TYPES = custom + 1 // additional entry representing the total number of types
  };

  enum TevoDir { Forward = 1, Back = -1 };

  void reverse(TevoDir &dir);

  /** Enum for Bra and Ket Vectors.
  */
  enum BraKet { Bra, Ket };

  /// Returns whether *type* is single particle Green's function.
  bool isSingleParticle(GFtype type);
  /// Returns whether *type* is a greater GF
  bool isGreater(GFtype type);
  /// Returns whether *type* is a lesser GF
  bool isLesser(GFtype type);

  /// Returns whether *type* is self energy Green's function.
  bool isSelfEnergy(GFtype type);
  /// Returns whether *type* is density Green's function.
  bool isDensity(GFtype type);
  /// Returns whether *type* is a custom type
  bool isCustom(GFtype type);

  /**
  * Enum for spins.
  */
  enum Spin { Up, Down };

  /**
  * Enum to define the orthogonality state of a tensor in the forktps. For a Bath tensor $A$, Rightwards means
  * for example that a contraction of $A^dagger A$ over the left in index as well as the site-index gives the identity
  * with respect to the right index. Similarly, for an Impurity tensor $A$, Rightwards means
  * that a contraction of $A^dagger A$ over the indices pointing up and down as well as the site-index gives the identity
  * with respect to the index pointing right.
  */
  enum OrthoState { Rightwards, Leftwards, Upwards, Downwards, Nonewards };

  /// Converter of GFtype to string.
  std::string to_string(GFtype type);
  /// Converter of BraKet to string.
  std::string to_string(BraKet bk);
  /// Converter of OrthoState to string.
  std::string to_string(OrthoState state);
  /// Converter of Spin to string.
  std::string to_string(Spin s);

  /** Names of various tensor network approximation parameters. 
  */
  struct Names {
    // Since this will be used in the intensor Args object use char*.

    /// Name of maximal bond dimension of impurity-impurity links.
    static const char *MAXMI;
    /// Name of maximal bond dimension of bath-bath links.
    static const char *MAXMB;
    /// Name of maximal bond dimension of impurity-bath links.
    static const char *MAXMIB;

    /// Name of truncated weight of impurity-impurity links.
    static const char *TWI;
    /// Name of truncated weight of bath-bath links.
    static const char *TWB;
    /// Name of truncated weight of impurity-bath links.
    static const char *TWIB;

    /// Itensor tags of impurity-impurity links.
    static const char *TAGSI;
    /// Itensor tags of bath-bath links.
    static const char *TAGSB;
    /// Itensor tags of impurity-bath links.
    static const char *TAGSIB;
  };

  const double TOOSMALL = 1E-15;
  const double ZERONORM = 1E-20;

  //defines allowed triqs block names.
  const std::vector<std::string> validBNup({"up", "Up"});
  const std::vector<std::string> validBNdn({"down", "Down", "dn"});
  const std::vector<std::string> validBN_SO({"ud_0", "ud_1"});

} // namespace forktps

#endif
