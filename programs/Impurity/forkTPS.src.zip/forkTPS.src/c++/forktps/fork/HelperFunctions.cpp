#include "HelperFunctions.hpp"

#include <forktps/fork/HelperFunctions.hpp>
#include <itensor/mps/siteset.h>
#include <optional>
#undef Print

#include <tuple>
#include <utility>
#include <ctime>
#include <functional>

using namespace forktps;

namespace forktps {

  std::vector<double> roundVec(const std::vector<double> &vec, int precision) {
    std::vector<double> rounded(0);
    for (auto v : vec) { rounded.push_back(roundVal(v, precision)); }
    return rounded;
  }

  double roundVal(double v, int precision) {
    int power  = std::pow(10, precision);
    auto round = std::round(v * power);
    return static_cast<double>(round) / power;
  }

  void PrintBorderLine(int num) {
    for (int i = 1; i <= num; i++) {
      std::cout << "-------------------------------------------------------------"
                   "-------------------------------"
                << std::endl;
    }
  }

  std::pair<ITensor, Index> LinkCombiner(const ITensor &A, const ITensor &B) {
    ITensor comb;
    //auto cinds = stdx::reserve_vector<Index>(A.r());
    std::vector<Index> cinds;
    for (auto &I : A.inds()) {
      if (hasIndex(B, I)) { cinds.push_back(I); }
    }
    Index c;
    std::tie(comb, c) = combiner(std::move(cinds));

    return std::make_pair(comb, c);
  }

  std::pair<ITensor, Index> LinkCombiner(const Index &i, const Index &j) {
    auto [comb, c] = combiner({i, j});
    return std::make_pair(comb, c);
  }

  itensor::IndexSet AllExcept(ITensor A, Index remove, Index add) {
    if (!itensor::hasIndex(A, remove)) Error("allExcept: A must contain index remove");

    std::vector<Index> store(0);
    for (auto ind : A.inds()) {
      if (ind != remove) store.push_back(ind);
    }

    if (add) store.push_back(add);

    return IndexSet(std::move(store));
  }

  long int MaxDim(const ITensor &A) {
    // return the maximum bond dimension of ITensor A
    long int max = 0;
    for (auto inds : A.inds()) { max = std::max(dim(inds), max); }
    return max;
  }

  long int Dim(const ITensor &A) {
    long int dimension = 1;
    for (auto ind : A.inds()) dimension *= dim(ind);

    return dimension;
  }

  void save(std::string fn, const ForkTPS &psi) {
    std::ofstream outstream(fn);
    psi.write(outstream);
    outstream.close();
  }

  void load(std::string fn, ForkTPS &psi, const SiteSet &sites) {
    std::ifstream instream(fn);
    if (instream.good()) {
      psi.read(instream, sites);
      instream.close();
    } else {
      instream.close();
      Error("Loading a ForkTPS: trying to load from invalid file.");
    }
  }

  void saveGS(const std::string fn, const ForkTPS &gs, const AIM_ForkSites &sites, double energy) {
    std::ofstream os(fn);
    if (os.bad()) throw ITError("Cant write to file " + fn);

    itensor::write(os, energy);
    sites.write(os);
    gs.write(os);

    os.close();
  }

  void loadGS(const std::string fn, ForkTPS &gs, AIM_ForkSites &sites, double &energy) {
    std::ifstream is(fn);
    if (is.bad()) throw ITError("Cant read from file " + fn);

    itensor::read(is, energy);
    sites.read(is);
    gs.read(is, sites);

    is.close();
  }

  /** Sets MaxDim and Cutoff of *args* to the correct values specified by the link
  *   of site *i* with its neighbor in direction *dir* in geometry *F*. Also returns
  *   the itensor tags of that link used in the svd.
  */
  std::string SetSVDParams(int i, const Fork &F, OrthoState dir, Args &args, int defaultMaxDim, double defaultCutoff) {

    long maxm{};
    double cutoff{};

    std::string TagName;
    int j = F.Neighbor(i, dir);

    if (F.IsImp(i)) {
      // i is an impurity site
      if (dir == Rightwards) {
        maxm    = args.getInt(Names::MAXMIB, args.getInt("MaxDim", defaultMaxDim));
        cutoff  = args.getReal(Names::TWIB, args.getReal("Cutoff", defaultCutoff));
        TagName = Names::TAGSIB;
      } else {
        maxm    = args.getInt(Names::MAXMI, args.getInt("MaxDim", defaultMaxDim));
        cutoff  = args.getReal(Names::TWI, args.getReal("Cutoff", defaultCutoff));
        TagName = Names::TAGSI;
      }
    } else {
      // i is a bath site
      if (F.IsImp(j)) {
        maxm    = args.getInt(Names::MAXMIB, args.getInt("MaxDim", defaultMaxDim));
        cutoff  = args.getReal(Names::TWIB, args.getReal("Cutoff", defaultCutoff));
        TagName = Names::TAGSIB;
      } else {
        maxm    = args.getInt(Names::MAXMB, args.getInt("MaxDim", defaultMaxDim));
        cutoff  = args.getReal(Names::TWB, args.getReal("Cutoff", defaultCutoff));
        TagName = Names::TAGSB;
      }
    }

    args.add("Cutoff", cutoff);
    args.add("MaxDim", maxm);
    return TagName;
  }

  std::string SetSVDParams(int i, const Fork &F, OrthoState dir, Args &args) {

    long maxm{};
    double cutoff{};
    const double defaultTw  = 1E-10;
    const long defaultDimI  = 200;
    const long defaultDimIB = 200;
    const long defaultDimB  = 400;

    std::string TagName;
    int j = F.Neighbor(i, dir);

    if (F.IsImp(i)) {
      if (dir == Rightwards) {
        maxm    = args.getInt(Names::MAXMIB, args.getInt("MaxDim", defaultDimIB));
        cutoff  = args.getReal(Names::TWIB, args.getReal("Cutoff", defaultTw));
        TagName = Names::TAGSIB;
      } else {
        maxm    = args.getInt(Names::MAXMI, args.getInt("MaxDim", defaultDimI));
        cutoff  = args.getReal(Names::TWI, args.getReal("Cutoff", defaultTw));
        TagName = Names::TAGSI;
      }
    } else {
      // i is a bath site
      if (F.IsImp(j)) {
        maxm    = args.getInt(Names::MAXMIB, args.getInt("MaxDim", defaultDimIB));
        cutoff  = args.getReal(Names::TWIB, args.getReal("Cutoff", defaultTw));
        TagName = Names::TAGSIB;
      } else {
        maxm    = args.getInt(Names::MAXMB, args.getInt("MaxDim", defaultDimB));
        cutoff  = args.getReal(Names::TWB, args.getReal("Cutoff", defaultTw));
        TagName = Names::TAGSB;
      }
    }

    args.add("Cutoff", cutoff);
    args.add("MaxDim", maxm);
    return TagName;
  }

  std::pair<ITensor, Index> nonSquareDiag(const Index &c, int dim) {
    Index cdag = dag(c);
    std::vector<std::pair<QN, long>> qnints{};
    long remainingSize   = dim;
    auto indicesPerBlock = static_cast<long>(std::max(1l, dim / c.nblock()));

    std::vector<int> sizes   = {};
    std::vector<int> offsets = {0};

    for (auto block : range1(c.nblock())) {
      int size = std::min(c.blocksize(block), indicesPerBlock);
      qnints.emplace_back(std::pair<QN, long>(c.qn(block), size));

      sizes.push_back(size);
      offsets.push_back(offsets.back() + c.blocksize(block));

      remainingSize -= indicesPerBlock;
      if (remainingSize <= 0) break;
    }
    Index reducedC(std::move(qnints), c.dir());

    ITensor diag(cdag, reducedC);

    int reducedIndex = 1;
    for (auto [blockIndex, size] : itertools::enumerate(sizes)) {
      for (auto k : range1(size)) {
        int cIndex = offsets[blockIndex] + k;
        diag.set(cdag(cIndex), reducedC(reducedIndex), 1.);

        reducedIndex++;
      }
    }

    return std::make_pair(diag, reducedC);
  }

} // namespace forktps
