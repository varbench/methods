#pragma once
#include "forktps/fork/typenames.hpp"
#include "forktps/fork/Fork.hpp"
#include "forktps/fork/ForkTN.hpp"
#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/ForkTPO.hpp"
#include "forktps/fork/ForkCalculus.hpp"
#include <forktps/fork/ForkLocalOp.hpp>
#include <forktps/fork/TevoMethods.hpp>
#include "itensor/mps/mpsalgs.cc"
#include "itensor/util/cputime.h"

using namespace itensor;

namespace forktps {
  ForkTPS DirectSum(ForkTPS const &psi_, ForkTPS const &phi_) {
    ForkTPS res = psi_;
    ITensor first, second, first_l, second_l;
    std::vector<ITensor> impTensors_psi(psi_.NArms()), impTensors_phi(phi_.NArms());

    if (psi_.NArms() != phi_.NArms() || psi_.N() != phi_.N()) { Error("@DirectSum, the input states do not have the same fork structure"); }
    //loop over the arms to sum bath tensors
    for (auto iarm : range1(psi_.NArms())) {
      auto impThisArm      = psi_.ImpSite(iarm);
      auto lastBathThisArm = psi_.ArmToSite(iarm, 1);
      //loop from the last site on this arm
      int site      = lastBathThisArm;
      auto link_psi = commonIndex(psi_.A(site), psi_.A(site - 1));
      auto link_phi = commonIndex(phi_.A(site), phi_.A(site - 1));
      auto link_sum = link_psi;
      plussers(link_psi, link_phi, link_sum, first, second);
      res.Anc(site) = psi_.A(site) * first + phi_.A(site) * second;
      for (int site = lastBathThisArm - 1; site > impThisArm; site--) {
        //ReportOnce("arm ", iarm, " bath site ", site, "\n");
        first_l  = first;
        second_l = second;

        link_psi = commonIndex(psi_.A(site), psi_.A(site - 1));
        link_phi = commonIndex(phi_.A(site), phi_.A(site - 1));
        link_sum = link_psi;
        plussers(link_psi, link_phi, link_sum, first, second);
        res.Anc(site) = dag(first_l) * psi_.A(site) * first + dag(second_l) * phi_.A(site) * second;
      }
      //ReportOnce("add imp site ", impThisArm);
      impTensors_psi.at(iarm - 1) = dag(first) * psi_.A(impThisArm);
      impTensors_phi.at(iarm - 1) = dag(second) * phi_.A(impThisArm);
    }
    //sum the impurity tensors
    auto thisImpSite = psi_.ImpSite(1);
    auto nextImpSite = psi_.ImpSite(2);

    auto link_psi = commonIndex(psi_.A(thisImpSite), psi_.A(nextImpSite));
    auto link_phi = commonIndex(phi_.A(thisImpSite), phi_.A(nextImpSite));
    auto link_sum = link_psi;
    plussers(link_psi, link_phi, link_sum, first, second);
    res.Anc(thisImpSite) = impTensors_psi.at(0) * first + impTensors_phi.at(0) * second;
    for (int iarm = 2; iarm < psi_.NArms(); iarm++) {
      first_l  = first;
      second_l = second;

      thisImpSite = psi_.ImpSite(iarm);
      nextImpSite = psi_.ImpSite(iarm + 1);

      link_psi = commonIndex(psi_.A(thisImpSite), psi_.A(nextImpSite));
      link_phi = commonIndex(phi_.A(thisImpSite), phi_.A(nextImpSite));
      link_sum = link_psi;
      plussers(link_psi, link_phi, link_sum, first, second);
      res.Anc(thisImpSite) = dag(first_l) * impTensors_psi.at(iarm - 1) * first + dag(second_l) * impTensors_phi.at(iarm - 1) * second;
    }
    thisImpSite          = psi_.ImpSite(psi_.NArms());
    res.Anc(thisImpSite) = dag(first) * impTensors_psi.at(psi_.NArms() - 1) + dag(second) * impTensors_phi.at(phi_.NArms() - 1);

    return res;
  }

  void addBasisWorker(std::vector<ForkTPS> &psis, ForkTPS &res, std::vector<ITensor> &Bs, int site, OrthoState dir, Args args = Args::global()) {
    int nextsite      = res.Neighbor(site, dir);
    auto [V1, S1, U1] = svd(Bs.front(), commonIndex(res.A(site), res.A(nextsite)));

    auto &to_orth    = Bs.front();
    auto &newoc      = res.A(nextsite);
    auto &activeInds = to_orth.inds();
    //auto cinds       = stdx::reserve_vector<Index>(activeInds.r());
    std::vector<Index> cinds;
    for (auto &I : activeInds) {
      if (!hasIndex(newoc, I)) cinds.push_back(I);
    }

    auto [cmb, mid] = combiner(std::move(cinds));

    if (dim(mid) <= dim(commonIndex(U1, S1))) {
      res.Anc(site) = U1;
      //res.InsertOrthoTensor(U1, site, dir);
    } else {
      // Density matrix summation to be truncated
      ITensor rho2;
      auto psi = psis.begin();
      for (auto B = Bs.begin() + 1; B != Bs.end(); ++B, ++psi) {
        rho2 += prime(*B) * dag(prime(*B, commonIndex((*psi).A(site), (*psi).A(nextsite))));
      }
      rho2.swapPrime(0, 1);

      U1 *= cmb;
      rho2 *= cmb;
      cmb.prime();
      cmb.dag();
      rho2 *= cmb;
      cmb.noPrime();

      // Project rho2c to the orthogonal complement of U1
      auto proj2    = toDense(delta(dag(mid), prime(mid))) - dag(U1) * prime(U1, mid);
      auto normrho2 = norm(rho2);
      rho2 *= mapPrime(proj2, 0, 2);
      rho2 *= proj2;
      rho2.mapPrime(2, 0);
      rho2.swapPrime(0, 1);
      auto normPrho2P = norm(rho2);
      if (normPrho2P / normrho2 < 1E-14) {
        res.Anc(site) = cmb * U1;
        //auto newTensor = cmb * U1;
        //res.InsertOrthoTensor(newTensor, site, dir);
      } else {
        // Diagonalize rho2c to obtain U2
        ITensor U2, D2;
        Args argsBasis{"Truncate", true};
        argsBasis.add("Cutoff", args.getReal("cutoffBE", 1E-6));
        argsBasis.add("MaxDim", args.getInt("bondBE", 30));
        //diagPosSemiDef(rho2, U2, D2, argsBasis); // T==prime(U)*D*dag(U)
        diag_hermitian(rho2, U2, D2, argsBasis);
        U2.dag();
        // Direct sum of U1 and U2
        auto i1 = commonIndex(U1, S1);
        auto i2 = commonIndex(U2, D2);
        Index sumind;
        if (res.IsImp(site) && res.IsImp(nextsite)) {
          sumind = Index(dim(i1) + dim(i2), Names::TAGSI);
        } else if (res.IsImp(site) && !res.IsImp(nextsite)) {
          sumind = Index(dim(i1) + dim(i2), Names::TAGSIB);
        } else if (!res.IsImp(site) && res.IsImp(nextsite)) {
          sumind = Index(dim(i1) + dim(i2), Names::TAGSIB);
        } else if (!res.IsImp(site) && !res.IsImp(nextsite)) {
          sumind = Index(dim(i1) + dim(i2), Names::TAGSB);
        } else {
          Error("addBasisWorker::sumind not correct!");
        }
        //printfln("------------- dim(i1)=%.12f, dim(i2)=%.12f, dim(sumind)=%.12f", dim(i1), dim(i2), dim(sumind));
        sumind.setDir(i1.dir());
        ITensor expand1, expand2;
        plussers(i1, i2, sumind, expand1, expand2);
        auto U        = U1 * expand1 + U2 * expand2;
        res.Anc(site) = cmb * U;
        //auto newTensor = cmb * U;
        //res.InsertOrthoTensor(newTensor, site, dir);
      }
    }
    // Obtain the new Bs for the operation of the next site
    Bs.front() *= dag(res.A(site));
    Bs.front() *= res.A(nextsite);
    auto psi = psis.begin();
    for (auto B = Bs.begin() + 1; B != Bs.end(); ++B, ++psi) {
      (*B) *= dag(res.A(site));
      (*B) *= (*psi).A(nextsite);
    }
  }

  /**
   * @brief using the krylov vectors generated by the input state res and Hamiltonian H to expand the basis 
   * 
   * @param res ForkTPS, refs of the state to be expanded
   * @param H   ForkTPO, tensor product operator representation of the Hamiltonian
   * @param args itensor::args, 
   *              int NKrylovBE   = 2,     number of krylov vectors used for the basis expansion
   *              bool verbose    = false, print out the details
   *              book fitApplyTPO=false,  apply ForkTPO onto ForkTPS exactly
   *                              =true,   apply ForkTPO onto ForkTPS by variational fitting algorithm
   */

  void addBasis(ForkTPS &res, ForkTPO const &H, Args args = Args::global()) {
    cpu_time expand_time;
    //generate the states that will be used to construct the expansion basis
    auto NKrylovBE = args.getInt("nKrylovBE", 2);
    bool verbose   = args.getBool("verbose", false);
    std::vector<ForkTPS> psis(NKrylovBE);
    Args args_check("Cutoff", -1);
    //bool fitApplyTPO  = args.getBool("fitApplyTPO", false); //res.MaxM() >= 10 ? true : false;
    //double oriErrGoal = args.getReal("ErrGoal");

    std::string Method = args.getString("BEMethod", "ApplyH");
    if (Method == "ApplyH" || Method == "ApplyExp") {
      Args args_applyH;
      args_applyH.add("UseSVD", true);
      args_applyH.add("MaxDim", args.getInt("MaxmI", 30));
      args_applyH.add("Cutoff", args.getReal("Cutoff", 1E-6));
      Args args_fit = args;
      args_fit.add("SubspaceMaxm", args.getInt("bondBE", 20));
      args_fit.add("MaxDim", args.getInt("MaxmI", 30));
      args_fit.add("Cutoff", args.getReal("Cutoff", 1E-6));
      args_fit.add("maxsweeps", 2);
      args_fit.add("ErrGoal", args.getReal("CutoffBE", 1E-4));

      long minI_ = 1000, maxI_ = 0;
      for (int iArm = 1; iArm < res.NArms(); ++iArm) {
        auto ind = commonIndex(res.A(res.ImpSite(iArm)), res.A(res.ImpSite(iArm + 1)));
        minI_    = std::min(minI_, dim(ind));
        maxI_    = std::max(maxI_, dim(ind));
      }

      if (verbose) { std::cout << "reference states are generated by " << Method << std::endl; };
      if (maxI_ <= 50) {
        psis.at(0) = exactApplyMPO(res, H, args_applyH);
      } else {
        psis.at(0) = FitApplyMPO(res, H, args_fit);
        //psis.at(0) = exactApplyMPO(res, H, args_applyH);
      }
      psis.at(0).position(1, args_check);
      psis.at(0).normalize();
      for (int ik = 1; ik < NKrylovBE; ++ik) {
        //psis.at(ik) = exactApplyMPO(psis.at(ik - 1), H, args_applyH);
        //psis.at(ik) = FitApplyMPO(psis.at(ik - 1), H, args_fit);
        if (maxI_ <= 50) {
          psis.at(ik) = exactApplyMPO(psis.at(ik - 1), H, args_applyH);
        } else {
          psis.at(ik) = FitApplyMPO(psis.at(ik - 1), H, args_fit);
          //psis.at(0) = exactApplyMPO(res, H, args_applyH);
        }

        psis.at(ik).position(1, args_check);
        psis.at(ik).normalize();
        if (args.getBool("verboseBEPrint", false)) {
          std::cout << ik << " th vector :: norm=" << psis.at(ik).norm() << std::endl;
          psis.at(ik).PrintImpM();
        }
      }
      for (int ik = 0; ik < NKrylovBE; ++ik) { psis.at(ik).position(1, args_applyH); };
    } else if (Method == "ImagTime") {
      if (verbose) { std::cout << "reference states are generated by " << Method << std::endl; };
      std::string tevoMehtodIn = args.getString("TevoMethod");
      args.add("TevoMethod", "TDVP_2");
      auto Heff_ = ForkLocalOp(H);
      double dt  = 0.05;
      for (int ik = 0; ik < NKrylovBE; ik++) {
        if (ik == 0) {
          Heff_.ForgetContraction();
          psis.at(ik) = res;
          TDVP(psis.at(ik), Heff_, Complex_i * dt, args);
          psis.at(ik).normalize();
        } else {
          Heff_.ForgetContraction();
          psis.at(ik) = psis.at(ik - 1);
          TDVP(psis.at(ik), Heff_, dt, args);
          psis.at(ik).normalize();
        }
      }
      args.add("TevoMethod", tevoMehtodIn);
    } else if (Method == "RealTime") {
      Args args_applyH;
      args_applyH.add("UseSVD", true);
      args_applyH.add("MaxDim", args.getInt("MaxmI", 20));
      args_applyH.add("Cutoff", 1E-16);
      psis.at(0) = exactApplyMPO(res, H, args_applyH);
      psis.at(0).position(1, args_applyH);
      psis.at(0) *= (-0.1 * Complex_i);
      psis.at(0) = DirectSum(res, psis.at(0));
      psis.at(0).normalize();
      for (int ik = 1; ik < NKrylovBE; ++ik) {
        psis.at(ik) = exactApplyMPO(psis.at(ik - 1), H, args_applyH);
        psis.at(ik).position(1, args_applyH);
        psis.at(ik) *= (-0.1 * Complex_i);
        psis.at(ik) = DirectSum(psis.at(ik - 1), psis.at(ik));
        psis.at(ik).normalize();
      }
      for (int ik = 0; ik < NKrylovBE; ++ik) { psis.at(ik).position(1, args_applyH); };
    } else {
      Error("---@addBasis:: Wrong BEMethod to generate reference states");
    }

    int startSite = res.ArmToSite(res.NArms(), 1);
    res.position(startSite, args_check);
    for (auto &psi : psis) { psi.position(startSite, args_check); }
    if (verbose) {
      printfln("addBasis::The input state has a norm of %.12f and max bond dimension %.12f ", res.norm(), res.MaxM());
      printfln("addBasis::The states used for expansion has::");
      for (auto const &psi : psis) {
        long maxI_ = 0;
        for (int iArm = 1; iArm < psi.NArms(); ++iArm) {
          auto ind = commonIndex(psi.A(psi.ImpSite(iArm)), psi.A(psi.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
        }
        printfln("------ norm=%.12f,  and max bond dimesnion=%.12f, and maxI =%.12f", psi.norm(), psi.MaxM(), maxI_);
      };
      printfln("addBasis::The basis expansion starts from site %.12f", startSite);
    }
    //record the initial energy
    double energyInitial{0.}, normIni{0.0};
    {
      auto Heff_ = ForkLocalOp(H);
      Heff_.position(1, res);
      energyInitial = std::real(Heff_.ContractAll(res));
      normIni       = res.norm();
    }
    //initialize the Bs tensors which keep tracking of the orthogonality center tensors
    std::vector<ITensor> Bs(psis.size() + 1);

    int NArms = res.NArms();
    //the NArm'th arm
    auto impThisArm      = res.ImpSite(NArms);
    auto lastBathThisArm = res.ArmToSite(NArms, 1);

    Bs.front() = res.A(lastBathThisArm);
    for (int i = 0; i < psis.size(); ++i) { Bs.at(i + 1) = psis.at(i).A(lastBathThisArm); }

    for (int site = lastBathThisArm; site > impThisArm; --site) { addBasisWorker(psis, res, Bs, site, Leftwards, args); }
    addBasisWorker(psis, res, Bs, impThisArm, Upwards, args);

    //middle arms
    for (int iArm = NArms - 1; iArm > 1; --iArm) {
      impThisArm      = res.ImpSite(iArm);
      lastBathThisArm = res.ArmToSite(iArm, 1);

      for (int site = impThisArm; site < lastBathThisArm; ++site) {
        if (site == impThisArm) {
          auto [V1, S1, U1] = svd(Bs.front(), commonIndex(Bs.front(), res.A(site + 1)));
          res.Anc(site)     = U1;
          //res.InsertOrthoTensor(U1, site, Rightwards);
          res.Anc(site + 1) *= (S1 * V1);
        } else {
          auto [V1, S1, U1] = svd(res.A(site), commonIndex(res.A(site), res.A(site + 1)));
          res.Anc(site)     = U1;
          //res.InsertOrthoTensor(U1, site, Rightwards);
          res.Anc(site + 1) *= (S1 * V1);
        }
      }

      for (int i = 0; i < psis.size(); ++i) {
        for (int site = impThisArm; site < lastBathThisArm; ++site) {
          if (site == impThisArm) {
            auto [V2, S2, U2]    = svd(Bs.at(i + 1), commonIndex(Bs.at(i + 1), psis.at(i).A(site + 1)));
            psis.at(i).Anc(site) = U2;
            psis.at(i).Anc(site + 1) *= (S2 * V2);
          } else {
            auto [V2, S2, U2]    = svd(psis.at(i).A(site), commonIndex(psis.at(i).A(site), psis.at(i).A(site + 1)));
            psis.at(i).Anc(site) = U2;
            psis.at(i).Anc(site + 1) *= (S2 * V2);
          }
        }
      }
      Bs.front() = res.A(lastBathThisArm);
      for (int i = 0; i < psis.size(); ++i) { Bs.at(i + 1) = psis.at(i).A(lastBathThisArm); }
      for (int site = lastBathThisArm; site > impThisArm; --site) { addBasisWorker(psis, res, Bs, site, Leftwards, args); }
      addBasisWorker(psis, res, Bs, impThisArm, Upwards, args);
    }

    //first arm
    impThisArm      = res.ImpSite(1);
    lastBathThisArm = res.ArmToSite(1, 1);
    for (int site = impThisArm; site < lastBathThisArm; ++site) { addBasisWorker(psis, res, Bs, site, Rightwards, args); }
    res.Anc(lastBathThisArm) = Bs.front();

    double energyExtended{0.}, normExtended{0.0};
    {
      auto Heff_ = ForkLocalOp(H);
      Heff_.position(1, res);
      energyExtended = std::real(Heff_.ContractAll(res));
      normExtended   = res.norm();
    }
    /*
    if (abs(energyInitial - energyExtended) > 1E-8) {
      Error(
         "addBasis:: the energy difference between the initial and extended state exceeds the threshold meaning the extended is modified from the initial one");
    }*/

    auto sm = expand_time.sincemark();
    //Args args_check("Cutoff", -1);

    res.position(1, args_check);
    res.position(res.N(), args_check);
    res.position(1, args_check);

    if (verbose) {
      printfln("addBasis::the norm of the initial and extended states are %.12f and %.12f", normIni, normExtended);
      printfln("addBasis::the energy of the initial and extended states are %.12f and %.12f", energyInitial, energyExtended);
      printfln("addBasis::MaxM of the state after expansion is %12.f", res.MaxM());
      for (int iArm = 1; iArm < NArms; ++iArm) {
        printfln("addBasis::dimesnion of the bond connecting the imp site is %.12f",
                 dim(commonIndex(res.A(res.ImpSite(iArm)), res.A(res.ImpSite(iArm + 1)))));
      }
      printfln("addBasis::the overall quantum number is %.12f", div(res.A(1)));
      printfln("addBasis::Global subspace expansion: cputime = %s, walltime = %s", showtime(sm.time), showtime(sm.wall));
    }
  }

  void addBasis(ForkTPS &res, ForkTPO const &H, ForkTPO const &HOffDia, Args args = Args::global()) {
    cpu_time expand_time;
    //generate the states that will be used to construct the expansion basis
    auto NKrylovBE = args.getInt("nKrylovBE", 2);
    bool verbose   = args.getBool("verbose", false);
    std::vector<ForkTPS> psis(NKrylovBE + 1);

    //bool fitApplyTPO  = args.getBool("fitApplyTPO", false); //res.MaxM() >= 10 ? true : false;
    //double oriErrGoal = args.getReal("ErrGoal");

    std::string Method = args.getString("BEMethod", "ApplyH");
    if (Method == "ApplyH") {
      Args args_applyH;
      args_applyH.add("UseSVD", false);
      args_applyH.add("MaxDim", args.getInt("MaxmI", 300));
      args_applyH.add("Cutoff", 1E-12);
      Args args_fit = args;
      args_fit.add("SubspaceMaxm", 300);
      args_fit.add("MaxDim", args.getInt("MaxmI", 300));
      args_fit.add("maxsweeps", 5);

      if (verbose) { std::cout << "reference states are generated by " << Method << std::endl; };
      psis.at(0) = exactApplyMPO(res, H, args_applyH);
      psis.at(0).position(psis.at(0).N(), args_applyH);
      psis.at(0).position(1, args_applyH);
      psis.at(0).normalize();

      for (int ik = 1; ik < NKrylovBE; ++ik) {
        //if (ik == 1) {
        //  psis.at(ik) = exactApplyMPO(psis.at(ik - 1), H, args_applyH);
        //  psis.at(ik).position(1, args_applyH);
        //} else {
        psis.at(ik) = exactApplyMPO(psis.at(ik - 1), H, args_applyH);
        psis.at(ik).position(psis.at(ik).N(), args_applyH);
        psis.at(ik).position(1, args_applyH);
        //}
        psis.at(ik).normalize();
        if (args.getBool("verboseBEPrint", false)) {
          std::cout << ik << " th vector " << std::endl;
          psis.at(ik).PrintImpM();
        }
      }
      psis.at(NKrylovBE) = exactApplyMPO(psis.at(NKrylovBE - 1), HOffDia, args_applyH);
      psis.at(NKrylovBE).position(psis.at(NKrylovBE).N(), args_applyH);
      psis.at(NKrylovBE).position(1, args_applyH);
      psis.at(NKrylovBE).normalize();

      for (int ik = 0; ik < NKrylovBE + 1; ++ik) {
        psis.at(ik).position(psis.at(ik).N(), args_applyH);
        psis.at(ik).position(1, args_applyH);
      };
    } else {
      Error("---@addBasis:: Wrong BEMethod to generate reference states");
    }

    int startSite = res.ArmToSite(res.NArms(), 1);
    res.position(startSite);
    for (auto &psi : psis) { psi.position(startSite); }
    if (verbose) {
      printfln("addBasis::The input state has a norm of %.12f and max bond dimension %.12f ", res.norm(), res.MaxM());
      printfln("addBasis::The states used for expansion has::");
      for (auto const &psi : psis) {
        long maxI_ = 0;
        for (int iArm = 1; iArm < psi.NArms(); ++iArm) {
          auto ind = commonIndex(psi.A(psi.ImpSite(iArm)), psi.A(psi.ImpSite(iArm + 1)));
          maxI_    = std::max(maxI_, dim(ind));
        }
        printfln("------ norm=%.12f,  and max bond dimesnion=%.12f, and maxI =%.12f", psi.norm(), psi.MaxM(), maxI_);
      };
      printfln("addBasis::The basis expansion starts from site %.12f", startSite);
    }
    //record the initial energy
    double energyInitial{0.};
    {
      auto resH     = exactApplyMPO(res, H, args);
      energyInitial = real(overlap(res, resH));
    }
    //initialize the Bs tensors which keep tracking of the orthogonality center tensors
    std::vector<ITensor> Bs(psis.size() + 1);

    int NArms = res.NArms();
    //the NArm'th arm
    auto impThisArm      = res.ImpSite(NArms);
    auto lastBathThisArm = res.ArmToSite(NArms, 1);

    Bs.front() = res.A(lastBathThisArm);
    for (int i = 0; i < psis.size(); ++i) { Bs.at(i + 1) = psis.at(i).A(lastBathThisArm); }

    for (int site = lastBathThisArm; site > impThisArm; --site) { addBasisWorker(psis, res, Bs, site, Leftwards, args); }
    addBasisWorker(psis, res, Bs, impThisArm, Upwards, args);

    //middle arms
    for (int iArm = NArms - 1; iArm > 1; --iArm) {
      impThisArm      = res.ImpSite(iArm);
      lastBathThisArm = res.ArmToSite(iArm, 1);

      for (int site = impThisArm; site < lastBathThisArm; ++site) {
        if (site == impThisArm) {
          auto [V1, S1, U1] = svd(Bs.front(), commonIndex(Bs.front(), res.A(site + 1)));
          res.Anc(site)     = U1;
          //res.InsertOrthoTensor(U1, site, Rightwards);
          res.Anc(site + 1) *= (S1 * V1);
        } else {
          auto [V1, S1, U1] = svd(res.A(site), commonIndex(res.A(site), res.A(site + 1)));
          res.Anc(site)     = U1;
          //res.InsertOrthoTensor(U1, site, Rightwards);
          res.Anc(site + 1) *= (S1 * V1);
        }
      }

      for (int i = 0; i < psis.size(); ++i) {
        for (int site = impThisArm; site < lastBathThisArm; ++site) {
          if (site == impThisArm) {
            auto [V2, S2, U2]    = svd(Bs.at(i + 1), commonIndex(Bs.at(i + 1), psis.at(i).A(site + 1)));
            psis.at(i).Anc(site) = U2;
            psis.at(i).Anc(site + 1) *= (S2 * V2);
          } else {
            auto [V2, S2, U2]    = svd(psis.at(i).A(site), commonIndex(psis.at(i).A(site), psis.at(i).A(site + 1)));
            psis.at(i).Anc(site) = U2;
            psis.at(i).Anc(site + 1) *= (S2 * V2);
          }
        }
      }
      Bs.front() = res.A(lastBathThisArm);
      for (int i = 0; i < psis.size(); ++i) { Bs.at(i + 1) = psis.at(i).A(lastBathThisArm); }
      for (int site = lastBathThisArm; site > impThisArm; --site) { addBasisWorker(psis, res, Bs, site, Leftwards, args); }
      addBasisWorker(psis, res, Bs, impThisArm, Upwards, args);
    }

    //first arm
    impThisArm      = res.ImpSite(1);
    lastBathThisArm = res.ArmToSite(1, 1);
    for (int site = impThisArm; site < lastBathThisArm; ++site) { addBasisWorker(psis, res, Bs, site, Rightwards, args); }
    res.Anc(lastBathThisArm) = Bs.front();

    double energyExtended{0.};
    {
      auto resH      = exactApplyMPO(res, H, args);
      energyExtended = real(overlap(res, resH));
    }
    /*
    if (abs(energyInitial - energyExtended) > 1E-8) {
      Error(
         "addBasis:: the energy difference between the initial and extended state exceeds the threshold meaning the extended is modified from the initial one");
    }*/
    if (verbose) {
      auto sm = expand_time.sincemark();
      Args args_check("Cutoff", -1);

      res.position(1, args_check);
      res.position(res.N(), args_check);
      res.position(1, args_check);
      printfln("addBasis::the energy of the initial and extended states are %.12f and %.12f", energyInitial, energyExtended);
      printfln("addBasis::Global subspace expansion: cputime = %s, walltime = %s", showtime(sm.time), showtime(sm.wall));
      printfln("addBasis::MaxM of the state after expansion is %12.f", res.MaxM());
      for (int iArm = 1; iArm < NArms; ++iArm) {
        printfln("addBasis::dimesnion of the bond connecting the imp site is %.12f",
                 dim(commonIndex(res.A(res.ImpSite(iArm)), res.A(res.ImpSite(iArm + 1)))));
      }
      printfln("addBasis::the overall quantum number is %.12f", div(res.A(1)));
    }
  }

} // namespace forktps