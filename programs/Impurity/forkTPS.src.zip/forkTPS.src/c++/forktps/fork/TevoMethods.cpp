#include "TevoMethods.hpp"
#include "forktps/fork/ForkCalculus.hpp"
#include "forktps/fork/ForkLocalOp.hpp"
#include "forktps/fork/Tevo/AIM_ForkGates.hpp"
#include "forktps/fork/Tevo/SFTevo.hpp"
#include "forktps/fork/typenames.hpp"
#include "lanczos.hpp"
#include "HelperFunctions.hpp"

#include <cstdio>
#include <iostream>
#include <itensor/global.h>
#include <itensor/itensor.h>
#include <itensor/iterativesolvers.h>

#include <itensor/types.h>
#include <utility>
#include <vector>

namespace forktps {

  template <class T> void BathStep(int site, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, bool doBackTevo, Args &args);

  template <class T> void BathStepSS(int site, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, bool doBackTevo, Args &args);

  template <class T> void Link_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args);

  template <class T> void TS_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args);

  template <class T> void SS_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args);

  void TrackNorm(ITensor &T, Args &args) {
    if (args.getBool("TrackNorm", false)) {
      auto n = norm(T);
      T /= n;
      n *= args.getReal("totalNorm");
      args.add("totalNorm", n);
    }
  }

  void TrackNorm(ForkTPS &psi, Args &args) {
    if (args.getBool("TrackNorm", false)) {
      auto n = psi.normalize();
      n *= args.getReal("totalNorm");
      args.add("totalNorm", n);
    }
  }

  template <class T> TEBD_container::TEBD_container(const H_int &hint, const bath &b, const hloc &e0, T dt, const AIM_ForkSites &sites) : dt(dt) {

    if (b.isOffDiag() || e0.isOffDiag()) Error("CreateTEBDOperators: TEBD does not work for a off-diagonal bath or off-diagonal e0.");

    // !(!hint) is a little weird, but ! operator is already defined
    if (!(!hint)) {
      DD_MPO = forktps::DD_MPO(dt / 2, hint, sites);

      if (hint.dd_only == false && b.NArms() > 2) {
        int Norbs = std::round(b.NArms() / 2);
        SF        = std::vector<ForkTPO>(0);
        PH        = std::vector<ForkTPO>(0);

        for (auto i : range1(Norbs - 1)) {
          for (auto j : range1(i + 1, Norbs)) {
            SF->push_back(ForkTPO(SFPH_TevoMPO(dt / 2, hint.J, SFPH::SF, std::make_pair(i, j), sites)));
            PH->push_back(ForkTPO(SFPH_TevoMPO(dt / 2, hint.J, SFPH::PH, std::make_pair(i, j), sites)));
          }
        }
      }
    }

    // no dt/2, because this function already creates all the gates for a second order breakup.
    gates = createAIMGates(dt, b, e0, sites);
  }

  // TDVP_SSImp performs the updates in the following order.
  // X : site of forward time evolution, to neighboring X -> two-site update
  // r: site or link of reverse time evolution
  // To perform a second order update, re-apply every term in reverse order.
  //
  //  1.)                    2.)                    3.)                    4.)
  //  o -- o -- X -- X       o -- o -- r -- o       o -- X -- X -- o       o -- r -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //  5.)                    6.)                    7.)                    8.)
  //  X -- X -- o -- o       r -- o -- o -- o       X -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       X -- o -- o -- o       r -- o -- o -- o
  //
  //
  //  9.)                    10.)                   11.)                   12.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o
  //
  //  13.)
  //  o -- o -- o -- o
  //  |
  //  o -- o -- X -- X

  template <class T> void TDVP_otherSweep(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args) {

    std::vector<int> NBath = psi.NBathVec();
    int NArms              = psi.NArms();
    if (NArms != 2) { Error("other sweep TDVP only implemented for 2 arms"); }
    bool doBackTevo(true);

    T actual_dt(0);
    int TDVPOrder = args.getInt("TDVPOrder", 2);
    if (TDVPOrder == 1)
      actual_dt = dt;
    else if (TDVPOrder == 2)
      actual_dt = dt / 2;
    else
      Error("Invalid Integration order provided to TDVP: " + str(TDVPOrder));

    //PrintBorderLine(3);
    // first half
    {
      int arm    = 1;
      doBackTevo = true;
      for (int indx = 1; indx <= NBath.at(arm); ++indx) {
        auto site = psi.ArmToSite(arm, indx) - 1;
        //std::cout<< "Doing " << site << " and " << site+1 <<" backTevo " << doBackTevo<<"\n";
        BathStep(site, Leftwards, Heff, dt / 2, psi, doBackTevo, args);
      }

      TS_ImpStep(arm, Downwards, Heff, dt / 2, psi, args);
      SS_ImpStep(arm + 1, Nonewards, Heff, -dt / 2, psi, args);

      arm = 2;
      for (int indx = NBath.at(arm); indx >= 1; --indx) {
        auto site  = psi.ArmToSite(arm, indx) - 1;
        doBackTevo = (indx == 1) ? false : true;
        //std::cout<< "Doing " << site << " and " << site+1 <<" backTevo " << doBackTevo<<"\n";
        BathStep(site, Rightwards, Heff, dt / 2, psi, doBackTevo, args);
      }
    }

    // second half
    {
      int arm    = 2;
      doBackTevo = true;
      for (int indx = 1; indx <= NBath.at(arm); ++indx) {
        auto site = psi.ArmToSite(arm, indx) - 1;
        //std::cout<< "Doing " << site << " and " << site+1 <<" backTevo " << doBackTevo<<"\n";
        BathStep(site, Leftwards, Heff, dt / 2, psi, doBackTevo, args);
      }
      arm = 1;
      TS_ImpStep(arm, Upwards, Heff, dt / 2, psi, args);
      SS_ImpStep(arm, Nonewards, Heff, -dt / 2, psi, args);

      for (int indx = NBath.at(arm); indx >= 1; --indx) {
        auto site  = psi.ArmToSite(arm, indx) - 1;
        doBackTevo = (indx == 1) ? false : true;
        //std::cout<< "Doing " << site << " and " << site+1 <<" backTevo " << doBackTevo<<"\n";
        BathStep(site, Rightwards, Heff, dt / 2, psi, doBackTevo, args);
      }
    }
  }

  // TDVP_SSImp performs the updates in the following order.
  // X : site of forward time evolution, to neighboring X -> two-site update
  // r: site or link of reverse time evolution
  // To perform a second order update, re-apply every term in reverse order.
  //
  //  1.)                    2.)                    3.)                    4.)
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  5.)                    6.)                    7.)                    8.)
  //  o -- o -- X -- X       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      r                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       X -- X -- o -- o       o -- r -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  9.)                    10.)                   11.)                   12.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- X -- X -- o       o -- o -- r -- o       o -- o -- X -- X       o -- o -- o -- o
  //  |                      |                      |                      r
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  13.)                   14.)                   15.)                   16.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o
  //
  //
  //  17.)
  //  o -- o -- o -- o
  //  |
  //  o -- o -- o -- o
  //  |
  //  o -- o -- X -- X

  template <class T> void TDVP_SSImp(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args) {

    std::vector<int> NBath = psi.NBathVec();
    int NArms              = psi.NArms();
    bool doBackTevo(true);

    T actual_dt(0);
    auto TDVPOrder = args.getInt("TDVPOrder", 2);
    if (TDVPOrder == 1)
      actual_dt = dt;
    else if (TDVPOrder == 2)
      actual_dt = dt / 2;
    else
      Error("Invalid Integration order provided to TDVP: " + str(TDVPOrder));

    // at each arm move from the impurity outwards and then update the impurity link to the arm below
    for (int ch = 1; ch <= NArms; ch++) {
      for (int indx = NBath.at(ch); indx >= 1; --indx) {
        auto site  = psi.ArmToSite(ch, indx) - 1;
        doBackTevo = (indx == 1) ? false : true;
        BathStep(site, Rightwards, Heff, actual_dt, psi, doBackTevo, args);
      }
      // at ch = NArms, there is no impurity link left to update
      if (ch != NArms) Link_ImpStep(ch, Downwards, Heff, actual_dt, psi, args);
    }

    if (TDVPOrder == 2) {
      // repeat steps in reverse order
      for (int ch = NArms; ch >= 1; --ch) {
        for (int indx = 1; indx <= NBath.at(ch); ++indx) {
          auto site  = psi.ArmToSite(ch, indx) - 1;
          doBackTevo = psi.IsImp(site) ? false : true;
          BathStep(site, Leftwards, Heff, actual_dt, psi, doBackTevo, args);
        }

        if (ch != 1) Link_ImpStep(ch - 1, Upwards, Heff, actual_dt, psi, args);
      }
    }
  }

  template <class T> void TDVP_FullSS(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args) {

    std::vector<int> NBath = psi.NBathVec();
    int NArms              = psi.NArms();
    bool doBackTevo(true);

    T actual_dt(0);
    auto TDVPOrder = args.getInt("TDVPOrder", 2);
    if (TDVPOrder == 1)
      actual_dt = dt;
    else if (TDVPOrder == 2)
      actual_dt = dt / 2;
    else
      Error("Invalid Integration order provided to TDVP: " + str(TDVPOrder));

    // at each arm move from the impurity outwards and then update the impurity link to the arm below
    for (int ch = 1; ch <= NArms; ch++) {
      for (int indx = NBath.at(ch); indx >= 1; --indx) {
        auto site  = psi.ArmToSite(ch, indx) - 1;
        doBackTevo = true;
        BathStepSS(site, Rightwards, Heff, actual_dt, psi, doBackTevo, args);
      }
      auto site = psi.ArmToSite(ch, 1);
      BathStepSS(site, Rightwards, Heff, actual_dt, psi, false, args);

      // at ch = NArms, there is no impurity link left to update
      if (ch != NArms) Link_ImpStep(ch, Downwards, Heff, actual_dt, psi, args);
    }

    if (TDVPOrder == 2) {
      // repeat steps in reverse order
      for (int ch = NArms; ch >= 1; --ch) {
        for (int indx = 1; indx <= NBath.at(ch); ++indx) {
          auto site  = psi.ArmToSite(ch, indx);
          doBackTevo = true; //psi.IsImp(site) ? false : true;
          BathStepSS(site, Leftwards, Heff, actual_dt, psi, doBackTevo, args);
        }
        auto site = psi.ImpSite(ch);
        BathStepSS(site, Leftwards, Heff, actual_dt, psi, false, args);

        if (ch != 1) Link_ImpStep(ch - 1, Upwards, Heff, actual_dt, psi, args);
      }
    }
  }

  // TDVP_TSImp performs the updates in the following order (note we start with a reverse update).
  // X : site of forward time evolution, to neighboring X -> two-site update
  // r: site of reverse time evolution
  // To perform a second order update, re-apply every term in reverse order.
  //
  //  1.)                    2.)                    3.)                    4.)
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  5.)                    6.)                    7.)                    8.)
  //  o -- o -- X -- X       r -- o -- o -- o       X -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       X -- o -- o -- o       r -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  9.)                    10.)                   11.)                   12.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //
  //
  //  13.)                   14.)                   15.)                   16.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- X -- X       r -- o -- o -- o       X -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       X -- o -- o -- o       r -- o -- o -- o
  //
  //
  //  17.)                   18.)                   19.)                   20.)
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o       o -- o -- o -- o
  //  |                      |                      |                      |
  //  X -- X -- o -- o       o -- r -- o -- o       o -- X -- X -- o       o -- o -- r -- o

  //  21.)
  //  o -- o -- o -- o
  //  |
  //  o -- o -- o -- o
  //  |
  //  o -- o -- X -- X

  template <class T> void TDVP_TSImp(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args) {

    std::vector<int> NBath = psi.NBathVec();
    int NArms              = psi.NArms();
    bool doBackTevo(true);

    T actual_dt(0);
    auto TDVPOrder = args.getInt("TDVPOrder", 2);
    if (TDVPOrder == 1)
      actual_dt = dt;
    else if (TDVPOrder == 2)
      actual_dt = dt / 2;
    else
      Error("Invalid Integration order provided to TDVP: " + str(TDVPOrder));

    for (auto arm : range1(NArms)) {
      for (int indx = NBath.at(arm); indx >= 1; --indx) {
        auto site  = psi.ArmToSite(arm, indx) - 1;
        doBackTevo = (indx == 1) ? false : true;
        BathStep(site, Rightwards, Heff, actual_dt, psi, doBackTevo, args);
      }

      if (arm != NArms) {
        SS_ImpStep(arm, Nonewards, Heff, -actual_dt, psi, args);
        TS_ImpStep(arm, Downwards, Heff, actual_dt, psi, args);
        SS_ImpStep(arm + 1, Nonewards, Heff, -actual_dt, psi, args);
      }
    }

    if (TDVPOrder == 2) {
      // repeat steps in reverse order
      for (auto arm = NArms; arm >= 1; --arm) {
        for (int indx = 1; indx <= NBath.at(arm); ++indx) {
          auto site  = psi.ArmToSite(arm, indx) - 1;
          doBackTevo = (site == 1) ? false : true; // only site one no back tevo
          BathStep(site, Leftwards, Heff, actual_dt, psi, doBackTevo, args);
        }

        if (arm != 1) {
          TS_ImpStep(arm - 1, Upwards, Heff, actual_dt, psi, args);
          SS_ImpStep(arm - 1, Rightwards, Heff, -actual_dt, psi, args);
        }
      }
    }
  }

  /** Performs a two-site TDVP step on two bath tensors or on a bath and an impurity tensor
  *   on sites *site* and *site+1*. The exponentiation uses the Hamiltonian *Heff* 
  *   with time step *dtime* and takes the start vector from forktps *psi*. After the exponentiation,
  *   stores the time evolved tensors in *psi* with the orthogonality center defined by *dir* 
  *   (*site* if *dir == Leftwards* or *site+1* if *dir == Rightwards*).
  */
  template <class T> void BathStep(int site, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, bool doBackTevo, Args &args) {
    // always use rightwards
    auto tag = SetSVDParams(site, psi, Rightwards, args);

    int nextSite = site + 1;

    //swap site and nextSite if Leftwards
    if (dir == Leftwards) std::swap(site, nextSite);

    //std::cout << "Doing Bath step at site " << site << " and " << nextSite<<std::endl;//<< "  with dir: " << to_string(dir); // <<"  tags: "<<tag<<std::endl;
    Args args_check("Cutoff", -1);

    psi.position(site, args_check);
    Heff.position(site, nextSite, psi);

    auto phi = psi.A(site) * psi.A(nextSite);
    itensor::applyExp(Heff, phi, -dtime, args);

    ITensor UU = psi.A(site), VV, DD;
    auto spec  = svd(phi, UU, DD, VV, {args, "LeftTags", tag});
    TrackNorm(DD, args);
    VV *= DD; //VV is ortho center

    if (args.getReal("MaxTruncErr", 1.) < spec.truncerr()) args.add("MaxTruncErr", (double)spec.truncerr());

    psi.InsertOrthoTensor(UU, site, dir);

    if (doBackTevo) {
      //std::cout<< " do back tevo " << nextSite << std::endl;
      Heff.position(nextSite, psi);
      itensor::applyExp(Heff, VV, dtime, args);
    }

    psi.Anc(nextSite) = VV;
  }

  template <class T> void BathStepSS(int site, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, bool doBackTevo, Args &args) {

    //std::cout << "Doing Bath step at site " << site << " and " << nextSite<<std::endl;//<< "  with dir: " << to_string(dir); // <<"  tags: "<<tag<<std::endl;
    Args args_check("Cutoff", -1);
    psi.position(site, args_check);
    double originCutoff = args.getReal("Cutoff", -1.0);
    args.add("Cutoff", originCutoff);

    Heff.position(site, psi);

    auto phi = psi.A(site);
    itensor::applyExp(Heff, phi, -dtime, args);
    //std::cout << "---@debug, ++ time @site " << site << std::endl;

    if (doBackTevo) {
      // always use rightwards
      auto tag = SetSVDParams(site, psi, dir, args);

      int nextSite; // = site + 1;

      //swap site and nextSite if Leftwards
      if (dir == Leftwards) {
        nextSite = site - 1;
      } else {
        nextSite = site + 1;
      }

      ITensor UU = psi.UTensor(site, dir), VV, DD;
      auto spec  = svd(phi, UU, DD, VV, {args, "LeftTags", tag});
      TrackNorm(DD, args);

      //std::cout << "---@debug, svd done" << std::endl;

      if (args.getReal("MaxTruncErr", 1.) < spec.truncerr()) args.add("MaxTruncErr", (double)spec.truncerr());

      //psi.InsertOrthoTensor(UU, site, dir);
      psi.InsertOrthoTensor(UU, site, dir);
      Heff.UpdateMe(site);

      VV *= DD;
      Heff.position_0site(site, nextSite, psi);
      itensor::applyExp(Heff, VV, dtime, args);

      //std::cout << "---@debug, -- time @site " << site << std::endl;

      //std::cout << "---@debug, backward time  done" << std::endl;
      psi.Anc(nextSite) *= (VV);
      Heff.UpdateMe(nextSite);

    } else {
      psi.Anc(site) = phi;
      Heff.UpdateMe(site);
    }
    args.add("Cutoff", originCutoff);
  }

  /** Performs a link TDVP step on an impurity-impurity link between the impurities on chain *ch*
  *   and *ch+1*. The exponentiation uses the Hamiltonian *Heff* with time step *dtime* and takes 
  *   the start vector from forktps *psi*. After the exponentiation, stores the time evolved 
  *   tensors in *psi* with the orthogonality center defined by *dir* 
  *   (*ch* if *dir == Upwards* or *ch+1* if *dir == Downwards*).
  */
  template <class T> void Link_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args) {

    // store orig cutoff to replace it afterwards
    double origCutoff = args.getReal("Cutoff", -1);
    args.add("Cutoff", origCutoff);
    args.add("MaxDim", args.getInt(Names::MAXMI, 200));

    //std::cout<< "Doing single site impurity step on arm " << ch << " " <<to_string(dir) <<std::endl;

    int site = psi.ImpSite(ch), nextSite = psi.ImpSite(ch + 1);

    // nextSite is on the arm below site. If we go upwards, swap site and nextSite
    if (dir == Upwards) std::swap(site, nextSite);
    Args args_check("Cutoff", -1);
    psi.position(site, args_check);
    ITensor UU = psi.UTensor(site, dir), VV, DD;

    // perform svd to get link tensor
    auto spec = svd(psi.A(site), UU, DD, VV, {args, "LeftTags", Names::TAGSI}); // VV is ortho center
    VV *= DD;

    psi.InsertOrthoTensor(UU, site, dir);
    Heff.UpdateMe(site);

    if (args.getReal("MaxTruncErr", 1.) < spec.truncerr()) args.add("MaxTruncErr", (double)spec.truncerr());

    //position 0site does not care if site < or > nextSite
    Heff.position_0site(site, nextSite, psi);

    // perform time evolution and store in psi
    itensor::applyExp(Heff, VV, dtime, args);
    TrackNorm(VV, args);
    //std::cout << "---@debug, -- time @site " << site << std::endl;

    psi.Anc(nextSite) *= VV;
    Heff.UpdateMe(nextSite); // nextSite changed has to be updated again

    args.add("Cutoff", origCutoff);
  }

  /** Performs a single site TDVP step on an impurity site on arms *ch*.
  *   The exponentiation uses the Hamiltonian *Heff* with time step *dtime* and takes 
  *   the start vector from forktps *psi*. After the exponentiation, stores the time evolved 
  *   tensor in *psi*. Does not perform a back time evolution. Shifts the 
  *   orthogonality center according to dir, if dir == Nonewards no shift ortho center happens.
  */
  template <class T> void SS_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args) {

    int site = psi.ImpSite(ch);
    //std::cout << "Doing SS Imp step at site " << site << "  with dir: " << to_string(dir)<< std::endl; // <<"  tags: "<<tag<<std::endl;

    psi.position(site);
    Heff.position(site, psi);

    //std::cout << "Doing SS Imp step at site " << site<<std::endl;

    auto phi = psi.A(site);
    itensor::applyExp(Heff, phi, -dtime, args);
    TrackNorm(phi, args);

    if (dir == Nonewards) {
      psi.Anc(site) = phi;
    } else {
      auto nextSite = psi.Neighbor(site, dir);
      auto tags     = (dir == Rightwards) ? Names::TAGSIB : Names::TAGSI;

      ITensor UU = psi.UTensor(site, dir), VV, DD;

      auto spec = svd(phi, UU, VV, DD, {"LeftTags", tags});

      // normalize if requested and store total norm
      if (args.getReal("MaxTruncErr", 1.) < spec.truncerr()) args.add("MaxTruncErr", (double)spec.truncerr());

      psi.InsertOrthoTensor(UU, site, dir);
      psi.Anc(nextSite) *= VV * DD;
    }
  }

  /** Performs a two site TDVP step on the two impurity sites on arms *ch*
  *   and *ch+1*. The exponentiation uses the Hamiltonian *Heff* with time step *dtime* and takes 
  *   the start vector from forktps *psi*. After the exponentiation, stores the time evolved 
  *   tensors in *psi* with the orthogonality center defined by *dir* 
  *   (*ch* if *dir == Upwards* or *ch+1* if *dir == Downwards*).
  */
  template <class T> void TS_ImpStep(int ch, OrthoState dir, ForkLocalOp &Heff, T dtime, ForkTPS &psi, Args &args) {

    int site = psi.ImpSite(ch), nextSite = psi.ImpSite(ch + 1);
    auto tags = SetSVDParams(site, psi, Downwards, args); //always use Downwards

    // nextSite is on the arm below site. If we go upwards, swap site and nextSite
    if (dir == Upwards) std::swap(site, nextSite);

    //std::cout << "Doing TS Imp step at site " << site<< " and "<< nextSite<<std::endl; //<< "  with dir: " << to_string(dir)<< std::endl; // <<"  tags: "<<tag<<std::endl;

    psi.position(site);
    Heff.position(site, nextSite, psi);

    auto phi = psi.A(site) * psi.A(nextSite);
    itensor::applyExp(Heff, phi, -dtime, args);

    ITensor UU = psi.UTensor(site, dir), VV, DD;
    auto spec  = svd(phi, UU, DD, VV, {args, "LeftTags", tags.c_str()}); // VV is ortho center

    // normalize if requested and store total norm
    TrackNorm(DD, args);
    if (args.getReal("MaxTruncErr", 1.) < spec.truncerr()) args.add("MaxTruncErr", (double)spec.truncerr());

    VV *= DD;
    psi.InsertOrthoTensors(std::move(UU), std::move(VV), site, nextSite, dir);
  }

  template <class T> void TDVP(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args) {
    std::string method = args.getString("TevoMethod", "TDVP");

    if (args.getBool("TrackNorm", false)) args.add("totalNorm", 1.);

    if (method == "TDVP") {
      TDVP_SSImp(psi, Heff, dt, args);
    } else if (method == "TDVPFullSS") {
      TDVP_FullSS(psi, Heff, dt, args);
    } else if (method == "TDVP_2") {
      TDVP_TSImp(psi, Heff, dt, args);
    } else if (method == "TDVP_2Experimental") {
      TDVP_otherSweep(psi, Heff, dt, args);
    } else
      Error("TDVP: Invalid tevo method " + method);
  }

  // explicit instantiations
  template TEBD_container::TEBD_container(const H_int &hint, const bath &b, const hloc &e0, double T, const AIM_ForkSites &sites);
  template TEBD_container::TEBD_container(const H_int &hint, const bath &b, const hloc &e0, Complex T, const AIM_ForkSites &sites);

  template void TDVP<double>(ForkTPS &psi, ForkLocalOp &Heff, double dt, Args &args);
  template void TDVP<Complex>(ForkTPS &psi, ForkLocalOp &Heff, Complex dt, Args &args);

  template void TDVP_TSImp<double>(ForkTPS &psi, ForkLocalOp &Heff, double dt, Args &args);
  template void TDVP_TSImp<Complex>(ForkTPS &psi, ForkLocalOp &Heff, Complex dt, Args &args);

  template void TDVP_SSImp<double>(ForkTPS &psi, ForkLocalOp &Heff, double dt, Args &args);
  template void TDVP_SSImp<Complex>(ForkTPS &psi, ForkLocalOp &Heff, Complex dt, Args &args);

  void TEBD(ForkTPS &psi, const TEBD_container &Ops, Args &args) {
    auto ApplyMPO = &exactApplyMPO;
    // apply all operators acording to a second order breakup, note the inverted order after the gates

    if (args.getBool("TrackNorm", false)) args.add("totalNorm", 1.);

    if (Ops.SF) { // spinflip
      for (const auto &Op : *Ops.SF) {
        psi = ApplyMPO(psi, Op, args);
        TrackNorm(psi, args);
      }
    }

    if (Ops.PH) { // pair hopping
      for (const auto &Op : *Ops.PH) {
        psi = ApplyMPO(psi, Op, args);
        TrackNorm(psi, args);
      }
    }

    // density density
    if (Ops.DD_MPO) {
      psi.ZipUpImpurityMPO(*Ops.DD_MPO, args);
      TrackNorm(psi, args);
    }

    // gates
    for (auto g : Ops.gates) {
      ApplyGate(psi, g, Rightwards, args);
      TrackNorm(psi, args);
    }

    // density density
    if (Ops.DD_MPO) {
      psi.ZipUpImpurityMPO(*Ops.DD_MPO, args);
      TrackNorm(psi, args);
    }

    if (Ops.PH) { // pair hopping
      // reverse iteration ... c++20 should have reverse(...)
      auto rbegin = Ops.PH->rbegin();
      auto rend   = Ops.PH->rend();
      for (auto it = rbegin; it != rend; it++) {
        psi = ApplyMPO(psi, *it, args);
        TrackNorm(psi, args);
      }
    }

    if (Ops.SF) { // spin flip
      // reverse iteration ... c++20 should have reverse(...)
      auto rbegin = Ops.SF->rbegin();
      auto rend   = Ops.SF->rend();
      for (auto it = rbegin; it != rend; it++) {
        psi = ApplyMPO(psi, *it, args);
        TrackNorm(psi, args);
      }
    }
  }

} // namespace forktps
