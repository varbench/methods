#ifndef __ARM__
#define __ARM__

#include "forktps/fork/typenames.hpp"
#include "itensor/itensor.h"
#undef Print

#include <sys/types.h>
#include <vector>

using namespace itensor;

namespace forktps {

  /**
 * Represents an arm of a forktps or forktpo, i.e.: a vector containing all bath
 * tensors, as well as some additional information about the arm itself.
 */

  struct Arm {
    /// If true, all tensors are are orthgonalized towards the impurity
    bool isOrtho;
    /// Every tensor including the one with index *inner_ortho_lim* is orthogonalized towards the end of the Arm
    int inner_ortho_lim;
    /// Every tensor including the one with index *outer_ortho_lim* is orthogonalized towards the impurity.
    int outer_ortho_lim;
    /// Number of sites
    int NBath;

    /// Contains all tensors of the arm (one-indexed).
    std::vector<ITensor> A_;

    /// Sets to Arm to be fully orthogonal, meaning that all bath tensors are orthogonalized towards the impurity.
    void CompOrtho();

    /// Changes the orthogonality limits such that the tensor at index *indx* is orthogonal in direction *dir*.
    void ShiftOrtho(int indx, OrthoState dir);

    /// Changes the orthogonality conditions as if the tensor on index *indx* was changed.
    void TouchOrtho(int indx);

    /// Sets *indx* to be the orthogonality center of the arm. If *indx* == Nbath + 1, arm is fully orthogonalized.
    void SSOrtho(int indx);

    /** Sets the two tensors at *indxI* and *indxJ* as a two-site orthocenter. Orthogonality 
    * limits are changed such that all tensors with index > max(indxI,indxJ) are 
    * right-normalized and all tensors with index < min(indxI,indxJ) are left-normalized.
    * Used by effective Hamiltonians.
    */
    void TSOrtho(int indxI, int indxJ);

    /** Sets the link between the two tensors at *indxI* and *indxJ* to be the orthocenter.
    */
    void LinkOrtho(int indxI, int indxJ);

    /// Arm forgets all orthogonality conditions it might have.
    void ForgetOrtho();
  };

} // namespace forktps
#endif
