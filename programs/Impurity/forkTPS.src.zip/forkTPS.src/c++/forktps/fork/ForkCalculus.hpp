#ifndef __FORKCALC__
#define __FORKCALC__

#include "ForkTPO.hpp"
#include "ForkTPS.hpp"
#include "Bath.hpp"
#include "Gates.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/GFComponent.hpp"

#include <iomanip>
#include <iostream>

using namespace itensor;

namespace forktps {
  /** Finds the ground state vector *A* of matrix *Heff* using either the Lanzcos 
  * or the Davidson algorithm depending on the flag "UseDavidson" in *args*.
  */
  template <typename BigMat> double Krylov(const BigMat &Heff, ITensor &A, Args &args);

  /**
  *Performes DMRG calculation with FTPO *H* calculating the
  *groundstate *GS* and its energy *energy*. Parameters are defined in *args* which takes the following entries.
  *@param      verbose        bool (default: true)
  *                           Writes information about the DMRG run in the console.
  *@param      InclNoise      bool (default: false)
  *                           If true, includes the noise term.
  *@param      FullSweep      bool (default: false)   
  *                           Usual DMRG updates the impurity-impurity links only once each sweep. If true, these links are updated twice.
  *@param      maxsweeps      int (default: 10)      
  *                           Number of DMRG sweeps.
  *@param      NAppH          int (default: 0)       
  *                           After maxsweeps sweeps apply the MPO and set maxsweeps to 5. Then restart DMRG (now with 5 sweeps). In total apply H *NAppH*-times.
  *@param      UseDavidson    bool (default: false)
  *                           If true, use ITensors Davidson algorithm instead of Lanzcos.
  *@param      Cutoff         double (default: 1E-10)
  *                           Truncated weight on all links unless specified otherwise by one of the other Cutoffs below.
  *@param      CutoffI        double (default: Cutoff)
  *                           Truncated weight on Impurity-Impurity links.
  *@param      CutoffB        double (default: Cutoff)
  *                           Truncated weight on  Bath-Bath links.
  *@param      CutoffIB       double (default: Cutoff)
  *                           Truncated weight on Impurity-Bath links.
  *@param      MaxDim         int 
  *                           Maximal bond dimension on all links unless specified otherwise by one of the other Maxm's below.
  *@param      MaxmI          int (default: 200)
  *                           Maxmial bond dimension allowed for impurity-impurity links.
  *@param      MaxmB          int (default: 400)
  *                           Maxmial bond dimension allowed for bath-bath links.
  *@param      MaxmIB         int (default: 200)
  *                           Maxmial bond dimension allowed for impurity-bath links.
  *@param      DMRGMethod     std::string (default: "SSImp")
  *                           Choice between "TwoSite" doing two-site DMRG at the impurity-impurity links and "SSImp" doing single-site DMRG with subspace expansion at the impurity-impurity links.
  */
  bool DMRG(ForkTPS &GS, const ForkTPO &H, double &energy, Args &args);

  /**
 * Apply gate \p G onto MPS \p psi. \p dir defines in which direction the
 * orthocenter of psi will be shifted.
 */
  void ApplyGate(ForkTPS &psi, const ForkGate &G, OrthoState dir, Args args);

  /** Applies the ForkTPO *K* onto forktps *psi* and stores the result in forktps *res*.
  * @param        x         ForkTPS
  *                         $| x \rangle$-state in $| res \rangle = K | x \rangle$ 
  * @param        K         ForkTPO
  *                         Operator to apply.
  * @param        res       ForkTPS
  *                         Result of $| res \rangle = K | x \rangle$.
  * @param        args      itensor::Args
  *                         Parameters forwarded to ForkTPS.orthogonalize(), hence:
  * @param Cutoff       double (default: MIN_CUT)
  *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB, CutoffIB, or CutoffI respectively.
  * @param CutoffI      double (default: Cutoff)
  *                     Truncated weight used for the impurity-impurity links.
  * @param CutoffB      double (default: Cutoff)
  *                     Truncated weight used for the bath-bath links.
  * @param CutoffIB     double (default: Cutoff)
  *                     Truncated weight used for the impurity-bath links.
  * @param MaxDim       double (default: 30000)
  *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB, MaxmIB or MaxmI respectively.
  * @param MaxmI        double (default: MaxDim)
  *                     Maximal bond dimension for the impurity-impurity links.    
  * @param MaxmB        double (default: MaxDim)
  *                     Maximal bond dimension for the bath-bath links.
  * @param MaxmIB       double (default: MaxDim)
  *                     Maximal bond dimension for the impurity-bath links.
  * @param UseSVD       bool (default: true)
  *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
  * @param DoNormalize  bool (default: false)
  *                     If true, normalizes the orthogonality center at each decomposition.
  */
  ForkTPS exactApplyMPO(ForkTPS const &x, ForkTPO const &K, Args &args);

  /** Applies the ForkTPO *K* onto forktps *psi* using the variational minimization of
  * $| |res\rangle - H | x\rangle |^2$ and returns the result. 
  * The minimization algorithm uses a single-site update with subspace expansion on the impurity tensors.
  *
  * @param        x         ForkTPS
  *                         $| x \rangle$-state in $| res \rangle = K | x \rangle$ 
  * @param        K         ForkTPO
  *                         Operator to apply.
  * @param        args      itensor::Args
  *                         Argument list, possible arguments are:
  * @param SubspaceAlpha    double (default 0.1)
  *                         Value of subspace expansion mixing factor. Set to 0 if no subspace expansion should be performed at all.
  * @param SubspaceMaxm     double (default 100)
  *                         Value of subspace expansion mixing factor. Set to 0 if no subspace expansion should be performed at all.
  * @param maxsweeps        int (default: 10)
  *                         Maximal number of sweeps.
  * @param ErrGoal          double (default: 1E-12)
  *                         Convergence criterium: difference in $2\Re \rangle x |H|res\langle$.
  * @param CutoffB          double (default: 1E-10)
  *                         Truncated weight used for the bath-bath links.
  * @param CutoffIB         double (default: 1E-10)
  *                         Truncated weight used for the impurity-bath links.    
  * @param MaxmB            double (default: 400)
  *                         Maximal bond dimension for the bath-bath links.
  * @param MaxmIB           double (default: 200)
  *                         Maximal bond dimension for the impurity-bath links.
  */
  ForkTPS FitApplyMPO(ForkTPS &x, const ForkTPO &H, Args args);

  /**
  * Measures the local observable with name *OpName* on site *i* with state *psi*
  * and returns the result.
  * @param        psi       ForkTPS
  *                         $| x \rangle$-state in $| res \rangle = K | x \rangle$ 
  * @param        OpName    std::string
  *                         Name of the operator to apply as defined in the SiteSet.
  * @param        i         int
  *                         Site where operator *OpName* acts.
  */
  double Measure(ForkTPS &psi, std::string OpName, int i);

  /**
  * Measures a set of operators acting on the impurity defined by *Ops* with state
  * *psi*. *Ops* contains a string for each impurity that defines the local operator
  * of this site and it is zero-indexed. This means also identity operators have to 
  * specified. For example to measure the density correlation between orbital A-up
  * and B-up in a two-orbital problem: *Ops = {"N","Id","N","Id"}*.
  * @param        psi       ForkTPS
  *                         State to measure.
  * @param        Ops       std::vector<std::string>
  *                         Vector containing the names of the operators on each impurity site as defined in the SiteSet.
  */
  double MeasureImp(ForkTPS &psi, std::vector<std::string> Ops);

  /**
  * Calculates the expectation value $\langle \text{bra} | \text{Ops} | \text{ket} \rangle$ 
  * where *bra* (*ket*) specifies the bra (ket) vector and *Ops* the operator to be measured.
  * *Ops* contains a string for each impurity that defines the local operator
  * of this site and it is zero-indexed. This means also identity operators have to 
  * specified.
  * @param        bra       ForkTPS
  *                         Bra-state in measurement.
  * @param        Ops       std::vector<std::string>
  *                         Vector containing the names of the operators on each impurity site as defined in the SiteSet.
  * @param        ket       ForkTPS
  *                         Ket-state in measurement. 
  */
  Complex MeasureImp(const ForkTPS &bra, std::vector<std::string> Ops, const ForkTPS &ket);

  /** Prints the ForkTPS *T* as vector into console. Only works as long as T does not describe more 
  *   than 16 sites. 
  * @param        T      ForkTPS
  *                      State printed.
  */
  void PrintVector(const ForkTPS &T);

  /**
 * Calculates $\langle GS |H| GS \rangle$ and $\langle GS |H^2| GS \rangle$ and returns these values 
 * as pair. The variance of the energy can be used as a measure for the convergence of DMRG.
 * @param        GS     ForkTPS
 *                      State used in the calculation.
 * @param        H      ForkTPO
 *                      Hamiltonian used in the calculation. 
 */
  std::pair<double, double> GSConvergence(const ForkTPS &GS, const ForkTPO &H);

  /**
 * Prints and returns the variance of the energy: $\langle GS |H| GS \rangle^2 - \langle GS |H^2| GS \rangle$ to console.
 * Can be used as a DMRG convergence criterium.
 * @param        GS     ForkTPS
 *                      State used in the calculation.
 * @param        H      ForkTPO
 *                      Hamiltonian used in the calculation. 
 */
  double PrintGSConvergence(const ForkTPS &GS, const ForkTPO &H);

  /** Applies the correct operator to state *psi* (mostly the ground state) before
    *   starting the time evolution.
    */
  void ApplyGFOperator(ForkTPS &psi, GFComponent c);

} // namespace forktps

#endif
