

#include "ForkTN.hpp"
#include "typenames.hpp"
#include "ForkCalculus.hpp"
#include "HelperFunctions.hpp"

#include <itensor/global.h>
#include <itensor/mps/localop.h>
#include <itensor/itensor.h>
#include <itensor/util/error.h>
#undef Print

#include <string>
#include <vector>

// TODO: when doing an svd on the impurity NArms()=1 is not supported

// TODO: what is private what not and what do I need from the outside
// TODO: Think about changing fromleft and fromright in svd routines!!!! This is
// because when looking at the fork fromleft and fromright are different than
// used in the program

// in the fork structure:

//    I  u u u u u u u u u u u u u
//    |
//    I  d d d d d d d d d d d d d
//    |
//    I  u u u u u u u u u u u u u
//    |
//    I  d d d d d d d d d d d d d
//    .
//    .
//
//
//
// sites are numbered as:

//    1       2 3 ...........    NBath +1
//    |
//  NBath+2   NBath+3 ......     2*(NBath+1)
//    |
//    ................................
//    .
//    .

namespace forktps {

  //-------------------------------------------------------------------------------------------------------
  // Constructors and operators:
  // --------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  ForkTN::ForkTN(const SiteSet &sites, int NArm) : Fork(length(sites), NArm), sites_(sites) {

    A_.resize(NArms() + 1);
    OSI_.resize(NArms() + 1);

    Arms_.resize(NArms() + 1);
    for (int arm = 1; arm <= NArms(); arm++) {
      std::vector<ITensor> A(NBath(arm) + 1);
      Arms_[arm] = {false, NBath(arm) + 1, 0, NBath(arm), A};
    }

    OC_ = -1;
    for (auto k : range1(NArms())) OSI_[k] = Nonewards;

    init_tensors();
  }

  ForkTN::ForkTN(const SiteSet &sites, std::vector<int> NBath) : Fork(NBath), sites_(sites) {
    A_.resize(NArms() + 1);
    OSI_.resize(NArms() + 1);
    InitState initState(sites);

    Arms_.resize(NArms() + 1);
    for (int ch = 1; ch <= NArms(); ch++) {
      std::vector<ITensor> A(NBath.at(ch) + 1);
      Arms_[ch] = {false, NBath.at(ch) + 1, 0, NBath.at(ch), A};
    }

    OC_ = -1;
    for (int k = 1; k <= NArms(); k++) OSI_[k] = Nonewards;

    init_tensors();
  }

  void ForkTN::init_tensors() {
    // initializes as MPS with the first state in sites_
    std::vector<QN> qarm, qaImpLinks;
    qaImpLinks.resize(0);
    qaImpLinks.emplace_back(QN());
    std::vector<Index> indx, indxImpLinks;
    indxImpLinks.resize(0);
    indxImpLinks.emplace_back();
    Index si;

    for (int j = 1; j <= NArms() - 1; j++) { // loop over all Arms except last one!!!
      qarm.resize(0);
      qarm.emplace_back();

      indx.resize(0);
      // dummy link
      indx.emplace_back(QN(), 1, Out, "Link");

      // create QNs

      for (int k = 1; k <= NBath(j); k++) {
        si = sites_.si(ArmToSite(j, k));
        qarm.push_back(In * (-qarm.back() * Out - si(1).qn() * Out));
      }

      // create Indices
      for (int k = 1; k < NBath(j); ++k) { indx.emplace_back(qarm[k], 1, Out, Names::TAGSB); }
      indx.emplace_back(qarm[NBath(j)], 1, Out, Names::TAGSIB);

      si             = sites_.si(ArmToSite(j, 1));
      Arms_[j].A_[1] = setElt(si(1), dag(indx[1])(1));

      for (int k = 2; k <= NBath(j); k++) {
        si             = sites_.si(ArmToSite(j, k));
        Arms_[j].A_[k] = setElt(indx[k - 1](1), si(1), dag(indx[k])(1));
      }

      // Impurity
      QN qnArm      = qarm.back();
      Index indxArm = indx.back();

      QN qnImpLinkUp      = qaImpLinks.back();
      Index indxImpLinkUp = indxImpLinks.back();

      si               = sites_.si(ImpSite(j));
      QN qnImpLinkDown = In * (-Out * qnArm - Out * qnImpLinkUp - Out * si(1).qn());
      Index indxImpLinkDown(qnImpLinkDown, 1, Out, Names::TAGSI);

      if (j == 1) {
        A_[j] = setElt(dag(indxImpLinkDown)(1), si(1), indxArm(1));
      } else {
        A_[j] = setElt(dag(indxImpLinkDown)(1), indxImpLinkUp(1), si(1), indxArm(1));
      }

      qaImpLinks.push_back(qnImpLinkDown);
      indxImpLinks.push_back(indxImpLinkDown);
    }

    // make last impurity
    QN qaImpLink      = qaImpLinks.back();
    Index indxImpLink = indxImpLinks.back();

    si       = sites_.si(ImpSite(NArms()));
    QN qaArm = In * (-Out * qaImpLink - Out * si(1).qn());

    Index indxArm(qaArm, 1, Out, Names::TAGSIB);

    A_[NArms()] = setElt(indxImpLink(1), dag(indxArm)(1), si(1));

    // fill last arm
    qarm.resize(0);
    qarm.push_back(qaArm);
    indx.resize(0);
    indx.push_back(indxArm);

    for (int k = NBath(NArms()); k > 1; k--) {
      si         = sites_(ArmToSite(NArms(), k));
      QN qnLeft  = qarm.back();
      QN qnRight = In * (-Out * qnLeft - Out * si(1).qn());

      Index indxLeft = indx.back();

      Index indxRight(qnRight, 1, Out, Names::TAGSB);

      Arms_[NArms()].A_[k] = setElt(indxLeft(1), si(1), dag(indxRight)(1));

      qarm.push_back(qnRight);
      indx.push_back(indxRight);
    }
    // last site
    si                   = sites_(N());
    Arms_[NArms()].A_[1] = setElt(indx.back()(1), si(1));
  }

  //-------------------------------------------------------------------------------------------------------
  // SVD and ortho related members:
  // --------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  void ForkTN::CompOrthoArm(int arm, Args &args) {
    // orthogonalizes the Arm arm so that ALL matrices (including the innermost)
    // are "outerorthonormal" meaning that sum_s A(s)^dag*A(s) = id
    if (Arms_[arm].isOrtho) return;

    for (int indx = Arms_[arm].outer_ortho_lim + 1; indx <= NBath(arm); indx++) { svdArm(arm, indx, Leftwards, LocalOp(), args); }

    OC_ = -1;
  }

  void ForkTN::OrthoArm(int arm, int indx, Args &args) {
    // orthogonalizes the Arm arm so that all matrices to the outside of indx are
    // "outernormal" and all sites to the inside of indx are "innernormal"

    for (int k = Arms_[arm].outer_ortho_lim + 1; k < indx; k++) { svdArm(arm, k, Leftwards, LocalOp(), args); }

    for (int k = Arms_[arm].inner_ortho_lim - 1; k > indx; k--) { svdArm(arm, k, Rightwards, LocalOp(), args); }

    OC_ = -1;

    return;
  }

  template <class BigMatrixT> Spectrum ForkTN::svdArm(int arm, int indx, OrthoState towards, const BigMatrixT &PH, Args &args) {
    // makes a singular value decomposition of Tensor AA and puts the site
    // matrices into indxI and indxJ belonging to Arm "arm" for each arm
    // towards=Leftwards means from outside towards the impurity and Rightwards from the
    // impurity outwards indxI and indxJ are the 2 indices of the Arm-matrices
    // (ie.: the MPS matrix of the site can be accessed by Arms_[arm].A_[indxI] )

    //std::cout<< "svdArm "<< arm<< " "<< indx << " "<< to_string(towards) <<std::endl;

    // checks
    if (indx > NBath(arm)) Error("svdArm: IndexI > NBath");

    Spectrum res;
    Args argsLoc = args;
    int site     = ArmToSite(arm, indx);
    ITensor AA = A(site), U = UTensor(site, towards), S, V;

    //auto noise  = args.getReal("Noise", 0.);
    auto usesvd      = args.getBool("UseSVD", true);
    auto DoNormalize = args.getBool("DoNormalize", false);

    // use tight default truncation parameters in case no args is provided and the user want no truncation.
    auto tags = SetSVDParams(ArmToSite(arm, indx), *this, towards, argsLoc, 30000, MIN_CUT);

    if (!usesvd && DoNormalize) Error("svdArm: Normalization only implemented for SVD.");
    if (usesvd) {
      res = svd(AA, U, S, V, {argsLoc, "LeftTags", tags.c_str()});
      if (DoNormalize) S *= 1. / itensor::norm(S);
      // V -> V*S
      V *= S;
    } else {
      res = denmatDecomp(AA, U, V, Fromleft, PH, {argsLoc, "LeftTags", tags.c_str()});
    }

    Arms_[arm].A_[indx] = U;
    Anc(Neighbor(site, towards)) *= V;

    // set ortho limits
    Arms_[arm].ShiftOrtho(indx, towards);

    if (args.getReal("MaxTruncErr", 1.) < res.truncerr()) { args.add("MaxTruncErr", (double)res.truncerr()); }

    return res;
  }

  void ForkTN::OrthoImps(int ImpIndex, OrthoState towards, Args &args) {
    // first orthogonalize all above ImpIndex
    for (int i = 1; i < ImpIndex; i++) {
      if (OSI_[i] != Downwards) { svdImp(i, Downwards, LocalOp(), args); }
    }

    // then all below ImpIndex
    for (int i = NArms(); i > ImpIndex; i--) {
      if (OSI_[i] != Upwards) { svdImp(i, Upwards, LocalOp(), args); }
    }

    // finally orthogonalize ImpIndex itself
    if (OSI_[ImpIndex] != towards) { svdImp(ImpIndex, towards, LocalOp(), args); }

    return;
  }

  template <class BigMatrixT> Spectrum ForkTN::svdImp(int arm, OrthoState towards, const BigMatrixT &PH, Args &args) {
    // performs svd of Impurity "arm" and sets its orthogonality in direction towards

    if (arm > NArms() || arm < 1) Error("svdImp: arm out of bounds: " + std::to_string(arm));
    if (towards != Rightwards && Arms_[arm].isOrtho == false)
      Error("svdImp: When Orthogonalizing Impurity right arm needs to be orthogonal " + std::to_string(arm));
    if ((towards == Upwards && arm == 1) || (towards == Downwards && arm == NArms()))
      Error("svdImp: Can't ortho first/last arm towards Up/Down " + std::to_string(arm));

    if (OSI_[arm] == towards) return {};

    // svd and multiply rest (D*V) on the next matrix
    ITensor AA = A_[arm], U = UTensor(ImpSite(arm), towards), D, V, VD;

    Spectrum res;
    Args argsLoc = args;

    //auto noise  = args.getReal("Noise", 0.);
    auto usesvd      = args.getBool("UseSVD", true);
    auto DoNormalize = args.getBool("DoNormalize", false);

    // use tight default truncation parameters in case no args is provided and the user want no truncation.
    auto tags = SetSVDParams(ImpSite(arm), *this, towards, argsLoc, 30000, MIN_CUT);

    if (!usesvd && DoNormalize) Error("svdArm: Normalization only implemented for SVD.");
    if (usesvd) {
      // Need high accuracy, use svd
      res = svd(AA, U, D, V, {argsLoc, "LeftTags", tags.c_str()});
      if (DoNormalize) D *= 1. / itensor::norm(D);

      VD = V * D;
    } else {
      // always use fromleft since U is already defined accordingly
      res = denmatDecomp(AA, U, VD, Fromleft, PH, {argsLoc, "LeftTags", tags.c_str()});
    }

    A_[arm]   = U;
    OSI_[arm] = towards;
    OC_       = -1;

    Anc(Neighbor(ImpSite(arm), towards)) *= VD;
    if (args.getReal("MaxTruncErr", 1.) < res.truncerr()) args.add("MaxTruncErr", res.truncerr());

    return res;
  }

  void ForkTN::position(int i) {
    Args args("Cutoff", MIN_CUT);
    position(i, args);
  }

  void ForkTN::position(int i, Args &args) {

    // sets the orthogonality center to site i
    if (i == OC_) { return; }
    if (IsImp(i)) {
      int IIndx = ImpIndx(i);

      //fully orthgonalize all arms
      for (int k = 1; k <= NArms(); k++) CompOrthoArm(k, args);

      // all impurity sites above need to be Downward ortho
      for (int k = 1; k < IIndx; k++) svdImp(k, Downwards, LocalOp(), args);

      // all impurity sites below need to be Upward ortho
      for (int k = NArms(); k > IIndx; k--) svdImp(k, Upwards, LocalOp(), args);

    } else {
      // i is an Arm site -> ortho all arms except the one i is on
      auto [arm, armIndx] = SiteToArm(i);

      OrthoState state = Rightwards;
      for (int k = 1; k <= NArms(); k++)
        if (k != arm) { CompOrthoArm(k, args); }

      // ortho impurities to site "ImpIndex" in direction "state"
      OrthoImps(arm, state, args);
      // finally orthonormalize the arm to site "armIndx"
      OrthoArm(arm, armIndx, args);
    }
    OC_ = i;

    return;
  }

  void ForkTN::orthogonalize(Args &args) {
    // orthogonalizes the MPS
    // Do a half-sweep to the right, orthogonalizing each bond
    // but first remove ortho conditions

    // Use smaller cutoff to orthogonalize w/ minimal truncation
    ForgetOrtho();
    double const tenPercent = 0.1;
    Args argsLoc            = args;
    auto orig_cut           = argsLoc.getReal("Cutoff", MIN_CUT);
    auto CutoffI            = argsLoc.getReal(Names::TWI, args.getReal("Cutoff", MIN_CUT));
    auto CutoffB            = argsLoc.getReal(Names::TWB, args.getReal("Cutoff", MIN_CUT));
    auto CutoffIBath        = argsLoc.getReal(Names::TWIB, args.getReal("Cutoff", MIN_CUT));

    argsLoc.add("Cutoff", tenPercent * orig_cut);
    argsLoc.add(Names::TWI, tenPercent * CutoffI);
    argsLoc.add(Names::TWB, tenPercent * CutoffB);
    argsLoc.add(Names::TWIB, tenPercent * CutoffIBath);

    position(N(), argsLoc);

    // Now basis is ortho, ok to truncate
    argsLoc.add("Cutoff", orig_cut);
    argsLoc.add(Names::TWI, CutoffI);
    argsLoc.add(Names::TWB, CutoffB);
    argsLoc.add(Names::TWIB, CutoffIBath);

    for (int ch = NArms(); ch >= 1; ch--) {
      CompOrthoArm(ch, args); // normalize current arm

      if (ch != 1) {
        OrthoImps(ch - 1, Rightwards, argsLoc); // ortho impurity towards next arm
        OrthoArm(ch - 1, 1, argsLoc);           // normalize arm outwards
      }
    }

    OC_ = 1;
    return;
  }

  /**
  * Forgets all orthogonality conditions.
  * */
  void ForkTN::ForgetOrtho() {
    // removes all knowlegde of ortho conditions
    OC_ = -1;
    for (int k = 1; k < NArms(); k++) { Arms_[k].ForgetOrtho(); }
    for (int k = 1; k < NArms(); k++) OSI_[k] = Nonewards;
  }

  //-------------------------------------------------------------------------------------------------------
  // Writing and reading:
  // ---------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  void ForkTN::write(std::ostream &s) const {
    itensor::write(s, N());
    itensor::write(s, NArms());
    for (int ch = 1; ch <= NArms(); ch++) { itensor::write(s, NBath(ch)); }

    for (int i = 1; i <= N(); i++) { itensor::write(s, A(i)); }
  }

  void ForkTN::read(std::istream &s, const SiteSet &sites) {
    std::vector<int> Nb;
    int N = 0, NArm = 0;

    itensor::read(s, N);
    if (N != length(sites)) {
      Error("Trying to read a state with " + std::to_string(N) + " sites using a SiteSet with " + std::to_string(length(sites)) + " sites.");
    }

    itensor::read(s, NArm);
    Nb.resize(NArm + 1);
    for (auto ch : range1(NArm)) { itensor::read(s, Nb.at(ch)); }

    // initialize ForkTN and read tensors
    *this = ForkTN(sites, Nb);
    for (int i = 1; i <= this->N(); i++) {
      itensor::read(s, Anc(i));
      // check that indices are consistent
      if (!hasIndex(A(i), sites.si(i))) { Error("Trying to load a state with incompatible SiteSet @" + std::to_string(i)); }
    }

    // set remaining parameters
    OC_ = -1;
    for (int i = 1; i <= NArms(); i++) { OSI_[i] = Nonewards; }
  }

  /*
  void ForkTN::copyTensors(const ForkTN &other) {
    if (NArms() != other.NArms()) {

      Error("copyTensors: NArms must be equal");
    }
    for (int ch = 1; ch <= NArms(); ch++) {
      if (NBath(ch) != other.NBath(ch)) {
;
        Error("copyTensors: NBath must be equal");
      }
    }
    // if(sites_ != other.sites_ ){ Error("copyTensors: sites must be equal"); }

    OC_ = other.OC_;
    for (int i = 1; i <= NArms(); i++) {
      Anc(ImpSite(i)) = other.A(ImpSite(i));
      OSI_[i] = other.OSI_[i];
      Arms_[i] = other.Arms_[i];
    }
  }
  */

  //-------------------------------------------------------------------------------------------------------
  // Index methods:
  // ---------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  void ForkTN::mapPrime(int oldp, int newp, std::string tags) { //****//
    // mapps the indices of Index Type type on all tensors
    // from "oldp" to "newp"
    for (int arm = 1; arm <= NArms(); arm++) {
      for (int indx = 1; indx <= NBath(arm); indx++) { Arms_[arm].A_[indx].mapPrime(oldp, newp, tags); }
    }

    for (int indx = 1; indx <= NArms(); indx++) { A_[indx].mapPrime(oldp, newp, tags); }
  }

  void ForkTN::primeLinks(int oldp, int newp) { mapPrime(oldp, newp, "Link"); }

  void ForkTN::noprimelink() {
    // unprimes all links
    for (int arm = 1; arm <= NArms(); arm++) {
      for (int indx = 1; indx <= NBath(arm); indx++) Arms_[arm].A_[indx].noPrime("Link");
    }

    for (int indx = 1; indx <= NArms(); indx++) A_[indx].noPrime("Link");
  }

  //-------------------------------------------------------------------------------------------------------
  // Accessor methods:
  // ---------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  const ITensor &ForkTN::A(int i) const {
    if (!IsImp(i)) {
      auto [arm, indx] = SiteToArm(i);
      return Arms_[arm].A_.at(indx);
    } else
      return A_[ImpIndx(i)];
  }

  ITensor &ForkTN::Anc(int i) {
    if (i != OC_) { OC_ = -1; }

    if (!IsImp(i)) {
      auto [arm, armIndx] = SiteToArm(i);
      Arms_[arm].TouchOrtho(armIndx);

      return Arms_[arm].A_.at(armIndx);
    } else {
      // i is impurity
      OSI_[ImpIndx(i)] = Nonewards;

      return A_[ImpIndx(i)];
    }
  }

  void ForkTN::InsertOrthoTensors(ITensor &&A, ITensor &&B, int siteA, int siteB, OrthoState dir) {
    if (OC_ != siteA && OC_ != siteB) {
      std::cout << "A: " << siteA << " B: " << siteB << "  OC: " << OC_ << std::endl;
      throw ITError("InsertOrthoTensors: OC_ must be either siteA or siteB");
    }

    if (siteA > siteB) {
      std::swap(siteA, siteB);
      std::swap(A, B);
    }

    if (IsImp(siteA) && IsImp(siteB)) {
      int IIndxA = ImpIndx(siteA);
      int IIndxB = ImpIndx(siteB);

      A_[IIndxA] = A;
      A_[IIndxB] = B;
      if (dir == Upwards) {
        OC_          = siteA;
        OSI_[IIndxA] = Nonewards;
        OSI_[IIndxB] = Upwards;
      } // A is new ortho center
      else if (dir == Downwards) {
        OC_          = siteB;
        OSI_[IIndxA] = Downwards;
        OSI_[IIndxB] = Nonewards;
      } // B is new ortho center
      else {
        Error(
           "InsertOrthoTensors: if both sites are impurity sites only "
           "direction Upwards or Downwards is allowed");
        return;
      }
    } else if (IsImp(siteA)) {
      int IIndxA        = ImpIndx(siteA);
      auto [arm, indxB] = SiteToArm(siteB);

      A_[IIndxA]           = A;
      Arms_[arm].A_[indxB] = B;
      if (dir == Leftwards) {
        OC_          = siteA;
        OSI_[IIndxA] = Nonewards;
        Arms_[arm].CompOrtho();
      } // A is new ortho center

      else if (dir == Rightwards) {
        OC_          = siteB;
        OSI_[IIndxA] = Rightwards;
        Arms_[arm].SSOrtho(NBath(arm));
      } // B is new ortho center
      else {
        Error(
           "InsertOrthoTensors: if one site is an impurity site and the other "
           "a Bath site only direction Rightwards or Leftwards are allowed");
        return;
      }
    } else {
      // no impurity involved
      auto indxA        = SiteToArm(siteA).second;
      auto [arm, indxB] = SiteToArm(siteB);

      if (indxA != indxB + 1) { Error("InsertOrthoTensors, indxA must be indxB+1"); }

      Arms_[arm].A_[indxA] = A;
      Arms_[arm].A_[indxB] = B;
      if (dir == Leftwards) {
        OC_ = siteA;
        Arms_[arm].SSOrtho(indxA);
      } // A is new ortho center
      else if (dir == Rightwards) {
        OC_ = siteB;
        Arms_[arm].SSOrtho(indxB);
      } // B is new ortho center
      else {
        Error(
           "InsertOrthoTensors: if both sites are Bath sites only direction "
           "Rightwards or Leftwards are allowed");
        return;
      }
    }

    return;
  }

  void ForkTN::InsertOrthoTensor(ITensor &A, int site, OrthoState dir) {
    if (OC_ != site) {
      std::cout << "Site: " << site << "  OC: " << OC_ << std::endl;
      throw ITError("InsertOrthoTensors: OC_ must be on site");
    }

    int nextSite = Neighbor(site, dir);
    OC_          = nextSite;

    if (IsImp(site)) {
      int Iindx = ImpIndx(site);
      A_[Iindx] = A;

      if (dir == Upwards) {
        OSI_[Iindx]     = Upwards;
        OSI_[Iindx - 1] = Nonewards;
      } // site above is new ortho center
      else if (dir == Downwards) {
        OSI_[Iindx]     = Downwards;
        OSI_[Iindx + 1] = Nonewards;
      } // site below is new ortho center
      else if (dir == Rightwards) {
        OSI_[Iindx] = Rightwards;
        Arms_[Iindx].SSOrtho(NBath(Iindx));
      }
    } else {
      // is bath site
      auto [arm, indx]    = SiteToArm(site);
      Arms_[arm].A_[indx] = A;

      if (dir == Leftwards) {
        if (indx == NBath(arm)) {
          OSI_[arm] = Nonewards;
          Arms_[arm].CompOrtho();
        } else {
          Arms_[arm].SSOrtho(indx + 1);
        }

      } else if (dir == Rightwards) {
        Arms_[arm].SSOrtho(indx - 1);
      }
    }
  }

  Index ForkTN::GetImpLink(int indx, OrthoState dir) const {

    int neighbor = Neighbor(ImpSite(indx), dir);

    return commonIndex(A_[indx], A(neighbor));
  }

  Index ForkTN::GetLink(int siteI, int siteJ) const {
    if (!AreNeighbors(siteI, siteJ)) {
      std::cout << siteI << " and " << siteJ << std::endl;
      throw ITError("GetLink, siteI and siteJ are not neighbors.");
    }

    return commonIndex(A(siteI), A(siteJ));
  }

  bool ForkTN::IsOrtho() const { return OC_ == -1 ? false : true; }

  int ForkTN::OrthoCenter() const { return OC_; }

  // //-------------------------------------------------------------------------------------------------------
  // //Output:
  // -----------------------------------------------------------------------------------
  // //-------------------------------------------------------------------------------------------------------

  void ForkTN::PrintOrthoConditions() const {
    // prints ortho conditions
    std::cout << "---------------------------------------------------------------"
                 "------------------------------"
              << std::endl;
    std::cout << "Ortho conditions of the arms: " << std::endl;
    for (int k = 1; k <= NArms(); k++) {
      std::cout << "Arm " << k << ":        IO: " << Arms_[k].inner_ortho_lim;
      std::cout << "  OO: " << Arms_[k].outer_ortho_lim << "  IsOrtho? " << Arms_[k].isOrtho << std::endl;
    }
    std::cout << "Printing ortho conditions Impurities: " << std::endl;
    for (int k = 1; k <= NArms(); k++) { std::cout << "Impurity " << k << ": " << to_string(OSI_[k]) << std::endl; }
    std::cout << "Ortho Center " << OC_ << std::endl;
    std::cout << "----------------------------------------------------------" << std::endl;
  }

  void ForkTN::PrintTensors() const {
    for (int k = 1; k <= N(); k++) { ITENSOR_Print(A(k)); }
  }

  void ForkTN::PrintDivs() const {
    for (int k = 1; k <= N(); k++) { ITENSOR_Print(div(A(k))); }
  }

  long ForkTN::PrintM(int i, int j) const {
    // prints the bond dimension from site i to site j, and returns
    // the maximum
    long maxM = 0;
    if (j == 0) { j = N(); }

    int count = 0;
    for (int k = i; k <= j; k++) {
      std::cout << "k= " << k << " ( ";
      auto indices = A(k).inds();
      for (auto indx : indices) {
        if (hasTags(indx, "Link")) {
          maxM = std::max(maxM, dim(indx));
          std::cout << dim(indx) << " ";
        }
      }
      std::cout << ")   ";
      count++;
      if (count == 5) {
        count = 0;
        std::cout << std::endl;
      }
    }
    std::cout << std::endl;
    return maxM;
  }

  long ForkTN::MaxM() const {
    // calculates the maximal bond dimension
    long maxM = 0;
    for (int k = 1; k <= N(); k++) {
      auto indices = A(k).inds();
      if (IsImp(k)) {
        maxM = std::max({maxM, dim(indices[1]), dim(indices[2]), dim(indices[3])});
      } else {
        maxM = std::max({maxM, dim(indices[1]), dim(indices[2])});
      }
    }
    return maxM;
  }

  void ForkTN::PrintImpM(int numSpaces) const {
    // Prints Bond dimensions of the impurity tensors
    std::string spaces(numSpaces, ' ');

    std::cout << spaces << "Dim of Impurity-Bath Links:     ";
    for (auto k : range1(NArms())) {
      Index ind = commonIndex(A(ImpSite(k)), A(ImpSite(k) + 1));
      std::cout << std::setw(7) << dim(ind) << "   ";
    }
    std::cout << std::endl;

    std::cout << spaces << "Dim of Impurity-Impurity Links: ";
    for (auto k : range1(NArms() - 1)) {
      Index ind = commonIndex(A(ImpSite(k)), A(ImpSite(k + 1)));
      std::cout << std::setw(7) << dim(ind) << "   ";
    }
    std::cout << std::endl;

    return;
  }

  std::vector<int> ForkTN::BondDims() const {
    // m contains first all impurity-impurity bond dimensions, thenn the bath bond
    // dimensions
    std::vector<int> m(0);
    for (int arm = 1; arm < NArms(); arm++) {
      auto ind = commonIndex(A(ImpSite(arm)), A(ImpSite(arm + 1)));
      m.push_back(dim(ind));
    }

    for (int arm = 1; arm <= NArms(); arm++) {
      // impurity-bath and bath-bath links
      int Isite = ImpSite(arm);
      for (int k = 1; k <= NBath(arm); k++) {
        auto ind = commonIndex(A(Isite + k - 1), A(Isite + k));
        m.push_back(dim(ind));
      }
    }

    return m;
  }

  Index ForkTN::GetLink(int site, OrthoState dir) const { return commonIndex(A(site), A(Neighbor(site, dir))); }

  ITensor ForkTN::UTensor(int site, OrthoState towards) const {
    std::vector<OrthoState> dirs;
    // find all possible directions of neighbors of site
    if (IsImp(site)) {
      if (ImpIndx(site) == 1)
        dirs = {Rightwards, Downwards};
      else if (ImpIndx(site) == NArms())
        dirs = {Rightwards, Upwards};
      else
        dirs = {Rightwards, Downwards, Upwards};
    } else {
      if (SiteToArm(site).second == 1)
        dirs = {Leftwards};
      else
        dirs = {Rightwards, Leftwards};
    }

    bool found = false;
    // create a list of all indices that must be in U
    std::vector<Index> indices(0);
    for (auto dir : dirs) {
      if (dir == towards) {
        found = true;
        continue; // do not include towards
      }
      indices.push_back(GetLink(site, dir));
    }
    indices.push_back(sites_(site));

    if (!found) Error("UTensor: direction " + to_string(towards) + " not a valid direction for site " + std::to_string(site));

    return ITensor(indices);
  }

} // namespace forktps
