#ifndef __FORKTDVP__
#define __FORKTDVP__

#include "ForkLocalOp.hpp"
#include "ForkTPS.hpp"
#include "Gates.hpp"
#include "forktps/fork/Bath.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"
#include "forktps/params.hpp"

#include <itensor/itensor.h>
#include <itensor/types.h>

#include <vector>
#undef Print

using namespace itensor;

namespace forktps {

  /** Performs a TDVP time evolution step $| \psi(t+\Delta t) \rangle \to  e^{-Hdt} | \psi(t) \rangle$. 
  * This function dispatches into either two-site or single-site TDVP for the impurity tensors depending 
  * on the *args*.
  * @param psi    ForkTPS
  *                 State to be time evolved.
  * @param Heff     ForkLocalOp
  *                 Represents the Hamiltonian in the form of effective Hamiltonians needed for the local time evolution steps.
  * @param dt       template, either double or Complex
  *                 Time step. Real *dt* means imaginary time evolution, and Complex *dt* real time evolution. Note the minus sign in the exponential: If *dt* is positive, the time evolution is perform in forward direction i.e.: $e^{-Hdt}$
  * @param args     ITensor::Args
  *                 Parameters, possible args are:
  *
  * @param TevoMethod   std::string (default: "TDVP")
  *                     Decides if two site TDVP ("TDVP_2") or single site TDVP ("TDVP") is used for the impurity-impurity links.
  * @param CutoffI      double (default: 1E-10)
  *                     Truncated weight used in the tensor decomposition for impurity-impurity links (only for two-site TDVP).
  * @param CutoffIB     double (default: 1E-10)
  *                     Truncated weight used in the tensor decomposition for impurity-bath links.
  * @param CutoffB      double (default: 1E-10)
  *                     Truncated weight used in the tensor decomposition for bath-bath links.
  * @param MaxmI        int (default: 200)
  *                     Maximal bond dimension for the tensor decomposition for impurity-impurity links (only for two-site TDVP).
  * @param MaxmIB       int (default: 200)
  *                     Maximal bond dimension for the tensor decomposition for impurity-bath links.
  * @param MaxmB        int (default: 400)
  *                     Maximal bond dimension for the tensor decomposition for bath-bath links.
  * @param ErrGoal      double (default: set by itensor)
  *                     Convergence Criterium of Krylov exponentiation.
  * @param MaxIter      int (default: set by itensor)
  *                     Maximal number of Krylov vectors generated.
  * @param NormCutoff   double (default: set by itensor)
  *                     If norm of new Krylov vector drops below this value, stop generating new vectors to avoid ghost states.
  * @param TrackNorm    bool (default false)
  *                     If true, normalizes the psi after every TDVP step, but stores the norm into the args variable totalNorm (access with getReal).
  */
  template <class T> void TDVP(ForkTPS &psi, ForkLocalOp &Heff, T dt, Args &args);

  /// Container for all operators and gates needed to perform a TEBD step.
  class TEBD_container {
    public:
    TEBD_container() = default;

    template <class T> TEBD_container(const H_int &hint, const bath &b, const hloc &e0, T dt, const AIM_ForkSites &sites);

    /// Time step with which the operators were created
    Complex dt{};

    /// vector of ForkTPOs storing the exponentiated spin-flip terms.
    std::optional<std::vector<ForkTPO>> SF;
    /// vector of ForkTPOs storing the exponentiated pair-hopping terms.
    std::optional<std::vector<ForkTPO>> PH;
    /// ForkTPO storing the exponentiated density-density terms.
    std::optional<std::vector<ITensor>> DD_MPO;
    /// Vector of two-site gates for the hybridization terms and all on-site energies.
    std::vector<ForkGate> gates{};
  };

  /** Performs a single TEBD step to time evolve *psi* using the operators stored in *Ops*.
  */
  void TEBD(ForkTPS &psi, const TEBD_container &Ops, Args &args);

} // namespace forktps
#endif
