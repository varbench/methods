namespace forktps {
#define UNUSED_VAR(x) (void)x
} // namespace forktps