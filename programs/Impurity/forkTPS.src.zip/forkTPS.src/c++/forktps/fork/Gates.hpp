#include <itensor/itensor.h>
#include <itensor/mps/siteset.h>
#undef Print

#include <vector>

using namespace itensor;

#ifndef __FORKGATES__
#define __FORKGATES__

namespace forktps {

  /**
 * The ForkGate class is used to represent a time evolution gate. The most
 * important aspects of a gate is the actual tensor it contains and the two
 * sites it acts upon. 
 */
  class ForkGate {
    public:
    // constructors:

    /// Default constructur
    ForkGate();

    /// Constructor with tensor *G* acting on sites *i* and *j*.
    ForkGate(ITensor G, int i, int j);

    /// Returns first site the gate acts on.
    int i() const;

    /// Returns second site the gate acts on.
    int j() const;

    /// Returns the number of sites this gate acts on (usually 2).
    int NSites() const;

    /// Returns the tensor of the gate.
    ITensor gate() const;

    /// Primes all indices with prime level *oldp* to prime level *newp*.
    void mapPrime(int oldp, int newp);

    /// Make a swap gate acting on sites *i* and *j* using the site indices of *sites*.
    void MakeSwap(int i, int j, const SiteSet &sites);

    /// Exponentiates the gate $e^{-dt*G}$ (note the minus sign) for real *dt*.
    void expGate(double dt, const SiteSet &sites);

    /// Exponentiates the gate $e^{-dt*G}$ (note the minus sign) for Complex *dt*.
    void expGate(Complex dt, const SiteSet &sites);

    /** Multiplication-Equal operator with gate *rhs*. Note that this multiplication
    * is not commutative and it is implemented such that *rhs* acts after the gate
    * on the left hand side of the operator *=.
    */
    ForkGate &operator*=(ForkGate &rhs);

    /** Multiplication operator with gate *other*. Note that this multiplication
    * is not commutative and it is implemented such that *other* acts after the gate
    * on the left hand side of the operator *.
    */
    const ForkGate operator*(ForkGate &other) const;

    private:
    //////////////////
    //
    // Data Members

    /// Number of sites this gate acts on (usual 2)
    int Nsites_;
    /// Vector containing the site.
    std::vector<int> Sites_;

    /// Tensor
    ITensor gate_;
  };

} // namespace forktps

#endif
