#include "Arm.hpp"
#include "forktps/fork/typenames.hpp"
#include <string>

using namespace itensor;

namespace forktps {

  void Arm::CompOrtho() {
    isOrtho         = true;
    inner_ortho_lim = NBath + 1;
    outer_ortho_lim = NBath;
  }

  void Arm::ShiftOrtho(int indx, OrthoState dir) {
    isOrtho = false;

    if (dir == Leftwards) {
      if (outer_ortho_lim != indx - 1) {
        std::string msg = std::string("ShiftOrtho: Trying to shift leftwards on index " + std::to_string(indx))
           + "with wrong inner_ortho_lim: " + std::to_string(outer_ortho_lim);
        Error(msg);
      }

      if (indx == NBath) {
        CompOrtho();
      } else {
        inner_ortho_lim = std::max(inner_ortho_lim, indx + 2);
        outer_ortho_lim = indx;
      }
    } else if (dir == Rightwards) {
      if (inner_ortho_lim != indx + 1) {
        std::string msg = std::string("ShiftOrtho: Trying to shift rightwards on index " + std::to_string(indx))
           + "with wrong inner_ortho_lim: " + std::to_string(inner_ortho_lim);
        Error(msg);
      }

      inner_ortho_lim = indx;
      outer_ortho_lim = std::min(outer_ortho_lim, indx - 2);
    } else {
      Error("Arm::Ortho: Wrong direction " + to_string(dir));
    }
  }

  void Arm::SSOrtho(int indx) {
    if (indx == NBath + 1) {
      CompOrtho();
    } else {
      isOrtho         = false;
      inner_ortho_lim = indx + 1;
      outer_ortho_lim = indx - 1;
    }
  }

  void Arm::TSOrtho(int indxI, int indxJ) {
    if (indxJ < indxI) std::swap(indxI, indxJ);

    if (indxJ != indxI + 1) {
      std::cout << "Nb " << NBath;
      std::cout << " i " << (indxI) << "    j " << indxJ << std::endl;
      Error("TwoSiteOrtho: indxi and indxj must be neighbors");
    }

    inner_ortho_lim = indxJ + 1;
    outer_ortho_lim = indxI - 1;
  }

  void Arm::LinkOrtho(int indxI, int indxJ) {
    if (indxJ < indxI) std::swap(indxI, indxJ);

    if (indxJ != indxI + 1) Error("TwoSiteOrtho: indxi and indxj must be neighbors");

    inner_ortho_lim = indxJ;
    outer_ortho_lim = indxI;
  }

  void Arm::TouchOrtho(int indx) {
    isOrtho = false;

    if (indx >= inner_ortho_lim) inner_ortho_lim = indx + 1;
    if (indx <= outer_ortho_lim) outer_ortho_lim = indx - 1;
  }

  void Arm::ForgetOrtho() {
    isOrtho         = false;
    inner_ortho_lim = NBath + 1;
    outer_ortho_lim = 0;
  }

} // namespace forktps