#ifndef __HELPERFUNCS__
#define __HELPERFUNCS__

#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"

#include <itensor/itensor.h>
#include <itensor/mps/siteset.h>
#include <itensor/util/print.h>
#include <optional>
#undef Print
#define ITENSOR_Print(X) itensor::PrintNice(#X, X)

#include <iostream>
#include <sstream>

namespace forktps {
  /*
  * In this file some usefull functions not directly related to
  * FTPS are implemented. Among others, here we declare the hash-functions used for
  * checkpointing.
  */

  /**
  * Defines the stream operator << for vectors.
  */
  template <class T> std::ostream &operator<<(std::ostream &os, const std::vector<T> &vec) {
    if (vec.size() > 0) {
      os << vec.at(0);
      for (auto i : itertools::range(1, vec.size())) os << " " << vec.at(i);
    }
    return os;
  }

  /** Rounds a vector of doubles to precsion-number of digits. 
  */
  std::vector<double> roundVec(const std::vector<double> &vec, int precision = 0);

  /** Rounds a double number to precsion-number of digits. 
  */
  double roundVal(double v, int precision = 0);

  /**
  * Writes '---------------------------------------' into the console *num* number of times.
  */
  void PrintBorderLine(int num = 1);

  /**
  * Generates and returns an itensor::combiner used to combine all indices that are 
  * present in both *A* and *B* into a single index. Also returns the combined index.
  * @param A    ITensor
  *             First tensor, can be multiplied by the combiner directly.
  * @param B    ITensor
  *             Second tensor, must be multiplied by the dag(combiner).
  */
  std::pair<ITensor, Index> LinkCombiner(const ITensor &A, const ITensor &B);

  /**
  * Generates and returns an itensor::combiner used to combine the two indices
  * *i* and *j* into a single index. Also returns the combined index.
  * @param i    Index
  *             First index to combine.
  * @param j    Index
  *             Second index to combine.
  */
  std::pair<ITensor, Index> LinkCombiner(const Index &i, const Index &j);

  /**
  * Returns the maximal bond dimension of tensor *A*
  */
  long int MaxDim(const ITensor &A);

  /** Returns the product of all index dimensions of tensor *A*. 
  *   Without quantum number conservation this is the same as the number of entries of *A*.
  */
  long int Dim(const ITensor &A);

  /** Returns an itensor::IndexSet (a container holding indices) conatining all
  *   indices of tensor *A* except index *remove*. If index *add* is provided,
  *   *add* replaces *remove*.
  * @param A        ITensor
  *                 Tensor from which indices are taken.
  * @param remove   Index
  *                 Index that is in *A* but not in the returned IndexSet.
  * @param add      Index (default: Index())
  *                 If provided, index added to the IndexSet.
  */
  itensor::IndexSet AllExcept(ITensor A, Index remove, Index add = Index());

  /**
  * single parameter version of AddToStream () -> see c++ vargs
  */
  template <typename T, typename... Rest> void AddToStream(std::stringstream &Stream, T t) { Stream << t; }

  /**
  * Function using vargs to combine a variable number of function arguments into
  * a single string, as long as the stream operator << is defined for each
  * function argument.
  */
  template <typename T, typename... Rest> void AddToStream(std::stringstream &Stream, T t, Rest... rest) {
    Stream << t;
    AddToStream(Stream, rest...);
  }

  /**
  * Hash function that takes a variable number of arguments and creates a hash
  * using every one of them as long as stream operator << is defined for each
  * argument. Creates a string from every argument and returns the hash of this string.
  */
  template <typename... Ts> std::string CreateHash(Ts... ts) {
    std::stringstream StreamToHash;

    AddToStream(StreamToHash, ts...);

    std::hash<std::string> hash_fn;
    int hash = hash_fn(StreamToHash.str());

    return std::to_string(hash);
  }

  /// Writes the forktps *psi* to file *fn*.
  void save(std::string fn, const ForkTPS &psi);

  /// Reads the forktps *psi* created with *sites* from file *fn* .
  void load(std::string fn, ForkTPS &psi, const SiteSet &sites);

  /// Reads the state *gs* with its SiteSet *sites* and ground state energy *energy* from file *fn*.
  void loadGS(const std::string fn, ForkTPS &gs, AIM_ForkSites &sites, double &energy);

  /// Writes the state *gs* with its SiteSet *sites* and ground state energy *energy* to file *fn*.
  void saveGS(const std::string fn, const ForkTPS &gs, const AIM_ForkSites &sites, double energy);

  /** Sets MaxDim and Cutoff of *args* to the correct values specified by the link
  *   of site *i* with its neighbor in direction *dir* in geometry *F*. Also returns
  *   the itensor tags of that link used in the svd. Default values are defined in 
  *   defaultMaxDim and defaultCutoff.
  */
  std::string SetSVDParams(int i, const Fork &F, OrthoState dir, Args &args, int defaultMaxDim, double defaultCutoff);

  /** Sets MaxDim and Cutoff of *args* to the correct values specified by the link
  *   of site *i* with its neighbor in direction *dir* in geometry *F*. Also returns
  *   the itensor tags of that link used in the svd.
  *   Default values:
  *   truncated weight impurity-impurity links :        1E-10
  *   truncated weight bath-bath links :                1E-10
  *   truncated weight impurity-bath links :            1E-10
  *   maximal bond dimension impurity-impurity links:   200
  *   maximal bond dimension impurity-bath links:       200
  *   maximal bond dimension bath-bath links:           400
  */
  std::string SetSVDParams(int i, const Fork &F, OrthoState dir, Args &args);

  /* Creates a tensor that when multiplied onto another tensor that has Index *c* 
  *  has the effect of truncating *c* to the first *dim* entries of it.
  */
  std::pair<ITensor, Index> nonSquareDiag(const Index &c, int dim);

} // namespace forktps

#endif
