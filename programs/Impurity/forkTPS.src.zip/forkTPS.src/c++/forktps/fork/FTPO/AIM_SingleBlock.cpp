#include "AIM_SingleBlock.hpp"
#include "forktps/fork/makros.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/params.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>



using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1) ( ie form for example (0,0) to (-1,-1) )
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

namespace forktps {

  // clang-format off
  

  AIM_FullOffDiag::AIM_FullOffDiag(const SiteSet &sites, bath ba, hloc h_loc, H_int hint, const Args& args)
     : sites_(sites),
       hint(hint),
       JSFPH_(hint.J),
       initted_(false),
       blockName(ba.blockNames().at(0)),
       b(std::move(ba)),
       e0(std::move(h_loc)) 
    {
    if(b.blockNames().size() != 1)
        Error("AIM_FullOffDiag: MPO can only be created for a single block");


    H = ForkTPO(sites_, b.NBathVec());

    if ( hint.dd_only ) JSFPH_ = 0;
    E0_ = args.getReal("E0Shift",0);
  }

  void AIM_FullOffDiag::init_() {
    if (initted_) return;

    std::vector<Index> ArmImpLinks(0);
    std::vector<Index> ImpImpLinks(0);

    MakeArmMPOs(ArmImpLinks);
    if (b.NArms() == 2) {
      MakeOneOrbitalMPO(ArmImpLinks);
    } else if (b.NArms() == 4) {
      MakeTwoOrbitalMPO(ArmImpLinks);
    } else if (b.NArms() == 6) {
      MakeThreeOrbitalMPO(ArmImpLinks);
    } else {
      std::cout<< b.NArms()<<"\n";
      Error("AIM_ForkTPO_NonDiagBath: Cannot create AIM_ForkTPO_NonDiagBath with this number of orbitals");
    }

    initted_ = true;
  }

  // clang-format off

  void AIM_FullOffDiag::MakeArmMPOs(std::vector<Index>& ArmImpLinks){

    // Vk_ is such that std::conj(Vk_) is used for the hopping where the creation operator acts in the bath i.e.: std::conj(Vk_) * c_k^\dag c_I
    ArmImpLinks.resize(0); ArmImpLinks.emplace_back(Index());


    for(int arm = 1; arm <= b.NArms(); arm++) {
      const int NBath = H.NBath(arm);
      std::vector<Index> ArmLinks(NBath+1);


      QN qnC    = - div( sites_.op( "Ck",  H.ImpSite(arm) ) );
      QN qnCDag = - div( sites_.op( "CkD", H.ImpSite(arm) ) );
      QN qn0    = - div( sites_.op( "Id",  H.ImpSite(arm) ) );
    

      //create links
      for(int l=1;l<=NBath;l++){
        auto indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;
        
        Index::qnstorage linkQNs(0);
        linkQNs.push_back( {qn0, 3} ); // Hfin, Id, p
        // hybridizations
        for(auto x : range1( arm, b.NArms() ) ){
            UNUSED_VAR(x);
            linkQNs.push_back( {qnC, 1} );
            linkQNs.push_back( {qnCDag,    1} );
        }

        ArmLinks.at(l) = Index( std::move(linkQNs),  Out, indxName );
      }

      // k == 1
      {
        int k =1;
        int site = H.ArmToSite(arm,1);
        ITensor& W =H.Anc(site);
        Index left=ArmLinks.at(1);
        triqs_indx I{blockName, arm-1};

        W=ITensor(dag(sites_.si(site)), sites_.siP(site), left);

        W += sites_.op("N"  ,site)*setElt( left(1) )* b.eps( I, k-1);
        W += sites_.op("Id" ,site)*setElt( left(2) );
        W += sites_.op("p"  ,site)*setElt( left(3) );

        //diagonal
        Complex V = b.V(I, I, k-1 );
        W += sites_.op("Ck" ,site)*setElt( left(4) )*           V ;  //V is the hopping onto impurity ie C in bath
        W += sites_.op("CkD",site)*setElt( left(5) )*std::conj(-V);  //Vdag is the hopping onto bath ie CD in bath

        //hybridization terms
        int offset = 5;
        for(auto armJ : range1( arm+1, b.NArms())){
          triqs_indx J{blockName, armJ-1};
          auto amp = b.V(I, J, k-1 );

          //if(std::abs(amp)>1E-12) std::cout << arm << " " << armJ << " " << k << " "<<amp << " into " << offset +1 << " "<< offset+2 <<std::endl;
          if(std::abs(amp)>1E-15){
            W += sites_.op("Ck*p" ,site)*setElt( left( offset+1 ) )*         (-amp);    //V is the hopping onto impurity ie C in bath
            W += sites_.op("CkD*p",site)*setElt( left( offset+2 ) )*std::conj( amp );  //Vdag is the hopping onto bath ie CD in bath
          }
          offset += 2;
        }

      }
      
      for(int k=2; k<=NBath; k++){

        int site = H.ArmToSite(arm,k);
        triqs_indx I{blockName, arm-1};

        ITensor& W =H.Anc(site);

        Index right =dag(ArmLinks.at(k-1));
        Index left  =    ArmLinks.at(k)   ;

        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left,right);
        W += sites_.op("Id",site)*setElt( left(1), right(1) );
        W += sites_.op("Id",site)*setElt( left(2), right(2) ); //ids
        W += sites_.op("p" ,site)*setElt( left(3), right(3) );
        W += sites_.op("p" ,site)*setElt( right(4), left(4) ); 
        W += sites_.op("p" ,site)*setElt( right(5), left(5) ); //ps

        W += sites_.op("N" ,site)*setElt( left(1), right(2) )* b.eps(I, k-1); //on-site energy

        //diagonal
        Complex V = b.V(I, I, k-1 );
        W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           V ;  //V is the hopping onto impurity ie C in bath
        W += sites_.op("CkD",site)*setElt( left(5), right(2) )*std::conj(-V);  //Vdag is the hopping onto bath ie CD in bath
        
        //hybridizations
        int offset = 5;
        for(auto armJ : range1( arm, b.NArms())){
          triqs_indx J{blockName, armJ-1};

          W += sites_.op("Id", site)*setElt( left(offset+1), right(offset+1) );
          W += sites_.op("Id", site)*setElt( left(offset+2), right(offset+2) );

          auto amp = b.V(I, J, k-1 );
          // In the fermionic order, this bath site (B) comes before the impurity (I)!
          // the hopping is defined as 
          // V cI^D cB + V* cB^D cI =  - V cB cI^d + V* cB cI^D. 
          // so here the V-term has a minus sign not the V*-term
          if(std::abs(amp)>1E-15){
            W += sites_.op("Ck*p" ,site)*setElt( left(offset+1), right(3) )*         (-amp );  //V is the hopping onto impurity ie C in bath
            W += sites_.op("CkD*p",site)*setElt( left(offset+2), right(3) )*std::conj( amp );  //Vdag is the hopping onto bath ie CD in bath
          }
          offset += 2;
        }
        
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

  }



  void AIM_FullOffDiag::MakeThreeOrbitalMPO( const std::vector<Index>& ArmImpLinks ){
    
    auto ImpLinks = GetImpLinks();
    

    //first Impurity site
    {
      int armI=1;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILink = ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      W  = sites_.op("Id",site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(2) );


      // index offset for impurity and bath
      int os(3), bathos(5);
      for (auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // Imp-Imp Hopping
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(os+1) )* (-e0(J, I)); // From armJ to armI 
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(os+2) )* (+e0(I, J)); // From armI to armJ
        
        //Bath-Imp Hopping (no p)
        W += sites_.op("Id",site) * setElt( ALink(bathos+1), ILink(os+1) ); 
        W += sites_.op("Id",site) * setElt( ALink(bathos+2), ILink(os+2) ); 
        
        bathos += 2;
        os += 2;
      }

      //finish hybridization and bath energy terms from local bath:
      W += sites_.op("N",site)    * setElt( ALink(2), ILink(1) )* onSiteE;
      W += sites_.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites_.op("Ck*p",site) * setElt( ALink(5), ILink(1) );

      W += sites_.op("N",site) * setElt( ALink(2), ILink(3) );

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILink(14) );
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILink(15) );
      }
    }

    //second Impurity site
    {
      int armI=2;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and Ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      // off-diag hybridizations and hoppings for impurities below
      int below(4), above(5), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (-e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (+e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }

      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      
      // finish diag hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // finish off-diag hybridizations and imp-imp hoppings
      W += sites_.op("CkD", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(1));
      W += sites_.op("Ck",  site) * setElt(ALink(2), ILinkUp(5), ILinkDn(1));

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      //finish density density interactions: nA_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.U); 	//with nA_up

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(14), ILinkDn(13) ); //cD*c SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(14) ); //cD*cD SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(15) ); //c*cD SFPH
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(15), ILinkDn(16) ); //c*c SFPH
      }
    }

    //third Impurity site B-up
    {
      int armI=3;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density term Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density term Adn

      // off-diag hopping + hybridization
      int below(5), above(6), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (-e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (+e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );

      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      
      // finish diag hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // finish off-diag hybridizations and imp-imp hoppings
      W += sites_.op("CkD", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(1));
      W += sites_.op("Ck",  site) * setElt(ALink(2), ILinkUp(6), ILinkDn(1));


      //finish density density interactions: nB_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up-hint.J);	//with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up);	//with nA_Dn

      //SF-PH 
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(12) ); //Ids for cD*c 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(13) ); //Ids for cD*cD 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(14) ); //Ids for c*cD 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(16), ILinkDn(15) ); //Ids for c*c 

        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(2), ILinkDn(16) ); //add new terms
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(2), ILinkDn(17) ); //add new terms

        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(13), ILinkDn(18) ); //cD*c*c
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(14), ILinkDn(19) ); //cD*cD*c 
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(15), ILinkDn(20) ); //c*cD*cD
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(16), ILinkDn(21) ); //c*c*cD
      }
    }

    //fourth Impurity site B-dn
    {
      int armI=4;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids 
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) ); //Hfin
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //big ID
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density operator Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density operator Adn
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(3) ); //density operator Bup

      //add density operator of this site
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );


      // off-diag hopping + hybridization
      int below(4), above(7), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (-e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (+e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }


      //finish bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      
      // finish diag hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // finish off-diag hybridizations and imp-imp hoppings
      W += sites_.op("CkD", site) * setElt(ALink(2), ILinkUp(6), ILinkDn(1));
      W += sites_.op("Ck",  site) * setElt(ALink(2), ILinkUp(7), ILinkDn(1));


      //finish density density interactions: N = nB_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up);     //with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up-hint.J);	//with nA_Dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(5), ILinkDn(1) )*(hint.U);	        //with nB_up

      //SF PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(18), ILinkDn(1) )*( JSFPH_); //finish
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(19), ILinkDn(1) )*(-JSFPH_); //finish
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(20), ILinkDn(1) )*( JSFPH_); //finish
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(21), ILinkDn(1) )*(-JSFPH_); //finish

        W += sites_.op("Ck", site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(9) ); //cD*c
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(10) ); //cD*cD
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(11) ); //c*cD
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(12) ); //c*c

        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(12), ILinkDn(9) ); //cD*c
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(10) ); //cD*cD
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(11) ); //c*cD
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(12) ); //c*c
      }


    }

    //fifth Impurity site C-up
    {
      int armI=5;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) ); //Hfin
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //big ID
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density operator Aup + Bup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density operator Adn + Bdn

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );


      // off-diag hopping + hybridization
      int below(5), above(6), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (-e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (+e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }



      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      
      // finish diag hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // finish off-diag hybridizations and imp-imp hoppings
      W += sites_.op("CkD", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(1));
      W += sites_.op("Ck",  site) * setElt(ALink(2), ILinkUp(6), ILinkDn(1));


      //finish density density interactions: nB_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up-hint.J);	//with A_up + B_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up);	    //with A_dn + B_dn

      //SF and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(9),  ILinkDn(8)  );
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(9)  );
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10) ); //CD*p = CD
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11) ); //CD*p = CD
      }
      
    }

    //last impurity
    {
      int armI=b.NArms();
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );


      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1) );   //combine Hfin from top with Id from bath
      W += sites_.op("Id",site) * setElt( ALink(1), ILinkUp(2) );  //combine Id from top with Hfin from bath
      

      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2) );

      //finish off-diag hybridizations and hoppings:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(6) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7) );

      // add E0 term here
      W += sites_.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish density interactions
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(3) )*( hint.Up    );	  //with A_up + B_up
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(4) )*( hint.Up-hint.J );   //with A_dn + B_dn
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(5) )*( hint.U         );		//with C_up 

      //finish Sf and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(8) ) *( JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(9) ) *(-JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(10) )*( JSFPH_);
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(11) )*(-JSFPH_);
      }
      
    }

  }


  void AIM_FullOffDiag::MakeTwoOrbitalMPO( const std::vector<Index>& ArmImpLinks ){

    auto ImpLinks = GetImpLinks();


    //first Impurity site
    {
      int armI=1;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILink = ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      W  = sites_.op("Id",site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(2) );


      // index offset for impurity and bath
      int os(3), bathos(5);
      for (auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // Imp-Imp Hopping
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(os+1) )* (-e0(J, I)); // From armJ to armI 
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(os+2) )* (+e0(I, J)); // From armI to armJ
        
        //Bath-Imp Hopping (no p)
        W += sites_.op("Id",site) * setElt( ALink(bathos+1), ILink(os+1) ); 
        W += sites_.op("Id",site) * setElt( ALink(bathos+2), ILink(os+2) ); 
        
        bathos += 2;
        os += 2;
      }

      // finish on-site energy and bath hybridization with diagonal bath
      W += sites_.op("N",site)  * setElt( ALink(2), ILink(1) )* onSiteE;
      W += sites_.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites_.op("Ck*p",site) * setElt( ALink(5), ILink(1) );

      // N for density-density terms
      W += sites_.op("N",site) * setElt( ALink(2), ILink(3) );

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILink(10) );
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILink(11) );
      }
    }

    //second Impurity site
    {
      int armI=2;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and Ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      // off-diag hopping
      int below(4), above(5), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }
      // bath energies:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      // impurity on-site energy
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      // diagonal hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );
      
      // off-diagonal hybridizations 
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(1) );
      W += sites_.op("Ck",site)  * setElt( ALink(2), ILinkUp(5), ILinkDn(1) );

      //finish density density interactions: nA_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.U); 	//with nA_up


      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(10), ILinkDn(9) ); //cD*c SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(10), ILinkDn(10) ); //cD*cD SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(11), ILinkDn(11) ); //c*cD SFPH
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(11), ILinkDn(12) ); //c*c SFPH
      }
    }

    //third Impurity site B-up
    {
      int armI=3;
      triqs_indx I{blockName, armI-1};
      double onSiteE = std::real( e0(I) );

      int site = H.ImpSite(armI);
      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );
      Index ILinkDn =      ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density term Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density term Adn


      // off-diag hopping
      int below(5), above(6), bath(5);
      for(auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // imp-imp hoppings
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(below+1) )* (-e0(J, I)); // From armJ to armI
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(below+2) )* (+e0(I, J)); // From armI to armJ
        
        // off-diag terms from above 
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+1), ILinkDn(below+1) );
        W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(above+2), ILinkDn(below+2) );

        // off-diag hybridizations from attached bath
        W += sites_.op("Id",site) * setElt( ALink(bath+1), ILinkUp(2), ILinkDn(below+1) );
        W += sites_.op("Id",site) * setElt( ALink(bath+2), ILinkUp(2), ILinkDn(below+2) );

        above += 2;
        below += 2;
        bath += 2;
      }


      // finish bath energies
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      // finish impurity on-site energy
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      // finish diagonal hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );
      // finish off-diagonal hybridizations
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(1) );
      W += sites_.op("Ck",site)  * setElt( ALink(2), ILinkUp(6), ILinkDn(1) );

      // finish density density interactions: nB_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up-hint.J);	//with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up);	//with nA_Dn


      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );

      //SF-PH 
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(9),  ILinkDn(8) ); //cD*c*c
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(9) ); //cD*cD*c 
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10) ); //c*cD*cD
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11) ); //c*c*cD
      }
    }

    //last impurity
    {
      int armI=b.NArms();
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILinkUp = dag( ImpLinks.at(armI-1) );

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );


      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1) );   //combine Hfin from top with Id from bath
      W += sites_.op("Id",site) * setElt( ALink(1), ILinkUp(2) );  //combine Id from top with Hfin from bath
      

      //bath hybridization with attached bath and local on-site energies
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2) )* onSiteE;

      // finish diag hyb
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2) );

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(6) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7) );

      // add E0 term here
      W += sites_.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish density interactions
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(3) )*( hint.Up        );	  //with nA_up
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(4) )*( hint.Up-hint.J ); 	//with nA_dn
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(5) )*( hint.U         );		//with nC_up



      //finish Sf and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(8) )*( JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(9) )*(-JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(10))*( JSFPH_);
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(11))*(-JSFPH_);
      }
    }
  }




  void AIM_FullOffDiag::MakeOneOrbitalMPO( const std::vector<Index>& ArmImpLinks ){
    auto ImpLinks = GetImpLinks();


    //first Impurity site
    {
      int armI=1;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(armI));
      Index ILink = ImpLinks.at(armI);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      W  = sites_.op("Id",site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(2) );

      
      int os(3), bathos(5);
      for (auto armJ : range1(armI+1, b.NArms())){
        triqs_indx J{blockName, armJ-1};
        // Imp-Imp Hopping
        W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(os+1) )* (-e0(J, I)); // From armJ to armI 
        W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(os+2) )* (+e0(I, J)); // From armI to armJ
        
        //Bath-Imp Hopping (no p)
        W += sites_.op("Id",site) * setElt( ALink(bathos+1), ILink(os+1) ); 
        W += sites_.op("Id",site) * setElt( ALink(bathos+2), ILink(os+2) ); 
        
        bathos += 2;
        os += 2;
      }

      // finish on-site energy and bath hybridization with diagonal bath
      W += sites_.op("N",site)  * setElt( ALink(2), ILink(1) )* onSiteE;
      W += sites_.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites_.op("Ck*p",site) * setElt( ALink(5), ILink(1) );

      // N for density-density terms
      W += sites_.op("N",site) * setElt( ALink(2), ILink(3) );

    }


    //second Impurity site
    {
      int armI=2;
      int site = H.ImpSite(armI);
      triqs_indx I{blockName, armI-1};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(armI));
      Index ILink   = dag( ImpLinks.at(armI-1) );

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      //Ids 
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(1) );

      // bath energies:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILink(2) );
      // impurity on-site energy
      W += sites_.op("N",site)   * setElt( ALink(2), ILink(2) )* onSiteE;
      // diagonal hybridizations
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILink(2) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILink(2) );
      
      // off-diagonal hybridizations 
      W += sites_.op("CkD",site) * setElt( ALink(2), ILink(4) );
      W += sites_.op("Ck",site)  * setElt( ALink(2), ILink(5) );

      //finish density density interactions: nA_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILink(3) )*(hint.U); 	//with nA_up

      // H - E0
      W += sites_.op("Id", site)  * setElt(ALink(2), ILink(2)) * E0_;
    }
  }



  std::vector<Index> AIM_FullOffDiag::GetImpLinks(){
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN c    = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    QN cD   = - div( sites_.op( "CkD", H.ImpSite(1) ) );


    std::vector<Index> ImpLinks; ImpLinks.resize(b.NArms()+1);
    //create links:
    if(b.NArms() == 6){
         if (std::abs(JSFPH_) > 1E-15) {
          
            ImpLinks.at(1) = Index( qn0,  3, 

                                    c,  1, //off diag to 2
                                    cD, 1, //off diag to 2
                                    c,  1, //off diag to 3
                                    cD, 1, //off diag to 3
                                    c,  1, //off diag to 4
                                    cD, 1, //off diag to 4
                                    c,  1, //off diag to 5 
                                    cD, 1, //off diag to 5
                                    c,  1, //off diag to 6 
                                    cD, 1, //off diag to 6

                                    cD, 1, //SFPH             
                                    c,  1, //SFPH

                                    Out, Names::TAGSI );

          ImpLinks.at(2) = Index( qn0,    4,

                                  c,  1, //off diag to 3
                                  cD, 1, //off diag to 3
                                  c,  1, //off diag to 4
                                  cD, 1, //off diag to 4
                                  c,  1, //off diag to 5 
                                  cD, 1, //off diag to 5
                                  c,  1, //off diag to 6 
                                  cD, 1, //off diag to 6

                                  cD+c,   1, // C_upD* C_dn  - SFPH
                                  cD+cD,  1, // C_upD* C_dnD - SFPH
                                  c +cD,  1, // C_up * C_dnD - SFPH
                                  c +c,   1, // C_up * C_dn  - SFPH  
  
                                  Out, Names::TAGSI );

          ImpLinks.at(3) = Index( qn0,  5,

                                  c,  1, //off diag to 4
                                  cD, 1, //off diag to 4
                                  c,  1, //off diag to 5 
                                  cD, 1, //off diag to 5
                                  c,  1, //off diag to 6 
                                  cD, 1, //off diag to 6

                                  cD+c,   1, // C_upD* C_dn  - SFPH
                                  cD+cD,  1, // C_upD* C_dnD - SFPH
                                  c +cD,  1, // C_up * C_dnD - SFPH
                                  c +c,   1, // C_up * C_dn  - SFPH    
                                  
                                  cD, 1,  //C_upD - SFPH
                                  c,  1,  //C_upD - SFPH

                                  cD + c  + c,   1, //C_upD* C_dn * C_up - SFPH
                                  cD + cD + c,   1, //C_upD* C_dnD* C_up - SFPH
                                  c  + cD + cD,  1, //C_up * C_dnD* C_upD- SFPH
                                  c  + c  + cD,  1, //C_up * C_dn * C_upD- SFPH


                                  Out, Names::TAGSI );

          ImpLinks.at(4) = Index( qn0,  4,

                                  c,    1, //off diag to 5 
                                  cD,   1, //off diag to 5
                                  c,    1, //off diag to 6 
                                  cD,   1, //off diag to 6

                                  cD+c,   1, // C_upD* C_dn  - SFPH
                                  cD+cD,  1, // C_upD* C_dnD - SFPH
                                  c +cD,  1, // C_up * C_dnD - SFPH
                                  c +c,   1, // C_up * C_dn  - SFPH     
                                  


                                  Out, Names::TAGSI );
        
          ImpLinks.at(5) = Index( qn0,  5,

                                  c,  1, //off diag to 6 
                                  cD, 1, //off diag to 6

                                  cD+c +c,   1, //C_upD* C_dn * C_up - SFPH
                                  cD+cD+c,   1, //C_upD* C_dnD* C_up - SFPH
                                  c +cD+cD,  1, //C_up * C_dnD* C_upD- SFPH
                                  c +c +cD,  1, //C_up * C_dn * C_upD- SFPH

                                  Out, Names::TAGSI );
        }
        else {
          // No SFPH, 6 Arms
          ImpLinks.at(1) = Index( qn0,  3, 

                                  c,  1, //off diag to 2
                                  cD, 1, //off diag to 2
                                  c,  1, //off diag to 3
                                  cD, 1, //off diag to 3
                                  c,  1, //off diag to 4
                                  cD, 1, //off diag to 4
                                  c,  1, //off diag to 5
                                  cD, 1, //off diag to 5
                                  c,  1, //off diag to 6
                                  cD, 1, //off diag to 6

                                  Out, Names::TAGSI );

          ImpLinks.at(2) = Index( qn0,  4,
                                  c,  1, //off diag to 3
                                  cD, 1, //off diag to 3
                                  c,  1, //off diag to 4
                                  cD, 1, //off diag to 4
                                  c,  1, //off diag to 5
                                  cD, 1, //off diag to 5
                                  c,  1, //off diag to 6
                                  cD, 1, //off diag to 6
                                  Out, Names::TAGSI );

          ImpLinks.at(3) = Index( qn0,  5,

                                  c,  1, //off diag to 4
                                  cD, 1, //off diag to 4
                                  c,  1, //off diag to 5
                                  cD, 1, //off diag to 5
                                  c,  1, //off diag to 6
                                  cD, 1, //off diag to 6
                                  Out, Names::TAGSI );

          ImpLinks.at(4) = Index( qn0,  4,
                                  c,    1, //off diag to 5
                                  cD,   1, //off diag to 5
                                  c,    1, //off diag to 6
                                  cD,   1, //off diag to 6
                                  Out, Names::TAGSI );
        
          ImpLinks.at(5) = Index( qn0,  5,

                                  c,    1, //off diag to 6
                                  cD,   1, //off diag to 6
                                  Out, Names::TAGSI );
        }
    }
    else if (b.NArms() == 4) {
      if (std::abs(JSFPH_) > 1E-15) {
        // with SFPH, 4 Arms
        ImpLinks.at(1) = Index( qn0,  3, 
                                c,    1,  //off diag to 2
                                cD,   1,  //off diag to 2
                                c,    1,  //off diag to 3
                                cD,   1,  //off diag to 3
                                c,    1,  //off diag to 4
                                cD,   1,  //off diag to 4

                                cD,   1,  //SFPH            
                                c,    1,  //SFPH
                                Out, Names::TAGSI );

        ImpLinks.at(2) = Index( qn0,    4,
                                c,      1,  //off diag to 3
                                cD,     1,  //off diag to 3
                                c,      1,  //off diag to 4
                                cD,     1,  //off diag to 4

                                cD+c,   1, // C_upD* C_dn  - SFPH
                                cD+cD,  1, // C_upD* C_dnD - SFPH
                                c +cD,  1, // C_up * C_dnD - SFPH
                                c +c,   1, // C_up * C_dn  - SFPH    
                                Out, Names::TAGSI );

        ImpLinks.at(3) = Index( qn0,  5,

                                c,    1,  //off diag to 4
                                cD,   1,  //off diag to 4

                                cD+c +c,   1, //C_upD* C_dn * C_up - SFPH
                                cD+cD+c,   1, //C_upD* C_dnD* C_up - SFPH
                                c +cD+cD,  1, //C_up * C_dnD* C_upD- SFPH
                                c +c +cD,  1, //C_up * C_dn * C_upD- SFPH
                                Out, Names::TAGSI );

      }
      else {
        // No SFPH, 4 Arms
        ImpLinks.at(1) = Index( qn0,  3, 

                                c,    1,  //off diag to 2
                                cD,   1,  //off diag to 2
                                c,    1,  //off diag to 3
                                cD,   1,  //off diag to 3
                                c,    1,  //off diag to 4
                                cD,   1,  //off diag to 4

                                Out, Names::TAGSI );

        ImpLinks.at(2) = Index( qn0,  4,
                                c,    1,  //off diag to 3
                                cD,   1,  //off diag to 3
                                c,    1,  //off diag to 4
                                cD,   1,  //off diag to 4

                                Out, Names::TAGSI );

        ImpLinks.at(3) = Index( qn0,  5,

                                c,    1,  //off diag to 4
                                cD,   1,  //off diag to 4

                                Out, Names::TAGSI );
      }
    }
    else if(b.NArms() == 2){
      ImpLinks.at(1) = Index( qn0,  3, 
                              c,    1,  //off diag to 2
                              cD,   1,  //off diag to 2

                                Out, Names::TAGSI );

    }
    return ImpLinks;
  }
  // clang-format on
} //namespace forktps
