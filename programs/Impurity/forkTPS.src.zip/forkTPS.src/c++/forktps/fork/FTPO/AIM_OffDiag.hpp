#include "../typenames.hpp"
#include "../ForkTPO.hpp"
#include "../Bath.hpp"
#include "../../params.hpp"

#include "itensor/mps/siteset.h"

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1) ( ie form for example (0,0) to (-1,-1) )
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

namespace forktps {

  class AIM_OffDiag {
    public:
    AIM_OffDiag(const SiteSet &sites, bath b, hloc e0, double U, double Uprime, double J, const Args &args);
    AIM_OffDiag(const SiteSet &sites, bath b, hloc e0, H_int hint, const Args &args = Args::global());

    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    void MakeArmMPOs(std::vector<Index> &ArmImpLinks);

    void MakeOneOrbitalMPO(const std::vector<Index> &ArmImpLinks);
    void MakeTwoOrbitalMPO(const std::vector<Index> &ArmImpLinks);
    void MakeThreeOrbitalMPO(const std::vector<Index> &ArmImpLinks);

    std::vector<Index> GetImpLinks();

    private:
    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;
    double U_;
    double Uprime_;
    double J_;
    double JSFPH_;
    double E0_;

    bool initted_;

    std::string blockNameUp;
    std::string blockNameDn;
    bath b;
    hloc e0;
    ForkTPO H;

    //
    //////////////////

    void init_();
  };

} //namespace forktps

/*

  void AIM_OffDiag::MakeTwoOrbitalArmMPOs(std::vector<Index>& ArmImpLinks){

    if(NArms_ != 4){Error("AIM_ForkTPO_NonDiagBath::MakeArmMPOs:: Error only Nchains=4 implemented!"); }
    ArmImpLinks.resize(0); ArmImpLinks.push_back(Index());

    const int NBath =H.NBath();
    std::vector<Index> ArmLinks(NBath+1);

    for(int arm = 1; arm <= NArms_; arm++) {
      QN qnC, qnCDag, qn0 = QN( {"Sz",0},{"Nf", 0,-1} );

      //std::cout << "-------------------------------------------"<<std::endl;
      //std::cout << "-------------------------------------------"<<std::endl;



      if(arm%2 == 1){
        qnC=     QN({"Sz", 1},{"Nf", 1,-1});
        qnCDag=  QN({"Sz",-1},{"Nf",-1,-1});
      }
      else {
        qnC=     QN({"Sz",-1},{"Nf", 1,-1});
        qnCDag=  QN({"Sz", 1},{"Nf",-1,-1});
      }

      //create links
      for(int l=1; l<=NBath;l++){
        auto indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;

        if(arm != NArms_ && arm != NArms_-1){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,    Out, indxName );
        }
        else
        {
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
        }
      }

      {
        int site = H.ArmToSite(arm,1);
        ITensor& W =H.Anc(site);
        Index left=ArmLinks.at(1);
        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left);


        W += sites_.op("N"  ,site)*setElt( left(1) )*ek_.at(arm).at(1);
        W += sites_.op("Id" ,site)*setElt( left(2) );
        W += sites_.op("p"  ,site)*setElt( left(3) );

        //std::cout<< "Use " << ek_.at(arm).at(1)<< " for on-site energy"<<std::endl;

        if(arm != NArms_ && arm != NArms_-1){
          W += sites_.op("Ck" ,site)*setElt( left(4) )*           vk_.at(arm).at(1)  ;
          W += sites_.op("CkD",site)*setElt( left(5) )*std::conj( vk_.at(arm).at(1) );
          W += sites_.op("Ck" ,site)*setElt( left(6) )*           vk_.at(arm+2).at(1);
          W += sites_.op("CkD",site)*setElt( left(7) )*std::conj( vk_.at(arm+2).at(1) );

          //std::cout<< "Use " << vk_.at(arm).at(1)<< "for diag bath, and "<< vk_.at(arm+2).at(1) <<" for non-diag bath"<<std::endl;
        }
        else {
          W += sites_.op("Ck" ,site)*setElt( left(4) )*           vk_.at(arm).at(NBath+1);
          W += sites_.op("CkD",site)*setElt( left(5) )*std::conj( vk_.at(arm).at(NBath+1) );
          //std::cout<< "Use " << vk_.at(arm).at(NBath+1)<< " for diag bath"<<std::endl;
        }


      }
      for(int n=2; n<=NBath; n++){

        int site = H.ArmToSite(arm,n);

        ITensor& W =H.Anc(site);

        Index right =dag(ArmLinks.at(n-1));
        Index left  =    ArmLinks.at(n)   ;

        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        W += sites_.op("Id",site)*setElt( left(1),right(1) ); 
        W += sites_.op("Id",site)*setElt( left(2),right(2) ); //ids
        
        W += sites_.op("p" ,site)*setElt( left(3), right(3) ); 
        W += sites_.op("p" ,site)*setElt( left(4), right(4) ); 
        W += sites_.op("p" ,site)*setElt( left(5), right(5) ); //ps

        W += sites_.op("N" ,site)*setElt( left(1), right(2) )*ek_.at(arm).at(n); //on-site energy

        //std::cout<< "Use " << ek_.at(arm).at(n)<< " for on-site energy"<<std::endl;

        if(arm == 1 || arm == 2){
          W += sites_.op("Id",site)*setElt( left(6), right(6) );
          W += sites_.op("Id",site)*setElt( left(7), right(7) );

          W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           vk_.at(arm).at(n)   ;
          W += sites_.op("CkD",site)*setElt( left(5), right(2) )*std::conj( vk_.at(arm).at(n) ) ;

          W += sites_.op("Ck" ,site)*setElt( left(6), right(3) )*           vk_.at(arm+2).at(n)   ;
          W += sites_.op("CkD",site)*setElt( left(7), right(3) )*std::conj( vk_.at(arm+2).at(n) ) ;

          //std::cout<< "Use " << vk_.at(arm).at(n)<< "for diag bath, and "<< vk_.at(arm+2).at(n)  <<" for non-diag bath"<<std::endl;
        }
        else {
          W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           vk_.at(arm).at(NBath+n)   ;
          W += sites_.op("CkD",site)*setElt( left(5), right(2) )*std::conj( vk_.at(arm).at(NBath+n) ) ;
          //std::cout<< "Use " << vk_.at(arm).at(NBath+n)<< " for diag bath"<<std::endl;
        }


      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

  }





*/
