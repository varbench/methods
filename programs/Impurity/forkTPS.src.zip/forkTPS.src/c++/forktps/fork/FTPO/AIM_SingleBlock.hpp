#include "../typenames.hpp"
#include "../ForkTPO.hpp"
#include "../Bath.hpp"
#include "../../params.hpp"

#include "itensor/mps/siteset.h"

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1) ( ie form for example (0,0) to (-1,-1) )
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

namespace forktps {

  class AIM_FullOffDiag {
    public:
    AIM_FullOffDiag(const SiteSet &sites, const Dmat &EpsK, const Cmat &VK, double U, double Uprime, double J, int NArms, const Args &args);
    AIM_FullOffDiag(const SiteSet &sites, bath bath, hloc h_loc, double U, double Uprime, double J, int NArms, const Args &args);
    AIM_FullOffDiag(const SiteSet &sites, bath bath, hloc h_loc, H_int hint, const Args &args = Args::global());

    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    void MakeArmMPOs(std::vector<Index> &ArmImpLinks);

    void MakeOneOrbitalMPO(const std::vector<Index> &ArmImpLinks);
    void MakeTwoOrbitalMPO(const std::vector<Index> &ArmImpLinks);
    void MakeThreeOrbitalMPO(const std::vector<Index> &ArmImpLinks);

    std::vector<Index> GetImpLinks();

    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    H_int hint;
    double JSFPH_;
    double E0_;

    bool initted_;

    std::string blockName;

    bath b;
    hloc e0;
    ForkTPO H;

    //
    //////////////////

    void init_();
  };

} //namespace forktps
