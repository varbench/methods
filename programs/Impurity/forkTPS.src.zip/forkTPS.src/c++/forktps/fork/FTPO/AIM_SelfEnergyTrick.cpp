#include "AIM_SelfEnergyTrick.hpp"
#include "forktps/fork/makros.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/params.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>
#undef Print

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1)
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

//with hopping terms in MPOs we mostly use the following convention
//regarding the Fermi Operators p:
//We do not use "p" on the first site (first with respect to the fermionic order)
//and therefore also do not include the minus sign. ie.:
//c1^dag c3 + c3^dag c1 = c1^dag c3 - c1 c3^dag
//since the second term annihilates on site 1 it must be occupied. this means that
//moving c3^dag past the first site gives always a minus sign which cancels the minus sign above

namespace forktps {

  // clang-format off

  AIM_SelfEnergyMPO::AIM_SelfEnergyMPO(const SiteSet &sites, double U, double Uprime, double J, int siteN, int NArms, const Args& args)
     : sites_(sites), initted_(false) {
    U_       = U;
    Uprime_  = Uprime;
    J_       = J;
    NArms_ = NArms;
    H        = ForkTPO(sites_, NArms_);

    JSFPH_ = J_;
    if (args.getBool("DDonly", false)) JSFPH_ = 0;

    siteN_ = siteN;

    if (siteN % 2 == 1) {
      spin_ = Up;
      orb_  = (siteN + 1) / 2;
    } else {
      spin_ = Down;
      orb_  = (siteN) / 2;
    }
  }

  AIM_SelfEnergyMPO::AIM_SelfEnergyMPO(const SiteSet &sites, double U, double Uprime, double J, int siteN, ivec NBath, const Args& args)
     : sites_(sites), initted_(false) {

    U_       = U;
    Uprime_  = Uprime;
    J_       = J;
    JSFPH_ = J_;
    if (args.getBool("DDonly", false)) JSFPH_ = 0;

    if (NBath.size() == 0) 
      H = ForkTPO(sites_, NBath.size()-1);
    else
      H = ForkTPO(sites_, NBath);
    
    siteN_ = siteN;

    if (siteN % 2 == 1) {
      spin_ = Up;
      orb_  = (siteN + 1) / 2;

    } else {
      spin_ = Down;
      orb_  = (siteN) / 2;
    }
  } 

  AIM_SelfEnergyMPO::AIM_SelfEnergyMPO(const SiteSet &sites, H_int hint, int siteN, int NArms, const Args& args)
     : sites_(sites), initted_(false) {
    
    UNUSED_VAR(args);
    U_       = hint.U;
    Uprime_  = hint.Up;
    J_       = hint.J;
    NArms_ = NArms;
    H        = ForkTPO(sites_, NArms_);

    JSFPH_ = J_;
    if ( hint.dd_only ) JSFPH_ = 0;

    siteN_ = siteN;

    if (siteN % 2 == 1) {
      spin_ = Up;
      orb_  = (siteN + 1) / 2;
    } else {
      spin_ = Down;
      orb_  = (siteN) / 2;
    }
  }

  void AIM_SelfEnergyMPO::init_() {
    if (initted_) { return; }

    std::vector<Index> ArmImpLinks;
    ArmImpLinks.resize(0);

    ArmMPOs(ArmImpLinks);


    if (orb_ == 1 && spin_ == Up)
      MakeImpMPO_SpinUp_Orb1Only(ArmImpLinks);
    else if (orb_ == 1 && spin_ == Down)
      MakeImpMPO_SpinDown_Orb1Only(ArmImpLinks);
    else if (spin_ == Up)
      MakeImpMPO_SpinUp(ArmImpLinks); //for all orbitals > 1
    else
      MakeImpMPO_SpinDown(ArmImpLinks); //for all orbitals > 1

    initted_ = true;
    return;
  }

  void AIM_SelfEnergyMPO::ArmMPOs(std::vector<Index>& ArmImpLinks) {
    // this MPO carries non-zero QN divergence, we let this value
    // "move outwards" the last arm. this quantum number is stored in the variable qnLastArm.
    ArmImpLinks.resize(0);
    ArmImpLinks.push_back(Index());
    QN qnLastArm, qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );

    if (spin_ == Up)
      qnLastArm = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    else
      qnLastArm = - div( sites_.op( "Ck",  H.ImpSite(2) ) );


    for (int arm = 1; arm <= NArms_; arm++) {

      int NBath = H.NBath(arm);
      std::vector<Index> ArmLinks(NBath + 1);

      //create links
      for (int l = 1; l <= NBath; l++) {
        auto indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;

        if (arm != NArms_)
          ArmLinks.at(l) = Index( qn0, 2, Out, indxName );
        else
          ArmLinks.at(l) = Index( qnLastArm, 2, Out, indxName );
      }

      //fill tensors
      {
        int site = H.ArmToSite(arm, 1);

        ITensor &W = H.Anc(site);

        Index left = ArmLinks.at(1);
        
        W  = ITensor(dag(sites_.si(site)), sites_.siP(site), left);

        W += sites_.op("Id", site) * setElt( left(1) );
        W += sites_.op("p",  site) * setElt( left(2) );
      }

      for (int n = 2; n <= NBath; n++) {

        int site = H.ArmToSite(arm, n);

        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(n - 1));
        Index left  = ArmLinks.at(n);

        W = ITensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        W += sites_.op("Id", site) * setElt( right(1), left(1) );
        W += sites_.op("p",  site) * setElt( right(2), left(2) );
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }
  }

  void AIM_SelfEnergyMPO::MakeImpMPO_SpinUp_Orb1Only(const std::vector<Index> &ArmImpLinks) {
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    //QN cupD = - div( sites_.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites_.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = - div( sites_.op( "CkD", H.ImpSite(2) ) );

    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    std::vector<int> LinkDim;
    LinkDim.resize(NArms_);
    LinkDim = {0, 3, 4, 5};

    //make ImpImpLinks
    {
      //first link
      ImpLinks.at(1) = Index( qn0, 2,
                              cup, 1, Out, Names::TAGSI); 

      //second link
      ImpLinks.at(2) = Index( cup,  1,
                              qn0,  2, 
                              cup,  1,
                              cdn,  1, 
                              cdnD, 1, Out, Names::TAGSI );
      //link between spin up -> spin down
      for (int imp = 3; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) =
           Index( cup,  1,
                  qn0,  2,
                  cup,  1,
                  cdn,  1,
                  cdnD, 1,
                  cup+cdn,  1, 
                  cdnD+cup, 1, Out, Names::TAGSI  );
      }

      //link between spin down -> spin up
      for (int imp = 4; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = Index(   cup,  1, 
                                    qn0,  2,
                                    cup,  1,
                                    cdn,  1,
                                    cdnD, 1, Out,Names::TAGSI  );
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W = sites_.op("Id", site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("p", site) * setElt( ALink(2), ILink(2) );
      W += sites_.op("Ck", site)* setElt( ALink(1), ILink(3) );
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W =  sites_.op("Nk", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(1))*(-U_);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(2));
      W += sites_.op("p", site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(3));
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(4));

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Ck", site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(5));
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(6));
      }
    }

    //all other spin up sites
    for (int impIndx = 3; impIndx <= NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p", site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish
      W += sites_.op("N", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_ - J_);

      //SF PH terms
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );

        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(5), ILinkDn(7));
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(6), ILinkDn(8));
      }
    }

    //all spin down sites except last
    for (int impIndx = 4; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );


      //finish
      W += sites_.op("N", site)   * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );

        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(7), ILinkDn(1) ) * (-JSFPH_);
        W += sites_.op("Ck", site)  * setElt( ALink(1), ILinkUp(8), ILinkDn(1) ) * (+JSFPH_);
      }
    }

    //last spin down site
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1) );

      //finish
      W += sites_.op("N",   site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (Uprime_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(7) ) * (-JSFPH_);
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(8) ) * (+JSFPH_);
      }
    }
  }

  void AIM_SelfEnergyMPO::MakeImpMPO_SpinDown_Orb1Only(const std::vector<Index> &ArmImpLinks) {
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = - div( sites_.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites_.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = - div( sites_.op( "CkD", H.ImpSite(2) ) );

    // cImp is the QN of the c-operator of the impurity on which the GF is calculated
    // cImp_BarSig is the QN of the opposite spin c-operator (of the same orbital) of the impurity degree of freedom on which the GF is calculated
    QN cn, cn_BarSig, cnD_BarSig;

    //might also be cmupD
    QN c_BarSig_cmup;
    QN cD_BarSig_cmup;

    if (spin_ == Down) {
      cn         = cdn;
      cn_BarSig  = cup;
      cnD_BarSig = cupD;

      c_BarSig_cmup  = cup + cupD;
      cD_BarSig_cmup = cupD + cup;
    } else {
      cn = cup; // cImp is the QN of the c-operator of the impurity on which the GF is calculated
      cn_BarSig =
         cdn; // cImp_BarSig is the QN of the opposite spin c-operator (of the same orbital) of the impurity degree of freedom on which the GF is calculated
      cnD_BarSig = cdnD;

      c_BarSig_cmup  = cdn + cup;
      cD_BarSig_cmup = cdnD + cup;
    }

    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    std::vector<int> LinkDim;
    LinkDim.resize(NArms_);
    LinkDim = {0, 3, 4, 5};

    //make ImpImpLinks
    {
      ImpLinks.at(1) = Index( qn0,        3, 
                              cn_BarSig,  1, 
                              cnD_BarSig, 1,  Out, Names::TAGSI);

      //second link
      ImpLinks.at(2) = Index(  cn,         1, 
                               qn0,        2,
                               cn,         1,
                               cn_BarSig,  1,
                               cnD_BarSig, 1, Out, Names::TAGSI);

      //link between spin up -> spin down
      for (int imp = 3; imp <= NArms_; imp += 2) {
        ImpLinks.at(imp) = Index(   cn,             1,
                                    qn0,            2,
                                    cn,             1,
                                    cn_BarSig,      1,
                                    cnD_BarSig,     1,
                                    c_BarSig_cmup,  1,
                                    cD_BarSig_cmup, 1, Out, Names::TAGSI);
      }

      //link between spin down -> spin up
      for (int imp = 4; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = Index( cn,         1,
                                  qn0,         2,
                                  cn,         1,
                                  cn_BarSig,  1,
                                  cnD_BarSig,  1, Out, Names::TAGSI);
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W = sites_.op("Id", site)   * setElt( ALink(1), ILink(1) );
      W += sites_.op("p", site)   * setElt( ALink(2), ILink(2) );
      W += sites_.op("N*p", site) * setElt( ALink(2), ILink(3) );
      
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILink(4) );
        W += sites_.op("CkD", site) * setElt( ALink(1), ILink(5) );
      }  
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(1) ) * (-U_) ;
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(3) );
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(4) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(6) );
      }
    }

    //all other spin up sites
    for (int impIndx = 3; impIndx <= NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish
      W += sites_.op("N", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );
        
        W += sites_.op("CkD*p", site) * setElt( ALink(2), ILinkUp(5), ILinkDn(7) );
        W += sites_.op("Ck*p" , site) * setElt( ALink(2), ILinkUp(6), ILinkDn(8) );
      }
    }

    //all spin down sites except last
    for (int impIndx = 4; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish
      W += sites_.op("N",  site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_ - J_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){ 
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );

        // finish
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(7), ILinkDn(1) ) * (+JSFPH_);
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(8), ILinkDn(1) ) * (-JSFPH_);
      }
    }

    //last spin down site
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1) );

      //finish
      W += sites_.op("N",  site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (Uprime_ - J_);
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){ 
        // finish
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(7) ) * (+JSFPH_);
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(8) ) * (-JSFPH_);
      }
    }
  }

  void AIM_SelfEnergyMPO::MakeImpMPO_SpinUp(const std::vector<Index> &ArmImpLinks) {
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = - div( sites_.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites_.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = - div( sites_.op( "CkD", H.ImpSite(2) ) );

    // cImp is the QN of the c-operator of the impurity on which the GF is calculated
    // cImp_BarSig is the QN of the opposite spin c-operator (of the same orbital) of the impurity degree of freedom on which the GF is calculated
    QN cn, cn_BarSig, cnD_BarSig;

    //might also be cmupD
    QN c_BarSig_cmup;
    QN cD_BarSig_cmup;

    QN cmup_cmdn, cmup_cDmdn;

    if (spin_ == Down) {
      cn         = cdn;
      cn_BarSig  = cup;
      cnD_BarSig = cupD;

      c_BarSig_cmup  = cup + cupD;
      cD_BarSig_cmup = cupD + cup;
    } else {

      cn = cup; // cImp is the QN of the c-operator of the impurity on which the GF is calculated
      cn_BarSig =
         cdn; // cImp_BarSig is the QN of the opposite spin c-operator (of the same orbital) of the impurity degree of freedom on which the GF is calculated
      cnD_BarSig = cdnD;

      c_BarSig_cmup  = cdn + cup;
      cD_BarSig_cmup = cdnD + cup;

      cmup_cmdn  = cup + cdn;
      cmup_cDmdn = cup + cdnD;
    }

    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    std::vector<int> LinkDim;
    LinkDim.resize(NArms_);
    LinkDim = {0, 3, 4, 5};

    //make ImpImpLinks
    {
      //first link
      ImpLinks.at(1) = Index(    qn0,  3, 
                                 cup,  1, 
                                 cup,  1, Out, Names::TAGSI);

      //link between spin down -> spin up above site n
      for (int imp = 2; imp < siteN_; imp += 2) {
        ImpLinks.at(imp) =
          Index(       qn0,        4,
                       cmup_cDmdn, 1, 
                       cmup_cmdn,  1, Out, Names::TAGSI );
      }

      //link between spin up -> spin down above site n
      for (int imp = 3; imp < siteN_; imp += 2) {
        ImpLinks.at(imp) = Index(  qn0,         4,
                                   cmup_cDmdn,  1,
                                   cmup_cmdn,   1,
                                   cup,         1,
                                   cup,         1, Out, Names::TAGSI );
      }

      //link between site N and site_N + 1
      ImpLinks.at(siteN_) = Index(  cn,         1,  
                                    qn0,        2,
                                    cn,         1,
                                    cmup_cDmdn, 1,
                                    cmup_cmdn,  1, Out, Names::TAGSI );

      //link between spin up -> spin down below site n
      for (int imp = siteN_ + 1; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) =
           Index(   cn,             1,
                    qn0,            2,
                    cn,             1,
                    cn_BarSig,      1,
                    cnD_BarSig,     1,
                    c_BarSig_cmup,  1,
                    cD_BarSig_cmup, 1, Out, Names::TAGSI);
      }

      //link between spin up -> spin down below site n
      for (int imp = siteN_ + 2; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = Index(             
                              cn,             1,
                              qn0,            2,
                              cn,             1,
                              cn_BarSig,      1,
                              cnD_BarSig,     1,
                              c_BarSig_cmup,  1,
                              cD_BarSig_cmup, 1, Out, Names::TAGSI );
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W = sites_.op("Id", site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("p", site) * setElt( ALink(2), ILink(2) );

      W += sites_.op("N*p", site) * setElt( ALink(2), ILink(3) ); //need ALink(2) and p since cn is comming at a later site

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILink(4) );  //take ALink(1)!!!
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILink(5) );  //take ALink(1)!!!
      }
    }

    //second Impurity site
    {
      int impIndx = 2;

      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      W += sites_.op("N*p",   site) * setElt( ALink(2), ILinkUp(2), ILinkDn(4) ); //cn still missing!

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("CkD*p", site) * setElt( ALink(2), ILinkUp(4), ILinkDn(5) ); //only cn missing
        W += sites_.op("Ck*p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(6) ); //only cn missing
      }
    }

    //all spin up sites before siteN_
    for (int impIndx = 3; impIndx < siteN_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //for large p
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //for nup
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //for ndn


      W += sites_.op("N*p", site) * setElt( ALink(2), ILinkUp(2), ILinkDn(3) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(5) ); //for cup cdnD
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(6) ); //for cup cdn

        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(2), ILinkDn(7) ); //take ALink(1) and no p in bath!!!
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(2), ILinkDn(8) ); //take ALink(1) and no p in bath!!!
      }
    }

    //all spin down sites before siteN_
    for (int impIndx = 4; impIndx < siteN_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //for large p
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //for nup
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //for ndn

      W += sites_.op("N*p",   site) * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(5) ); //for cup cdnD
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(6) ); //for cup cdn

        W += sites_.op("CkD*p", site) * setElt( ALink(2), ILinkUp(7), ILinkDn(5) ); //cn still missing
        W += sites_.op("Ck*p",  site) * setElt( ALink(2), ILinkUp(8), ILinkDn(6) );  //cn still missing
      }
    }

    //siteN
    {
      int impIndx = siteN_;
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //finish n*c terms
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(1) ) * (-1) * (Uprime_ - J_);
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);

      //"diagonals"
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(3) ); //for large p

      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(4) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(5) ); //for cm_up cm_dnDag
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(6) ); //for cm_up cm_dn
      }
      
    }

    //siteN+1 if it is not the last site
    if (siteN_ + 1 != NArms_) {
      int impIndx = siteN_ + 1;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //"diagonals"
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish terms
      W += sites_.op("N",   site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-U_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        //finish
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(5), ILinkDn(1) ) * (-JSFPH_);
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(1) ) * (+JSFPH_);

        //keep cndn and cndnDag
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(3), ILinkDn(5) );
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(6) );
      }
    }

    //all spin up sites except last
    for (int impIndx = siteN_ + 2; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      W += sites_.op("N",    site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_ - J_);
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(5), ILinkDn(7) ); //cm still missing
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(6), ILinkDn(8) ); //cm still missing
        
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );
      }
    }

    //all spin down sites except last
    for (int impIndx = siteN_ + 3; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish
      W += sites_.op("N",   site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );

        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(7), ILinkDn(1) ) * (-JSFPH_);
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(8), ILinkDn(1) ) * (+JSFPH_);
      }
    }

    //last spin down site
    {

      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1) );

      //finish

      if (siteN_ + 1 == NArms_) {
        W += sites_.op("N",   site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (U_);
        // SF PH
        if( std::abs(JSFPH_)>1E-15 ){
          W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(5) ) * (-JSFPH_);
          W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(6) ) * (+JSFPH_);
        }
      } else {
        W += sites_.op("N",   site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (Uprime_);
         // SF PH
        if( std::abs(JSFPH_)>1E-15 ){
          W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(7) ) * (-JSFPH_);
          W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(8) ) * (+JSFPH_);
        }
      }
    }
  }

  void AIM_SelfEnergyMPO::MakeImpMPO_SpinDown(const std::vector<Index> &ArmImpLinks){
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = - div( sites_.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites_.op( "Ck",  H.ImpSite(2) ) );
    //QN cdnD = - div( sites_.op( "CkD", H.ImpSite(2) ) );

    // cImp is the QN of the c-operator of the impurity on which the GF is calculated
    // cImp_BarSig is the QN of the opposite spin c-operator (of the same orbital) of the impurity degree of freedom on which the GF is calculated
    QN cn, cn_BarSig, cnD_BarSig;

    //might also be cmupD
    QN cBarSig_cDmup;
    QN cDBarSig_cmup;

    QN PH, SF;

    if (spin_ == Down) {
      cn         = cdn;
      cn_BarSig  = cup;
      cnD_BarSig = cupD;

      cBarSig_cDmup = cup + cupD;
      cDBarSig_cmup = cupD + cup;

      SF = cupD + cdn;
      PH = cup + cdn;
    }

    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms_ + 1);
    std::vector<int> LinkDim;
    LinkDim.resize(NArms_);
    LinkDim = {0, 3, 4, 5};

    //make ImpImpLinks
    {
      //first link
      ImpLinks.at(1) = Index(   qn0,  3, 
                                cupD, 1, 
                                cup,  1, Out, Names::TAGSI);

      //link between spin down -> spin up above site n
      for (int imp = 2; imp < siteN_ - 1; imp += 2) {
        ImpLinks.at(imp) = Index(   qn0, 4,
                                    SF,  1,
                                    PH,  1, Out, Names::TAGSI);
      }

      //link between spin up -> spin down above site n
      for (int imp = 3; imp < siteN_ - 1; imp += 2) {
        ImpLinks.at(imp) = Index(   qn0,    4,
                                    SF,     1,
                                    PH,     1,
                                    cupD,   1,
                                    cup,    1, Out, Names::TAGSI);
      }

      //link between site N-1 and site_N , i.e.: link between spin up and spin down in orbital n
      ImpLinks.at(siteN_ - 1) = Index(  cn,           1,
                                        qn0,          5,
                                        cn_BarSig,    1,                           
                                        cnD_BarSig,   1, Out, Names::TAGSI);

      //link between spin up -> spin down below site n (if it exists)
      for (int imp = siteN_; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = Index(   cn,         1,
                                    qn0,        2,
                                    cn,         1,
                                    cn_BarSig,  1,
                                    cnD_BarSig, 1, Out, Names::TAGSI);
      }

      //link between spin up -> spin down below site n
      for (int imp = siteN_ + 1; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = Index( cn,             1,
                                  qn0,            2,
                                  cn,             1,
                                  cn_BarSig,      1,
                                  cnD_BarSig,     1,
                                  cBarSig_cDmup,  1, 
                                  cDBarSig_cmup,  1, Out, Names::TAGSI);
      }
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W += sites_.op("Id", site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("p", site) * setElt( ALink(2), ILink(2) );

      W += sites_.op("N*p", site) * setElt( ALink(2), ILink(3) ); //need ALink(2) and p since cn acts at a later site

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("CkD", site) * setElt( ALink(1), ILink(4) ); //take ALink(1)!!!
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILink(5) );  //take ALink(1)!!!
      }
    }

    //second Impurity site
    {
      int impIndx = 2;
      int site     = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      W += sites_.op("N*p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );  //cn still missing!
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(4), ILinkDn(5) ); //only cn missing
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(5), ILinkDn(6) ); //only cn missing
      }
    }

    //all spin up sites before siteN_
    for (int impIndx = 3; impIndx < siteN_ - 1; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //for large p
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //for nup
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //for ndn

      W += sites_.op("N*p", site) * setElt( ALink(2), ILinkUp(2), ILinkDn(3) );
      
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(5) ); //for cupD cdn
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(6) ); //for cup cdn

        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(7) ); //take ALink(1) -> no p in bath!!!
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(2), ILinkDn(8) );  //take ALink(1) -> no p in bath!!!
      }
    }

    //all spin down sites before siteN_
    for (int impIndx = 4; impIndx < siteN_ - 1; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //for large p
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //for nup
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //for ndn

      W += sites_.op("N*p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );  //cn still missing

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(5), ILinkDn(5) ); //for cup cdnD
        W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(6) ); //for cup cdn

        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(7), ILinkDn(5) ); //cn still missing
        W += sites_.op("Ck*p", site) * setElt( ALink(2), ILinkUp(8), ILinkDn(6) ); //cn still missing
      }
    }

    //siteN -1 i.e.: spin up site on orbital n
    {
      int impIndx = siteN_ - 1;

      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);



      //"diagonals"
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(2), ILinkDn(3) ); //for large p
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(4) ); //for nup
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(4), ILinkDn(5) ); //for ndn

      W += sites_.op("N*p", site) * setElt( ALink(2), ILinkUp(2), ILinkDn(6) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        //finish 
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(5), ILinkDn(1) ) * (+JSFPH_);
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(1) ) * (-JSFPH_);

        // cn_bar_sigma for orbitals m > n
        W += sites_.op("Ck",  site) * setElt( ALink(1), ILinkUp(2), ILinkDn(7) );
        W += sites_.op("CkD", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(8) );
      }
    }

    //make siteN if it is not the last site
    if (siteN_ != NArms_) {
      int impIndx = siteN_;

      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //"diagonals"
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      //finish terms
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(1) ) * (-1) * (Uprime_ - J_);
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(1) ) * (-1) * (U_);

      // cn for density density terms 
      W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(3), ILinkDn(4) );

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(7), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(8), ILinkDn(6) );
      }
    }

    //all spin up sites m>n
    for (int impIndx = siteN_ + 1; impIndx < NArms_; impIndx += 2) {

      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      W += sites_.op("N",     site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_);

      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );
        
        W += sites_.op("CkD*p", site) * setElt( ALink(2), ILinkUp(5), ILinkDn(7) ); //cm still missing
        W += sites_.op("Ck*p",  site) * setElt( ALink(2), ILinkUp(6), ILinkDn(8) );  //cm still missing
      }
    }

    //all spin down sites except last
    for (int impIndx = siteN_ + 2; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //diagonals
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("p",  site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(4), ILinkDn(4) );

      //finish
      W += sites_.op("N",  site) * setElt( ALink(1), ILinkUp(4), ILinkDn(1) ) * (-1) * (Uprime_ - J_);
      
      // SF PH
      if( std::abs(JSFPH_)>1E-15 ){
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(5), ILinkDn(5) );
        W += sites_.op("Id", site) * setElt( ALink(1), ILinkUp(6), ILinkDn(6) );

        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(7), ILinkDn(1) ) * (+JSFPH_);
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(8), ILinkDn(1) ) * (-JSFPH_);
      }
    }

    //last spin down site
    {

      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * setElt( ALink(1), ILinkUp(1) );

      //finish

      if (siteN_ == NArms_) {
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (Uprime_);
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(5) ) * (-1) * (Uprime_ - J_);
        W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(6) ) * (-1) * (U_);
      } else {
        W += sites_.op("N",  site) * setElt( ALink(1), ILinkUp(4) ) * (-1) * (Uprime_ - J_);
        // SF PH
        if( std::abs(JSFPH_)>1E-15 ){
          W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(7) ) * (+JSFPH_);
          W += sites_.op("Ck", site) * setElt( ALink(1), ILinkUp(8) ) * (-JSFPH_);
        }
      }
    }
  }

  // clang-format on

} // namespace forktps
