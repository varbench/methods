#include <iostream>
#include <algorithm>
#include "itensor/mps/siteset.h"
#include "itensor/mps/mps.h"
#include "itensor/iqtensor.h"

#include "../typenames.h"
#include "../fork/ForkTPO.h"

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1)
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

//with hopping terms in MPOs we mostly use the following convention
//regarding the Fermi Operators p:
//We do not use "p" on the first site (first with respect to the fermionic order)
//and therefore also do not include the minus sign. ie.:
//c1^dag c3 + c3^dag c1 = c1^dag c3 - c1 c3^dag
//since the second term annihilates on site 1 it must be occupied. this means that
//moving c3^dag past the first site gives always a minus sign which cancels the minus sign above

namespace itensor {

  class AIM_ForkTPO_Chain_SF {
    public:
    AIM_ForkTPO_Chain_SF(const SiteSet &sites, std::vector<double> &EpsK, std::vector<Complex> &t, double U, double Uprime, double J, int NArms);

    operator ForkTPO() {
      init_();
      return H;
    }

    void MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks);

    void MakeFiveOrbitalMPO(const std::vector<IQIndex> &ArmImpLinks);

    private:
    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;
    double U_;
    double Uprime_;
    double J_;
    double ImpHoppt_;
    Dmat ek_;
    Cmat tk_;
    bool initted_;
    bool ImpHopp_;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

  inline AIM_ForkTPO_Chain_SF::AIM_ForkTPO_Chain_SF(const SiteSet &sites, std::vector<double> &EpsK, std::vector<Complex> &t, double U, double Uprime,
                                                    double J, int NArms)
     : sites_(sites), initted_(false), ImpHopp_(false) {
    U_      = U;
    Uprime_ = Uprime;
    J_      = J;
    NArms_  = NArms;
    H       = ForkTPO(sites_, NArms_);

    ek_.resize(NArms_ + 1);
    tk_.resize(NArms_ + 1);
    for (int i = 1; i <= NArms_; i++) {
      tk_[i].resize(t.size());
      ek_[i].resize(EpsK.size());

      for (int k = 0; k < t.size(); k++) { tk_[i][k] = t[k]; }
      for (int k = 0; k < EpsK.size(); k++) { ek_[i][k] = EpsK[k]; }
    }

    Print("ek: ");
    for (auto vec : ek_) {
      for (auto val : vec) { std::cout << val << " "; }
      std::cout << std::endl;
    }

    Print("tk: ");
    for (auto vec : tk_) {
      for (auto val : vec) { std::cout << val << " "; }
      std::cout << std::endl;
    }
  }

  void inline AIM_ForkTPO_Chain_SF::init_() {
    if (initted_) return;

    std::vector<Index> ArmImpLinks;
    ArmImpLinks.resize(0);

    MakeArmMPOs(ArmImpLinks);
    MakeFiveOrbitalMPO(ArmImpLinks);
    return;
    initted_ = true;
  }

  void AIM_ForkTPO_Chain_SF::MakeArmMPOs(std::vector<Index> &ArmImpLinks) {

    ArmImpLinks.resize(0);
    ArmImpLinks.push_back(Index());

    for (int arm = 1; arm <= NArms_; arm++) {
      int numQN0 = 2 + arm % 2; //defines how many states have QN (0,0), needed since only up-arms need "p"
      QN qnC, qnCDag;           //means which quantum number has the link after C (CDag) has acted

      int NBath = H.NBath(arm);
      std::vector<Index> InterArmLinks(NBath + 1);

      if (H.GetArmSpin(arm) == Up) {
        qnC    = QN(1, 1);
        qnCDag = QN(-1, -1);
      } else {
        qnC    = QN(-1, 1);
        qnCDag = QN(1, -1);
      }

      for (int l = 1; l <= NBath; l++) {

        std::stringstream s, sId, sC, sCD;
        s << "H ARM " << arm << " l " << l;
        sId << "Diag arm" << arm << " l" << l;
        sC << "C arm" << arm << " l" << l;
        sCD << "CD arm" << arm << " l" << l;

        InterArmLinks.at(l) = IQIndex(s.str(), Index(sId.str(), numQN0), QN(0, 0), Index(sC.str(), 1), qnC, Index(sCD.str(), 1), qnCDag);
      }

      {
        int n    = 1;
        int site = H.ArmToSite(arm, n);
        int indx = NBath - n + 1;

        IQTensor &W  = H.Anc(site);
        IQIndex left = InterArmLinks.at(n);
        W            = IQTensor(dag(sites_.si(site)), sites_.siP(site), left);

        W += sites_.op("N", site) * left(1) * ek_[arm][indx];
        W += sites_.op("Id", site) * left(2);
        if (arm % 2 == 1) { W += sites_.op("p", site) * left(numQN0); } // add p for all odd arms
        W += sites_.op("Ck", site) * left(numQN0 + 1);
        W += sites_.op("CkD", site) * left(numQN0 + 2);

        //if(arm == 1 || arm ==2)
        //  PrintDat(W);
      }

      for (int n = 2; n <= NBath; n++) {

        int site = H.ArmToSite(arm, n);
        int indx = NBath - n + 1;

        IQTensor &W = H.Anc(site);

        IQIndex right = dag(InterArmLinks.at(n - 1));
        IQIndex left  = InterArmLinks.at(n);

        W = IQTensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        W += sites_.op("Id", site) * left(1) * right(1);
        W += sites_.op("Id", site) * left(2) * right(2);

        W += sites_.op("Ck", site) * left(numQN0 + 1) * right(2);
        W += sites_.op("CkD", site) * left(numQN0 + 2) * right(2);

        if (arm % 2 == 1) { W += sites_.op("p", site) * right(numQN0) * left(numQN0); } // add p for all odd arms

        //finish terms
        W += sites_.op("N", site) * left(1) * right(2) * ek_[arm][indx];
        W += sites_.op("CkD", site) * left(1) * right(numQN0 + 1) * tk_[arm][indx];
        W += sites_.op("Ck", site) * left(1) * right(numQN0 + 2) * std::conj(tk_[arm][indx]);

        //if(arm == 1 || arm ==2)
        //  PrintDat(W);
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }
  }

  void AIM_ForkTPO_Chain_SF::MakeFiveOrbitalMPO(const std::vector<IQIndex> &ArmImpLinks) {

    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    //define links
    {
      { //Aup
        int imp          = 1;
        ImpLinks.at(imp) = IQIndex(nameint("L I", imp), Index("m ILink ", 3), QN(0, 0), //Hfin, Id, N_Aup
                                   Index("I1cD", 1), QN(-1, -1),                        //cD
                                   Index("I1c", 1), QN(1, 1)                            //c
        );
      }

      // all links of down impurities are the same
      for (int imp = 2; imp < NArms_; imp += 2) {
        ImpLinks.at(imp) = IQIndex(nameint("L I", imp), Index("m ILink ", 4), QN(0, 0), //Hfin, Id, N_up, N_dn
                                   Index("IcDc", 1), QN(-2, 0),                         // C_upD* C_dn
                                   Index("IcDcD", 1), QN(0, -2),                        // C_upD* C_dnD
                                   Index("IccD", 1), QN(2, 0),                          // C_up * C_dnD
                                   Index("Icc", 1), QN(0, 2)                            // C_up * C_dn
        );

        if (ImpHopp_) {
          ImpLinks.at(imp) =
             IQIndex(nameint("L I", imp), Index("m ILink ", 4), QN(0, 0), //Hfin, Id, N_up, N_dn
                     Index("IcDc", 1), QN(-2, 0),                         // C_upD* C_dn
                     Index("IcDcD", 1), QN(0, -2),                        // C_upD* C_dnD
                     Index("IccD", 1), QN(2, 0),                          // C_up * C_dnD
                     Index("Icc", 1), QN(0, 2),                           // C_up * C_dn
                     Index("ihcuD", 1), QN(-1, -1), Index("ihcu", 1), QN(1, 1), Index("ihcdD", 1), QN(1, -1), Index("ihcd", 1), QN(-1, 1));
        }
      }

      // all links of up impurities are the same (except E_dn)
      for (int imp = 3; imp < NArms_ - 1; imp += 2) {
        ImpLinks.at(imp) = IQIndex(nameint("L I", imp), Index("m ILink ", 5), QN(0, 0), //Hfin, Id, N_up, N_dn, N_Iup

                                   Index("IcDc", 1), QN(-2, 0),  // C_upD* C_dn
                                   Index("IcDcD", 1), QN(0, -2), // C_upD* C_dnD
                                   Index("IccD", 1), QN(2, 0),   // C_up * C_dnD
                                   Index("Icc", 1), QN(0, 2),    // C_up * C_dn

                                   Index("IcD", 1), QN(-1, -1), //C_upD
                                   Index("Ic", 1), QN(1, 1),    //C_up

                                   Index("IcDcc", 1), QN(-1, 1),  //C_upD* C_dn * C_Iup
                                   Index("IcDcDc", 1), QN(1, -1), //C_upD* C_dnD* C_Iup
                                   Index("IccDcD", 1), QN(1, -1), //C_up * C_dnD* C_IupD
                                   Index("IcccD", 1), QN(-1, 1)   //C_up * C_dn * C_IupD
        );

        if (ImpHopp_) {
          ImpLinks.at(imp) =
             IQIndex(nameint("L I", imp), Index("m ILink ", 5), QN(0, 0), //Hfin, Id, N_up, N_dn, N_Iup

                     Index("IcDc", 1), QN(-2, 0),  // C_upD* C_dn
                     Index("IcDcD", 1), QN(0, -2), // C_upD* C_dnD
                     Index("IccD", 1), QN(2, 0),   // C_up * C_dnD
                     Index("Icc", 1), QN(0, 2),    // C_up * C_dn

                     Index("IcD", 1), QN(-1, -1), //C_upD
                     Index("Ic", 1), QN(1, 1),    //C_up

                     Index("IcDcc", 1), QN(-1, 1),  //C_upD* C_dn * C_Iup
                     Index("IcDcDc", 1), QN(1, -1), //C_upD* C_dnD* C_Iup
                     Index("IccDcD", 1), QN(1, -1), //C_up * C_dnD* C_IupD
                     Index("IcccD", 1), QN(-1, 1),  //C_up * C_dn * C_IupD

                     Index("ihcuD", 1), QN(-1, -1), Index("ihcu", 1), QN(1, 1), Index("ihcdD", 1), QN(1, -1), Index("ihcd", 1), QN(-1, 1));
        }
      }

      //finally define link between E_up and E_dn
      {
        int imp          = NArms_ - 1;
        ImpLinks.at(imp) = IQIndex(nameint("L I", imp), Index("m ILink ", 5), QN(0, 0), //Hfin, Id, N_up, N_dn, N_Iup

                                   Index("IcDcc", 1), QN(-1, 1),  //C_upD* C_dn * C_Iup
                                   Index("IcDcDc", 1), QN(1, -1), //C_upD* C_dnD* C_Iup
                                   Index("IccDcD", 1), QN(1, -1), //C_up * C_dnD* C_IupD
                                   Index("IcccD", 1), QN(-1, 1)   //C_up * C_dn * C_IupD
        );

        if (ImpHopp_) {
          ImpLinks.at(imp) = IQIndex(nameint("L I", imp), Index("m ILink ", 5), QN(0, 0), //Hfin, Id, N_up, N_dn, N_Iup

                                     Index("IcDcc", 1), QN(-1, 1),  //C_upD* C_dn * C_Iup
                                     Index("IcDcDc", 1), QN(1, -1), //C_upD* C_dnD* C_Iup
                                     Index("IccDcD", 1), QN(1, -1), //C_up * C_dnD* C_IupD
                                     Index("IcccD", 1), QN(-1, 1),  //C_up * C_dn * C_IupD

                                     Index("ihcdD", 1), QN(1, -1), Index("ihcd", 1), QN(-1, 1));
        }
      }
    }

    //first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      W = sites_.op("Id", site) * ALink(2) * ILink(2);

      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("N", site) * ALink(2) * ILink(1) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(4) * ILink(1) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(5) * ILink(1) * std::conj(tk_[impIndx][0]);

      W += sites_.op("N", site) * ALink(2) * ILink(3);

      //SF-PH
      W += sites_.op("CkD", site) * ALink(3) * ILink(4);
      W += sites_.op("Ck*p", site) * ALink(3) * ILink(5);
    }

    //second Impurity site A_dn
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(2) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);

      //hybridization and bath energy terms:
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(1) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(2) * ILinkDn(1) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(4) * ILinkUp(2) * ILinkDn(1) * std::conj(tk_[impIndx][0]);

      //finish dens-dens interaction
      W += sites_.op("N", site) * ALink(2) * ILinkUp(3) * ILinkDn(1) * (U_); //with nA_up nA_dn

      //Nk for other Impurities
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(4);

      //SF and PH terms: no ps needed here
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(4) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(4) * ILinkDn(6);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(5) * ILinkDn(7);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(5) * ILinkDn(8);

      if (ImpHopp_) {
        W += sites_.op("F", site) * ALink(2) * ILinkUp(4) * ILinkDn(9);
        W += sites_.op("F", site) * ALink(2) * ILinkUp(5) * ILinkDn(10);
        W += sites_.op("CkD*p", site) * ALink(2) * ILinkUp(2) * ILinkDn(11);
        W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(2) * ILinkDn(12);
      }
    }

    //impurities B_up, C_up, D_up
    for (int impIndx = 3; impIndx < NArms_ - 1; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(2) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);

      W += sites_.op("Id", site) * ALink(2) * ILinkUp(5) * ILinkDn(6);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(6) * ILinkDn(7);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(7) * ILinkDn(8);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(8) * ILinkDn(9);

      //hybridization and bath energy terms:
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(1) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(4) * ILinkUp(2) * ILinkDn(1) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(5) * ILinkUp(2) * ILinkDn(1) * std::conj(tk_[impIndx][0]);

      //finish dens-dens interaction
      W += sites_.op("N", site) * ALink(2) * ILinkUp(3) * ILinkDn(1) * (Uprime_ - J_); //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(4) * ILinkDn(1) * (Uprime_);      //with n_mup n_ndn

      //Nk for other Impurities
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(5);

      //SF and PH terms:
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(2) * ILinkDn(10);
      W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(2) * ILinkDn(11);

      W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(5) * ILinkDn(12);
      W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(6) * ILinkDn(13);
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(7) * ILinkDn(14);
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(8) * ILinkDn(15);

      if (ImpHopp_) {
        W += sites_.op("F", site) * ALink(3) * ILinkUp(9) * ILinkDn(16);
        W += sites_.op("F", site) * ALink(3) * ILinkUp(10) * ILinkDn(17);
        W += sites_.op("F", site) * ALink(3) * ILinkUp(11) * ILinkDn(18);
        W += sites_.op("F", site) * ALink(3) * ILinkUp(12) * ILinkDn(19);

        W += sites_.op("CkD", site) * ALink(3) * ILinkUp(2) * ILinkDn(16);
        W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(2) * ILinkDn(17);

        W += sites_.op("Ck", site) * ALink(2) * ILinkUp(9) * ILinkDn(1) * ImpHoppt_;
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(10) * ILinkDn(1) * ImpHoppt_;
      }
    }

    //impurities B_dn, C_dn, D_dn
    for (int impIndx = 4; impIndx < NArms_; impIndx += 2) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(2) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);

      W += sites_.op("Id", site) * ALink(2) * ILinkUp(6) * ILinkDn(5);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(7) * ILinkDn(6);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(8) * ILinkDn(7);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(9) * ILinkDn(8);

      //hybridization and bath energy terms:
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(1) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(2) * ILinkDn(1) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(4) * ILinkUp(2) * ILinkDn(1) * std::conj(tk_[impIndx][0]);

      //finish dens-dens interaction
      W += sites_.op("N", site) * ALink(2) * ILinkUp(3) * ILinkDn(1) * (Uprime_);      //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(4) * ILinkDn(1) * (Uprime_ - J_); //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(5) * ILinkDn(1) * (U_);           //with n_mup n_ndn

      //finish Sf and PH terms:
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(12) * ILinkDn(1) * (J_);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(13) * ILinkDn(1) * (-J_);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(14) * ILinkDn(1) * (J_);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(15) * ILinkDn(1) * (-J_);

      //add Ns to corresponding entries
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(5) * ILinkDn(3);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(4);

      //add SF and PH terms to corresponding entries
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(10) * ILinkDn(5);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(10) * ILinkDn(6);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(11) * ILinkDn(7);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(11) * ILinkDn(8);

      if (ImpHopp_) {
        W += sites_.op("F", site) * ALink(2) * ILinkUp(16) * ILinkDn(9);
        W += sites_.op("F", site) * ALink(2) * ILinkUp(17) * ILinkDn(10);
        W += sites_.op("F", site) * ALink(2) * ILinkUp(18) * ILinkDn(11);
        W += sites_.op("F", site) * ALink(2) * ILinkUp(19) * ILinkDn(12);

        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(2) * ILinkDn(11);
        W += sites_.op("Ck*p", site) * ALink(2) * ILinkUp(2) * ILinkDn(12);

        W += sites_.op("Ck", site) * ALink(2) * ILinkUp(18) * ILinkDn(1) * ImpHoppt_;
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(19) * ILinkDn(1) * ImpHoppt_;
      }
    }

    //impurity E_up
    {
      int impIndx = NArms_ - 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites_.op("Id", site) * ALink(2) * ILinkUp(1) * ILinkDn(1);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(2) * ILinkDn(2);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);
      W += sites_.op("Id", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);

      //hybridization and bath energy terms:
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(1) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(4) * ILinkUp(2) * ILinkDn(1) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(5) * ILinkUp(2) * ILinkDn(1) * std::conj(tk_[impIndx][0]);

      //finish dens-dens interaction
      W += sites_.op("N", site) * ALink(2) * ILinkUp(3) * ILinkDn(1) * (Uprime_ - J_); //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(4) * ILinkDn(1) * (Uprime_);      //with n_mup n_ndn

      //Nk for other Impurities
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ILinkDn(5);

      //SF and PH terms:
      W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(5) * ILinkDn(6);
      W += sites_.op("Ck*p", site) * ALink(3) * ILinkUp(6) * ILinkDn(7);
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(7) * ILinkDn(8);
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(8) * ILinkDn(9);

      if (ImpHopp_) {
        W += sites_.op("F", site) * ALink(3) * ILinkUp(11) * ILinkDn(10);
        W += sites_.op("F", site) * ALink(3) * ILinkUp(12) * ILinkDn(11);

        W += sites_.op("Ck", site) * ALink(2) * ILinkUp(9) * ILinkDn(1) * ImpHoppt_;
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(10) * ILinkDn(1) * ImpHoppt_;
      }
    }

    //impurity E_dn
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      W = sites_.op("Id", site) * ALink(2) * ILinkUp(1);

      //hybridization and bath energy terms:
      W += sites_.op("Id", site) * ALink(1) * ILinkUp(2);
      W += sites_.op("N", site) * ALink(2) * ILinkUp(2) * ek_[impIndx][0];
      W += sites_.op("CkD", site) * ALink(3) * ILinkUp(2) * tk_[impIndx][0];
      W += sites_.op("Ck", site) * ALink(4) * ILinkUp(2) * std::conj(tk_[impIndx][0]);

      //finish dens-dens interaction
      W += sites_.op("N", site) * ALink(2) * ILinkUp(3) * (Uprime_);      //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(4) * (Uprime_ - J_); //with n_mup n_ndn
      W += sites_.op("N", site) * ALink(2) * ILinkUp(5) * (U_);           //with n_mup n_ndn

      //finish Sf and PH terms:
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(6) * (J_);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(7) * (-J_);
      W += sites_.op("Ck", site) * ALink(2) * ILinkUp(8) * (J_);
      W += sites_.op("CkD", site) * ALink(2) * ILinkUp(9) * (-J_);

      if (ImpHopp_) {
        W += sites_.op("Ck", site) * ALink(2) * ILinkUp(10) * ImpHoppt_;
        W += sites_.op("CkD", site) * ALink(2) * ILinkUp(11) * ImpHoppt_;
      }
    }
  }

} //end of namespace itensor
