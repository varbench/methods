#include <iostream>
#include <algorithm>
#include "itensor/mps/siteset.h"
#include "itensor/mps/mps.h"
#include "itensor/itensor.h"

#include "../typenames.hpp"
#include "../Bath.hpp"
#include "../ForkTPO.hpp"
#include "../../params.hpp"

using namespace itensor;

namespace forktps {

  class AIM_SpinOrbit {
    public:
    /** Creates the FTPO using SiteSet *sites*, with parameters specified in *ba*, *e0* and *hint*.
    * @param sites      itensor::SiteSet
    *                   Defines the indices as well as the operators on each site.
    * @param ba         bath
    *                   Bath object storing the bath parameters $\epsilon_k$ and $V_k$.
    * @param e0         hloc
    *                   Non-interacting Hamiltonian of the impurity.
    * @param hint       H_int
    *                   Interaction Hamiltonian.
    * @param args       itensor::Args
    *                   Argument list that can take the following entries
    * @param E0Shift    double (default 0.)
    *                   Shift of the Hamiltonian: H -> H + E0Shift*ID
    */
    AIM_SpinOrbit(const SiteSet &sites, bath b, hloc e0, H_int hint, const Args &args = Args::global());

    /// Creates and returns the FTPO
    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    /// Creates the bath tensors and returns the impurity bath links.
    std::vector<Index> MakeThreeOrbitalArmMPOs();
    //std::vector<Index> MakeTwoOrbitalArmMPOs();

    //void MakeTwoOrbitalMPO(const std::vector<Index> &ArmImpLinks);

    /// Creates the impurity tensors using the indices in ArmImpLinks as impurity bath links.
    void MakeThreeOrbitalMPO(const std::vector<Index> &ArmImpLinks);

    /// Creates the impurity-impurity links.
    std::vector<Index> GetImpLinks();

    //////////////////
    //
    // Data Members

    /// The itensor SiteSet providing the local operators and site-indices
    const SiteSet &sites;

    /// Interaction parameters
    H_int hint;

    /// Constant energy shift: H -> H - E0 * ID
    double E0;

    /// Name of the block containing orbitals Aup, Bdn and Cdn.
    std::string blockName1;

    /// Name of the block containing orbitals Adn, Bup and Cup
    std::string blockName2;

    /// Bath, providing bath parameters.
    bath b;
    /// Non-interacting impurity Hamiltonian
    hloc e0;

    /// The Hamiltonian in FTPO form.
    ForkTPO H;

    //
    //////////////////

    void init_();
  };

} // namespace forktps
