#include "ExpectationValues.hpp"

using namespace itensor;

///to write it once and for all: IQINDICES of operators:

///c_up^D: has a change in bond indices by (-1,-1)
///c_up  : has a change in bond indices by ( 1, 1)

///c_dn^D: has a change in bond indices by ( 1,-1)
///c_dn  : has a change in bond indices by (-1, 1)

///with hopping terms in MPOs we mostly use the following convention
///regarding the Fermi Operators p:
///We do not use "p" on the first site (first with respect to the fermionic order)
///and therefore also do not include the minus sign. ie.:
///c1^dag c3 + c3^dag c1 = c1^dag c3 - c1 c3^dag
///since the second term annihilates on site 1 it must be occupied. this means that
///moving c3^dag past the first site gives always a minus sign which cancels the minus sign above

namespace forktps {
  // --------------------------------------------------------
  // --------------------------------------------------------
  // N^2
  // --------------------------------------------------------
  // --------------------------------------------------------
  std::vector<Index> FillArms_N2(ForkTPO &H, const SiteSet &sites) {
    std::vector<Index> ArmImpLinks(0);
    ArmImpLinks.emplace_back(Index());

    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    //Create Bath Tensors
    for (auto arm : range1(H.NArms())) {
      auto NBath = H.NBath(arm);
      std::vector<Index> ArmLinks(NBath + 1);

      //create links
      for (auto k : range1(NBath)) {
        auto indxName = Names::TAGSB;
        if (k == NBath) indxName = Names::TAGSIB;

        ArmLinks.at(k) = Index(qn0, 3, Out, indxName);
      }

      //Fill MPOs
      {
        int k      = 1;
        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(k);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);

        W += sites.op("Nk", site) * setElt(left(1)); // here actually n^2 but n^2 = n
        W += sites.op("Id", site) * setElt(left(2));
        W += sites.op("Nk", site) * setElt(left(3));
      }

      for (int k = 2; k <= NBath; k++) {

        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(k - 1));
        Index left  = ArmLinks.at(k);

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);

        W += sites.op("Id", site) * setElt(left(1), right(1));
        W += sites.op("Id", site) * setElt(left(2), right(2));
        W += sites.op("Id", site) * setElt(left(3), right(3));

        W += sites.op("Nk", site) * setElt(left(1), right(2));     // here actually n^2 but n^2 = n
        W += sites.op("Nk", site) * setElt(left(1), right(3)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
        W += sites.op("Nk", site) * setElt(left(3), right(2));
      }
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;
  }

  void FillImps_N2(ForkTPO &H, const SiteSet &sites, std::vector<Index> ArmImpLinks) {
    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    auto NArms = H.NArms();
    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms + 1);

    for (auto i : range1(NArms)) ImpLinks.at(i) = Index(qn0, 3, Out, Names::TAGSI);

    // first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ILink(1), ALink(1));
      W += sites.op("Id", site) * setElt(ILink(2), ALink(2));
      W += sites.op("Id", site) * setElt(ILink(3), ALink(3));

      W += sites.op("Nk", site) * setElt(ILink(1), ALink(2));     // here actually n^2 but n^2 = n
      W += sites.op("Nk", site) * setElt(ILink(1), ALink(3)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ILink(3), ALink(2));
    }

    // all other impurity sites except last
    for (int impIndx = 2; impIndx < NArms; ++impIndx) {
      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      int site   = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      ///Ids
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(3));

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(3), ILinkUp(3), ILinkDn(1)) * 2;
      W += sites.op("Id", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(3));

      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(1));     // here actually n^2 but n^2 = n
      W += sites.op("Nk", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(1)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(3));
    }

    // last impurity site
    {
      int impIndx = NArms;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = dag(ImpLinks[impIndx - 1]);

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ALink(2), ILink(1));
      W += sites.op("Id", site) * setElt(ALink(1), ILink(2));
      W += sites.op("Id", site) * setElt(ALink(3), ILink(3)) * 2;

      W += sites.op("Nk", site) * setElt(ALink(2), ILink(2));     // here actually n^2 but n^2 = n
      W += sites.op("Nk", site) * setElt(ALink(3), ILink(2)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILink(3)) * 2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
    }
  }

  ForkTPO NTot2(const SiteSet &sites, std::vector<int> Nbs) {
    ForkTPO H(sites, Nbs);
    auto links = FillArms_N2(H, sites);
    FillImps_N2(H, sites, links);
    return H;
  }

  // --------------------------------------------------------
  // --------------------------------------------------------
  // N^2 one arm
  // --------------------------------------------------------
  // --------------------------------------------------------

  /*
  std::vector<Index> FillArms_N2_Arm(ForkTPO &H, const SiteSet &sites, int arm) {
    std::vector<Index> ArmImpLinks(0);
    ArmImpLinks.emplace_back(Index());

    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    //Create Bath Tensors
    for (auto ch : range1(H.NArms())) {
      auto NBath = H.NBath(ch);
      std::vector<Index> ArmLinks(NBath + 1);

      //create links
      for (auto k : range1(NBath)) {
        auto indxName = Names::TAGSB;
        if (k == NBath) indxName = Names::TAGSIB;
        if(ch == arm)
          ArmLinks.at(k) = Index(qn0, 3, Out, indxName);
        else
          ArmLinks.at(k) = Index(qn0, 1, Out, indxName);
      }

      //Fill MPOs
      {
        int k      = 1;
        int site   = H.ArmToSite(ch, k);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(k);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);

        W = sites.op("Id", site) * setElt(left(1));
        if(ch == arm){
          W  = sites.op("Nk", site) * setElt(left(1)); // here actually n^2 but n^2 = n
          W += sites.op("Id", site) * setElt(left(2));
          W += sites.op("Nk", site) * setElt(left(3));
        }

      }

      for (int k = 2; k <= NBath; k++) {

        int site   = H.ArmToSite(ch, k);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(k - 1));
        Index left  = ArmLinks.at(k);

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);
        W += sites.op("Id", site) * setElt(left(1), right(1));

        if(ch == arm){
          W += sites.op("Id", site) * setElt(left(2), right(2));
          W += sites.op("Id", site) * setElt(left(3), right(3));

          W += sites.op("Nk", site) * setElt(left(1), right(2)); // here actually n^2 but n^2 = n
          W += sites.op("Nk", site) * setElt(left(1), right(3))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
          W += sites.op("Nk", site) * setElt(left(3), right(2));
        }
      }
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;
  }

  void FillImps_N2_Arm(ForkTPO &H, const SiteSet &sites, std::vector<Index> ArmImpLinks, int arm) {
    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    auto NArms = H.NArms();
    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms + 1);

    for (auto i : range1(NArms)) {
      ImpLinks.at(i) = Index(qn0, 1, Out, Names::TAGSI);
    }

    // first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ILink(1), ALink(1));
      if(impIndx == arm){
        W += sites.op("Id", site) * setElt(ILink(2), ALink(2));
        W += sites.op("Id", site) * setElt(ILink(3), ALink(3));

        W += sites.op("Nk", site) * setElt(ILink(1), ALink(2)); // here actually n^2 but n^2 = n
        W += sites.op("Nk", site) * setElt(ILink(1), ALink(3))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
        W += sites.op("Nk", site) * setElt(ILink(3), ALink(2));
      }
    }

    // all other impurity sites except last
    for (int impIndx = 2; impIndx < NArms; ++impIndx) {
      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];
 
      int site   = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      ///Ids
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(3));

      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(3), ILinkUp(3), ILinkDn(1))*2;
      W += sites.op("Id", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(3));

      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(1));   // here actually n^2 but n^2 = n
      W += sites.op("Nk", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(1))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(3));
    }

    // last impurity site
    {
      int impIndx = NArms;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = dag(ImpLinks[impIndx - 1]);

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ALink(2), ILink(1));
      W += sites.op("Id", site) * setElt(ALink(1), ILink(2));
      W += sites.op("Id", site) * setElt(ALink(3), ILink(3))*2;

      W += sites.op("Nk", site) * setElt(ALink(2), ILink(2));   // here actually n^2 but n^2 = n
      W += sites.op("Nk", site) * setElt(ALink(3), ILink(2))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
      W += sites.op("Nk", site) * setElt(ALink(2), ILink(3))*2; // factor of 2 to account for ni nj + nj ni = 2 ni nj
    }
  }
  

  ForkTPO NTot2_Arm(const SiteSet &sites, int NArms, int arm){
    ForkTPO H(sites, NArms);
    auto links = FillArms_N2_Arm(H, sites, arm);
    FillImps_N2_Arm(H, sites, links, arm);
    return H;
  }
  */

  std::vector<Index> FillArms_N(ForkTPO &H, const SiteSet &sites) {
    std::vector<Index> ArmImpLinks(0);
    ArmImpLinks.emplace_back(Index());

    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    //Create Bath Tensors
    for (auto arm : range1(H.NArms())) {
      auto NBath = H.NBath(arm);
      std::vector<Index> ArmLinks(NBath + 1);

      //create links
      for (auto k : range1(NBath)) {
        auto indxName = Names::TAGSB;
        if (k == NBath) indxName = Names::TAGSIB;

        ArmLinks.at(k) = Index(qn0, 2, Out, indxName);
      }

      //Fill MPOs
      {
        int k      = 1;
        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(k);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);

        ///bath is zero indexed, k is one indexed
        W += sites.op("Nk", site) * setElt(left(1));
        W += sites.op("Id", site) * setElt(left(2));
      }

      for (int k = 2; k <= NBath; k++) {

        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(k - 1));
        Index left  = ArmLinks.at(k);

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);

        W += sites.op("Id", site) * setElt(right(1), left(1));
        W += sites.op("Id", site) * setElt(right(2), left(2));
        W += sites.op("Nk", site) * setElt(right(2), left(1));
      }
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;
  }

  void FillImps_N(ForkTPO &H, const SiteSet &sites, std::vector<Index> ArmImpLinks) {
    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    auto NArms = H.NArms();
    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms + 1);

    for (auto i : range1(NArms)) ImpLinks.at(i) = Index(qn0, 3, Out, Names::TAGSI);

    // first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ALink(1), ILink(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILink(2));
      W += sites.op("Nk", site) * setElt(ALink(2), ILink(1));
    }

    // first Impurity site A_up
    for (int impIndx = 2; impIndx < NArms; ++impIndx) {
      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      int site   = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      ///Ids
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(2), ILinkDn(1));

      W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(1));
    }
    {
      int impIndx = NArms;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = dag(ImpLinks[impIndx - 1]);

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ALink(2), ILink(1));
      W += sites.op("Id", site) * setElt(ALink(1), ILink(2));

      W += sites.op("Nk", site) * setElt(ALink(2), ILink(2));
    }
  }

  ForkTPO NTot(const SiteSet &sites, std::vector<int> Nbs) {
    ForkTPO H(sites, Nbs);
    auto links = FillArms_N(H, sites);
    FillImps_N(H, sites, links);
    return H;
  }

  // --------------------------------------------------------
  // --------------------------------------------------------
  // N one arm
  // --------------------------------------------------------
  // --------------------------------------------------------

  std::vector<Index> FillArms_N_Arm(ForkTPO &H, const SiteSet &sites, int arm) {
    std::vector<Index> ArmImpLinks(0);
    ArmImpLinks.emplace_back(Index());

    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    //Create Bath Tensors
    for (auto ch : range1(H.NArms())) {
      auto NBath = H.NBath(ch);
      std::vector<Index> ArmLinks(NBath + 1);

      //create links
      for (auto k : range1(NBath)) {
        auto indxName = Names::TAGSB;
        if (k == NBath) indxName = Names::TAGSIB;

        ArmLinks.at(k) = Index(qn0, 1, Out, indxName);
        if (ch == arm) ArmLinks.at(k) = Index(qn0, 2, Out, indxName);
      }

      //Fill MPOs
      {
        int k      = 1;
        int site   = H.ArmToSite(ch, k);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(k);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);

        ///bath is zero indexed, k is one indexed
        if (ch == arm) {
          W += sites.op("Nk", site) * setElt(left(1));
          W += sites.op("Id", site) * setElt(left(2));
        } else
          W += sites.op("Id", site) * setElt(left(1));
      }

      for (int k = 2; k <= NBath; k++) {

        int site   = H.ArmToSite(ch, k);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(k - 1));
        Index left  = ArmLinks.at(k);

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);

        W += sites.op("Id", site) * setElt(right(1), left(1));
        if (ch == arm) {
          W += sites.op("Id", site) * setElt(right(2), left(2));
          W += sites.op("Nk", site) * setElt(right(2), left(1));
        }
      }
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;
  }

  void FillImps_N_Arm(ForkTPO &H, const SiteSet &sites, std::vector<Index> ArmImpLinks, int arm) {
    QN qn0 = -div(sites.op("Id", H.ImpSite(1)));

    auto NArms = H.NArms();
    std::vector<Index> ImpLinks;
    ImpLinks.resize(NArms + 1);

    for (auto i : range1(NArms)) ImpLinks.at(i) = Index(qn0, 1, Out, Names::TAGSI);

    // first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W += sites.op("Id", site) * setElt(ALink(1), ILink(1));
      if (impIndx == arm) W += sites.op("Nk", site) * setElt(ALink(2), ILink(1));
    }

    // first Impurity site A_up
    for (int impIndx = 2; impIndx < NArms; ++impIndx) {
      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      int site   = H.ImpSite(impIndx);
      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      ///Ids
      if (impIndx == arm) {
        W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
        W += sites.op("Nk", site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      } else
        W += sites.op("Id", site) * setElt(ALink(1), ILinkUp(1), ILinkDn(1));
    }
    {
      int impIndx = NArms;
      int site    = H.ImpSite(impIndx);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = dag(ImpLinks[impIndx - 1]);

      ITensor &W = H.Anc(site);
      W          = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      if (impIndx == arm) {
        W += sites.op("Id", site) * setElt(ALink(1), ILink(1));
        W += sites.op("Nk", site) * setElt(ALink(2), ILink(1));
      } else
        W += sites.op("Id", site) * setElt(ALink(1), ILink(1));
    }
  }

  ForkTPO NTot_Arm(const SiteSet &sites, std::vector<int> Nbs, int arm) {
    ForkTPO H(sites, Nbs);
    auto links = FillArms_N_Arm(H, sites, arm);
    FillImps_N_Arm(H, sites, links, arm);
    return H;
  }

  std::pair<double, double> MeasureArmN(int arm, ForkTPS &psi) {
    auto sites = psi.sites();
    Args args;

    ForkTPO N_op = forktps::NTot_Arm(sites, psi.NBathVec(), arm);
    auto res     = exactApplyMPO(psi, N_op, args);

    auto n  = std::real(overlap(psi, res));
    auto n2 = std::real(overlap(res, res));

    return std::make_pair(n, n2);
  }

  // --------------------------------------------------------
  // --------------------------------------------------------

  std::pair<double, double> MeasureTotN(ForkTPS &psi) {
    auto sites = psi.sites();
    Args args;

    ForkTPO N_op = forktps::NTot(sites, psi.NBathVec());
    auto res     = exactApplyMPO(psi, N_op, args);

    auto n  = std::real(overlap(psi, res));
    auto n2 = std::real(overlap(res, res));

    return std::make_pair(n, n2);
  }

  std::vector<std::pair<double, double>> MeasureAllArmN(ForkTPS &psi) {
    std::vector<std::pair<double, double>> res(0);

    for (auto arm : range1(psi.NArms())) res.push_back(MeasureArmN(arm, psi));

    return res;
  }

} // namespace forktps
