
#include "../typenames.hpp"
#include "../typenames.hpp"
#include "../ForkTPO.hpp"
#include "../../params.hpp"

#include "itensor/mps/siteset.h"

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1)
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

//with hopping terms in MPOs we mostly use the following convention
//regarding the Fermi Operators p:
//We do not use "p" on the first site (first with respect to the fermionic order)
//and therefore also do not include the minus sign. ie.:
//c1^dag c3 + c3^dag c1 = c1^dag c3 - c1 c3^dag
//since the second term annihilates on site 1 it must be occupied. this means that
//moving c3^dag past the first site gives always a minus sign which cancels the minus sign above

namespace forktps {

  class AIM_SelfEnergyMPO {

    public:
    AIM_SelfEnergyMPO(const SiteSet &sites, double U, double Uprime, double J, int siteN, int NArms, const Args &args);
    AIM_SelfEnergyMPO(const SiteSet &sites, double U, double Uprime, double J, int siteN, ivec NBath, const Args &args);
    AIM_SelfEnergyMPO(const SiteSet &sites, H_int hint, int siteN, int NArms, const Args &args);

    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    void ArmMPOs(std::vector<Index> &ArmImpLinks);

    void MakeImpMPO_SpinUp_Orb1Only(const std::vector<Index> &ArmImpLinks);   //orbital n = 1
    void MakeImpMPO_SpinDown_Orb1Only(const std::vector<Index> &ArmImpLinks); //orbital n = 1
    void MakeImpMPO_SpinUp(const std::vector<Index> &ArmImpLinks);            //orbital n > 1
    void MakeImpMPO_SpinDown(const std::vector<Index> &ArmImpLinks);          //orbital n > 1

    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;
    double U_;
    double Uprime_;
    double J_;
    double JSFPH_;

    int siteN_;
    int orb_;
    Spin spin_;

    std::vector<double> localMuShift_;
    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

} // namespace forktps
