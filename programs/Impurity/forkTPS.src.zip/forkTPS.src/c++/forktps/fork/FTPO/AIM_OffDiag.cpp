#include "AIM_OffDiag.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/params.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>



using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1) ( ie form for example (0,0) to (-1,-1) )
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

namespace forktps {

  // clang-format off

  AIM_OffDiag::AIM_OffDiag(const SiteSet &sites, bath b, hloc e0, double U, double Uprime, double J, const Args &args)
     : sites_(sites),
       NArms_(b.NArms()),
       U_(U),
       Uprime_(Uprime),
       J_(J),
       initted_(false),
       blockNameUp("up"),
       blockNameDn("dn"),
       b(std::move(b)),
       e0(std::move(e0)) {

    if(this->b.isSpinOrbit())
      Error("AIM_OffDiag: Cant use spin orbit bath with this FTPO!");
    

    if (this->b.NArms() % 2 != 0) {
      Error("AIM_OffDiag: NArms must be even!");
    }

    blockNameUp = this->b.blockNameUp();
    blockNameDn = this->b.blockNameDn();

    H = ForkTPO(sites_, this->b.NBathVec());

    JSFPH_ = J_;
    if (args.getBool("DDonly", false)) JSFPH_ = 0;
    E0_ = args.getReal("E0Shift",0);
  }

  AIM_OffDiag::AIM_OffDiag(const SiteSet &sites, bath b, hloc e0, H_int hint, const Args& args)
     : sites_(sites),
       NArms_(b.NArms()),
       U_(hint.U),
       Uprime_(hint.Up),
       J_(hint.J),
       initted_(false),
       blockNameUp("up"),
       blockNameDn("dn"),
       b(std::move(b)),
       e0(std::move(e0)) {

    blockNameUp = this->b.blockNameUp();
    blockNameDn = this->b.blockNameDn();

    H = ForkTPO(sites_, this->b.NBathVec());

    JSFPH_ = J_;
    if ( hint.dd_only ) JSFPH_ = 0;
    E0_ = args.getReal("E0Shift",0);
  }

  void AIM_OffDiag::init_() {
    if (initted_) return;

    std::vector<Index> ArmImpLinks(0);
    std::vector<Index> ImpImpLinks(0);

    MakeArmMPOs(ArmImpLinks);
    if (NArms_ == 2) {
      MakeOneOrbitalMPO(ArmImpLinks);
    } else if (NArms_ == 4) {
      MakeTwoOrbitalMPO(ArmImpLinks);
    } else if (NArms_ == 6) {
      MakeThreeOrbitalMPO(ArmImpLinks);
    } else {
      std::cout<<NArms_<<"\n";
      Error("AIM_ForkTPO_NonDiagBath: Cannot create AIM_ForkTPO_NonDiagBath with this number of orbitals");
    }

    initted_ = true;
  }

  // clang-format off

  void AIM_OffDiag::MakeArmMPOs(std::vector<Index>& ArmImpLinks){

    // Vk_ is such that std::conj(Vk_) is used for the hopping where the creation operator acts in the bath i.e.: std::conj(Vk_) * c_k^\dag c_I
    ArmImpLinks.resize(0); ArmImpLinks.emplace_back(Index());



    for(int arm = 1; arm <= NArms_; arm++) {
      const int NBath =H.NBath(arm);
      int blockI=0, blockSize=0;
      std::vector<Index> ArmLinks(NBath+1);
      std::string blockName;
      //std::cout << "-------------------------------------------"<<std::endl;
      //std::cout << "-------------------------------------------"<<std::endl;
      //std::cout<<arm<<"\n";

      QN qnC    = - div( sites_.op( "Ck",  H.ImpSite(arm) ) );
      QN qnCDag = - div( sites_.op( "CkD", H.ImpSite(arm) ) );
      QN qn0    = - div( sites_.op( "Id",  H.ImpSite(arm) ) );


      if(arm%2 == 1){
        blockName = blockNameUp;
        blockI = (arm-1)/2;
      }
      else {
        blockName = blockNameDn;
        blockI = (arm)/2-1;
      }

      blockSize = b.blockSize(blockName);

      //create links
      for(int l=1;l<=NBath;l++){
        auto indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;
        

        if( arm == 1 || arm == 2 ){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,   
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
          
        }
        else if ( arm == 3 || arm == 4 ){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );

        }
        else{
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
        }
      }


      // n == 1
      {
        int k =1;
        int site = H.ArmToSite(arm,1);
        triqs_indx I{blockName, blockI};

        Index left=ArmLinks.at(1);
        ITensor& W =H.Anc(site);
        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left);

        W += sites_.op("N"  ,site)*setElt( left(1) )* b.eps(I, k-1);
        W += sites_.op("Id" ,site)*setElt( left(2) );
        W += sites_.op("p"  ,site)*setElt( left(3) );

        //diagonal
        Complex amp = b.V(I, I, k-1 );
        W += sites_.op("Ck" ,site)*setElt( left(4) )*           amp  ;  //V is the hopping onto impurity ie C in bath
        W += sites_.op("CkD",site)*setElt( left(5) )* (-std::conj( amp ));  //Vdag is the hopping onto bath ie CD in bath
        //std::cout<<"Arm "<< arm <<" k "<< k<<std::endl <<"    Diag term:  "<< amp<<std::endl;
        //off-diagonal
        int offset = 0;

        for(auto bJ = blockI+1; bJ < blockSize; bJ++){
          triqs_indx J{blockName, bJ};

          amp = b.V(I, J, k-1 );
          // In the fermionic order, the bath site comes before the impurity!
          // the hopping is defined as 
          // V cI^D cB + V* cB^D cI =  - V cB cI^d + V* cB cI^D. 
          // so here the V-term has a minus sign not the V*-term
          W += sites_.op("Ck*p" ,site)*setElt( left( 5+offset+1 ) )*          (-amp);   //V is the hopping onto impurity ie C in bath
          W += sites_.op("CkD*p",site)*setElt( left( 5+offset+2 ) )*(std::conj(+amp));  //Vdag is the hopping onto bath ie CD in bath
          offset += 2;
        }

      }
      
      for(int k=2; k<=NBath; k++){

        int site = H.ArmToSite(arm,k);
        triqs_indx I{blockName, blockI};

        Index right =dag(ArmLinks.at(k-1));
        Index left  =    ArmLinks.at(k)   ;

        ITensor& W =H.Anc(site);
        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        W += sites_.op("Id",site)*setElt( left(2), right(2) ); //ids

        W += sites_.op("Id",site)*setElt( left(1), right(1) );
        W += sites_.op("p" ,site)*setElt( left(3), right(3) ); 
        W += sites_.op("p" ,site)*setElt( left(4), right(4) ); 
        W += sites_.op("p" ,site)*setElt( left(5), right(5) ); //ps
        W += sites_.op("N" ,site)*setElt( left(1), right(2) )* b.eps(I, k-1); //on-site energy

        //diagonal
        Complex amp = b.V(I, I, k-1);
        W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           amp  ;  //V is the hopping onto impurity ie C in bath
        W += sites_.op("CkD",site)*setElt( left(5), right(2) )*(-std::conj( amp ));  //Vdag is the hopping onto bath ie CD in bath
        //std::cout<<"Arm "<< arm <<" k "<< k<<std::endl <<"    Diag term:  "<< amp<<std::endl;

        //off-diagonal
        int offset = 0;
        for(auto bJ = blockI+1; bJ < blockSize; bJ++){
          triqs_indx J{blockName, bJ};
          // IDs here!
          W += sites_.op("Id",site)*setElt( left(5+offset+1), right(5+offset+1) );
          W += sites_.op("Id",site)*setElt( left(5+offset+2), right(5+offset+2) );

          amp = b.V(I, J, k-1);
          // In the fermionic order, the bath site comes before the impurity!
          // the hopping is defined as 
          // V cI^D cB + V* cB^D cI =  - V cB cI^d + V* cB cI^D. 
          // so here the V-term has a minus sign not the V*-term
          W += sites_.op("Ck*p" ,site)*setElt( left( 5+offset+1 ), right(3) )*         (-amp);    //V is the hopping onto impurity ie C in bath
          W += sites_.op("CkD*p",site)*setElt( left( 5+offset+2 ), right(3) )*std::conj(+amp);  //Vdag is the hopping onto bath ie CD in bath
          offset += 2;
        }

      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

  }



  void AIM_OffDiag::MakeThreeOrbitalMPO( const std::vector<Index>& ArmImpLinks ){
    
    auto ImpLinks = GetImpLinks();
    

    //first Impurity site
    {
      int impIndx=1;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx-1)/2;
      auto blockName = blockNameUp;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILink = ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      W  = sites_.op("Id",site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(2) );

      // imp-imp hoppings
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(4) ) * (-e0({blockName, 1}, I              )); // From B to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(5) ) * (+e0(I,              {blockName, 1} )); // From A to B
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(6) ) * (-e0({blockName, 2}, I              )); // From C to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(7) ) * (+e0(I,              {blockName, 2} )); // From A to C
      // off-diag hybridizations (no p)
      W += sites_.op("Id",site) * setElt( ALink(6), ILink(4) );
      W += sites_.op("Id",site) * setElt( ALink(7), ILink(5) );
      W += sites_.op("Id",site) * setElt( ALink(8), ILink(6) );
      W += sites_.op("Id",site) * setElt( ALink(9), ILink(7) );


      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("N",site)  * setElt( ALink(2), ILink(1) )* onSiteE;
      W += sites_.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites_.op("Ck*p",site) * setElt( ALink(5), ILink(1) );

      W += sites_.op("N",site) * setElt( ALink(2), ILink(3) );

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILink(8) );
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILink(9) );
      }
    }

    //second Impurity site
    {
      int impIndx=2;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx)/2-1;
      auto blockName = blockNameDn;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and Ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );

      // imp-imp hoppings
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(9) ) * (-e0({blockName, 1}, I              )); // From B to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(10)) * (+e0(I,              {blockName, 1} )); // From A to B
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(11)) * (-e0({blockName, 2}, I              )); // From C to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(12)) * (+e0(I,              {blockName, 2} )); // From A to C

      // off-diag hybridizations for spin-up
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(4), ILinkDn(5) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(5), ILinkDn(6) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(6), ILinkDn(7) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(7), ILinkDn(8) );
      // off-diag hybridizations for spin-down
      W += sites_.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(9)  );
      W += sites_.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(10) );
      W += sites_.op("Id",site) * setElt( ALink(8), ILinkUp(2), ILinkDn(11) );
      W += sites_.op("Id",site) * setElt( ALink(9), ILinkUp(2), ILinkDn(12) );


      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      //finish density density interactions: nA_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(U_); 	//with nA_up

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(8), ILinkDn(13) ); //cD*c SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(8), ILinkDn(14) ); //cD*cD SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(9), ILinkDn(15) ); //c*cD SFPH
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(9), ILinkDn(16) ); //c*c SFPH
      }
    }

    //third Impurity site B-up
    {
      int impIndx=3;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx-1)/2;
      auto blockName = blockNameUp;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density term Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density term Adn


      // imp-imp hoppings
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(6) ) * (-e0({blockName, 2}, I              )); // From C to B
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(7) ) * (+e0(I,              {blockName, 2} )); // From B to C

      //add off diag terms from local bath
      W += sites_.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(6) );
      W += sites_.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(7) );
      // off-diag hybridizations for spin-up
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(7), ILinkDn(6) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(8), ILinkDn(7) );

      // off-diag hybridizations for spin-down
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(9),  ILinkDn(8) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(9) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10));
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11));


      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );

      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      //finish density density interactions: nB_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(Uprime_-J_);	//with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(Uprime_);	//with nA_Dn

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(1) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(6), ILinkDn(1) );

      //SF-PH 
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(12) ); //Ids for cD*c 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(13) ); //Ids for cD*cD 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(14) ); //Ids for c*cD 
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(16), ILinkDn(15) ); //Ids for c*c 

        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(2), ILinkDn(16) ); //add new terms
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(2), ILinkDn(17) ); //add new terms

        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(13), ILinkDn(18) ); //cD*c*c
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(14), ILinkDn(19) ); //cD*cD*c 
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(15), ILinkDn(20) ); //c*cD*cD
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(16), ILinkDn(21) ); //c*c*cD
      }
    }

    //fourth Impurity site B-dn
    {
      int impIndx=4;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx)/2-1;
      auto blockName = blockNameDn;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids 
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) ); //Hfin
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //big ID
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density operator Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density operator Adn
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(3) ); //density operator Bup

      //add density operator of this site
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );


  
      // imp-imp hoppings
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(7) ) * (-e0({blockName, 2}, I              )); // From C to B
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(8) ) * (+e0(I,              {blockName, 2} )); // From B to C
      // add off-diag terms from local bath
      W += sites_.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(7) );
      W += sites_.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(8) );

      //move off-diag hoppings past
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(6),  ILinkDn(5) ); // spin up from C
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(7),  ILinkDn(6) ); // spin up to C
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(7) ); // spin dn from C
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(11), ILinkDn(8) ); // spin dn to C



      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );


      //finish density density interactions: N = nB_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(Uprime_);     //with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(Uprime_-J_);	//with nA_Dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(5), ILinkDn(1) )*(U_);	        //with nB_up

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(8), ILinkDn(1) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(9), ILinkDn(1) );

      //SF PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(18), ILinkDn(1) )*( JSFPH_); //finish
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(19), ILinkDn(1) )*(-JSFPH_); //finish
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(20), ILinkDn(1) )*( JSFPH_); //finish
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(21), ILinkDn(1) )*(-JSFPH_); //finish

        W += sites_.op("Ck", site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(9) ); //cD*c
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(10) ); //cD*cD
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(11) ); //c*cD
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(12) ); //c*c

        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(12), ILinkDn(9) ); //cD*c
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(10) ); //cD*cD
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(11) ); //c*cD
        W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(12) ); //c*c
      }


    }

    //fifth Impurity site C-up
    {
      int impIndx=5;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx-1)/2;
      auto blockName = blockNameUp;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );  //Hfin
      
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); //big ID
       
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density operator Aup + Bup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density operator Adn + Bdn

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );



      //move off diagonal hopping terms past this site
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(7), ILinkDn(6) ); // spin down hopping from C
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(8), ILinkDn(7) ); // spin down hopping to C



      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      //finish density density interactions: nB_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(Uprime_-J_);	//with A_up + B_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(Uprime_);	    //with A_dn + B_dn

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(1) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(6), ILinkDn(1) );

      //SF and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(9),  ILinkDn(8)  );
        W += sites_.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(10), ILinkDn(9)  );
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10) ); 
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11) );
      }
      
    }

    //last impurity
    {
      int impIndx=NArms_;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx)/2-1;
      auto blockName = blockNameDn;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );


      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1) );   //combine Hfin from top with Id from bath
      W += sites_.op("Id",site) * setElt( ALink(1), ILinkUp(2) );  //combine Id from top with Hfin from bath
      

      //finish diagonal hybridization and bath energy terms from local bath:
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2) );

      // add E0 term here
      W += sites_.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish density interactions
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(3) )*( Uprime_    );	  //with A_up + B_up
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(4) )*( Uprime_-J_ );   //with A_dn + B_dn
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(5) )*( U_         );		//with C_up 

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(6) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7) );

      //finish Sf and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(8) ) *( JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(9) ) *(-JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(10) )*( JSFPH_);
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(11) )*(-JSFPH_);
      }
      
    }

  }


  void AIM_OffDiag::MakeTwoOrbitalMPO( const std::vector<Index>& ArmImpLinks ){

    auto ImpLinks = GetImpLinks();


    //first Impurity site
    {
      int impIndx=1;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx-1)/2;
      auto blockName = blockNameUp;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILink = ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      W  = sites_.op("Id",site) * setElt( ALink(1), ILink(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILink(2) );


      // imp-imp hoppings
      triqs_indx J{blockName, 1};
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILink(4) )* (-e0(J, I)); // From B to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILink(5) )* (+e0(I, J)); // From A to B
      // off-diag hybridizations (no p)
      W += sites_.op("Id",site) * setElt( ALink(6), ILink(4) ); 
      W += sites_.op("Id",site) * setElt( ALink(7), ILink(5) ); 


      // finish on-site energy and bath hybridization with diagonal bath
      W += sites_.op("N",site)  * setElt( ALink(2), ILink(1) )* onSiteE;
      W += sites_.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites_.op("Ck*p",site) * setElt( ALink(5), ILink(1) );

      W += sites_.op("N",site) * setElt( ALink(2), ILink(3) );

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILink(6) );
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILink(7) );
      }
    }

    //second Impurity site
    {
      int impIndx=2;
      int site = H.ImpSite(impIndx);

      auto blockName = blockNameDn;
      int blockI = (impIndx)/2-1;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and Ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );


      // imp-imp hoppings
      triqs_indx J{blockName, 1};
      W += sites_.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(7) )* (-e0(J, I)); // From B to A
      W += sites_.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(8) )* (+e0(I, J)); // From A to B
      // off-diag hybridizations for up
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(4), ILinkDn(5) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(5), ILinkDn(6) );
      // off-diag hybridizations for dn
      W += sites_.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(7) );
      W += sites_.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(8) );


      //hybridization and bath energy terms into the bath attached to impurity:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      //finish density density interactions: nA_dn
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(U_); 	//with nA_up

      //SF-PH
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(6), ILinkDn(9) ); //cD*c SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(6), ILinkDn(10) ); //cD*cD SFPH
        W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(7), ILinkDn(11) ); //c*cD SFPH
        W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7), ILinkDn(12) ); //c*c SFPH
      }
    }

    //third Impurity site B-up
    {
      int impIndx=3;

      int blockI = (impIndx-1)/2;
      auto blockName = blockNameUp;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      int site = H.ImpSite(impIndx);
      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      //Ids and ps
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); //density term Aup
      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); //density term Adn

      //move off-diag hoppings past this impurity
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(7), ILinkDn(6) );
      W += sites_.op("p",site) * setElt( ALink(3), ILinkUp(8), ILinkDn(7) );

      //Nk for other Impurities
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );

      //hybridization and bath energy terms:
      W += sites_.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      //finish density density interactions: nB_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(Uprime_-J_);	//with nA_up
      W += sites_.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(Uprime_);	//with nA_Dn

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(1) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(6), ILinkDn(1) );

      //SF-PH 
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(9),  ILinkDn(8) ); //cD*c*c
        W += sites_.op("Ck*p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(9) ); //cD*cD*c 
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10) ); //c*cD*cD
        W += sites_.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11) ); //c*c*cD
      }
    }

    //last impurity
    {
      int impIndx=NArms_;
      int site = H.ImpSite(impIndx);

      int blockI = (impIndx)/2-1;
      auto blockName = blockNameDn;
      triqs_indx I{blockName, blockI};

      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );

      W=ITensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );


      W += sites_.op("Id",site) * setElt( ALink(2), ILinkUp(1) );   //combine Hfin from top with Id from bath
      W += sites_.op("Id",site) * setElt( ALink(1), ILinkUp(2) );  //combine Id from top with Hfin from bath
      

      //bath hybridization with attached bath and local on-site energies
      W += sites_.op("N",site)   * setElt( ALink(2), ILinkUp(2) )* onSiteE;
      W += sites_.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2) );
      W += sites_.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2) );

      // add E0 term here
      W += sites_.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish density interactions
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(3) )*( Uprime_    );	  //with nA_up
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(4) )*( Uprime_-J_ );   	//with nA_dn
      W += sites_.op("N",site) * setElt( ALink(2), ILinkUp(5) )*( U_         );		//with nC_up

      //finish off-diag hopping:
      W += sites_.op("CkD",site) * setElt( ALink(2), ILinkUp(6) );
      W += sites_.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7) );

      //finish Sf and PH terms:
      if (std::abs(JSFPH_) > 1E-15) {
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(8) )*( JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(9) )*(-JSFPH_);
        W += sites_.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(10))*( JSFPH_);
        W += sites_.op("CkD",site)  * setElt( ALink(2), ILinkUp(11))*(-JSFPH_);
      }
    }
  }




  void AIM_OffDiag::MakeOneOrbitalMPO( const std::vector<Index>& ArmImpLinks ){
    auto i = ArmImpLinks.at(0);
    Error("One orbital MPO not implemented!! ");
    
  }



  std::vector<Index> AIM_OffDiag::GetImpLinks(){
    QN qn0  = - div( sites_.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites_.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = - div( sites_.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites_.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = - div( sites_.op( "CkD", H.ImpSite(2) ) );

    std::vector<Index> ImpLinks; ImpLinks.resize(NArms_+1);
    //create links:
    if(NArms_ == 6){
         if (std::abs(JSFPH_) > 1E-15) {
          ImpLinks.at(1) = Index( qn0,  3, 

                                  cup,  1, //off diag
                                  cupD, 1, //off diag
                                  cup,  1, //off diag
                                  cupD, 1, //off diag

                                  cupD, 1, //SFPH             
                                  cup,  1, //SFPH
                                  Out, Names::TAGSI );

          ImpLinks.at(2) = Index( qn0,  4,
                                  cup,  1,      //off diag
                                  cupD, 1,      //off diag
                                  cup,  1,      //off diag
                                  cupD, 1,      //off diag
                                  cdn,  1,      //off diag
                                  cdnD, 1,      //off diag
                                  cdn,  1,      //off diag
                                  cdnD, 1,      //off diag
                                  cupD+cdn,  1, // C_upD* C_dn  - SFPH
                                  cupD+cdnD, 1, // C_upD* C_dnD - SFPH
                                  cup+cdnD,  1, // C_up * C_dnD - SFPH
                                  cup+cdn,   1, // C_up * C_dn  - SFPH    
                                  Out, Names::TAGSI );

          ImpLinks.at(3) = Index( qn0,  5,

                                  cup,  1,    //off diag
                                  cupD, 1,    //off diag
                                  cdn,  1,    //off diag
                                  cdnD, 1,    //off diag
                                  cdn,  1,    //off diag
                                  cdnD, 1,    //off diag

                                  cupD+cdn,  1, // C_upD* C_dn  - SFPH
                                  cupD+cdnD, 1, // C_upD* C_dnD - SFPH
                                  cup+cdnD,  1, // C_up * C_dnD - SFPH
                                  cup+cdn,   1, // C_up * C_dn  - SFPH    
                                  
                                  cupD, 1,  //C_upD - SFPH
                                  cup,  1,  //C_upD - SFPH

                                  cupD+cdn+cup,  1, //C_upD* C_dn * C_up - SFPH
                                  cupD+cdnD+cup, 1, //C_upD* C_dnD* C_up - SFPH
                                  cup+cdnD+cupD, 1, //C_up * C_dnD* C_upD- SFPH
                                  cup+cdn+cupD,  1, //C_up * C_dn * C_upD- SFPH
                                  Out, Names::TAGSI );

          ImpLinks.at(4) = Index( qn0,  4,
                                  cup,  1,   //off diag
                                  cupD, 1,   //off diag
                                  cdn,  1,   //off diag
                                  cdnD, 1,   //off diag

                                  cupD+cdn,  1, // C_upD* C_dn  - SFPH
                                  cupD+cdnD, 1, // C_upD* C_dnD - SFPH
                                  cup+cdnD,  1, // C_up * C_dnD - SFPH
                                  cup+cdn,   1, // C_up * C_dn  - SFPH     
                                  Out, Names::TAGSI );
        
          ImpLinks.at(5) = Index( qn0,  5,
                                  cdn,  1,
                                  cdnD, 1,
                                  cupD+cdn+cup,  1, //C_upD* C_dn * C_up - SFPH
                                  cupD+cdnD+cup, 1, //C_upD* C_dnD* C_up - SFPH
                                  cup+cdnD+cupD, 1, //C_up * C_dnD* C_upD- SFPH
                                  cup+cdn+cupD,  1, //C_up * C_dn * C_upD- SFPH
                                  Out, Names::TAGSI );
        }
        else {
          // No SFPH
          ImpLinks.at(1) = Index( qn0,  3, 

                                  cup,  1, //off diag
                                  cupD, 1, //off diag
                                  cup,  1, //off diag
                                  cupD, 1, //off diag
                                  Out, Names::TAGSI );

          ImpLinks.at(2) = Index( qn0,  4,
                                  cup,  1,      //off diag
                                  cupD, 1,      //off diag
                                  cup,  1,      //off diag
                                  cupD, 1,      //off diag
                                  cdn,  1,      //off diag
                                  cdnD, 1,      //off diag
                                  cdn,  1,      //off diag
                                  cdnD, 1,      //off diag
                                  Out, Names::TAGSI );

          ImpLinks.at(3) = Index( qn0,  5,

                                  cup,  1,    //off diag
                                  cupD, 1,    //off diag
                                  cdn,  1,    //off diag
                                  cdnD, 1,    //off diag
                                  cdn,  1,    //off diag
                                  cdnD, 1,    //off diag
                                  Out, Names::TAGSI );

          ImpLinks.at(4) = Index( qn0,  4,
                                  cup,  1,   //off diag
                                  cupD, 1,   //off diag
                                  cdn,  1,   //off diag
                                  cdnD, 1,   //off diag
                                  Out, Names::TAGSI );
        
          ImpLinks.at(5) = Index( qn0,  5,
                                  cdn,  1,
                                  cdnD, 1,
                                  Out, Names::TAGSI );
        }
    }
    else if (NArms_ == 4) {
      if (std::abs(JSFPH_) > 1E-15) {
        ImpLinks.at(1) = Index( qn0,  3, 
                                cup,  1,  //off diag
                                cupD, 1,  //off diag
                                cupD, 1,  //SFPH            
                                cup,  1,  //SFPH
                                Out, Names::TAGSI );

        ImpLinks.at(2) = Index( qn0,  4,
                                cup,  1,
                                cupD, 1,
                                cdn,  1,
                                cdnD, 1,
                                cupD+cdn,  1, // C_upD* C_dn  - SFPH
                                cupD+cdnD, 1, // C_upD* C_dnD - SFPH
                                cup+cdnD,  1, // C_up * C_dnD - SFPH
                                cup+cdn,   1, // C_up * C_dn  - SFPH    
                                Out, Names::TAGSI );

        ImpLinks.at(3) = Index( qn0,  5,
                                cdn,  1,    //off diag
                                cdnD, 1,    //off diag

                                cupD+cdn+cup,  1, //C_upD* C_dn * C_up - SFPH
                                cupD+cdnD+cup, 1, //C_upD* C_dnD* C_up - SFPH
                                cup+cdnD+cupD, 1, //C_up * C_dnD* C_upD- SFPH
                                cup+cdn+cupD,  1, //C_up * C_dn * C_upD- SFPH
                                Out, Names::TAGSI );

      }
      else {
        // No SFPH
        ImpLinks.at(1) = Index( qn0,  3, 
                                cup,  1,  //off diag
                                cupD, 1,  //off diag
                                Out, Names::TAGSI );

        ImpLinks.at(2) = Index( qn0,  4,
                                cup,  1,
                                cupD, 1,
                                cdn,  1,
                                cdnD, 1,
                                Out, Names::TAGSI );

        ImpLinks.at(3) = Index( qn0,  5,
                                cdn,  1,    //off diag
                                cdnD, 1,    //off diag
                                Out, Names::TAGSI );
      }
    }
    return ImpLinks;
  }
  // clang-format on
} //namespace forktps

/*

  void AIM_OffDiag::MakeTwoOrbitalArmMPOs(std::vector<Index>& ArmImpLinks){

    if(NArms_ != 4){ Error("AIM_ForkTPO_NonDiagBath::MakeArmMPOs:: Error only Nchains=4 implemented!"); }
    ArmImpLinks.resize(0); ArmImpLinks.push_back(Index());

    const int NBath =H.NBath();
    std::vector<Index> ArmLinks(NBath+1);

    for(int arm = 1; arm <= NArms_; arm++) {
      QN qnC, qnCDag, qn0 = QN( {"Sz",0},{"Nf", 0,-1} );

      //std::cout << "-------------------------------------------"<<std::endl;
      //std::cout << "-------------------------------------------"<<std::endl;


      if(arm%2 == 1){
        qnC=     QN({"Sz", 1},{"Nf", 1,-1});
        qnCDag=  QN({"Sz",-1},{"Nf",-1,-1});
      }
      else {
        qnC=     QN({"Sz",-1},{"Nf", 1,-1});
        qnCDag=  QN({"Sz", 1},{"Nf",-1,-1});
      }

      //create links
      for(int l=1; l<=NBath;l++){
        auto indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;

        if(arm != NArms_ && arm != NArms_-1){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,    Out, indxName );
        }
        else
        {
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
        }
      }

      {
        int site = H.ArmToSite(arm,1);
        ITensor& W =H.Anc(site);
        Index left=ArmLinks.at(1);
        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left);


        W += sites_.op("N"  ,site)*setElt( left(1) )*ek_.at(arm).at(1);
        W += sites_.op("Id" ,site)*setElt( left(2) );
        W += sites_.op("p"  ,site)*setElt( left(3) );

        //std::cout<< "Use " << ek_.at(arm).at(1)<< " for on-site energy"<<std::endl;

        if(arm != NArms_ && arm != NArms_-1){
          W += sites_.op("Ck" ,site)*setElt( left(4) )*           vk_.at(arm).at(1)  ;
          W += sites_.op("CkD",site)*setElt( left(5) )*std::conj( vk_.at(arm).at(1) );
          W += sites_.op("Ck" ,site)*setElt( left(6) )*           vk_.at(arm+2).at(1);
          W += sites_.op("CkD",site)*setElt( left(7) )*std::conj( vk_.at(arm+2).at(1) );

          //std::cout<< "Use " << vk_.at(arm).at(1)<< "for diag bath, and "<< vk_.at(arm+2).at(1) <<" for non-diag bath"<<std::endl;
        }
        else {
          W += sites_.op("Ck" ,site)*setElt( left(4) )*           vk_.at(arm).at(NBath+1);
          W += sites_.op("CkD",site)*setElt( left(5) )*std::conj( vk_.at(arm).at(NBath+1) );
          //std::cout<< "Use " << vk_.at(arm).at(NBath+1)<< " for diag bath"<<std::endl;
        }


      }
      for(int n=2; n<=NBath; n++){

        int site = H.ArmToSite(arm,n);

        ITensor& W =H.Anc(site);

        Index right =dag(ArmLinks.at(n-1));
        Index left  =    ArmLinks.at(n)   ;

        W=ITensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        W += sites_.op("Id",site)*setElt( left(1),right(1) ); 
        W += sites_.op("Id",site)*setElt( left(2),right(2) ); //ids
        
        W += sites_.op("p" ,site)*setElt( left(3), right(3) ); 
        W += sites_.op("p" ,site)*setElt( left(4), right(4) ); 
        W += sites_.op("p" ,site)*setElt( left(5), right(5) ); //ps

        W += sites_.op("N" ,site)*setElt( left(1), right(2) )*ek_.at(arm).at(n); //on-site energy

        //std::cout<< "Use " << ek_.at(arm).at(n)<< " for on-site energy"<<std::endl;

        if(arm == 1 || arm == 2){
          W += sites_.op("Id",site)*setElt( left(6), right(6) );
          W += sites_.op("Id",site)*setElt( left(7), right(7) );

          W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           vk_.at(arm).at(n)   ;
          W += sites_.op("CkD",site)*setElt( left(5), right(2) )*std::conj( vk_.at(arm).at(n) ) ;

          W += sites_.op("Ck" ,site)*setElt( left(6), right(3) )*           vk_.at(arm+2).at(n)   ;
          W += sites_.op("CkD",site)*setElt( left(7), right(3) )*std::conj( vk_.at(arm+2).at(n) ) ;

          //std::cout<< "Use " << vk_.at(arm).at(n)<< "for diag bath, and "<< vk_.at(arm+2).at(n)  <<" for non-diag bath"<<std::endl;
        }
        else {
          W += sites_.op("Ck" ,site)*setElt( left(4), right(2) )*           vk_.at(arm).at(NBath+n)   ;
          W += sites_.op("CkD",site)*setElt( left(5), right(2) )*std::conj( vk_.at(arm).at(NBath+n) ) ;
          //std::cout<< "Use " << vk_.at(arm).at(NBath+n)<< " for diag bath"<<std::endl;
        }


      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

  }





*/
