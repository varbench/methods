
#include "itensor/mps/siteset.h"
#include "itensor/mps/mps.h"
#include "itensor/iqtensor.h"

#include "../typenames.h"

using namespace itensor;

namespace itensor {

  /*

  class FermionicOrderSwapper
  {
    //this class generates an MPO that swaps the fermionnic order
    //so that ImpI is directly !!!BEFORE!!! ImpJ
    //ATTENTION: swapping ImpI with ImpJ itself is done with a separate "swap gate"
    //
    // Fermionic order before                     becomes if ImpI=1 and ImpJ=3:
    //
    // 1 - 2 - 3                                  6 - 2 - 3
    // |                                          |
    // 4 - 5 - 6                                  4 - 5 - 1
    // |              ---->>>---->>>----          |
    // 7 - 8 - 9                                  7 - 8 - 9
    // |                                          |
    //10 - 11 - 12                                10 - 11 - 12
    public:

    FermionicOrderSwapper(const SiteSet& sites, int NArms, int ImpI, int ImpJ );

    operator ForkTPO () { init_(); return H; }

    void MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks);
    void MakeImpMPOs(const std::vector<IQIndex>& ArmImpLinks);

    private:

    //////////////////
    //
    // Data Members

    const SiteSet& sites_;

    int NArms_;


    int ImpI_;
    int ImpJ_;

    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void
    init_();

  };



  inline FermionicOrderSwapper::
  FermionicOrderSwapper(const SiteSet& sites, int NArms, int ImpI, int ImpJ )
  :
  sites_(sites),
  initted_(false)
  {
    NArms_=NArms;
    ImpI_ = ImpI;
    ImpJ_ = ImpJ;

    if(ImpI_>ImpJ_){ std::swap( ImpI_, ImpJ_ ); }
  }



  void inline FermionicOrderSwapper:: init_() {
    if(initted_) return;

    H = ForkTPO(sites_,NArms_);

    std::vector<IQIndex> ArmImpLinks; ArmImpLinks.resize(0);


    MakeArmMPOs(ArmImpLinks);
    MakeImpMPOs(ArmImpLinks);


    initted_ = true;
  }


  void FermionicOrderSwapper::MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks){


    ArmImpLinks.resize(0); ArmImpLinks.push_back(IQIndex());

    const int NBath =H.NBath();
    std::vector<IQIndex> InterArmLinks(NBath+1);

    for(int arm = 1; arm <= NArms_; arm++) {

      int dimArmLinks=0;
      if( arm < ImpI_ || arm>= ImpJ_ )           { dimArmLinks = 1; }
      else if (arm >= ImpI_ && arm < ImpJ_-1 )  { dimArmLinks = 2; }
      else if (arm == ImpJ_-1 )                 { dimArmLinks = 4; }

      //create links
      for(int l=1;l<=NBath;l++){
        std::stringstream s;
        s<<"SWL_a"<<arm;
        InterArmLinks.at(l) = IQIndex( s.str(), Index(s.str() ,dimArmLinks), QN( 0,0) );
      }

      //create first MPO
      {
        int Bindx = 1;
        int site = H.ArmToSite(arm,Bindx);
        IQTensor& W =H.Anc(site);
        IQIndex left=InterArmLinks.at(Bindx);
        W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left);

        if(arm < ImpI_ || arm>= ImpJ_ )            { W = sites_.op("Id",site)*left(1); }
        else if (arm >= ImpI_ && arm < ImpJ_-1 ){
          W = sites_.op("Id", site)*left(1);
          W+= sites_.op("p" , site)*left(2);
        }
        else if (arm == ImpJ_-1 ){
          W = sites_.op("One-N", site)*left(1);
          W+= sites_.op("N"    , site)*left(2);
          W+= sites_.op("One-N", site)*left(3);
          W+= sites_.op("N"    , site)*left(4);
        }

      }

      //create MPO for index 2-Nbath
      for(int Bindx=2; Bindx<=NBath; Bindx++){

        int site = H.ArmToSite(arm,Bindx);
        IQTensor& W =H.Anc(site);

        IQIndex right =dag(InterArmLinks.at(Bindx-1));
        IQIndex left  =    InterArmLinks.at(Bindx)   ;

        W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        if(arm < ImpI_ || arm >= ImpJ_ )            { W = sites_.op("Id",site)*left(1)*right(1); }
        else if (arm >= ImpI_ && arm < ImpJ_-1 ){
          W = sites_.op("Id", site)*left(1)*right(1);
          W+= sites_.op("p" , site)*left(2)*right(2);
        }
        else if (arm == ImpJ_-1 ){
          W = sites_.op("Id", site)*left(1)*right(1);
          W+= sites_.op("Id", site)*left(2)*right(2);
          W+= sites_.op("p" , site)*left(3)*right(3);
          W+= sites_.op("p" , site)*left(4)*right(4);
        }

      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }

  }

  void FermionicOrderSwapper::MakeImpMPOs(const std::vector<IQIndex>& ArmImpLinks){
    std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);

    //make imp-imp links
    for(int imp=1;imp< NArms_;imp++){
      int dimImpLinks;
      if( imp < ImpI_ || imp>= (ImpJ_-1) )  { dimImpLinks = 1; }
      else                                  { dimImpLinks = 4; }

      ImpLinks.at(imp) = IQIndex( nameint("SW IL ",imp), Index("swIlink",dimImpLinks),QN(0,0));
    }

    //first Impurity site
    {
      int impIndx=1;
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      if( ImpI_ == impIndx ){
        W += sites_.op("One-N", site)* ALink(1)*ILink(1);
        W += sites_.op("N"    , site)* ALink(1)*ILink(2)*(-1.0);
        W += sites_.op("N"    , site)* ALink(2)*ILink(3);
        W += sites_.op("One-N", site)* ALink(2)*ILink(4);
      }
      else {
        W += sites_.op("Id",site)    * ALink(1)*ILink(1);
      }
    }

    //second to NArms-1
    for(int impIndx=2; impIndx <= NArms_-1; impIndx++){
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink   = dag( ArmImpLinks[impIndx] );
      IQIndex ILinkUp = dag( ImpLinks[impIndx-1] );
      IQIndex ILinkDn =      ImpLinks[impIndx];

      W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      if( impIndx < ImpI_ ){
        W += sites_.op("Id", site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
      }
      else if ( impIndx == ImpI_ ){
        W += sites_.op("One-N", site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
        W += sites_.op("N"    , site)* ALink(1)*ILinkUp(1)*ILinkDn(2)*(-1.0);
        W += sites_.op("N"    , site)* ALink(2)*ILinkUp(1)*ILinkDn(3);
        W += sites_.op("One-N", site)* ALink(2)*ILinkUp(1)*ILinkDn(4);
      }
      else if ( impIndx  < (ImpJ_ - 1) ) {
        W += sites_.op("Id" , site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
        W += sites_.op("Id" , site)* ALink(1)*ILinkUp(2)*ILinkDn(2);
        W += sites_.op("p"  , site)* ALink(2)*ILinkUp(3)*ILinkDn(3);
        W += sites_.op("p"  , site)* ALink(2)*ILinkUp(4)*ILinkDn(4);
      }

      else if ( impIndx  == (ImpJ_ - 1) ) {
        W += sites_.op("Id" , site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
        W += sites_.op("Id" , site)* ALink(2)*ILinkUp(2)*ILinkDn(1);
        W += sites_.op("p"  , site)* ALink(3)*ILinkUp(3)*ILinkDn(1);
        W += sites_.op("p"  , site)* ALink(4)*ILinkUp(4)*ILinkDn(1);
      }
      else {
        W += sites_.op("Id", site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
      }

    }

    //last impurity
    {
      int impIndx=NArms_;
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink   = dag( ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag( ImpLinks[impIndx-1] );

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );

      W+= sites_.op("Id",site)    * ALink(1)*ILinkUp(1);
    }

  }

  */

  class FermionicOrderSwapper_ImpImp {
    //this class generates an MPO that swaps the fermionnic order
    //of ImpI with ImpJ
    //ATTENTION: swapping ImpI with ImpJ itself needs to be done with a separate "swap gate"
    //
    // Fermionic order before                     becomes if ImpI=1 and ImpJ=3:
    //
    // 1 - 2 - 3                                  7 - 2 - 3
    // |                                          |
    // 4 - 5 - 6                                  4 - 5 - 6
    // |              ---->>>---->>>----          |
    // 7 - 8 - 9                                  1 - 8 - 9
    // |                                          |
    //10 - 11 - 12                                10 - 11 - 12
    public:
    FermionicOrderSwapper_ImpImp(const SiteSet &sites, int NArms, int ImpI, int ImpJ);

    operator ForkTPO() {
      init_();
      return H;
    }

    void MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks);
    void MakeImpMPOs(const std::vector<IQIndex> &ArmImpLinks);

    private:
    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;

    int ImpI_;
    int ImpJ_;

    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

  inline FermionicOrderSwapper_ImpImp::FermionicOrderSwapper_ImpImp(const SiteSet &sites, int NArms, int ImpI, int ImpJ)
     : sites_(sites), initted_(false) {
    NArms_ = NArms;
    ImpI_  = ImpI;
    ImpJ_  = ImpJ;

    if (ImpI_ > ImpJ_) { std::swap(ImpI_, ImpJ_); }
  }

  void inline FermionicOrderSwapper_ImpImp::init_() {
    if (initted_) return;

    H = ForkTPO(sites_, NArms_);

    std::vector<IQIndex> ArmImpLinks;
    ArmImpLinks.resize(0);

    MakeArmMPOs(ArmImpLinks);
    MakeImpMPOs(ArmImpLinks);

    initted_ = true;
  }

  void FermionicOrderSwapper_ImpImp::MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks) {

    ArmImpLinks.resize(0);
    ArmImpLinks.push_back(IQIndex());

    const int NBath = H.NBath();
    std::vector<IQIndex> InterArmLinks(NBath + 1);

    for (int arm = 1; arm <= NArms_; arm++) {

      int dimArmLinks = 0;
      if (arm < ImpI_ || arm >= ImpJ_) {
        dimArmLinks = 1;
      } else {
        dimArmLinks = 2;
      }

      //create links
      for (int l = 1; l <= NBath; l++) {
        std::stringstream s;
        s << "SWL_a" << arm;
        InterArmLinks.at(l) = IQIndex(s.str(), Index(s.str(), dimArmLinks), QN(0, 0));
      }

      //create first MPO
      {
        int Bindx    = 1;
        int site     = H.ArmToSite(arm, Bindx);
        IQTensor &W  = H.Anc(site);
        IQIndex left = InterArmLinks.at(Bindx);
        W            = IQTensor(dag(sites_.si(site)), sites_.siP(site), left);

        if (arm < ImpI_ || arm >= ImpJ_) {
          W = sites_.op("Id", site) * left(1);
        } else {
          W = sites_.op("Id", site) * left(1);
          W += sites_.op("p", site) * left(2);
        }
      }

      //create MPO for index 2-Nbath
      for (int Bindx = 2; Bindx <= NBath; Bindx++) {

        int site    = H.ArmToSite(arm, Bindx);
        IQTensor &W = H.Anc(site);

        IQIndex right = dag(InterArmLinks.at(Bindx - 1));
        IQIndex left  = InterArmLinks.at(Bindx);

        W = IQTensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        if (arm < ImpI_ || arm >= ImpJ_) {
          W = sites_.op("Id", site) * left(1) * right(1);
        } else {
          W = sites_.op("Id", site) * left(1) * right(1);
          W += sites_.op("p", site) * left(2) * right(2);
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }
  }

  void FermionicOrderSwapper_ImpImp::MakeImpMPOs(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    //make imp-imp links
    for (int imp = 1; imp < NArms_; imp++) {
      int dimImpLinks;
      if (imp < ImpI_ || imp >= ImpJ_) {
        dimImpLinks = 1;
      } else {
        dimImpLinks = 4;
      }

      ImpLinks.at(imp) = IQIndex(nameint("SW IL ", imp), Index("swIlink", dimImpLinks), QN(0, 0));
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      if (ImpI_ == impIndx) {
        W += sites_.op("One-N", site) * ALink(1) * ILink(1);
        W += sites_.op("N", site) * ALink(1) * ILink(2) * (-1.);
        W += sites_.op("N", site) * ALink(2) * ILink(3);
        W += sites_.op("One-N", site) * ALink(2) * ILink(4);
      } else {
        W += sites_.op("Id", site) * ALink(1) * ILink(1);
      }
    }

    //second to NArms-1
    for (int impIndx = 2; impIndx <= NArms_ - 1; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      if (impIndx < ImpI_) {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      } else if (impIndx == ImpI_) {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(1) * ILinkDn(2) * (-1.);
        W += sites_.op("N", site) * ALink(2) * ILinkUp(1) * ILinkDn(3);
        W += sites_.op("One-N", site) * ALink(2) * ILinkUp(1) * ILinkDn(4);
      } else if (impIndx < ImpJ_) {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("p", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("p", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
      } else if (impIndx == ImpJ_) {

        W = sites_.op("One-N", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      } else {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      }
    }

    //last impurity
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      if (impIndx == ImpJ_) {
        W = sites_.op("One-N", site) * ALink(1) * ILinkUp(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(4);
      } else {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      }
    }
  }

  class FermionicOrderSwapper_ImpAscOrder {
    //this class generates an MPO that swaps the fermionnic order
    //of a Bath site with an impurity site.
    //it assumes that the swaped impurity is NEVER moved past any
    //other impurity. This is used get a fermionic order in which
    //the impurities are direct neighbors to each other
    // A typical case where this operator is used is:
    //
    //
    // Start with typical fermionic order:
    //
    // 1 - 2 - 3 - 4
    // |
    // 5 - 6 - 7 - 8
    // |
    // 9 - 10 - 11 - 12
    // |
    //13 - 14 - 15 - 16
    //
    //
    // swap impurity 2 to be second :
    //
    // 1 - 5 - 3 - 4
    // |
    // 2 - 6 - 7 - 8
    // |
    // 9 - 10 - 11 - 12
    // |
    //13 - 14 - 15 - 16
    //
    // swap impurity 3 to be third :
    //
    // 1 - 5 - 9 - 4
    // |
    // 2 - 6 - 7 - 8
    // |
    // 3 - 10 - 11 - 12
    // |
    //13 - 14 - 15 - 16
    //
    //and finally swap impurity 4 to be fourth
    // swap impurity 3 to be third :
    //
    // 1 - 5 - 9 - 13
    // |
    // 2 - 6 - 7 - 8
    // |
    // 3 - 10 - 11 - 12
    // |
    // 4 - 14 - 15 - 16

    public:
    FermionicOrderSwapper_ImpAscOrder(const SiteSet &sites, int NArms, int Site, int Imp);

    operator ForkTPO() {
      init_();
      return H;
    }

    void MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks);
    void MakeImpMPOs(const std::vector<IQIndex> &ArmImpLinks);

    private:
    //////////////////
    //
    // Data Members

    const SiteSet &sites_;

    int NArms_;

    int Site_;
    int Imp_;

    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void init_();
  };

  inline FermionicOrderSwapper_ImpAscOrder::FermionicOrderSwapper_ImpAscOrder(const SiteSet &sites, int NArms, int Site, int Imp)
     : sites_(sites), initted_(false) {

    NArms_ = NArms;
    Imp_   = Imp;
    Site_  = Site;
  }

  void inline FermionicOrderSwapper_ImpAscOrder::init_() {
    if (initted_) return;
    H = ForkTPO(sites_, NArms_);

    std::vector<IQIndex> ArmImpLinks;
    ArmImpLinks.resize(0);

    MakeArmMPOs(ArmImpLinks);
    MakeImpMPOs(ArmImpLinks);

    initted_ = true;
  }

  void FermionicOrderSwapper_ImpAscOrder::MakeArmMPOs(std::vector<IQIndex> &ArmImpLinks) {

    ArmImpLinks.resize(0);
    ArmImpLinks.push_back(IQIndex());
    auto [SArm, SIndx] = H.SiteToArm(Site_);
    int NBath          = H.NBath();
    std::vector<IQIndex> InterArmLinks(NBath + 1);

    if (SArm != 1) {
      Print(Site_);
      Print(SArm);
      Error("FermionicOrderSwapperIII::MakeArmMPOs: Only SArm = 1 Implemented!");
    }
    if (NBath < NArms_) {
      Print(NBath);
      Print(NArms_);
      Error("FermionicOrderSwapperIII::MakeArmMPOs: NBath < NArms not implemented!");
    }
    if (Imp_ - 1 != NBath - SIndx + 1) {
      Print(Imp_);
      Print(NBath - SIndx + 1);
      Error("FermionicOrderSwapperIII::MakeArmMPOs: Second impurity should be swapped with first bath site etc. ...!");
    }

    //arm =1
    {
      int arm         = 1;
      int dimArmLinks = 0;

      //create links
      for (int l = 1; l <= NBath; l++) {
        if (l < SIndx) {
          dimArmLinks = 2;
        } else if (l >= SIndx) {
          dimArmLinks = 4;
        }

        std::stringstream s;
        s << "SWL_a" << arm;
        InterArmLinks.at(l) = IQIndex(s.str(), Index(s.str(), dimArmLinks), QN(0, 0));
      }

      //create first MPO
      {
        int Bindx    = 1;
        int site     = H.ArmToSite(arm, Bindx);
        IQTensor &W  = H.Anc(site);
        IQIndex left = InterArmLinks.at(Bindx);
        W            = IQTensor(dag(sites_.si(site)), sites_.siP(site), left);

        if (Bindx > SIndx) {
          //add identities this never happens it is there for consistency reasons:
          W = sites_.op("Id", site) * left(1);
          W += sites_.op("Id", site) * left(2);
          W += sites_.op("Id", site) * left(3);
          W += sites_.op("Id", site) * left(4);
        } else if (Bindx == SIndx) {
          W = sites_.op("One-N", site) * left(1);      //gets Ids ; 1-n  at end
          W += sites_.op("N", site) * left(2) * (-1.); //gets Ids ; n    at end
          W += sites_.op("N", site) * left(3);         //gets ps  ; 1-n  at end
          W += sites_.op("One-N", site) * left(4);     //gets gs  ; n    at end
        } else {
          W = sites_.op("Id", site) * left(1);
          W += sites_.op("p", site) * left(2);
        }
      }

      //create MPO for index 2-Nbath
      for (int Bindx = 2; Bindx <= NBath; Bindx++) {

        int site    = H.ArmToSite(arm, Bindx);
        IQTensor &W = H.Anc(site);

        IQIndex right = dag(InterArmLinks.at(Bindx - 1));
        IQIndex left  = InterArmLinks.at(Bindx);

        W = IQTensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        if (Bindx > SIndx) {
          //note that this operator always swaps all bath sites
          //(see explanation in class definition)
          W = sites_.op("Id", site) * left(1) * right(1);
          W += sites_.op("Id", site) * left(2) * right(2);
          W += sites_.op("p", site) * left(3) * right(3);
          W += sites_.op("p", site) * left(4) * right(4);
        } else if (Bindx == SIndx) {
          W = sites_.op("One-N", site) * left(1) * right(1);
          W += sites_.op("N", site) * left(2) * right(1) * (-1.);
          W += sites_.op("N", site) * left(3) * right(2);
          W += sites_.op("One-N", site) * left(4) * right(2);
        } else {
          W = sites_.op("Id", site) * left(1) * right(1);
          W += sites_.op("p", site) * left(2) * right(2);
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }

    for (int arm = 2; arm <= NArms_; arm++) {

      int dimArmLinks = 0;

      //create links
      for (int l = 1; l <= NBath; l++) {
        if (arm < Imp_) {
          dimArmLinks = 2;
        } else {
          dimArmLinks = 1;
        }
        std::stringstream s;
        s << "SWL_a" << arm;
        InterArmLinks.at(l) = IQIndex(s.str(), Index(s.str(), dimArmLinks), QN(0, 0));
      }

      //create first MPO
      {
        int Bindx    = 1;
        int site     = H.ArmToSite(arm, Bindx);
        IQTensor &W  = H.Anc(site);
        IQIndex left = InterArmLinks.at(Bindx);
        W            = IQTensor(dag(sites_.si(site)), sites_.siP(site), left);

        if (arm < Imp_) {
          W = sites_.op("Id", site) * left(1);
          W += sites_.op("p", site) * left(2);
        } else {
          W = sites_.op("Id", site) * left(1);
        }
      }

      //create MPO for index 2-Nbath
      for (int Bindx = 2; Bindx <= NBath; Bindx++) {

        int site      = H.ArmToSite(arm, Bindx);
        IQTensor &W   = H.Anc(site);
        IQIndex right = dag(InterArmLinks.at(Bindx - 1));
        IQIndex left  = InterArmLinks.at(Bindx);
        W             = IQTensor(dag(sites_.si(site)), sites_.siP(site), left, right);

        if (arm < Imp_) {
          W = sites_.op("Id", site) * left(1) * right(1);
          W += sites_.op("p", site) * left(2) * right(2);
        } else {
          W = sites_.op("Id", site) * left(1) * right(1);
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }
  }

  void FermionicOrderSwapper_ImpAscOrder::MakeImpMPOs(const std::vector<IQIndex> &ArmImpLinks) {
    std::vector<IQIndex> ImpLinks;
    ImpLinks.resize(NArms_ + 1);

    //make imp-imp links
    for (int imp = 1; imp < NArms_; imp++) {
      int dimImpLinks;

      if (imp < Imp_) {
        dimImpLinks = 4;
      } else {
        dimImpLinks = 1;
      }

      ImpLinks.at(imp) = IQIndex(nameint("SW IL ", imp), Index("swIlink", dimImpLinks), QN(0, 0));
    }

    //first Impurity site
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink);

      //first impurity always has IDs ie never gets swapped by this operator
      W += sites_.op("Id", site) * ALink(1) * ILink(1);
      W += sites_.op("Id", site) * ALink(2) * ILink(2);
      W += sites_.op("Id", site) * ALink(3) * ILink(3);
      W += sites_.op("Id", site) * ALink(4) * ILink(4);
    }

    //second to NArms-1
    for (int impIndx = 2; impIndx <= NArms_ - 1; impIndx++) {
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);
      IQIndex ILinkDn = ImpLinks[impIndx];

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn);

      if (impIndx < Imp_) {
        //we assume that all impurities above Imp_ dont need to be swapped
        //(see explanation in class definition)
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(2) * ILinkDn(2);
        W += sites_.op("Id", site) * ALink(2) * ILinkUp(3) * ILinkDn(3);
        W += sites_.op("Id", site) * ALink(2) * ILinkUp(4) * ILinkDn(4);
      } else if (impIndx == Imp_) {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2) * ILinkDn(1);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3) * ILinkDn(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(4) * ILinkDn(1);
      } else {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1) * ILinkDn(1);
      }
    }

    //last impurity
    {
      int impIndx = NArms_;
      int site    = H.ImpSite(impIndx);
      IQTensor &W = H.Anc(site);

      IQIndex ALink   = dag(ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp);

      if (impIndx == Imp_) {
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(1);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(2);
        W += sites_.op("One-N", site) * ALink(1) * ILinkUp(3);
        W += sites_.op("N", site) * ALink(1) * ILinkUp(4);
      } else {
        W += sites_.op("Id", site) * ALink(1) * ILinkUp(1);
      }
    }
  }

  /*
  class FermionicOrderSwapperIII{
    //this class generates an MPO that swaps the fermionnic order
    //of a Bath site with an impurity site
    //
    // Fermionic order before                     becomes if Site=2 and ImpJ=4:
    //
    // 1 - 2 - 3                                  1 - 10 - 3
    // |                                          |
    // 4 - 5 - 6                                  4 - 5 - 6
    // |              ---->>>---->>>----          |
    // 7 - 8 - 9                                  7 - 8 - 9
    // |                                          |
    //10 - 11 - 12                                2 - 11 - 12
    public:

    FermionicOrderSwapperIII(const SiteSet& sites, int NArms, int Site, int Imp );

    operator ForkTPO () { init_(); return H; }

    void MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks);
    void MakeImpMPOs(const std::vector<IQIndex>& ArmImpLinks);

    private:

    //////////////////
    //
    // Data Members

    const SiteSet& sites_;

    int NArms_;


    int Site_;
    int Imp_;

    bool initted_;

    ForkTPO H;

    //
    //////////////////

    void
    init_();

  };



  inline FermionicOrderSwapperIII::FermionicOrderSwapperIII(const SiteSet& sites, int NArms, int Site, int Imp )
  :
  sites_(sites),
  initted_(false)
  {
    if(Imp == 1){ Print(Imp); Error("FermionicOrderSwapperIII::FermionicOrderSwapperIII: Imp == 1 not supported!"); }
    NArms_=NArms;
    Imp_  = Imp;
    Site_ = Site;
  }



  void inline FermionicOrderSwapperIII::init_() {
    if(initted_) return;

    H = ForkTPO(sites_,NArms_);

    std::vector<IQIndex> ArmImpLinks; ArmImpLinks.resize(0);


    MakeArmMPOs(ArmImpLinks);
    MakeImpMPOs(ArmImpLinks);

    initted_ = true;
  }


  void FermionicOrderSwapperIII::MakeArmMPOs(std::vector<IQIndex>& ArmImpLinks){


    ArmImpLinks.resize(0); ArmImpLinks.push_back(IQIndex());

    int SArm = H.GetArm(Site_);
    int SIndx = H.SiteToArm(Site_);
    int NBath = H.NBath();
    std::vector<IQIndex> InterArmLinks(NBath+1);

    if(SArm != 1)         { Print(Site_); Print(SArm); Error("FermionicOrderSwapperIII::MakeArmMPOs: Only SArm = 1 Implemented!"); }
    if(NBath < NArms_ ) { Print(NBath); Print(NArms_); Error("FermionicOrderSwapperIII::MakeArmMPOs: NBath < NArms not implemented!"); }

    //arm =1
    {
      int arm =1;
      int dimArmLinks=0;

      //create links
      for(int l=1;l<=NBath;l++){
        if      ( l <  SIndx )  { dimArmLinks = 2; }
        else if ( l >= SIndx )  { dimArmLinks = 4; }

        std::stringstream s;
        s<<"SWL_a"<<arm;
        InterArmLinks.at(l) = IQIndex( s.str(), Index(s.str() ,dimArmLinks), QN( 0,0) );
      }

      //create first MPO
      {
        int Bindx = 1;
        int site = H.ArmToSite( arm, Bindx );
        IQTensor& W =H.Anc( site );
        IQIndex left=InterArmLinks.at( Bindx );
        W=IQTensor( dag( sites_.si( site ) ), sites_.siP( site ), left);

        if( Bindx > SIndx ){
          //add identities this never happens it is there for consistency reasons:
          W  = sites_.op("Id", site)*left(1);
          W += sites_.op("Id", site)*left(2);
          W += sites_.op("Id", site)*left(3);
          W += sites_.op("Id", site)*left(4);
        }
        else if (Bindx == SIndx){
          W  = sites_.op("One-N", site)*left(1);
          W += sites_.op("N",     site)*left(2)*(-1.);
          W += sites_.op("N",     site)*left(3);
          W += sites_.op("One-N", site)*left(4);
        }
        else {
          W  = sites_.op("Id", site)*left(1);
          W += sites_.op("p", site)*left(2);
        }

      }

      //create MPO for index 2-Nbath
      for( int Bindx=2; Bindx<=NBath; Bindx++ ){

        int site = H.ArmToSite(arm,Bindx);
        IQTensor& W =H.Anc(site);

        IQIndex right =dag(InterArmLinks.at(Bindx-1));
        IQIndex left  =    InterArmLinks.at(Bindx)   ;

        W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        if( Bindx > SIndx ){
          //add identities this never happens it is there for consistency reasons:
          W  = sites_.op("Id", site)*left(1)*right(1);
          W += sites_.op("Id", site)*left(2)*right(2);
          W += sites_.op("Id", site)*left(3)*right(3);
          W += sites_.op("Id", site)*left(4)*right(4);
        }
        else if (Bindx == SIndx){
          W  = sites_.op("One-N", site)*left(1)*right(1);
          W += sites_.op("N",     site)*left(2)*right(1)*(-1.);
          W += sites_.op("N",     site)*left(3)*right(2);
          W += sites_.op("One-N", site)*left(4)*right(2);
        }
        else {
          W  = sites_.op("Id", site)*left(1)*right(1);
          W += sites_.op("p", site) *left(2)*right(2);
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }


    for(int arm = 2; arm <= NArms_; arm++) {

      int dimArmLinks=0;

      //create links
      for( int l=1;l<=NBath;l++ ){
        if ( arm < Imp_ )  { dimArmLinks = 2; }
        else               { dimArmLinks = 1; }
        std::stringstream s;
        s<<"SWL_a"<<arm;
        InterArmLinks.at(l) = IQIndex( s.str(), Index(s.str() ,dimArmLinks), QN( 0,0) );
      }

      //create first MPO
      {
        int Bindx = 1;
        int site = H.ArmToSite( arm, Bindx );
        IQTensor& W =H.Anc( site );
        IQIndex left=InterArmLinks.at( Bindx );
        W=IQTensor( dag( sites_.si( site ) ), sites_.siP( site ), left);

        if( arm < Imp_ ){
          W  = sites_.op("Id", site)*left(1);
          W += sites_.op("p", site)*left(2);
        }
        else {
          W  = sites_.op("Id", site)*left(1);
        }
      }

      //create MPO for index 2-Nbath
      for(int Bindx=2; Bindx<=NBath; Bindx++){

        int site = H.ArmToSite(arm,Bindx);
        IQTensor& W =H.Anc(site);
        IQIndex right =dag(InterArmLinks.at(Bindx-1));
        IQIndex left  =    InterArmLinks.at(Bindx)   ;
        W=IQTensor(dag(sites_.si(site)), sites_.siP(site),left,right);

        if( arm < Imp_ ){
          W  = sites_.op("Id", site)*left(1)*right(1);
          W += sites_.op("p", site) *left(2)*right(2);
        }
        else {
          W  = sites_.op("Id", site)*left(1)*right(1);
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(InterArmLinks.at(NBath));
    }

  }

  void FermionicOrderSwapperIII::MakeImpMPOs(const std::vector<IQIndex>& ArmImpLinks){
    std::vector<IQIndex> ImpLinks; ImpLinks.resize(NArms_+1);

    //make imp-imp links
    for(int imp=1;imp< NArms_;imp++){
      int dimImpLinks;

      if( imp < Imp_ ) { dimImpLinks = 4; }
      else             { dimImpLinks = 1; }

      ImpLinks.at(imp) = IQIndex( nameint("SW IL ",imp), Index("swIlink",dimImpLinks),QN(0,0));
    }

    //first Impurity site
    {
      int impIndx=1;
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink = dag(ArmImpLinks[impIndx]);
      IQIndex ILink = ImpLinks[impIndx];

      W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILink );

      //first impurity always has IDs ie never gets swapped by this operator
      W += sites_.op("Id",site)    * ALink(1)*ILink(1);
      W += sites_.op("Id",site)    * ALink(2)*ILink(2);
      W += sites_.op("Id",site)    * ALink(3)*ILink(3);
      W += sites_.op("Id",site)    * ALink(4)*ILink(4);
    }

    //second to NArms-1
    for(int impIndx=2; impIndx <= NArms_-1; impIndx++){
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink   = dag( ArmImpLinks[impIndx] );
      IQIndex ILinkUp = dag( ImpLinks[impIndx-1] );
      IQIndex ILinkDn =      ImpLinks[impIndx];

      W=IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp, ILinkDn );

      if( impIndx < Imp_ ){
        W += sites_.op("Id", site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
        W += sites_.op("Id", site)* ALink(1)*ILinkUp(2)*ILinkDn(2);
        W += sites_.op("p",  site)* ALink(2)*ILinkUp(3)*ILinkDn(3);
        W += sites_.op("p",  site)* ALink(2)*ILinkUp(4)*ILinkDn(4);
      }
      else if ( impIndx == Imp_ ){
        W += sites_.op("One-N", site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
        W += sites_.op("N"    , site)* ALink(1)*ILinkUp(2)*ILinkDn(1);
        W += sites_.op("One-N", site)* ALink(1)*ILinkUp(3)*ILinkDn(1);
        W += sites_.op("N"    , site)* ALink(1)*ILinkUp(4)*ILinkDn(1);
      }
      else {
        W += sites_.op("Id" , site)* ALink(1)*ILinkUp(1)*ILinkDn(1);
      }


    }

    //last impurity
    {
      int impIndx=NArms_;
      int site = H.ImpSite(impIndx);
      IQTensor& W= H.Anc(site);

      IQIndex ALink   = dag( ArmImpLinks[impIndx]);
      IQIndex ILinkUp = dag( ImpLinks[impIndx-1] );

      W = IQTensor(dag(sites_.si(site)), sites_.siP(site), ALink, ILinkUp );


      if ( impIndx == Imp_ ){
        W += sites_.op("One-N", site)* ALink(1)*ILinkUp(1);
        W += sites_.op("N"    , site)* ALink(1)*ILinkUp(2);
        W += sites_.op("One-N", site)* ALink(1)*ILinkUp(3);
        W += sites_.op("N"    , site)* ALink(1)*ILinkUp(4);
      }
      else {
        W += sites_.op("Id" , site)* ALink(1)*ILinkUp(1);
      }
    }
  }

*/

}; //namespace itensor
