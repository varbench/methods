#include "AIM.hpp"
#include "forktps/fork/Bath.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/params.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>
#include <itensor/util/error.h>
#include <triqs/utility/exceptions.hpp>
#undef Print

#include <iostream>
#include <algorithm>
#include <string>
#include <vector>

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1)
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

//with hopping terms in MPOs we mostly use the following convention
//regarding the Fermi Operators p:
//We do not use "p" on the first site (first with respect to the fermionic order)
//and therefore also do not include the minus sign. ie.:
//c1^dag c3 + c3^dag c1 = c1^dag c3 - c1 c3^dag
//since the second term annihilates on site 1 it must be occupied. this means that
//moving c3^dag past the first site gives always a minus sign which cancels the minus sign above

namespace forktps {

  // clang-format off
  AIM::AIM(const SiteSet &sites, const dvec& eps, const dvec& V, double U, double Up,
                                           double J, int NArms, const Args &args)
     : sites(sites),
       hint(U, J, Up, args.getBool("DDonly", false) ),
       b(eps, V, NArms / 2),
       e0(eps, NArms / 2),
       E0_(args.getReal("E0Shift",0)),
       H(sites, b.NArms())
  {
    if (NArms % 2 != 0) 
      Error("AIM: NArms must be even! Got: " + std::to_string(NArms));
    
  }

  AIM::AIM(const SiteSet &sites, const Dmat& eps, const Cmat& V, double U, double Up, double J, int NArms,
                                           const Args &args)
     : sites(sites),
       hint( U, J, Up, args.getBool("DDonly", false) ) ,
       b(eps, V, int(NArms / 2)  ),
       e0(eps, int(NArms / 2) ),
       E0_(args.getReal("E0Shift",0)),
       H(sites, NArms)
  {
    if (NArms % 2 != 0) {
      Error("AIM: NArms must be even! Got: " + std::to_string(NArms));
    }
  }


  AIM::AIM(const SiteSet &sites, bath ba, hloc e0, H_int hint, const Args &args)
     : sites(sites),
       hint(std::move(hint)),
       b(std::move(ba)),
       e0(std::move(e0)),
       E0_(args.getReal("E0Shift",0)),
       H(sites, b.NBathVec() )
  {
    if(e0.isOffDiag())
      Error("AIM: off-diagonal e0 not implemented");

    if(ba.isSpinOrbit())
      Error("AIM: Cant use spin orbit bath with this FTPO!");
  }


  void AIM::init_() {
    auto ArmImpLinks = MakeArmMPOs();

    if(b.NArms() ==2){
      MakeOneOrbImpMPO(ArmImpLinks);
    }
    else {
      MakeImpMPO(ArmImpLinks);
    }
    return;
  }

  std::vector<Index> AIM::MakeArmMPOs() {
    std::vector<Index> ArmImpLinks(1);

    for (auto arm : range1(b.NArms())) {
      bool addP = (arm % 2 == 1 || e0.isOffDiag() );
      int numQN0 = addP ? 3 : 2;
      int NBath = H.NBath(arm), blockI(0);


      // means which quantum number has the link after C (CDag) has acted
      QN qnC    = - div( sites.op( "Ck",  H.ImpSite(arm)+1 ) );
      QN qnCDag = - div( sites.op( "CkD", H.ImpSite(arm)+1 ) );
      QN qn0    = - div( sites.op( "Id",  H.ImpSite(arm)+1 ) );
     
      // create links
      std::vector<Index> ArmLinks(NBath + 1);
      std::string blockName;

      if (arm % 2 == 1) {
        blockName = b.blockNameUp();
        blockI    = (arm - 1) / 2;
      } else {
        blockName = b.blockNameDn();
        blockI    = arm / 2 - 1;
      }

      for (auto l : range1(NBath)) {
        auto indxName = Names::TAGSB;
        if (l == NBath) indxName = Names::TAGSIB;

        ArmLinks.at(l) = Index(qn0, numQN0, qnC, 1, qnCDag, 1, Out, indxName);
      }

      // set tensors
      {
        int k      = 1;
        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);
        Index left = ArmLinks.at(k);
        W          = ITensor(dag(sites.si(site)), sites.siP(site), left);
        triqs_indx I = {blockName, blockI};

        //bath is zero indexed, k is one indexed
        W += sites.op("N", site) * setElt(left(1)) * b.eps(I, k - 1);
        W += sites.op("Id", site) * setElt(left(2));
        if (addP) W += sites.op("p", site) * setElt(left(numQN0));

        //bath is zero indexed, k is one indexed
        Complex amp = b.V(I, k - 1);
        W += sites.op("Ck", site) * setElt(left(numQN0 + 1))  *  amp;
        W += sites.op("CkD", site) * setElt(left(numQN0 + 2)) * -std::conj(amp);
      }

      for (int k = 2; k <= NBath; k++) {

        int site   = H.ArmToSite(arm, k);
        ITensor &W = H.Anc(site);

        Index right = dag(ArmLinks.at(k - 1));
        Index left  = ArmLinks.at(k);
        triqs_indx I = {blockName, blockI};

        W = ITensor(dag(sites.si(site)), sites.siP(site), left, right);

        W += sites.op("Id", site) * setElt(right(1), left(1));
        W += sites.op("Id", site) * setElt(right(2), left(2));
        if (addP) W += sites.op("p", site) * setElt(right(numQN0), left(numQN0));
        
        // bath on-site energies
        W += sites.op("N", site) * setElt(left(1), right(2)) * b.eps(I, k - 1);

        // bath hybridizations
        W += sites.op("p", site) * setElt(right(numQN0 + 1), left(numQN0 + 1));
        W += sites.op("p", site) * setElt(right(numQN0 + 2), left(numQN0 + 2));

        Complex amp = b.V(I, k - 1);
        W += sites.op("Ck", site)  * setElt(left(numQN0 + 1), right(2)) * amp;
        W += sites.op("CkD", site) * setElt(left(numQN0 + 2), right(2)) * -std::conj(amp);
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }


    return ArmImpLinks;
  }

  void AIM::MakeImpMPO(const std::vector<Index> &ArmImpLinks) {
    auto ImpLinks = GetImpLinks();



    //first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      int blockI   = (impIndx - 1) / 2;
      triqs_indx I = {b.blockNameUp(), blockI};
      
      double onSiteE = std::real( e0(I) );

      ITensor &W = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W = sites.op("Id", site)  * setElt(ALink(2), ILink(2));
      W += sites.op("Id", site) * setElt(ALink(1), ILink(1));
      W += sites.op("N", site)  * setElt(ALink(2), ILink(1)) * (onSiteE);
      W += sites.op("CkD*p", site)* setElt(ALink(4), ILink(1));
      W += sites.op("Ck*p", site) * setElt(ALink(5), ILink(1));

      W += sites.op("N", site)  * setElt(ALink(2), ILink(3));

      //SF-PH
      if (!hint.dd_only) {
        W += sites.op("CkD*p", site)  * setElt(ALink(3), ILink(4));
        W += sites.op("Ck*p", site) * setElt(ALink(3), ILink(5));
      }
    }

    //second Impurity site A_dn
    {
      int impIndx = 2;
      int site    = H.ImpSite(impIndx);
      int QN0 = 2;
      if(e0.isOffDiag()) QN0 += 1; // also down arms have p if e0 off-diag

      int blockI     = (impIndx) / 2 - 1;
      triqs_indx I = {b.blockNameDn(), blockI};
      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites.op("Id", site)  * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(3));

      //hybridization and bath energy terms:
      W += sites.op("Id", site) * setElt(ALink(1),     ILinkUp(2), ILinkDn(1));
      W += sites.op("N", site)  * setElt(ALink(2),     ILinkUp(2), ILinkDn(1)) * (onSiteE);
      W += sites.op("CkD*p", site)* setElt(ALink(QN0+1), ILinkUp(2), ILinkDn(1));
      W += sites.op("Ck*p", site) * setElt(ALink(QN0+2), ILinkUp(2), ILinkDn(1));

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1)) * (hint.U); //with nA_up nA_dn

      //Nk for other Impurities
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(4));

      //SF and PH terms: no ps needed here
      if (!hint.dd_only) {
        W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(4), ILinkDn(5));
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(6));
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(7));
        W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(5), ILinkDn(8));
      }

      if (e0.isOffDiag()) {
        W += sites.op("F"    , site) * setElt(ALink(3), ILinkUp(4), ILinkDn(9) );
        W += sites.op("F"    , site) * setElt(ALink(3), ILinkUp(5), ILinkDn(10));
        W += sites.op("CkD*p", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(11));
        W += sites.op("Ck*p" , site) * setElt(ALink(3), ILinkUp(2), ILinkDn(12));
      }
    }

    //impurities B_up, C_up ... except second to last
    for (int impIndx = 3; impIndx < b.NArms() - 1; impIndx += 2) {
      int site = H.ImpSite(impIndx);

      int blockI     = (impIndx - 1) / 2;
      triqs_indx I ={b.blockNameUp(), blockI};

      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W  = sites.op("Id", site)  * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(3));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(4));

      //hybridization and bath energy terms:
      W += sites.op("Id",  site)   * setElt(ALink(1), ILinkUp(2), ILinkDn(1));
      W += sites.op("N",   site)   * setElt(ALink(2), ILinkUp(2), ILinkDn(1)) * (onSiteE);
      W += sites.op("CkD*p", site) * setElt(ALink(4), ILinkUp(2), ILinkDn(1));
      W += sites.op("Ck*p",  site) * setElt(ALink(5), ILinkUp(2), ILinkDn(1));

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1)) * (hint.Up - hint.J); //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(1)) * (hint.Up);      //with n_mup n_ndn

      //Nk for other Impurities
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(5));

      //SF and PH terms:
      if (!hint.dd_only) {
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(6));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(6), ILinkDn(7));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(7), ILinkDn(8));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(8), ILinkDn(9));

        W += sites.op("CkD*p", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(10));
        W += sites.op("Ck*p", site)  * setElt(ALink(3), ILinkUp(2), ILinkDn(11));

        W += sites.op("Ck*p", site)  * setElt(ALink(3), ILinkUp(5), ILinkDn(12));
        W += sites.op("Ck*p", site)  * setElt(ALink(3), ILinkUp(6), ILinkDn(13));
        W += sites.op("CkD*p", site) * setElt(ALink(3), ILinkUp(7), ILinkDn(14));
        W += sites.op("CkD*p", site) * setElt(ALink(3), ILinkUp(8), ILinkDn(15));
      }

      if (e0.isOffDiag()) {
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(9), ILinkDn(16));
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(10), ILinkDn(17));
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(11), ILinkDn(18));
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(12), ILinkDn(19));

        W += sites.op("CkD", site)  * setElt(ALink(3), ILinkUp(2), ILinkDn(16));
        W += sites.op("Ck*p", site) * setElt(ALink(3), ILinkUp(2), ILinkDn(17));

        //W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(9), ILinkDn(1))  * 1.22;
        //W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(10), ILinkDn(1)) * 1.22;
      }
    }

    //impurities B_dn, C_dn ... except last
    for (int impIndx = 4; impIndx < b.NArms(); impIndx += 2) {
      int site = H.ImpSite(impIndx);
      int QN0 = 2;
      if(e0.isOffDiag()) QN0 += 1; // also down arms have p if e0 off-diag

      int blockI     = (impIndx) / 2 - 1;
      triqs_indx I{b.blockNameDn(), blockI};
      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W  = sites.op("Id",  site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(3), ILinkDn(3));
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(4), ILinkDn(4));

      //hybridization and bath energy terms:
      W += sites.op("Id",  site) * setElt(ALink(1), ILinkUp(2), ILinkDn(1));
      W += sites.op("N",   site) * setElt(ALink(2), ILinkUp(2), ILinkDn(1)) * (onSiteE);
      W += sites.op("CkD*p", site) * setElt(ALink(QN0+1), ILinkUp(2), ILinkDn(1));
      W += sites.op("Ck*p",  site) * setElt(ALink(QN0+2), ILinkUp(2), ILinkDn(1));

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1)) * (hint.Up);      //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(1)) * (hint.Up - hint.J); //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(1)) * (hint.U);           //with n_mup n_ndn

      //add Ns to corresponding entries
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(5), ILinkDn(3));
      W += sites.op("N",  site) * setElt(ALink(2), ILinkUp(2), ILinkDn(4));

      // SF and PH terms:
      if (!hint.dd_only) {
        // Finish
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(12), ILinkDn(1)) * (+hint.J);
        W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(13), ILinkDn(1)) * (-hint.J);
        W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(14), ILinkDn(1)) * (+hint.J);
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(15), ILinkDn(1)) * (-hint.J);

        //ids
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(6), ILinkDn(5));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(7), ILinkDn(6));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(8), ILinkDn(7));
        W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(9), ILinkDn(8));

        //add SF and PH terms to corresponding entries
        W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(10), ILinkDn(5));
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(10), ILinkDn(6));
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(11), ILinkDn(7));
        W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(11), ILinkDn(8));
      }

      if (e0.isOffDiag()) {
        W += sites.op("F", site) * setElt(ALink(2), ILinkUp(16), ILinkDn(9));
        W += sites.op("F", site) * setElt(ALink(2), ILinkUp(17), ILinkDn(10));
        W += sites.op("F", site) * setElt(ALink(2), ILinkUp(18), ILinkDn(11));
        W += sites.op("F", site) * setElt(ALink(2), ILinkUp(19), ILinkDn(12));

        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(11));
        W += sites.op("Ck*p", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(12));

        // Add sign if this should ever be necesary
        //W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(18), ILinkDn(1)) * 1.22;
        //W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(19), ILinkDn(1)) * 1.22;
      }
    }

    // second to last impurity
    {
      int impIndx = b.NArms() - 1;
      int site    = H.ImpSite(impIndx);
      ITensor &W  = H.Anc(site);

      int blockI     = (impIndx - 1) / 2;
      triqs_indx I{b.blockNameUp(), blockI};
      double onSiteE = std::real(e0(I));

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);
      Index ILinkDn = ImpLinks[impIndx];

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn);

      //Ids
      W = sites.op("Id", site) * setElt(ALink(2), ILinkUp(1), ILinkDn(1));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(2));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(3));
      W += sites.op("Id", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(4));

      //hybridization and bath energy terms:
      W += sites.op("Id",  site) * setElt(ALink(1), ILinkUp(2), ILinkDn(1));
      W += sites.op("N",   site) * setElt(ALink(2), ILinkUp(2), ILinkDn(1)) * (onSiteE);
      W += sites.op("CkD*p", site) * setElt(ALink(4), ILinkUp(2), ILinkDn(1));
      W += sites.op("Ck*p",  site) * setElt(ALink(5), ILinkUp(2), ILinkDn(1));

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3), ILinkDn(1)) * (hint.Up - hint.J); //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(4), ILinkDn(1)) * (hint.Up);      //with n_mup n_ndn

      //Nk for other Impurities
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(2), ILinkDn(5));

      //SF and PH terms:
      if (!hint.dd_only) {
        W += sites.op("Ck*p", site) * setElt(ALink(3), ILinkUp(5), ILinkDn(6));
        W += sites.op("Ck*p", site) * setElt(ALink(3), ILinkUp(6), ILinkDn(7));
        W += sites.op("CkD*p", site)  * setElt(ALink(3), ILinkUp(7), ILinkDn(8));
        W += sites.op("CkD*p", site)  * setElt(ALink(3), ILinkUp(8), ILinkDn(9));
      }

      if (e0.isOffDiag()) {
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(11), ILinkDn(10));
        W += sites.op("F", site) * setElt(ALink(3), ILinkUp(12), ILinkDn(11));

        // add sign if necessary
        //W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(9), ILinkDn(1))   * 1.22;
        //W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(10), ILinkDn(1)) * 1.22;
      }
    }

    // last impurity
    {
      int impIndx = b.NArms();
      int site   = H.ImpSite(impIndx);
      int QN0 = 2;
      if(e0.isOffDiag()) QN0 += 1;

      int blockI     = (impIndx) / 2 - 1;
      triqs_indx I{b.blockNameDn(), blockI};
      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);

      W = sites.op("Id", site) * setElt(ALink(2), ILinkUp(1));

      //hybridization and bath energy terms:
      W += sites.op("Id", site)  * setElt(ALink(1), ILinkUp(2));
      W += sites.op("N", site)   * setElt(ALink(2), ILinkUp(2)) * (onSiteE);
      W += sites.op("CkD*p", site) * setElt(ALink(QN0+1), ILinkUp(2));
      W += sites.op("Ck*p", site)  * setElt(ALink(QN0+2), ILinkUp(2));

      // add E0 term here
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3)) * (hint.Up);      //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(4)) * (hint.Up - hint.J); //with n_mup n_ndn
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(5)) * (hint.U);           //with n_mup n_ndn

      //finish Sf and PH terms:
      if ( !hint.dd_only) {
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(6))* (+hint.J);
        W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(7)) * (-hint.J);
        W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(8)) * (+hint.J);
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(9))* (-hint.J);
      }

      if (e0.isOffDiag()) {
        W += sites.op("Ck", site) * setElt(ALink(2), ILinkUp(10))  * 1.22;
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(11)) * 1.22;
      }
    }
  }


  void AIM::MakeOneOrbImpMPO(const std::vector<Index> &ArmImpLinks) {
    if( std::fabs(hint.J) > 1E-15 || std::fabs(hint.Up) > 1E-15 ){
      std::cout << hint << std::endl; 
      Error("J and U' must be zero for a one-band model.");
    }
    std::vector<Index> ImpLinks;
    ImpLinks.resize(b.NArms() + 1);


    QN qn0  = -div( sites.op("Id",  1) );
    QN cup  = -div( sites.op("Ck",  1) );
    QN cupD = -div( sites.op("CkD", 1) );
    //define indices
    {
      //Aup
      ImpLinks.at(1) = Index(qn0, 3, Out, Names::TAGSI);

      if(e0.isOffDiag())
        ImpLinks.at(1) = Index(qn0, 3, cupD, 1, cup, 1, Out, Names::TAGSI);
      
    }



    //first Impurity site A_up
    {
      int impIndx = 1;
      int site    = H.ImpSite(impIndx);

      int blockI     = (impIndx - 1) / 2;
      triqs_indx I{b.blockNameUp(), blockI};
      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink = dag(ArmImpLinks[impIndx]);
      Index ILink = ImpLinks[impIndx];
      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink);

      W = sites.op("Id", site)  * setElt(ALink(2), ILink(2)); 
      W += sites.op("Id", site) * setElt(ALink(1), ILink(1)); 
      W += sites.op("N", site)  * setElt(ALink(2), ILink(1)) * (onSiteE); 

      W += sites.op("CkD*p", site) * setElt(ALink(4), ILink(1));
      W += sites.op("Ck*p",  site) * setElt(ALink(5), ILink(1));


      W += sites.op("N", site)  * setElt(ALink(2), ILink(3));

      //hoppings
      if(e0.isOffDiag()){
        W += sites.op("CkD*p", site) * setElt(ALink(3), ILink(4));
        W += sites.op("Ck*p" , site) * setElt(ALink(3), ILink(5));
      }
    }

    //impurity A_dn
    {
      int impIndx = b.NArms();
      int site   = H.ImpSite(impIndx);

      int blockI     = (impIndx) / 2 - 1;
      triqs_indx I{b.blockNameDn(), blockI};
      double onSiteE = std::real(e0(I));

      ITensor &W = H.Anc(site);

      Index ALink   = dag(ArmImpLinks[impIndx]);
      Index ILinkUp = dag(ImpLinks[impIndx - 1]);

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp);

      W = sites.op("Id", site) * setElt(ALink(2), ILinkUp(1));

      //hybridization and bath energy terms:
      W += sites.op("Id", site)  * setElt(ALink(1), ILinkUp(2));
      W += sites.op("N", site)   * setElt(ALink(2), ILinkUp(2)) * (onSiteE);
      W += sites.op("CkD*p", site) * setElt(ALink(3), ILinkUp(2));
      W += sites.op("Ck*p",  site) * setElt(ALink(4), ILinkUp(2));


      // add E0 term here
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0_;

      //finish dens-dens interaction
      W += sites.op("N", site) * setElt(ALink(2), ILinkUp(3)) * (hint.U);           //with n_mup n_ndn

      if (e0.isOffDiag()) {
        W += sites.op("Ck", site)  * setElt(ALink(2), ILinkUp(4)); // not used!!!!
        W += sites.op("CkD", site) * setElt(ALink(2), ILinkUp(5));
      }
    }
  }


  std::vector<Index> AIM::GetImpLinks(){
    std::vector<Index> ImpLinks;
    ImpLinks.resize(b.NArms() + 1);

    QN qn0  = -div( sites.op( "Id",  H.ImpSite(1) ) );
    QN cup  = -div( sites.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = -div( sites.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = -div( sites.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = -div( sites.op( "CkD", H.ImpSite(2) ) );

    //Aup
    {
      int imp          = 1;
      ImpLinks.at(imp) = Index(qn0, 3, cupD, 1, cup, 1, Out, Names::TAGSI);

      if(e0.isOffDiag())
        ImpLinks.at(imp) = Index(qn0, 3, cupD, 1, cup, 1, cupD, 1, cup, 1, Out, Names::TAGSI);
    }

    // all links of down impurities are the same
    for (int imp = 2; imp < b.NArms(); imp += 2) {
      ImpLinks.at(imp) = Index( qn0, 4, 
                                cupD + cdn , 1, 
                                cupD + cdnD, 1, 
                                cup + cdnD , 1, 
                                cup + cdn  , 1, Out, Names::TAGSI);

      if (e0.isOffDiag()) {
        ImpLinks.at(imp) = Index(qn0, 4,
                                cupD + cdn,  1,   // SFPH
                                cupD + cdnD, 1,   // SFPH
                                cup + cdnD,  1,   // SFPH
                                cup + cdn,   1,   // SFPH
                                cupD, 1,          // off-diag e0
                                cup,  1,          // off-diag e0
                                cdnD, 1,          // off-diag e0
                                cdn,  1,          // off-diag e0
                                Out, Names::TAGSI);
      }
    }

    // all links of up impurities are the same (except E_dn)
    for (int imp = 3; imp < b.NArms() - 1; imp += 2) {
      ImpLinks.at(imp) = Index( qn0, 5, 
                                cupD + cdn,  1,         // SFPH carry past
                                cupD + cdnD, 1,         // SFPH carry past
                                cup + cdnD,  1,         // SFPH carry past
                                cup + cdn,   1,         // SFPH carry past
                                cupD, 1,                // SFPH new terms
                                cup,  1,                // SFPH new terms
                                cupD + cdn  + cup,  1,  // SFPH finish
                                cupD + cdnD + cup,  1,  // SFPH finish
                                cup  + cdnD + cupD, 1,  // SFPH finish
                                cup  + cdn  + cupD, 1,  // SFPH finish
                                Out, Names::TAGSI);

      if (e0.isOffDiag()) {
        ImpLinks.at(imp) = Index( qn0, 5, 
                                  cupD + cdn,  1,        // SFPH carry past
                                  cupD + cdnD, 1,        // SFPH carry past
                                  cup + cdnD,  1,        // SFPH carry past
                                  cup + cdn,   1,        // SFPH carry past
                                  cupD, 1,               // SFPH new terms
                                  cup,  1,               // SFPH new terms
                                  cupD + cdn  + cup,  1, // SFPH finish
                                  cupD + cdnD + cup,  1, // SFPH finish
                                  cup  + cdnD + cupD, 1, // SFPH finish
                                  cup  + cdn  + cupD, 1, // SFPH finish
                                  cupD, 1,               // off-diag e0
                                  cup,  1,               // off-diag e0
                                  cdnD, 1,               // off-diag e0
                                  cdn,  1,               // off-diag e0
                                  Out, Names::TAGSI);
      }
    }

    //finally define link between E_up and E_dn
    {
      int imp          = b.NArms() - 1;
      ImpLinks.at(imp) = Index( qn0, 5, 
                                cupD + cdn  + cup,  1,  // SFPH finish   
                                cupD + cdnD + cup,  1,  // SFPH finish 
                                cup  + cdnD + cupD, 1,  // SFPH finish 
                                cup  + cdn  + cupD, 1,  // SFPH finish
                                Out, Names::TAGSI);

      if (e0.isOffDiag()) {
        ImpLinks.at(imp) =
          Index(  qn0, 5, 
                  cupD + cdn  + cup,  1,  // SFPH finish   
                  cupD + cdnD + cup,  1,  // SFPH finish   
                  cup  + cdnD + cupD, 1,  // SFPH finish   
                  cup  + cdn  + cupD, 1,  // SFPH finish   
                  cdnD, 1,                // off-diag e0               
                  cdn,  1,                // off-diag e0
                  Out, Names::TAGSI);
      }
    }
  

    return ImpLinks;
  }

  // clang-format on

} // namespace forktps