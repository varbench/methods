#ifndef __MPO_AIMSF__
#define __MPO_AIMSF__

#include "../typenames.hpp"
#include "../ForkTPO.hpp"
#include "../Bath.hpp"
#include "../../params.hpp"

#include <itensor/mps/siteset.h>

#include <vector>

using namespace itensor;

namespace forktps {

  class AIM {
    public:
    /** Creates the FTPO of a fully degenerate diagonal AIM, using SiteSet *sites*.
    * @param sites      itensor::SiteSet
    *                   Defines the indices as well as the operators on each site.
    * @param eps        std::vector<double>
    *                   Vector of on-site energies (same on each arm). The zeroth entry is the on-site energy of the impurity.
    * @param V          std::vector<double>
    *                   Vector of hopping amplitudes to the bath (same on each arm). 
    * @param U          double
    *                   Coulomb interaction U.
    * @param Up         double
    *                   Coulomb interaction U' (usually U-2J).
    * @param J          double
    *                   Hund's coupling.
    * @param NArms      int
    *                   Number of arms of the forkMPO.
    * @param args       itensor::Args
    *                   Argument list that can take the following entries:
    * @param E0Shift    double (default 0.)
    *                   Shift of the Hamiltonian: H -> H + E0Shift*ID.
    * @param DDonly     bool (default false)
    *                   If true, spin-flip and pair-hopping terms are neglected.
    */
    AIM(const SiteSet &sites, const dvec &eps, const dvec &V, double U, double Up, double J, int NArms, const Args &args);

    /** Creates the FTPO using SiteSet *sites*, with parameters specified in *ba*, *e0* and *hint*.
    * @param sites      itensor::SiteSet
    *                   Defines the indices as well as the operators on each site.
    * @param eps        Dmat aka std::vector<std::vector<double>>
    *                   Matrix with on-site energies (one indexed in the second dimension) i.e.: eps[0][3] is the on-site energy of the third bath site on the first arm.
    * @param V          Cmat aka std::vector<std::vector<Complex>>
    *                   Complex matrix of hopping amplitudes (zero indexed in both dimensions). 
    *                   i.e., V[0][2] is the amplitude of the hopping of the first impurity site to the third bath site.
    * @param U          double
    *                   Coulomb interaction U.
    * @param Up         double
    *                   Coulomb interaction U' (usually U-2J).
    * @param J          double
    *                   Hund's coupling.
    * @param NArms      int
    *                   Number of arms of the forkMPO.
    * @param args       itensor::Args
    *                   Argument list that can take the following entries:
    * @param E0Shift    double (default 0.)
    *                   Shift of the Hamiltonian: H -> H + E0Shift*ID.
    * @param DDonly     bool (default false)
    *                   If true, spin-flip and pair-hopping terms are neglected.
    */
    AIM(const SiteSet &sites, const Dmat &eps, const Cmat &V, double U, double Up, double J, int NArms, const Args &args);

    /** Creates the FTPO using SiteSet *sites*, with parameters specified in *ba*, *e0* and *hint*.
    * @param sites      itensor::SiteSet
    *                   Defines the indices as well as the operators on each site.
    * @param ba         bath
    *                   Bath object storing the bath parameters $\epsilon_k$ and $V_k$.
    * @param e0         hloc
    *                   Non-interacting Hamiltonian of the impurity.
    * @param hint       H_int
    *                   Interaction Hamiltonian.
    * @param args       itensor::Args
    *                   Argument list that can take the following entries
    * @param E0Shift    double (default 0.)
    *                   Shift of the Hamiltonian: H -> H + E0Shift*ID
    */
    AIM(const SiteSet &sites, bath ba, hloc e0, H_int hint, const Args &args);

    /// Creates and returns the ForkTPO that was created.
    operator ForkTPO() {
      init_();
      return H;
    }

    private:
    /// Creates the tensors on all arms representing the bath sites. Returns a one-indexed vector containing the link indices connecting the arms to the impurities.
    std::vector<Index> MakeArmMPOs();

    void MakeImpMPO(const std::vector<Index> &ArmImpLinks);

    void MakeOneOrbImpMPO(const std::vector<Index> &ArmImpLinks);

    std::vector<Index> GetImpLinks();

    /// The itensor SiteSet providing the local operators and site-indices
    const SiteSet &sites;

    /// Interaction parameters
    H_int hint;

    /// Bath, providing bath parameters.
    bath b;
    /// Non-interacting impurity Hamiltonian
    hloc e0;

    /// Constant energy shift: H -> H - E0 * ID
    double E0_;

    /// The Hamiltonian in FTPO form.
    ForkTPO H;

    ///
    //////////////////////

    void init_();
  };

} // namespace forktps

#endif
