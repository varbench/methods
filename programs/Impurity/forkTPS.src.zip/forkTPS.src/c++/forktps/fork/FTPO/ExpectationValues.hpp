#include <iostream>
#include <algorithm>
#include <utility>
#include <vector>
#include "itensor/mps/siteset.h"
#include "itensor/mps/mps.h"
#include "itensor/itensor.h"

#include "../typenames.hpp"
#include "../ForkTPO.hpp"
#include "../Bath.hpp"
#include "../ForkCalculus.hpp"

#ifndef __AIM_EXPECTATIONOPS_
#define __AIM_EXPECTATIONOPS_

using namespace itensor;

namespace forktps {

  /// Constructes the MPO of N, where N is the total number of particles
  ForkTPO NTot(const SiteSet &sites, std::vector<int> Nbs);

  /// Constructes the MPO of N^2, where N is the total number of particles
  ForkTPO NTot2(const SiteSet &sites, std::vector<int> Nbs);

  /// Constructes the MPO of N, where N is the total number of particles on the arm arm
  ForkTPO NTot_Arm(const SiteSet &sites, std::vector<int> Nbs, int arm);

  /// Constructes the MPO of N^2, where N is the total number of particles on the arm arm
  ForkTPO NTot2_Arm(const SiteSet &sites, std::vector<int> Nbs, int arm);

  /// calculates <N> and <N^2>, where N is the total number of particles on the arm arm
  std::pair<double, double> MeasureArmN(int arm, ForkTPS &psi);

  /// calculates <N> and <N^2>, where N is the total number of particles
  std::pair<double, double> MeasureTotN(ForkTPS &psi);

  /// calculates for each arm <N> and <N^2>, where N is the total number of particles on the arm
  std::vector<std::pair<double, double>> MeasureAllArmN(ForkTPS &psi);

} // namespace forktps

#endif
