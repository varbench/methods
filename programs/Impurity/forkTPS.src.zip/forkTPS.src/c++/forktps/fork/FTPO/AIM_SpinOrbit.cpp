#include "AIM_SpinOrbit.hpp"
#include "../HelperFunctions.hpp"
#include "forktps/fork/Bath.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/params.hpp"
#include <string>
#include <vector>

using namespace itensor;

//to write it once and for all: IQINDICES of operators:

//c_up^D: has a change in bond indices by (-1,-1) ( ie form for example (0,0) to (-1,-1) )
//c_up  : has a change in bond indices by ( 1, 1)

//c_dn^D: has a change in bond indices by ( 1,-1)
//c_dn  : has a change in bond indices by (-1, 1)

namespace forktps {

  AIM_SpinOrbit::AIM_SpinOrbit(const SiteSet &sites, bath b, hloc e0, H_int hint, const Args &args)
     : sites(sites), hint(hint), b(std::move(b)), e0(std::move(e0)) {
    blockName1 = this->b.blockNameUp();
    blockName2 = this->b.blockNameDn();

    H  = ForkTPO(sites, this->b.NBathVec());
    E0 = args.getReal("E0Shift", 0);
  }

  void AIM_SpinOrbit::init_() {

    if (b.NArms() == 6) {
      auto ArmImpLinks = MakeThreeOrbitalArmMPOs();
      MakeThreeOrbitalMPO(ArmImpLinks);
    } else {
      Error("AIM_SpinOrbit: Cannot create AIM_ForkTPO_NonDiagBath with this number of orbitals: " + std::to_string(b.NArms()));
    }
  }

  // clang-format off



  std::vector<Index> AIM_SpinOrbit::MakeThreeOrbitalArmMPOs(){
    //ek_ is a matrix of on-site energies
    //and Vk_ a matrix where for each orbital the first index is zero,
    //the entry one to Nbath are the hoppings into orbital A
    //Nbath+1 to 2*Nbath are the hoppings into orbital B
    //and 2*Nbath+1 to 3*Nbath is the hoppint into orbital C


    // Vk_ is such that std::conj(Vk_) is used for the hopping where the creation operator acts in the bath i.e.: std::conj(Vk_) * c_k^\dag c_I
    std::vector<Index> ArmImpLinks{Index()};

    for(int arm = 1; arm <= b.NArms(); arm++) {

      const int NBath =H.NBath(arm);
      int blockI = 0, blockSize = 0;
      std::vector<Index> ArmLinks(NBath+1);
      std::string blockName;
      //std::cout << "-------------------------------------------"<<std::endl;
      //std::cout << "-------------------------------------------"<<std::endl;

      QN qnC    = - div( sites.op( "Ck",  H.ImpSite(arm) ) );
      QN qnCDag = - div( sites.op( "CkD", H.ImpSite(arm) ) );
      QN qn0    = - div( sites.op( "Id",  H.ImpSite(arm) ) );

      if( arm == 1 || arm == 4 || arm ==6 ){
        blockName = blockName1;
        blockI = (arm == 1) ? 0 : int(arm/2)-1; // arm 1 has index 0, arm 4 has index 1, arm 6 has index 2
      }
      else {
        blockName = blockName2;
        blockI = (arm == 2) ? 0 : int((arm-1)/2); // arm 2 has index 0, arm 3 has index 1, arm 5 has index 2
      }
      blockSize = b.blockSize(blockName);

      //create links
      for(int l=1;l<=NBath;l++)
      {
        std::string indxName = Names::TAGSB;
        if(l == NBath)
          indxName = Names::TAGSIB;
        

        if( arm == 1 || arm == 2 ){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,   
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
          
        }
        else if ( arm == 3 || arm == 4 ){
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );

        }
        else{
          ArmLinks.at(l) = Index( qn0,    3,
                                  qnC,    1,
                                  qnCDag, 1,  Out, indxName );
        }
      }
      
      
      // n == 1
      {
        int k = 1;
        int site = H.ArmToSite(arm,1);
        ITensor& W =H.Anc(site);
        Index left=ArmLinks.at(1);
        triqs_indx I{blockName, blockI};
        W=ITensor(dag(sites.si(site)), sites.siP(site),left);


        W += sites.op("N"  ,site)*setElt( left(1) )* b.eps(I, k-1);
        W += sites.op("p"  ,site)*setElt( left(3) );
        //std::cout<< "Use " << * b.eps(blockName, blockI, k-1) << " for on-site energy"<<std::endl;

        W += sites.op("Id" ,site)*setElt( left(2) );

        //diagonal
        
        Complex amp = b.V(I, I, k-1 );
        W += sites.op("Ck" ,site)*setElt( left(4) )*           amp  ;  //V is the hopping onto impurity ie C in bath
        W += sites.op("CkD",site)*setElt( left(5) )*std::conj(-amp );  //Vdag is the hopping onto bath ie CD in bath

        int offset = 0;
        for(auto bJ = blockI+1; bJ < blockSize; bJ++ ){
          triqs_indx J{blockName, bJ};
          amp = b.V(I, J, k-1 );
          // In the fermionic order, this bath site comes before the impurity!
          // the hopping is defined as 
          // V cI^D cB + V* cB^D cI =  - V cB cI^d + V* cB cI^D. 
          // so here the V-term has a minus sign not the V*-term
          W += sites.op("Ck*p" ,site)*setElt( left( 5+offset+1 ) )*         (-amp);    //V is the hopping onto impurity ie C in bath
          W += sites.op("CkD*p",site)*setElt( left( 5+offset+2 ) )*std::conj( amp );  //Vdag is the hopping onto bath ie CD in bath
          offset += 2;
        }
      }
      
      for(int k=2; k<=NBath; k++){

        int site = H.ArmToSite(arm,k);
        ITensor& W =H.Anc(site);

        Index right =dag(ArmLinks.at(k-1));
        Index left  =    ArmLinks.at(k)   ;

        triqs_indx I{blockName, blockI};

        W=ITensor(dag(sites.si(site)), sites.siP(site),left,right);

        W += sites.op("Id",site)*setElt( right(2), left(2) ); //ids
        W += sites.op("Id",site)*setElt( right(1), left(1) );
        W += sites.op("p" ,site)*setElt( right(3), left(3) ); 
        W += sites.op("p" ,site)*setElt( right(4), left(4) ); 
        W += sites.op("p" ,site)*setElt( right(5), left(5) ); //ps
        W += sites.op("N" ,site)*setElt( right(2), left(1) )* b.eps(I, k-1); //on-site energy


        //diagonal
        Complex amp = b.V(I, I, k-1 );
        W += sites.op("Ck" ,site)*setElt( left(4), right(2) )*           amp ;  //V is the hopping onto impurity ie C in bath
        W += sites.op("CkD",site)*setElt( left(5), right(2) )*std::conj(-amp);  //Vdag is the hopping onto bath ie CD in bath
        //std::cout<<"Arm "<< arm <<" k "<< k<<std::endl <<"    Diag term:  "<< amp<<std::endl;
        //std::cout<< "Use " << b.eps(I, k-1) << " for on-site energy"<<std::endl;

        //offdiagonal
        int offset = 0;
        for(auto bJ = blockI+1; bJ < blockSize; bJ++){
          triqs_indx J{blockName, bJ};
          W += sites.op("Id",site)*setElt( left(5+offset+1), right(5+offset+1) );
          W += sites.op("Id",site)*setElt( left(5+offset+2), right(5+offset+2) );

          amp = b.V(I, J, k-1);
          // In the fermionic order, this bath site (B) comes before the impurity (I)!
          // the hopping is defined as 
          // V cI^D cB + V* cB^D cI =  - V cB cI^d + V* cB cI^D. 
          // so here the V-term has a minus sign not the V*-term
          W += sites.op("Ck*p" ,site)*setElt( left( 5+offset+1 ), right(3) )*         (-amp);  //V is the hopping onto impurity ie C in bath
          W += sites.op("CkD*p",site)*setElt( left( 5+offset+2 ), right(3) )*std::conj( amp);  //Vdag is the hopping onto bath ie CD in bath
          offset += 2;
        }
      }

      //store last link for Impurity tensors
      ArmImpLinks.push_back(ArmLinks.at(NBath));
    }

    return ArmImpLinks;

  }

  void AIM_SpinOrbit::MakeThreeOrbitalMPO( const std::vector<Index>& ArmImpLinks ){
    
    auto ImpLinks = GetImpLinks();
    //std::cout << "Done creating Impurity Links .....  First Impurity Site\n";
    //first Impurity site
    {

      int impIndx=1;
      int site = H.ImpSite(impIndx);

      std::string blockName = blockName1;
      int blockI = 0;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);
      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILink = ImpLinks.at(impIndx);

      W=ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILink );

      W += sites.op("Id",site) * setElt( ALink(1), ILink(1) );
      // big ID
      W += sites.op("Id",site) * setElt( ALink(2), ILink(2) );

      // diagonal hybridizations and on-site energies
      W += sites.op("N",site)  * setElt( ALink(2), ILink(1) )*onSiteE;
      W += sites.op("CkD*p",site)* setElt( ALink(4), ILink(1) );
      W += sites.op("Ck*p",site) * setElt( ALink(5), ILink(1) );


      // density-density terms
      W += sites.op("N",site) * setElt( ALink(2), ILink(3) );


      // ----  off diag terms -----
      // imp-imp hoppings
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILink(4) )* (-e0({blockName, 1},  I              )); // From B to A
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILink(5) )* (+e0(I,               {blockName, 1} )); // From A to B
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILink(6) )* (-e0({blockName, 2},  I              )); // From C to A
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILink(7) )* (+e0(I,               {blockName, 2} )); // From A to C
      // off-diag hybridizations
      W += sites.op("Id",site) * setElt( ALink(6), ILink(4) ); 
      W += sites.op("Id",site) * setElt( ALink(7), ILink(5) ); 
      W += sites.op("Id",site) * setElt( ALink(8), ILink(6) ); 
      W += sites.op("Id",site) * setElt( ALink(9), ILink(7) ); 


      //SF-PH
      if(!hint.dd_only){
        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILink(8) );
        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILink(9) );
      }
    }

    //second Impurity site
    {
      int impIndx=2;
      int site = H.ImpSite(impIndx);

      std::string blockName = blockName2;
      int blockI = 0;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink   = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn );

      // Hfin
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      // big ID
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );


      // diagonal hybridizations and on-site energies      
      W += sites.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )*onSiteE;
      W += sites.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // density-density terms
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) );
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) ); 
      // finish DD (NAdn)
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.U); 	//with NAup, 

      
      // ----  off diag terms -----
      // imp-imp hoppings
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2),ILinkDn(9)  )* (-e0( {blockName, 1}, I              )); // From B to A
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2),ILinkDn(10) )* (+e0( I,              {blockName, 1} )); // From A to B
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2),ILinkDn(11) )* (-e0( {blockName, 2}, I              )); // From C to A
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2),ILinkDn(12) )* (+e0( I,              {blockName, 2} )); // From A to C
      
      // hybridizations from above
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(4), ILinkDn(5) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(5), ILinkDn(6) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(6), ILinkDn(7) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(7), ILinkDn(8) );

      // hybridizations from bath
      W += sites.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(9) );
      W += sites.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(10));
      W += sites.op("Id",site) * setElt( ALink(8), ILinkUp(2), ILinkDn(11));
      W += sites.op("Id",site) * setElt( ALink(9), ILinkUp(2), ILinkDn(12));


      //SF-PH
      if(!hint.dd_only){
        W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(8), ILinkDn(13) ); //cD*c 
        W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(8), ILinkDn(14) ); //cD*cD 
        W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(9), ILinkDn(15) ); //c*cD 
        W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(9), ILinkDn(16) ); //c*c 
      }
    }

    //third Impurity site B-up
    {
      int impIndx=3;
      int site = H.ImpSite(impIndx);

      std::string blockName = blockName2;
      int blockI = 1;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );


      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn );

      // Hfin
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      // big ID
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );


      // diagonal hybridizations and on-site energies  
      W += sites.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );


      // density-density terms
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); // NAup
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); // NAdn
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) );

      // finish DD (NBup)
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up-hint.J);	// with NAup
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up);	      // with NADn


      // ----  off diag terms -----
      // imp-imp hoppings
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(10) ) * (-e0( {blockName, 2}, I             )); // From C to B
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(11) ) * (+e0( I,              {blockName,2} )); // From B to C
      
      // terms from above
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(5) , ILinkDn(6) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(6) , ILinkDn(7) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(7) , ILinkDn(8) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(8) , ILinkDn(9) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10));
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11));

      // hybridizations from bath
      W += sites.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(10) );
      W += sites.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(11) );

      // finish off-diag hopping
      W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(9) , ILinkDn(1) );
      W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(10), ILinkDn(1) );


      //SF-PH 
      if(!hint.dd_only){
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(12) ); //Ids for cD*c 
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(13) ); //Ids for cD*cD 
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(14) ); //Ids for c*cD 
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(16), ILinkDn(15) ); //Ids for c*c 

        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(2), ILinkDn(16) ); //add new terms
        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(2), ILinkDn(17) ); //add new terms

        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(13), ILinkDn(18) ); //cD*c*c
        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(14), ILinkDn(19) ); //cD*cD*c 
        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(15), ILinkDn(20) ); //c*cD*cD
        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(16), ILinkDn(21) ); //c*c*cD
      }
    }

    //fourth Impurity site B-dn
    {
      int impIndx=4;
      int site = H.ImpSite(impIndx);
      std::string blockName = blockName1;
      int blockI = 1;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );


      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn );

      // Hfin 
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) );
      // big ID
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) );


      // diagonal hybridizations and on-site energies  
      W += sites.op("Id",site)  * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites.op("N",site)   * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )* onSiteE;
      W += sites.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // density-density terms
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); // NAup
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); // NAdn
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(5), ILinkDn(3) ); // NBup
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(4) );

      // finish DD (NBdn)
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up);        //with NAup
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up-hint.J);	//with NAdn
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(5), ILinkDn(1) )*(hint.U);	        //with NBup

      // ----  off diag terms -----
      // imp-imp hoppings
      W += sites.op("Ck*p",site)  * setElt( ALink(3), ILinkUp(2), ILinkDn(5)) * (-e0({blockName, 2}, I              )); // From C to B
      W += sites.op("CkD*p",site) * setElt( ALink(3), ILinkUp(2), ILinkDn(6)) * (+e0(I,              {blockName, 2} )); // From B to C

      // terms from above
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(8),  ILinkDn(5) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(9),  ILinkDn(6) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(10), ILinkDn(7) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(11), ILinkDn(8));

      // hybridizations from bath
      W += sites.op("Id",site) * setElt( ALink(6), ILinkUp(2), ILinkDn(5) );
      W += sites.op("Id",site) * setElt( ALink(7), ILinkUp(2), ILinkDn(6) );

      // finish off-diag hopping
      W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(6), ILinkDn(1) );
      W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7), ILinkDn(1) );

      //SF PH
      if(!hint.dd_only){
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(18), ILinkDn(1) )*( hint.J); //finish
        W += sites.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(19), ILinkDn(1) )*(-hint.J); //finish
        W += sites.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(20), ILinkDn(1) )*( hint.J); //finish
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(21), ILinkDn(1) )*(-hint.J); //finish

        W += sites.op("Ck", site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(9) );  // cD*c
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(16), ILinkDn(10) ); // cD*cD
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(11) ); // c*cD
        W += sites.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(17), ILinkDn(12) ); // c*c

        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(12), ILinkDn(9) );  // cD*c
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(13), ILinkDn(10) ); // cD*cD
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(14), ILinkDn(11) ); // c*cD
        W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(15), ILinkDn(12) ); // c*c
      }

    }

    //fifth Impurity site C-up
    {
      
      int impIndx=5;
      int site = H.ImpSite(impIndx);
      std::string blockName = blockName2;
      int blockI = 2;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );
      Index ILinkDn =      ImpLinks.at(impIndx);

      W=ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp, ILinkDn );

      // Hfin
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(1), ILinkDn(1) ); 
      // big ID 
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(2), ILinkDn(2) ); 
       
      // diagonal hybridizations and on-site energies      
      W += sites.op("Id",site)    * setElt( ALink(1), ILinkUp(2), ILinkDn(1) );
      W += sites.op("N",site)     * setElt( ALink(2), ILinkUp(2), ILinkDn(1) )*onSiteE;
      W += sites.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2), ILinkDn(1) );
      W += sites.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2), ILinkDn(1) );

      // density-density terms
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(3), ILinkDn(3) ); // NAup + NBup
      W += sites.op("Id",site) * setElt( ALink(2), ILinkUp(4), ILinkDn(4) ); // NAdn + NBdn
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(2), ILinkDn(5) ); // NCup
      
      // finish DD (NCup)
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(3), ILinkDn(1) )*(hint.Up-hint.J);	// with NAup + NBup
      W += sites.op("N",site)  * setElt( ALink(2), ILinkUp(4), ILinkDn(1) )*(hint.Up);	      // with NAdn + NBdn

  
      // ----  off diag terms -----
      // terms from above
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(5), ILinkDn(6) );
      W += sites.op("p",site) * setElt( ALink(3), ILinkUp(6), ILinkDn(7) );

      // finish off-diag hopping
      W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(7), ILinkDn(1) );
      W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(8), ILinkDn(1) );

      // SF PH
      if(!hint.dd_only){
        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(9),  ILinkDn(8) );
        W += sites.op("Ck*p",site)   * setElt( ALink(3), ILinkUp(10), ILinkDn(9) );
        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(11), ILinkDn(10) ); //CD*p = CD
        W += sites.op("CkD*p" ,site) * setElt( ALink(3), ILinkUp(12), ILinkDn(11) ); //CD*p = CD
      }
      
    }

    //last impurity
    {
      int impIndx=b.NArms();
      int site = H.ImpSite(impIndx);
      std::string blockName = blockName1;
      int blockI = 2;
      triqs_indx I{blockName, blockI};
      double onSiteE = std::real( e0(I) );

      ITensor& W= H.Anc(site);

      Index ALink = dag(ArmImpLinks.at(impIndx));
      Index ILinkUp = dag( ImpLinks.at(impIndx-1) );

      W = ITensor(dag(sites.si(site)), sites.siP(site), ALink, ILinkUp );

      // Hfin
      W += sites.op("Id",site)  * setElt( ALink(2), ILinkUp(1) );   
      
      // on-site energy and bath hybridization with local bath  
      W += sites.op("Id",site)  * setElt( ALink(1), ILinkUp(2) );
      W += sites.op("N",site)   * setElt( ALink(2), ILinkUp(2) )* onSiteE;
      W += sites.op("CkD*p",site) * setElt( ALink(4), ILinkUp(2) );
      W += sites.op("Ck*p",site)  * setElt( ALink(5), ILinkUp(2) );

      // add E0 term ( H -> H - E0 ID)
      W += sites.op("Id", site)  * setElt(ALink(2), ILinkUp(2)) * E0;

      // finish DD (NCdn)
      W += sites.op("N",site) * setElt( ALink(2), ILinkUp(3) )*( hint.Up    );	    // with NAup + NBup
      W += sites.op("N",site) * setElt( ALink(2), ILinkUp(4) )*( hint.Up-hint.J );  // with NAdn + NBdn
      W += sites.op("N",site) * setElt( ALink(2), ILinkUp(5) )*( hint.U         );	// with NCup

      // ----  off diag terms -----
      // finish off-diag hopping
      W += sites.op("CkD",site) * setElt( ALink(2), ILinkUp(6) );
      W += sites.op("Ck" ,site) * setElt( ALink(2), ILinkUp(7) );

      // SF PH
      if(!hint.dd_only){
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(8)  )*(+hint.J);
        W += sites.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(9)  )*(-hint.J);
        W += sites.op("Ck" ,site)  * setElt( ALink(2), ILinkUp(10) )*(+hint.J);
        W += sites.op("CkD",site)  * setElt( ALink(2), ILinkUp(11) )*(-hint.J);
      }
      
    }

  }

  std::vector<Index> AIM_SpinOrbit::GetImpLinks(){
    
    QN qn0  = - div( sites.op( "Id",  H.ImpSite(1) ) );
    QN cup  = - div( sites.op( "Ck",  H.ImpSite(1) ) );
    QN cupD = - div( sites.op( "CkD", H.ImpSite(1) ) );
    QN cdn  = - div( sites.op( "Ck",  H.ImpSite(2) ) );
    QN cdnD = - div( sites.op( "CkD", H.ImpSite(2) ) );

    std::vector<Index> ImpLinks; ImpLinks.resize(b.NArms()+1);

    //create links:
    if ( !hint.dd_only ) {
      ImpLinks.at(1) = Index(     qn0,    3,
                                  cup,    1, // hopping orb Bdn to orb Aup
                                  cupD,   1, // hopping orb Aup to orb Bdn
                                  cup,    1, // hopping orb Cdn to orb Aup
                                  cupD,   1, // hopping orb Aup to orb Cdn
                                  cupD,   1,   //SF and PH
                                  cup,    1,   //SF and PH
                                  Out, Names::TAGSI ); 
    

    
      ImpLinks.at(2) = Index(   qn0,      4,

                                cup,      1, // hopping orb Bdn to orb Aup
                                cupD,     1, // hopping orb Aup to orb Bdn
                                cup,      1, // hopping orb Cdn to orb Aup
                                cupD,     1, // hopping orb Aup to orb Cdn
                                cdn,      1, // hopping orb Bup to orb Adn
                                cdnD,     1, // hopping orb Adn to orb Bup
                                cdn,      1, // hopping orb Cup to orb Adn
                                cdnD,     1, // hopping orb Adn to orb Cup

                                cupD+cdn, 1,   //C_upD*C_dn  - SFPH
                                cupD+cdnD,1,   //C_upD*C_dnD - SFPH
                                cup+cdnD, 1,   //C_up *C_dnD - SFPH
                                cup+cdn,  1,   //C_up*C_dn - SFPH
                                Out, Names::TAGSI  ); 
    

    
      ImpLinks.at(3) = Index(   qn0,        5,

                                cup,        1,   // hopping orb Bdn to orb Aup
                                cupD,       1,   // hopping orb Aup to orb Bdn
                                cup,        1,   // hopping orb Cdn to orb Aup
                                cupD,       1,   // hopping orb Aup to orb Cdn
                                cdn,        1,   // hopping orb Cup to orb Adn (also Bup to Cup)
                                cdnD,       1,   // hopping orb Adn to orb Cup (also Cup to Bup)

                                cupD+cdn,   1, // C_upD* C_dn  - SFPH
                                cupD+cdnD,  1, // C_upD* C_dnD - SFPH
                                cup+cdnD,   1, // C_up * C_dnD - SFPH
                                cup+cdn,    1, // C_up * C_dn  - SFPH    

                                cupD,       1,  //C_upD - SFPH
                                cup,        1,  //C_upD - SFPH

                                cupD+cdn+cup,  1, //C_upD* C_dn * C_up - SFPH
                                cupD+cdnD+cup, 1, //C_upD* C_dnD* C_up - SFPH
                                cup+cdnD+cupD, 1, //C_up * C_dnD* C_upD- SFPH
                                cup+cdn+cupD,  1, //C_up * C_dn * C_upD- SFPH
                                Out, Names::TAGSI );
    

    
      ImpLinks.at(4) = Index( qn0,    4,

                              cup,  1,  // hopping orb Cdn to orb Aup (also Cdn to Bdn )
                              cupD, 1,  // hopping orb Aup to orb Cdn (also Bdn to Cdn )
                              cdn,  1,  // hopping orb Cup to orb Adn (also Cup to Bup )
                              cdnD, 1,  // hopping orb Adn to orb Cup (also Bup to Cup )

                              cupD+cdn,  1, // C_upD* C_dn  - SFPH
                              cupD+cdnD, 1, // C_upD* C_dnD - SFPH
                              cup+cdnD,  1, // C_up * C_dnD - SFPH
                              cup+cdn,   1, // C_up * C_dn  - SFPH     
                              Out, Names::TAGSI );
    

    
      ImpLinks.at(5) = Index(   qn0,      5,

                                cup,      1, // hopping orb Cdn to orb Aup (also Cdn to Bdn )
                                cupD,     1, // hopping orb Aup to orb Cdn (also Bdn to Cdn )

                                cupD+cdn+cup,  1, //C_upD* C_dn * C_up - SFPH
                                cupD+cdnD+cup, 1, //C_upD* C_dnD* C_up - SFPH
                                cup+cdnD+cupD, 1, //C_up * C_dnD* C_upD- SFPH
                                cup+cdn+cupD,  1, //C_up * C_dn * C_upD- SFPH
                                Out, Names::TAGSI );
    }
    else {
      ImpLinks.at(1) = Index(     qn0,    3,
                                  cup,    1, // hopping orb Bdn to orb Aup
                                  cupD,   1, // hopping orb Aup to orb Bdn
                                  cup,    1, // hopping orb Cdn to orb Aup
                                  cupD,   1, // hopping orb Aup to orb Cdn
                                  Out, Names::TAGSI ); 
    

    
      ImpLinks.at(2) = Index(   qn0,      4,
                                cup,      1, // hopping orb Bdn to orb Aup
                                cupD,     1, // hopping orb Aup to orb Bdn
                                cup,      1, // hopping orb Cdn to orb Aup
                                cupD,     1, // hopping orb Aup to orb Cdn
                                cdn,      1, // hopping orb Bup to orb Adn
                                cdnD,     1, // hopping orb Adn to orb Bup
                                cdn,      1, // hopping orb Cup to orb Adn
                                cdnD,     1, // hopping orb Adn to orb Cup
                                Out, Names::TAGSI  ); 
    

    
      ImpLinks.at(3) = Index(   qn0,        5,
                                cup,        1,   // hopping orb Bdn to orb Aup
                                cupD,       1,   // hopping orb Aup to orb Bdn
                                cup,        1,   // hopping orb Cdn to orb Aup
                                cupD,       1,   // hopping orb Aup to orb Cdn
                                cdn,        1,   // hopping orb Cup to orb Adn (also Bup to Cup)
                                cdnD,       1,   // hopping orb Adn to orb Cup (also Cup to Bup)
                                Out, Names::TAGSI );
    

    
      ImpLinks.at(4) = Index(   qn0,  4,
                                cup,  1,  // hopping orb Cdn to orb Aup (also Cdn to Bdn )
                                cupD, 1,  // hopping orb Aup to orb Cdn (also Bdn to Cdn )
                                cdn,  1,  // hopping orb Cup to orb Adn (also Cup to Bup )
                                cdnD, 1,  // hopping orb Adn to orb Cup (also Bup to Cup )
                                Out, Names::TAGSI );
    

    
      ImpLinks.at(5) = Index(   qn0,      5,
                                cup,      1, // hopping orb Cdn to orb Aup (also Cdn to Bdn )
                                cupD,     1, // hopping orb Aup to orb Cdn (also Bdn to Cdn )
                                Out, Names::TAGSI );
    }

    return ImpLinks;
  }



















} //namespace itensor
