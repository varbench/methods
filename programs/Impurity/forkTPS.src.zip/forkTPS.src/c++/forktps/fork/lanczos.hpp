#ifndef __FORKLANZCOS__
#define __FORKLANZCOS__

#include "EigSolver.hpp"
#include "HelperFunctions.hpp"

#include <itensor/itensor.h>
#undef Print

#include <itertools/itertools.hpp>

using namespace itensor;

namespace forktps::ED {

  /** \file lanczos.h
 * In this file we implement lanczos functions used by DMRG or TDVP
 */

  /**
  * Calculates the ground state of matrix *H* with the lanzcos algorithm using
  * *phi* as a starting vector. It accepts any object as matrix, as long as the
  * member H.product( ITensor ... ) is defined.
  * @param H      template
  *               Needs to implement the function product with an ITensor.
  * @param phi    ITensor
  *               Start vector of lanzcos method, after function call stores the ground state.
  * @param args   itensor::Args (default: Args::global())
  *               Parameters, args used by this function are:
  * @param     MaxIter (default: 10)
  *            Maximal number of Krylov vectors generated. Note for DMRG this number should be small, since it is iterative and it might even make convergence worse if too many steps are taken.
  * @param     NormCutoff (default: 1E-13) 
  *            If norm of new Krylov vector drops below this value, stop generating new vectors to avoid ghost states.
  * @param     ErrGoal (default: 1E-12) 
  *            Convergence criteria.
  * @param     DiagEvery (default: 4):
  *            Perform the diagonalization of the tri-diagonal matrix every *DiagEvery* step.
  */
  template <class Matrix> double lanzcos(const Matrix &H, ITensor &phi, Args &args = Args::global()) {

    const double DefaultErrGoal = 1E-12, defaultNormCutoff = 1E-13;
    auto NKrylovMax = args.getInt("MaxIter", 10), DiagEvery = args.getInt("DiagEvery", 4);
    int StepsDone = 0;
    double energy = 0, energyLastIt = 0, KrylovNormError = args.getReal("NormCutoff", defaultNormCutoff),
           energyConv = args.getReal("ErrGoal", DefaultErrGoal);

    bool basisFull = false;

    std::vector<double> eps, kappa, GS;
    eps.resize(0);
    kappa.resize(0);
    std::vector<ITensor> KrylovVecs;

    if (H.size() < NKrylovMax) NKrylovMax = H.size();

    ITensor xn, xnm1, xnp1;
    xn = phi;
    xn /= norm(xn);

    for (auto i : itertools::range(NKrylovMax)) {
      kappa.push_back(norm(xn));

      if (std::fabs(kappa.back()) > KrylovNormError)
        xn /= kappa.back();
      else
        basisFull = true;

      KrylovVecs.push_back(xn);

      H.product(xn, xnp1);
      ITensor ovlp = xn * dag(xnp1);
      eps.push_back(std::real(ovlp.cplx()));

      xnp1 += -eps[i] * xn;
      if (i > 0) xnp1 += -kappa[i] * xnm1;

      xnm1 = xn;
      xn   = xnp1;

      // diagonalize matrix if any of the three conditions is fullfilled
      // 1. automatically diagonalize ever DiagEvery step
      // 2. basis is full, i.e.: norm(kappa) < KrylovNormError
      // 3. maximum number of krylov vectors is reached
      if ((i % DiagEvery == 0 && i != 0) || basisFull || i == NKrylovMax - 1) {
        StepsDone = basisFull ? i : i + 1;

        double *Htri = new double[StepsDone * StepsDone];
        double *diag = new double[StepsDone];

        FillHtri(Htri, StepsDone, eps, kappa);

        ev_hermitian(Htri, diag, StepsDone, 'V');

        energy = diag[0];
        GS.resize(StepsDone);
        for (auto k : itertools::range(StepsDone)) GS[k] = Htri[k];

        delete[] Htri;
        delete[] diag;

        // converged?
        if (std::fabs(energy - energyLastIt) < energyConv || basisFull) break;

        energyLastIt = energy;
      }
    }

    args.add("LanzcosStepsDone", StepsDone);

    // xn=phi; xnm1 = ITensor(), xnp1 = ITensor();
    for (auto i : itertools::range(StepsDone)) {
      i == 0 ? phi = GS.at(i) * KrylovVecs.at(i) : phi += GS.at(i) * KrylovVecs.at(i);

      // xn /= kappa[i];
      // H.product(xn,xnp1);
      // xnp1 += -eps[i]*xn - kappa[i]*xnm1;
      // xnm1 = xn;
      // xn=xnp1;
      // xn.scaleTo(1);
    }

    // phi.scaleTo(1);

    return energy;
  }

} // namespace forktps::ED

#endif
