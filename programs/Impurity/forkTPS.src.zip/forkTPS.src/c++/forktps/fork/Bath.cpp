#include "Bath.hpp"
#include "HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/types.hpp"

#include <algorithm>
#include <cmath>
#include <h5/generic.hpp>
#include <ios>
#include <iostream>
#include <itensor/util/error.h>

#include <itertools/itertools.hpp>
#include <limits>
#include <nda/nda.hpp>

#include <triqs/hilbert_space/fundamental_operator_set.hpp>
#include <triqs/utility/exceptions.hpp>
#include <utility>
#include <vector>

using namespace forktps;

//TODO: check all documentation

namespace forktps {

  /// Generates a gf_struct object consisting of two blocks with names blockNameUp and blockNameDn each with size blockSize
  gf_struct_t createGFStruct(std::string blockNameUp, std::string blockNameDn, int blockSize) {
    gf_struct_t gfstruct = gf_struct_t{};
    for (auto blockName : {blockNameUp, blockNameDn}) { gfstruct.push_back({blockName, blockSize}); }
    return gfstruct;
  }

  /// returns a vector of all triqs_index in gfstruct
  std::vector<triqs_indx> BlockIndexIterator(gf_struct_t gfstruct) {

    std::vector<triqs_indx> v(0);
    for (auto [bl_name, bl_size] : gfstruct) {
      for (auto indx : itertools::range(bl_size)) { v.emplace_back(bl_name, indx); }
    }

    return v;
  }

  /// Checks if the entries of blockNames are valid names
  bool BlockNamesValid(const std::vector<string> &blockNames, bool SO) {
    for (auto name : blockNames) {
      if (SO) {
        if (name != validBN_SO.at(0) && name != validBN_SO.at(1)) return false;
      } else {
        auto foundUp = std::find(validBNup.begin(), validBNup.end(), name);
        auto foundDn = std::find(validBNdn.begin(), validBNdn.end(), name);

        if (foundUp == validBNup.end() && foundDn == validBNdn.end()) return false;
      }
    }

    return true;
  }

  /// Returns the name of the spin-up block in blockNames.
  std::string blockNameUp(const std::vector<std::string> &blockNames, bool SO) {
    if (blockNames.size() == 1) { Error("Called blockNameUp with just a single block."); }
    if (SO) return validBN_SO.at(0);

    for (auto name : blockNames) {
      auto found = std::find(validBNup.begin(), validBNup.end(), name);
      if (found != validBNup.end()) return name;
    }

    std::cout << blockNames << std::endl;
    Error("No name found for up-block!!!");
    return "";
  }

  /// Returns the name of the spin-down block in blockNames.
  std::string blockNameDn(const std::vector<std::string> &blockNames, bool SO) {
    if (blockNames.size() == 1) { Error("Called blockNameUp with just a single block."); }

    if (SO) return validBN_SO.at(1);

    for (auto name : blockNames) {
      auto found = std::find(validBNdn.begin(), validBNdn.end(), name);
      if (found != validBNdn.end()) return name;
    }

    std::cout << blockNames << std::endl;
    Error("No name found for down-block!!!");
    return "";
  }

  [[nodiscard]] std::vector<int> bath::NBathVec() {
    // TODO make vector zero indexed
    std::vector<int> Nbs{0};
    auto bNs = blockNames();
    auto bS  = blockSize(bNs.at(0));

    if (bNs.size() == 1) {
      // single block
      for (auto bI : itertools::range(bS)) { Nbs.push_back(bI); }
    } else {
      // # blocks == 2
      for (auto bI : itertools::range(bS)) {
        for (auto bN : {blockNameUp(), blockNameDn()}) { // order is important
          Nbs.push_back(NBath({bN, bI}));
        }
      }
    }

    return Nbs;
  }

  /// Write to hdf5
  void h5_write(h5::group h5group, std::string subgroup_name, bath_site const &b) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "eps", b.eps);
    h5_write(grp, "V", b.V);
  }

  /// Read from hdf5
  void h5_read(h5::group h5group, std::string subgroup_name, bath_site &b) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "eps", b.eps);
    h5_read(grp, "V", b.V);
  }

  std::ostream &operator<<(std::ostream &os, const BandWidths &bw) {
    os << "\n";
    for (auto mp : bw) {
      os << "Bath Bandwidths of Block " << mp.first << ":\n";
      for (auto [indx, pair] : itertools::enumerate(mp.second)) {
        os << "   Orbital " << indx << std::fixed << std::setprecision(2) << ": [" << pair.first << ", " << pair.second << "]\n";
      }
    }
    os << "\n\n";
    //reset float formating
    std::cout.unsetf(std::ios_base::floatfield);
    return os;
  }

  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // ---------------------------------- Bath -------------------------------
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------

  bath::bath(gf_struct_t gfstruct, bool SO) : blockNames_(0), SpinOrbit(SO), gf_struct_(gfstruct) {

    if (gfstruct.size() == 2) {
      if (gfstruct[0].second != gfstruct[1].second) Error("bath::bath: both blocks must be of equal size in ftps solver");
    }

    for (auto mp : gfstruct) blockNames_.push_back(mp.first);

    if (!BlockNamesValid(blockNames_, SpinOrbit)) {
      std::cout << blockNames_ << std::endl;
      Error("Encountered invalid blockname in construction of bath");
    }

    //reshape everything
    auto blockSize = gfstruct.at(0).second;
    for (auto blockName : blockNames_) {
      b[blockName] = bath_block(blockSize);
      for (auto bI : itertools::range(blockSize)) {
        //bath
        b[blockName][bI].resize(0);
      }
    }
  }

  bath::bath(const dvec &eps, const dvec &V, int blockSize, std::string bNameUp, std::string bNameDn)
     : blockNames_{bNameUp, bNameDn}, gf_struct_(createGFStruct(bNameUp, bNameDn, blockSize)) {
    int NBath = V.size();

    for (auto blockName : blockNames_) {
      b[blockName] = bath_block(blockSize);

      for (auto bI : itertools::range(blockSize)) {

        //bath
        b[blockName][bI].resize(NBath);
        for (auto k : itertools::range(NBath)) {
          b[blockName][bI][k].V.resize(blockSize);
          b[blockName][bI][k].eps      = eps.at(k + 1); //eps[0] is the on-site energy of impurity -> k+1
          b[blockName][bI][k].V.at(bI) = V.at(k);
        }
      }
    }
  }

  bath::bath(const Dmat &eps, const Cmat &V, int blockSize, std::string bNameUp, std::string bNameDn, bool isOffDiag)
     : blockNames_{bNameUp, bNameDn}, gf_struct_(createGFStruct(bNameUp, bNameDn, blockSize)) {
    auto NBath = eps.at(0).size() - 1;

    //fill actual parameters
    for (auto blockName : blockNames_) {
      b[blockName] = bath_block(blockSize);

      for (auto bI : itertools::range(blockSize)) {
        long armIndx = (blockName == blockNameUp()) ? 2 * bI : 2 * bI + 1;

        //bath
        b[blockName][bI].resize(NBath);

        for (auto k : itertools::range(NBath)) {
          b[blockName][bI][k].V.resize(blockSize);
          b[blockName][bI][k].eps = eps.at(armIndx).at(k + 1); // eps[0] is on-site energy of impurity

          if (isOffDiag) {
            for (auto bJ : itertools::range(blockSize)) {
              long armIndxJ                = (blockName == blockNameUp()) ? 2 * bJ : 2 * bJ + 1;
              b[blockName][bI][k].V.at(bJ) = V.at(armIndxJ).at(k + NBath * bI);
            }
          } else {
            b[blockName][bI][k].V.at(bI) = V.at(armIndx).at(k);
          }
        }
      }
    }
  }

  void bath::addSite(triqs_indx indx, double eps, cvec V) {
    auto found = std::find(blockNames_.begin(), blockNames_.end(), indx.first);
    if (found == blockNames_.end()) Error("bath::addSite: can only insert to preexisting blocks and " + indx.first + " does not exist");

    if (indx.second < 0 || indx.second > b[indx.first].size() - 1) Error("bath::addSite: block index bIndx out of range");

    bath_site site{eps, V};
    if (site.V.size() != blockSize(indx.first)) Error("bath::addSite: wrong shape of vector V");

    auto &bathChain = b.at(indx.first).at(indx.second);
    bathChain.push_back(site);
  }

  gf_struct_t bath::gf_struct() const { return gf_struct_; }

  [[nodiscard]] int bath::NArms() const {
    int size = 0;
    for (const auto &block : b) size += block.second.size();

    return size;
  }

  [[nodiscard]] int bath::NBath(triqs_indx indx) const {
    //all bath sizes equal
    return b.at(indx.first).at(indx.second).size();
  }

  [[nodiscard]] int bath::N() const {
    int Ntot = 0;
    for (auto I : BlockIndexIterator(gf_struct_)) { Ntot += NBath(I) + 1; }

    return Ntot;
  }

  [[nodiscard]] Complex bath::V(triqs_indx indx, int k) const { return b.at(indx.first).at(indx.second).at(k).V.at(indx.second); }

  [[nodiscard]] Complex bath::V(triqs_indx indxI, triqs_indx indxJ, int k) const {
    if (indxI.first != indxJ.first) return 0.;

    return b.at(indxI.first).at(indxI.second).at(k).V.at(indxJ.second);
  }

  [[nodiscard]] double bath::eps(triqs_indx indx, int k) const { return b.at(indx.first).at(indx.second).at(k).eps; }

  [[nodiscard]] int bath::blockSize(std::string bName) const { return b.at(bName).size(); }

  [[nodiscard]] int bath::blockToFTPSIndx(triqs_indx indx) const {
    auto bN = indx.first;
    auto bI = indx.second;

    // if only one block:
    if (blockNames_.size() == 1) return indx.second + 1;

    // two blocks
    if (!SpinOrbit) { // normal case
      if (bN == blockNameUp())
        return 2 * bI + 1;
      else if (bN == blockNameDn())
        return 2 * bI + 2;
      else {
        Error("blockToFTPSIndx: invalid block Name");
        return 0;
      }
    } else { // with spin orbit coupling
      if (bN == blockNameUp())
        return (bI == 0) ? 1 : 2 * bI + 2;
      else if (bN == blockNameDn())
        return (bI == 0) ? 2 : 2 * bI + 1;
      else {
        Error("blockToFTPSIndx: invalid block Name");
        return 0;
      }
    }
  }

  [[nodiscard]] triqs_indx bath::FTPSIndxToBlock(int arm) const {
    auto bI        = (arm + arm % 2) / 2 - 1;
    std::string bN = arm % 2 == 1 ? blockNameUp() : blockNameDn();

    // spin-orbit case is different if arm >2
    if (isSpinOrbit() && arm > 2) { bN = arm % 2 == 1 ? blockNameDn() : blockNameUp(); }

    return {bN, bI};
  }

  [[nodiscard]] std::vector<std::string> bath::blockNames() const { return blockNames_; }

  [[nodiscard]] std::string bath::blockNameUp() const {
    // call free function blockNameUp
    return ::blockNameUp(blockNames_, SpinOrbit);
  }

  [[nodiscard]] std::string bath::blockNameDn() const {
    // call free function blockNameDn
    return ::blockNameDn(blockNames_, SpinOrbit);
  }

  bath bath::todiag() const {
    bath diagbath = *this;

    for (auto &block : diagbath.b) {
      for (auto bI : itertools::range(block.second.size())) {
        auto &arm = block.second.at(bI);
        for (auto &site : arm) {
          for (auto bJ : itertools::range(block.second.size())) {
            if (bJ == bI) continue;
            site.V.at(bJ) = 0.;
          }
        }
      }
    }

    return diagbath;
  }

  BandWidths bath::bandwidth() const {
    BandWidths bw;
    for (auto bN : blockNames()) bw[bN] = {};

    for (auto I : BlockIndexIterator(gf_struct_)) {
      double mi = std::numeric_limits<double>::max(), ma = std::numeric_limits<double>::lowest();
      for (auto k : itertools::range(NBath(I))) {
        auto val = eps(I, k);
        mi       = std::min(mi, val);
        ma       = std::max(ma, val);
      }

      bw[I.first].push_back(std::make_pair(mi, ma));
    }

    return bw;
  }

  void bath::MakePHSymmetric() {

    if (isOffDiag()) TRIQS_RUNTIME_ERROR << "Particle hole symmetry does not exist for off-diagonal bath";

    for (auto I : BlockIndexIterator(gf_struct_)) {
      auto Nb = NBath(I);
      for (auto k : itertools::range(Nb)) {

        auto avgEps = 0.5 * (eps(I, k) - eps(I, Nb - k - 1));
        auto avgV   = 0.5 * (V(I, k) + V(I, Nb - k - 1));

        b[I.first][I.second][k].eps          = +avgEps;
        b[I.first][I.second][Nb - k - 1].eps = -avgEps;

        b[I.first][I.second][k].V[I.second]          = avgV;
        b[I.first][I.second][Nb - k - 1].V[I.second] = avgV;

        if (k == (int)((Nb - 1) / 2)) break;
      }
    }
  }

  [[nodiscard]] std::vector<int> bath::numNegative() const {
    std::vector<int> NNeg(NArms());

    for (auto I : BlockIndexIterator(gf_struct_)) {
      int arm = blockToFTPSIndx(I);
      for (auto k : itertools::range(NBath(I))) {
        if (eps(I, k) < 0) { NNeg.at(arm - 1)++; }
      }
    }

    return NNeg;
  }

  bool bath::isOffDiag() const {
    /// loop over blocks
    for (auto mp : b) {
      /// loop over bath arms
      for (auto [i, arm] : itertools::enumerate(mp.second)) {
        /// loop over all sites in arm
        for (auto site : arm) {
          /// loop over all V on site
          for (auto [j, val] : itertools::enumerate(site.V)) {
            if (i == j) continue;
            if (std::abs(val) > TOOSMALL) return true;
          }
        }
      }
    }

    return false;
  }

  [[nodiscard]] bool bath::isSpinOrbit() const { return SpinOrbit; }

  [[nodiscard]] bool bath::hasOnlyOneBlock() const { return (blockNames_.size() == 1) ? true : false; };

  g_w_t bath::reconstructDelta(const gf_mesh<refreq> &w, double eta) {
    g_w_t DeltaRe(w, gf_struct());

    //loop over blocks
    for (auto [name, gf] : itertools::zip(DeltaRe.block_names(), DeltaRe)) {
      int bS = blockSize(name);

      //loop over all bath sites
      for (auto ik : itertools::range(bS)) {
        triqs_indx I{name, ik};
        for (auto k : itertools::range(NBath(I))) {
          auto e = eps(I, k);
          //loop over block structure
          for (auto [i, j] : product_range(bS, bS)) {
            auto amp = V(I, {name, i}, k) * std::conj(V(I, {name, j}, k));
            //loop over omega
            for (auto omega : w) gf[omega](i, j) += amp / (omega - e + itensor::Complex_i * eta);
          }
        }
      }
    }

    return DeltaRe;
  }

  std::ostream &operator<<(std::ostream &out, const bath &b) {
    std::string shift  = "    ";
    std::string shift2 = shift + shift;

    out << "The bath consists of the following sites: \n";
    for (auto mp : b.b) {
      out << "Block Name: " << mp.first << std::endl;

      int blockCount = 0;
      for (auto bathChain : mp.second) {
        out << shift + " Block indx: " << blockCount << std::endl;
        for (auto site : bathChain) {
          out << shift2 + " Site with: eps =  " << site.eps << "  V = ";
          for (auto val : site.V) out << val << "  ";
          out << std::endl;
        }

        blockCount++;
      }
    }

    return out;
  }

  void h5_write(h5::group h5group, std::string subgroup_name, bath const &b) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "SpinOrbit", b.SpinOrbit);

    h5_write(grp, "bath", b.b);
    h5_write(grp, "gf_struct", b.gf_struct_);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, bath &b) {
    auto grp = h5group.open_group(subgroup_name);
    h5_read(grp, "SpinOrbit", b.SpinOrbit);

    h5_read(grp, "bath", b.b);
    h5_read_gf_struct(grp, "gf_struct", b.gf_struct_);

    b.blockNames_.resize(0);
    for (auto block : b.gf_struct_) { b.blockNames_.push_back(block.first); }
  }
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // ---------------------------------- hloc -------------------------------
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------

  hloc::hloc(gf_struct_t gfstruct, bool SO) : SpinOrbit(SO), gf_struct_(gfstruct) {

    if (gfstruct.size() == 2) {
      if (gfstruct[0].second != gfstruct[1].second) Error("hloc::hloc: both blocks must be of equal size in ftps solver");
    }

    for (auto mp : gfstruct) blockNames_.push_back(mp.first);

    if (!BlockNamesValid(blockNames_, SpinOrbit)) {
      std::cout << blockNames_ << std::endl;
      Error("Encountered invalid blockname in construction of e0");
    }

    //reshape the matrix
    auto blockSize = gfstruct.at(0).second;
    for (auto blockName : blockNames_) { e[blockName].resize(make_shape(blockSize, blockSize)); }
  }

  hloc::hloc(const Dmat &eps, int blockSize, std::string bNameUp, std::string bNameDn)
     : blockNames_{bNameUp, bNameDn}, gf_struct_(createGFStruct(bNameUp, bNameDn, blockSize)) {

    if (!BlockNamesValid(blockNames_, SpinOrbit)) {
      std::cout << blockNames_ << std::endl;
      Error("Encountered invalid blockname in construction of e0");
    }

    //fill actual parameters
    for (auto blockName : blockNames_) {
      e[blockName].resize(make_shape(blockSize, blockSize));

      for (auto bI : itertools::range(blockSize)) {
        long armIndx = (blockName == blockNameUp()) ? 2 * bI : 2 * bI + 1;

        //e0
        e[blockName](bI, bI) = eps.at(armIndx).at(0);
      }
    }
  }

  hloc::hloc(const dvec &eps, int blockSize, std::string bNameUp, std::string bNameDn)
     : blockNames_{bNameUp, bNameDn}, gf_struct_(createGFStruct(bNameUp, bNameDn, blockSize)) {
    if (!BlockNamesValid(blockNames_, SpinOrbit)) {
      std::cout << blockNames_ << std::endl;
      Error("Encountered invalid blockname in construction of e0");
    }

    for (auto blockName : blockNames_) {
      e[blockName].resize(make_shape(blockSize, blockSize));

      //e0
      for (auto bI : itertools::range(blockSize)) e[blockName](bI, bI) = eps.at(0);
    }
  }

  void hloc::Fill(std::string bName, array<Complex, 2> e0) {
    auto shape = e0.shape();
    if (shape[0] != shape[1]) Error("Local H0 must be a square matrix");

    e.at(bName) = e0;
  }

  void hloc::Fill(array<Complex, 2> e0) {
    for (auto name : blockNames_) Fill(name, e0);
  }

  array<Complex, 2> hloc::operator()(std::string bName) const { return e.at(bName); }

  Complex hloc::operator()(triqs_indx indx) const { return e.at(indx.first)(indx.second, indx.second); }

  Complex hloc::operator()(triqs_indx indxI, triqs_indx indxJ) const {
    if (indxI.first != indxJ.first) return 0.;

    return e.at(indxI.first)(indxI.second, indxJ.second);
  }

  std::ostream &operator<<(std::ostream &out, const hloc &e0) {

    out << "Non-Interacting Impurity Hamiltonian: \n\n";
    for (auto mp : e0.e) {
      out << "Matrix of Block " << mp.first << ":";
      auto mat = mp.second;
      out << mat << std::endl << std::endl;
    }
    return out;
  }

  bool hloc::isOffDiag() const {
    for (auto mp : e) {
      for (auto [i, j] : itertools::product_range(mp.second.shape()[0], mp.second.shape()[1])) {
        if (i == j) continue;
        if (std::abs(mp.second(i, j)) > TOOSMALL) { return true; }
      }
    }
    return false;
  }

  bool hloc::isSpinOrbit() const { return SpinOrbit; }

  std::vector<std::string> hloc::blockNames() const { return blockNames_; }

  [[nodiscard]] std::string hloc::blockNameUp() const {
    // call free function blockNameUp
    return ::blockNameUp(blockNames_, SpinOrbit);
  };

  [[nodiscard]] std::string hloc::blockNameDn() const {
    // call free function blockNameDn
    return ::blockNameDn(blockNames_, SpinOrbit);
  };

  [[nodiscard]] hloc hloc::todiag() const {
    hloc diaghloc = *this;

    for (auto &mp : diaghloc.e) {
      for (auto [i, j] : itertools::product_range(mp.second.shape()[0], mp.second.shape()[1])) {
        if (i == j) continue;
        mp.second(i, j) = 0;
      }
    }

    return diaghloc;
  }

  void h5_write(h5::group h5group, std::string subgroup_name, hloc const &e0) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "SpinOrbit", e0.SpinOrbit);
    h5_write(grp, "hloc", e0.e);
    h5_write(grp, "gf_struct", e0.gf_struct_);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, hloc &e0) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "SpinOrbit", e0.SpinOrbit);
    h5_read(grp, "hloc", e0.e);
    h5_read_gf_struct(grp, "gf_struct", e0.gf_struct_);

    e0.blockNames_.resize(0);
    for (auto block : e0.gf_struct_) { e0.blockNames_.push_back(block.first); }
  }

  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // ---------------------------------- Other ------------------------------
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------

  // Check if bath and e0 are valid
  void check(const bath &b, const hloc &e0) {
    // check bath
    int NBlocks      = b.blockNames().size();
    int sizeOfBlocks = b.blockSize(b.blockNames()[0]);

    for (auto name : b.blockNames()) {
      if (b.blockSize(name) != sizeOfBlocks) Error("check(): All blocks must be of equal size");
    }

    // for off-diagonal baths, bath size needs to be the same in each block
    if (b.isOffDiag()) {
      for (auto bN : b.blockNames()) {
        for (auto bI : itertools::range(b.blockSize(bN))) {
          if (b.NBath({bN, bI}) != b.NBath({bN, 0})) {
            Error("check(): Off-diagonal bath, each block must have the same number of bath sites in each orbital.");
          }
        }
      }
    }

    if (NBlocks * sizeOfBlocks != b.NArms()) Error("check(): The total size of all blocks must equal the number of Arms");

    // compare bath and hloc
    for (auto mp : e0.e) {
      //checks whether the sizes match
      if (mp.second.shape()[0] != sizeOfBlocks) Error("check(): Dimension missmatch between bath and hloc");
    }

    // Checks if SpinOrbit variable is the same for both
    if (b.isSpinOrbit() != e0.isSpinOrbit()) Error("check(): bath and hloc must both either be spin-orbit coupled or not.");

    //currently this code supports only some certain block names to make
    //sure FTPS is not used incorrectly
    if (!BlockNamesValid(b.blockNames(), b.isSpinOrbit())) {
      std::string msg = "check(): One or more incorrect block names found! Valid names are : ";
      if (!b.isSpinOrbit()) {
        for (auto name : validBNup) msg += " " + name;
        for (auto name : validBNdn) msg += " " + name;
      } else {
        for (auto name : validBN_SO) msg += " " + name;
      }

      Error(msg);
    }
  }

} // namespace forktps
