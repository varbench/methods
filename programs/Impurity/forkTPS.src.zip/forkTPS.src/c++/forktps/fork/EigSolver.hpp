#ifndef __FORKEIGSOLVER__
#define __FORKEIGSOLVER__

#include "itertools/itertools.hpp"
#include "itensor/types.h"
using namespace itensor;

namespace forktps::ED {

  /**
  * Eigenvalue solver for the tridiagonal matrix in Krylov space. It uses the lapack dsyev_ method.
  * @param MAT     double []
  *                Matrix to be diagonalized in vector form (length $L^2$), contains eigenvectors after function call.
  * @param diag    double []
  *                Array of lentgh *L*, contains the eigenvalues after function call.
  * @param L       int
  *                Size of matrix.
  * @param JOBZ    char
  *                'V' to calculate eigenvectors and eigenvalues, 'N' to calculate for eigenvalues only.
  */
  void ev_hermitian(double *MAT, double *diag, int L, char JOBZ);

  /**
  * Generates a $L \times L$ tri-diagonal matrix with diagonal *eps* and off-diagonal *kappa*.
  * @param Htri    double []
  *                Resulting tri-diagonal matrix in vector form (length $L^2$).
  * @param L       int
  *                Size of matrix.
  * @param eps     std::vector<double>
  *                Diagonal of the matrix.
  * @param kappa   std::vector<double>
  *                Off-diagonal of the matrix.
  */
  void FillHtri(double *Htri, int L, std::vector<double> eps, std::vector<double> kappa);

} // namespace forktps::ED

#endif
