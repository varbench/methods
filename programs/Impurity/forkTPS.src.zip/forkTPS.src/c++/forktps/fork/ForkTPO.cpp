#include <algorithm>
#include <iostream>

#include <itensor/qn.h>

#include "ForkTPO.hpp"

// TODO: when doing an svd on the impurity NArms_=1 is not supported
// TODO: care must be taken when using svdimp, since it doesnt check every ortho
// condition
// TODO: what is private what not and what do I need from the outside

namespace forktps {

  //-------------------------------------------------------------------------------------------------------
  // Constructors and operators:
  // --------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  ForkTPO::ForkTPO(const SiteSet &sites, int NArms) : ForkTN(sites, NArms) { init_tensors(); }

  ForkTPO::ForkTPO(const SiteSet &sites, std::vector<int> Nbath) : ForkTN(sites, Nbath) { init_tensors(); }

  void ForkTPO::init_tensors() {
    // initializes the MPO tensors for the first time using identities
    std::vector<Index> indx, indxImp;
    indxImp.resize(0);
    QN qn0 = -div(sites_.op("Id", 1));

    for (int arm = 1; arm <= NArms(); ++arm) {
      indx.resize(0);
      indx.emplace_back();

      // create Indices
      for (int k = 1; k < NBath(arm); ++k) indx.emplace_back(qn0, 1, Out, Names::TAGSB);

      indx.emplace_back(qn0, 1, Out, Names::TAGSIB);

      auto si  = sites_.si(ArmToSite(arm, 1));
      auto siP = sites_.siP(ArmToSite(arm, 1));

      Arms_[arm].A_[1] = sites_.op("Id", ArmToSite(arm, 1)) * setElt(indx[1](1));

      for (int k = 2; k <= NBath(arm); k++) {
        Index row = dag(indx[k - 1]), col = indx[k];
        si  = sites_.si(ArmToSite(arm, k));
        siP = sites_.siP(ArmToSite(arm, k));

        Arms_[arm].A_[k] = sites_.op("Id", ArmToSite(arm, k)) * setElt(row(1), col(1));
      }

      // Make Impurity ITensor
      si  = sites_.si(ImpSite(arm));
      siP = sites_.siP(ImpSite(arm));

      Index indxArm = indx.back();

      if (arm == 1) {
        Index indxLinkDown(qn0, 1, Out, Names::TAGSI);
        A_[arm] = sites_.op("Id", ImpSite(arm)) * setElt(indxLinkDown(1), dag(indxArm)(1));

        indxImp.push_back(indxLinkDown);
      } else if (arm != NArms()) {
        Index indxLinkUp = indxImp.back();
        Index indxLinkDown(qn0, 1, Out, Names::TAGSI);

        A_[arm] = sites_.op("Id", ImpSite(arm)) * setElt(dag(indxLinkUp)(1), indxLinkDown(1), dag(indxArm)(1));
        indxImp.push_back(indxLinkDown);
      } else {
        Index indxLinkUp = indxImp.back();
        A_[arm]          = sites_.op("Id", ImpSite(arm)) * setElt(dag(indxLinkUp)(1), dag(indxArm)(1));
      }
    }

    return;
  }

  ITensor ForkTPO::UTensor(int site, OrthoState towards) const {

    std::vector<OrthoState> dirs;

    // find all possible directions of neighbors of site
    if (IsImp(site)) {
      if (ImpIndx(site) == 1)
        dirs = {Rightwards, Downwards};
      else if (ImpIndx(site) == NArms())
        dirs = {Rightwards, Upwards};
      else
        dirs = {Rightwards, Downwards, Upwards};
    } else {
      if (SiteToArm(site).second == 1)
        dirs = {Leftwards};
      else
        dirs = {Rightwards, Leftwards};
    }

    bool found = false;
    // create a list of all indices that must be in U
    std::vector<Index> indices(0);
    for (auto dir : dirs) {
      if (dir == towards) {
        found = true;
        continue; // do not include towards
      }
      indices.push_back(GetLink(site, dir));
    }
    auto si = sites_(site);
    indices.push_back(si);
    indices.push_back(dag(prime(si)));

    if (!found) Error("UTensor: direction " + to_string(towards) + " not a valid direction for site " + std::to_string(site));

    return ITensor(indices);
  }

  void ForkTPO::HermitianConjugate() {
    for (auto site : range1(N())) {
      ITensor W = A(site);

      W = dag(W);

      W.mapPrime(1, 2, "Site");
      W.mapPrime(0, 1, "Site");
      W.mapPrime(2, 0, "Site");
      Anc(site) = W;
    }
  }

  // end of namespace itensor
} // namespace forktps
