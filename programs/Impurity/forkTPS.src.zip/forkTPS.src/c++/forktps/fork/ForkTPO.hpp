#ifndef __FORKMPO__
#define __FORKMPO__

#include "ForkTN.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/itensor.h>
#undef Print

#include <vector>

using namespace itensor;

namespace forktps {

  class ForkTPO : public ForkTN {
    public:
    // Constructors

    /// Default constructor.
    ForkTPO() = default;

    /** Constructs a forkMPO with *NArms* arms using the site indices from *sites*. It is initialized as identity operator.
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param NArms    int
    *                 Number of arms.
    */
    ForkTPO(const SiteSet &sites, int NArms);

    /** Constructs a ForkTPO and with *Nbath[m]* bath sites on arm *m* using the site indices from *sites*. 
    * It is initialized as identity operator.
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param Nbath    std::vector<int>
    *                 Vector containing the number of bath sites for each arm (one-indexed, i.e, Nbath[1] is the number of bath sites of the first arm).
    */
    ForkTPO(const SiteSet &sites, std::vector<int> Nbath);

    protected:
    /// Called by the constructors, this function actually initializes the tensors with identities.
    void init_tensors();

    ///
    public:
    ITensor UTensor(int site, OrthoState towards) const override;

    void HermitianConjugate();
  };

} // namespace forktps

#endif
