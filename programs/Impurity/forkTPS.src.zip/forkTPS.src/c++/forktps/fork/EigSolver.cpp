#include "EigSolver.hpp"
#include <itensor/tensor/lapack_wrap.h>

namespace forktps::ED {

  /**
  * Returns the matrix entry of the product $v_i = (U e^{ -i \Delta t d } U )_{i0} = \sum_k U_{ik} e^{ -i \Delta t d_k } U_{k0}$ as a vector.
  * Needed for Krylov time evolution where this vector contains the weights of the individual Krylov vectors.
  * @param L       int
  *                Matrix dimension.
  * @param U       double []
  *                Unitary transformation diagonalizing the Hamiltonian (as a vector of length $L^2$; usually the tri-diagonal matrix of the Hamiltonian in the Krylov basis).
  * @param d       double []
  *                One-dimensional vector of eigenvalues (length $L$)
  * @param dt      double
  *                Time Step
  */
  std::vector<Complex> ExpMCoeff(int L, double *U, double *d, double dt) {
    // calculates only the entries exp(matrix)[i][0] needed for the krylov time evolution
    std::vector<Complex> cns(L);
    for (int i = 0; i < L; ++i) {
      cns.at(i) = 0;
      for (int k = 0; k < L; k++) cns[i] += U[k * L + i] * std::exp(-Complex_i * dt * d[k]) * U[k * L + 0];
    }
    return cns;
  }

  void ev_hermitian(double *MAT, double *diag, int L, char JOBZ) {
    int LDA = L, info, LWORK = 2 * L * L;

    auto *WORK = new double[LWORK];
    char UPLO  = 'U';

    dsyev_(&JOBZ, &UPLO, &L, MAT, &LDA, diag, WORK, &LWORK, &info);

    delete[] WORK;
    return;
  }

  void FillHtri(double *Htri, int L, std::vector<double> eps, std::vector<double> kappa) {
    for (auto k : itertools::range(L * L)) Htri[k] = 0;

    for (auto k : itertools::range(L)) {
      Htri[k * (L + 1)] = eps[k];
      if (k != 0) { Htri[k * L + k - 1] = kappa[k]; }         // add upper tridiag
      if (k != L - 1) { Htri[k * L + k + 1] = kappa[k + 1]; } // add lower tridiag
    }
  }

} // namespace forktps::ED
