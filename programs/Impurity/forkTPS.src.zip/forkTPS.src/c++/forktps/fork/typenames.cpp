#include "typenames.hpp"
#include <string>
#include <triqs/operators/many_body_operator.hpp>
#include <utility>
#include <vector>
namespace forktps {
  using namespace forktps;

  std::string to_string(GFtype type) {
    if (type == singlePart_lesser)
      return "single particle lesser";
    else if (type == singlePart_greater)
      return "single particle greater";
    else if (type == selfEnergy_lesser)
      return "self energy lesser";
    else if (type == selfEnergy_greater)
      return "self energy greater";
    else if (type == density)
      return "density";
    else if (type == custom)
      return "custom <A(t)*B>";
    else
      return "";
  }

  bool isSingleParticle(GFtype type) { return (type == singlePart_greater || type == singlePart_lesser); }

  bool isSelfEnergy(GFtype type) { return (type == selfEnergy_greater || type == selfEnergy_lesser); }

  bool isDensity(GFtype type) { return type == density; }

  bool isGreater(GFtype type) {
    if (type == singlePart_greater || type == selfEnergy_greater) return true;
    return false;
  }

  bool isLesser(GFtype type) {
    if (type == singlePart_lesser || type == selfEnergy_lesser) return true;
    return false;
  }

  bool isCustom(GFtype type) { return type == custom ? true : false; }

  void reverse(TevoDir &dir) { dir = static_cast<TevoDir>(static_cast<int>(dir) * -1); }

  std::string to_string(BraKet bk) {
    if (bk == forktps::Bra)
      return "Bra";
    else
      return "Ket";
  }

  std::string to_string(OrthoState state) {
    if (state == Leftwards) {
      return "Leftwards";
    } else if (state == Rightwards) {
      return "Rightwards";
    } else if (state == Upwards) {
      return "Upwards";
    } else if (state == Downwards) {
      return "Downwards";
    } else {
      return "Nonewards";
    }
  }

  std::string to_string(Spin s) {
    if (s == Up)
      return "Up";
    else
      return "Down";
  }

  // define constant names
  const char *Names::MAXMI  = "MaxmI";
  const char *Names::MAXMB  = "MaxmB";
  const char *Names::MAXMIB = "MaxmIB";

  const char *Names::TWI  = "CutoffI";
  const char *Names::TWB  = "CutoffB";
  const char *Names::TWIB = "CutoffIB";

  const char *Names::TAGSI  = "Imp,Link";
  const char *Names::TAGSB  = "Bath,Link";
  const char *Names::TAGSIB = "IB,Link";

} // namespace forktps
