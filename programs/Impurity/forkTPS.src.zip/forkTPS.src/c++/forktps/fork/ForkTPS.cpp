#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/makros.hpp"
#include "HelperFunctions.hpp"
#include "typenames.hpp"

#include <ios>
#include <itensor/global.h>
#include <itensor/itensor.h>
#include <itensor/util/error.h>
#include <itertools/itertools.hpp>
#undef Print

#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

// TODO: when doing an svd on the impurity NArms_=1 is not supported

// TODO: what is private what not and what do I need from the outside
// TODO: Think about changing fromleft and fromright in svd routines!!!! This is
// because when looking at the fork fromleft and fromright are different than
// used in the program

// in the fork structure:

//    I  u u u u u u u u u u u u u
//    |
//    I  d d d d d d d d d d d d d
//    |
//    I  u u u u u u u u u u u u u
//    |
//    I  d d d d d d d d d d d d d
//    .
//    .
//
//
//
// sites are numbered as:

//    1       2 3 ...........    NBath +1
//    |
//  NBath+2   NBath+3 ......     2*(NBath+1)
//    |
//    ................................
//    .
//    .

namespace forktps {

  //-------------------------------------------------------------------------------------------------------
  // Constructors and operators:
  // --------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------------------

  ForkTPS::ForkTPS(const InitState &initState, int NArms) : ForkTN(initState.sites(), NArms) { init_tensors(initState); }

  ForkTPS::ForkTPS(const SiteSet &sites, int NArms) : ForkTN(sites, NArms) {
    // ForkTN constructor initializes tensors for ForkTPS SiteSet
  }

  ForkTPS::ForkTPS(const InitState &initState, std::vector<int> NBath) : ForkTN(initState.sites(), NBath) { init_tensors(initState); }

  ForkTPS::ForkTPS(const SiteSet &sites, std::vector<int> NBath) : ForkTN(sites, NBath) {
    // ForkTN constructor initializes tensors for ForkTPS SiteSet
  }

  void ForkTPS::init_tensors(const InitState &initState) {
    // initializes the MPS with the first state in sites_
    std::vector<QN> qarm, qaImpLinks;
    qaImpLinks.resize(0);
    qaImpLinks.emplace_back(QN());
    std::vector<Index> indx, indxImpLinks;
    indxImpLinks.resize(0);
    indxImpLinks.emplace_back();

    for (auto j : range1(NArms() - 1)) {
      // loop over all Arms except last one!!!
      qarm.resize(0);
      qarm.emplace_back();

      indx.resize(0);
      // dummy link
      indx.emplace_back(QN(), 1, Out, "Link");

      // create QNs
      for (auto k : range1(NBath(j))) { qarm.push_back(In * (-qarm.back() * Out - initState(ArmToSite(j, k)).qn() * Out)); }

      // create Indices
      for (int k = 1; k < NBath(j); ++k) { indx.emplace_back(qarm[k], 1, Out, Names::TAGSB); }
      indx.emplace_back(qarm[NBath(j)], 1, Out, Names::TAGSIB);

      Arms_[j].A_[1] = setElt(initState(ArmToSite(j, 1)), dag(indx[1])(1));
      for (int k = 2; k <= NBath(j); k++) { Arms_[j].A_[k] = setElt(indx[k - 1](1), initState(ArmToSite(j, k)), dag(indx[k])(1)); }

      // Impurity
      QN qnArm      = qarm.back();
      Index indxArm = indx.back();

      QN qnImpLinkUp      = qaImpLinks.back();
      Index indxImpLinkUp = indxImpLinks.back();

      QN qnImpLinkDown = In * (-Out * qnArm - Out * qnImpLinkUp - Out * initState(ImpSite(j)).qn());
      Index indxImpLinkDown(qnImpLinkDown, 1, Out, Names::TAGSI);

      if (j == 1) {
        A_[j] = setElt(dag(indxImpLinkDown)(1), initState(ImpSite(j)), indxArm(1));
      } else {
        A_[j] = setElt(dag(indxImpLinkDown)(1), indxImpLinkUp(1), initState(ImpSite(j)), indxArm(1));
      }

      qaImpLinks.push_back(qnImpLinkDown);
      indxImpLinks.push_back(indxImpLinkDown);
    }

    // make last impurity
    QN qaImpLink      = qaImpLinks.back();
    Index indxImpLink = indxImpLinks.back();

    QN qaArm = In * (-Out * qaImpLink - Out * initState(ImpSite(NArms())).qn());

    Index indxArm(qaArm, 1, Out, Names::TAGSIB);

    A_[NArms()] = setElt(indxImpLink(1), dag(indxArm)(1), initState(ImpSite(NArms())));

    // fill last arm
    qarm.resize(0);
    qarm.push_back(qaArm);
    indx.resize(0);
    indx.push_back(indxArm);

    for (int k = NBath(NArms()); k > 1; k--) {
      QN qnLeft  = qarm.back();
      QN qnRight = In * (-Out * qnLeft - Out * initState(ArmToSite(NArms(), k)).qn());

      Index indxLeft = indx.back();

      Index indxRight(qnRight, 1, Out, Names::TAGSB);

      Arms_[NArms()].A_[k] = setElt(indxLeft(1), initState(ArmToSite(NArms(), k)), dag(indxRight)(1));

      qarm.push_back(qnRight);
      indx.push_back(indxRight);
    }

    Arms_[NArms()].A_[1] = setElt(indx.back()(1), initState(ArmToSite(NArms(), 1)));
  }

  void ForkTPS::randomize(int dim) {

    if (sites_.si(1).qn(1) != QN()) Error("randomize function not implemented for forktps with QN conservation.");

    std::vector<Index> ArmLinks, ImpLinks(1);

    for (auto j : range1(NArms())) { // loop over all Arms except last one!!!
      ArmLinks.resize(0);
      // dummy link
      ArmLinks.emplace_back(QN(), dim, "Link");

      // create Indices
      int actual_dim = 1;
      for (int k = 1; k < NBath(j); ++k) {
        if (actual_dim < dim) {
          auto nextdim = int(actual_dim * sites_.si(ArmToSite(j, k)).dim());
          actual_dim   = std::min(nextdim, dim);
        }
        ArmLinks.emplace_back(QN(), actual_dim, Names::TAGSB);
      }
      ArmLinks.emplace_back(QN(), dim, Names::TAGSIB);

      auto site = ArmToSite(j, 1);
      Anc(site) = ITensor(QN(), sites_.si(site), dag(ArmLinks.at(1))).randomize();
      for (int k = 2; k <= NBath(j); k++) {
        site      = ArmToSite(j, k);
        Anc(site) = ITensor(QN(), ArmLinks.at(k - 1), sites_.si(site), dag(ArmLinks.at(k))).randomize();
      }

      // Impurity
      Index indxArm       = ArmLinks.back();
      Index indxImpLinkUp = ImpLinks.back();
      Index indxImpLinkDown(QN(), dim, Names::TAGSI);

      site = ImpSite(j);
      if (j == 1)
        Anc(site) = ITensor(QN(), dag(indxImpLinkDown), sites_.si(site), indxArm).randomize();
      else if (j == NArms())
        Anc(site) = ITensor(QN(), indxImpLinkUp, sites_.si(site), indxArm).randomize();
      else
        Anc(site) = ITensor(QN(), dag(indxImpLinkDown), indxImpLinkUp, sites_.si(site), indxArm).randomize();

      ImpLinks.push_back(indxImpLinkDown);
    }
  }

  double ForkTPS::normalize() {
    // normalizes the MPS
    auto norm_ = norm();
    if (std::fabs(norm_) < ZERONORM) Error("ForkTPS::normalize: Zero norm");
    operator/=(norm_);
    return norm_;
  }

  double ForkTPS::normalizeLim() {
    // normalizes the MPS
    auto norm_     = norm();
    double up_lim  = std::numeric_limits<double>::max() / 10.0;
    double low_lim = -std::numeric_limits<double>::max() / 10.0;
    if (std::fabs(norm_) < low_lim) { norm_ = low_lim; }
    if (std::fabs(norm_) > up_lim) { norm_ = up_lim; }
    //if (std::fabs(norm_) < ZERONORM) Error("ForkTPS::normalize: Zero norm");
    operator/=(norm_);
    return norm_;
  }

  ITensor ForkTPS::UTensor(int site, OrthoState towards) const {
    // ForkTN implementation is defined to be for the MPS, just a reminder that it is virtual
    return ForkTN::UTensor(site, towards);
  }

  double ForkTPS::norm() const {
    // calculates the norm of the MPS
    if (OC_ != -1)
      return itensor::norm(A(OC_));
    else
      return std::sqrt(std::abs(overlap(*this, *this)));
  }

  // //-------------------------------------------------------------------------------------------------------
  // //Operator:
  // -----------------------------------------------------------------------------------
  // //-------------------------------------------------------------------------------------------------------

  void ForkTPS::ApplySingleSiteOp(const ITensor &Op, int site, bool sign) {
    // Applies the single site operator Op at site site
    // sign == true means, that at all sites before "site" the fermi operator gets
    // applied

    if (sign) {
      for (int k = 1; k < site; k++) {
        ITensor AA = (*this).A(k);
        AA *= sites_.op("p", k);
        AA.noPrime();
        (*this).Anc(k) = AA;
      }
    }

    ITensor AA = (*this).A(site);
    AA *= Op;
    AA.noPrime();
    (*this).Anc(site) = AA;

    return;
  }

  void ForkTPS::ApplyImpurityMPO(const std::vector<ITensor> &Ops, Args &args) {
    // applies the MPO stored in "Ops" which only acts onto the impurities
    // note that Ops is one-indexed, so Ops[0] is not defined!

    int site = ImpSite(1), nextsite = 0;
    args.add("Cutoff", -1);
    position(site);
    Anc(site) *= Ops[1];

    for (auto i : range1(NArms() - 1)) {
      site     = ImpSite(i);
      nextsite = ImpSite(i + 1);

      Anc(nextsite) *= Ops[i + 1];
      auto [comb, c] = LinkCombiner(A(site), A(nextsite));
      // Apply combiner to product tensors
      Anc(site)     = A(site) * comb;          // m^3 k^3 d
      Anc(nextsite) = dag(comb) * A(nextsite); // m^3 k^3 d
    }
    mapPrime(1, 0, "Site");

    // svd to reduce bond dimensions:
    auto orig_cut = args.getReal("Cutoff", -1);

    args.add("Cutoff", 0.1 * orig_cut);
    OrthoImps(1, Rightwards, args);
    args.add("Cutoff", orig_cut);
    CompOrthoArm(1, args);
    OrthoImps(NArms(), Rightwards, args);
    // CompOrthoArm(NArms_,args);
    // OrthoImps(1, Rightwards, args);
    OC_ = ImpSite(NArms()) + 1;

    return;
  }

  /*
void ForkTPS::ApprApplyImpurityMPO(const std::vector<ITensor>& Ops, ForkTPS
&psi0, Args &args) {
  // this function approximatly applies an MPO acting only on the impurity sites
  // this means that the tensor network of <psi|H|psi> contracts all the bath
  // states automatically ( once the right orthonormalization is made) therefore
  // we dont need tensors R from the bath, only Up (U) and down(D) from the
  // impurities.

  copyTensors(psi0);
  position(1);
  std::vector<Index> ImpBathsInds;
  ImpBathsInds.resize(NArms_ + 1);
  for (int i = 1; i <= NArms_; i++) {
    ImpBathsInds[i] = commonIndex(A(ImpSite(i)), A(ImpSite(i) + 1));
  }

  std::vector<ITensor> ProjH;
  ProjH.resize(NArms_ + 1);

  long sweeps = args.getInt("Sweeps", 1);

  // init ProjH:
  for (int i = NArms_; i > 1; i--) {
    ITensor M = psi0.A(NImp_[i]), Mp = A(NImp_[i]);
    Mp.primeExcept(ImpBathsInds[i]);
    if (i == NArms_) {
      ProjH[i] = M * Ops[i] * dag(Mp);
    } else {
      ProjH[i] = ProjH[i + 1] * M;
      ProjH[i] *= dag(Mp);
      ProjH[i] *= Ops[i];
    }

    // std::cout << i <<"
    // --------------------------------------------------------"<<std::endl;

  }

  for (int sw = 1; sw <= sweeps; sw++) {
    //"rightsweeps"
    for (int b = 1; b < NArms_; b++) {
      int site = NImp_[b], nextsite = NImp_[b + 1];

      ITensor AA;
      if (b == 1) {
        AA = psi0.A(site) * Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
        AA *= ProjH[b + 2];
      } else if (b == NArms_ - 1) {
        AA = ProjH[b - 1];
        AA *= psi0.A(site);
        AA *= Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
      } else {
        AA = ProjH[b - 1];
        AA *= psi0.A(site);
        AA *= Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
        AA *= ProjH[b + 2];
      }


      AA.noprime();
      ITensor U = A_[b], D, V;
      auto spec = svd(AA, U, D, V, args);

      if (b == NArms_ - 1) {
        A_[b] = U * D;
        A_[b + 1] = V;
        OSI_[b] = Nonewards;
        OSI_[b + 1] = Upwards;
        OC_ = site;
      } else {
        A_[b] = U;
        A_[b + 1] = V * D;
        OSI_[b] = Downwards;
        OSI_[b + 1] = Nonewards;
        OC_ = nextsite;
      }

      if (b == 1) {
        ITensor M = psi0.A(site), Mp = A_[b];
        Mp.primeExcept(ImpBathsInds[b]);
        ProjH[b] = M * Ops[b] * dag(Mp);
      } else if (b != NArms_ - 1) {
        ITensor M = psi0.A(site), Mp = A_[b];
        Mp.primeExcept(ImpBathsInds[b]);
        ProjH[b] = ProjH[b - 1] * M;
        ProjH[b] *= Ops[b];
        ProjH[b] *= dag(Mp);
      }
    }
    // leftsweep
    for (int b = NArms_ - 1; b >= 1; b--) {
      int site = NImp_[b], nextsite = NImp_[b + 1];

      ITensor AA;
      if (b == 1) {
        AA = psi0.A(site) * Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
        AA *= ProjH[b + 2];
      } else if (b == NArms_ - 1) {
        AA = ProjH[b - 1];
        AA *= psi0.A(site);
        AA *= Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
      } else {
        AA = ProjH[b - 1];
        AA *= psi0.A(site);
        AA *= Ops[b];
        AA *= psi0.A(nextsite);
        AA *= Ops[b + 1];
        AA *= ProjH[b + 2];
      }

      AA.noprime();
      ITensor U = A_[b], D, V;
      auto spec = svd(AA, U, D, V, args);

      A_[b] = U * D;
      A_[b + 1] = V;
      OSI_[b] = Nonewards;
      OSI_[b + 1] = Upwards;
      OC_ = site;

      if (b == NArms_ - 1) {
        ITensor M = psi0.A(nextsite), Mp = A_[b + 1];
        Mp.primeExcept(ImpBathsInds[b + 1]);
        ProjH[b + 1] = M * Ops[b + 1] * dag(Mp);
      } else if (b != 1) {
        ITensor M = psi0.A(nextsite), Mp = A_[b + 1];
        Mp.primeExcept(ImpBathsInds[b + 1]);
        ProjH[b + 1] = ProjH[b + 2] * M;
        ProjH[b + 1] *= Ops[b + 1];
        ProjH[b + 1] *= dag(Mp);
      }
    }
  }

  return;
}
*/

  void ForkTPS::ZipUpImpurityMPO(const std::vector<ITensor> &Ops, Args &args) {
    // this function approximatly applies an MPO acting only on the impurity sites
    // by using the zip up algorithm: "Minimally Entangled Typical Thermal State
    // Algorithms; Stoudenmire and White" assumes that the vector of operators is
    // right normal

    position(1);
    ITensor U, D, V, AA;

    SetSVDParams(1, *this, Downwards, args);

    for (auto i : range1(NArms() - 1)) {
      auto Isite = ImpSite(i);
      AA         = A_[i];
      if (i > 1) AA *= V;
      AA *= Ops[i];
      AA.noPrime();

      auto ArmLink = commonIndex(A(Isite), A(Isite + 1));
      //auto newLink = commonIndex(AA,  )
      if (i == 1)
        U = ITensor(sites_.si(Isite), ArmLink);
      else
        U = ITensor(sites_.si(Isite), ArmLink, commonIndex(AA, A(ImpSite(i - 1))));

      auto res = svd(AA, U, D, V, {args, "LeftTags", Names::TAGSI});
      V *= D;
      if (args.getReal("MaxTruncErr", 1.) < res.truncerr()) { args.add("MaxTruncErr", (double)res.truncerr()); }
      InsertOrthoTensor(U, Isite, Downwards);
    }

    A_[NArms()] *= V;
    A_[NArms()] *= Ops[NArms()];
    A_[NArms()].noPrime();
    OSI_[NArms()] = Nonewards;
    OC_           = ImpSite(NArms());

    position(1, args);

    return;
  }

  // //-------------------------------------------------------------------------------------------------------
  // //Output:
  // -----------------------------------------------------------------------------------
  // //-------------------------------------------------------------------------------------------------------

  std::vector<double> ForkTPS::ImpOccs() {
    std::vector<double> Occ(0);
    for (auto k : range1(NArms())) {
      auto site = ImpSite(k);
      position(site);
      Occ.push_back(std::real((A(site) * sites_.op("N", site) * dag(prime(A(site), "Site"))).cplx()));
    }

    return Occ;
  }

  void ForkTPS::PrintImpOcc(int numSpaces) {
    std::cout << std::string(numSpaces, ' ') << "Impurity Occupation:              ";
    const int outputPrecision = 5;

    std::cout.setf(std::ios::fixed, std::ios::floatfield); // set fixed floating format
    std::cout.precision(outputPrecision);

    auto Occ = ImpOccs();
    for (auto k : itertools::range(NArms())) { std::cout << std::setw(outputPrecision) << Occ.at(k) << "   "; }
    std::cout << std::endl;

    // reset format
    std::cout.precision(0);
    std::cout.unsetf(std::ios::fixed | std::ios::scientific);
  }

  void ForkTPS::PrintOccs() {

    std::cout << "Occupation: " << std::endl;
    for (int site = 1; site <= N(); site++) {
      position(site);
      if (IsImp(site) && site != 1) { std::cout << std::endl << " | " << std::endl; }
      std::cout << std::setprecision(4) << std::real((A(site) * sites_.op("N", site) * dag(prime(A(site), "Site"))).cplx()) << " - ";
    }
    std::cout << std::endl;
  }

  /** Calculates the tensor of the overlap $\rangle \psi | \phi \langle$ which is actually a scalar tensor.
  * This function is called by the overlap function.
  */
  ITensor OverlapTensor(const ForkTPS &psi, const ForkTPS &phi) {
    int NArms = psi.NArms();
    int N     = psi.N();

    // Checks
    if (psi.sites().si(1) != phi.sites().si(1)) Error("overlap: psi and phi must be based off the same SiteSet.");
    if (N != phi.N()) Error("overlap: N of psi and phi not equal.");

    ITensor res;
    for (int arm = 1; arm < NArms; arm++) {
      ITensor ContrArm;
      for (int indx = 1; indx <= psi.NBath(arm); indx++) {
        int site = psi.ArmToSite(arm, indx);
        indx == 1 ? ContrArm = phi.A(site) : ContrArm *= phi.A(site);
        ContrArm *= dag(prime(psi.A(site), "Link"));
      }

      int Isite = psi.ImpSite(arm);
      arm == 1 ? res = phi.A(Isite) : res *= phi.A(Isite);
      res *= ContrArm;
      res *= dag(prime(psi.A(Isite), "Link"));
    }

    // last Impurity and Arm
    int Isite = psi.ImpSite(NArms);
    res *= phi.A(Isite);
    res *= dag(prime(psi.A(Isite), "Link"));
    // last bath outwards
    for (int indx = psi.NBath(NArms); indx >= 1; --indx) {
      int site = psi.ArmToSite(NArms, indx);
      res *= phi.A(site);
      res *= dag(prime(psi.A(site), "Link"));
    }

    return res;
  }

  Complex overlap(const ForkTPS &psi, const ForkTPS &phi) { return OverlapTensor(psi, phi).cplx(); }

  //Complex overlapC(const ForkTPS &psi, const ForkTPS &phi) { return OverlapTensor(psi, phi).cplx(); }

} // namespace forktps
