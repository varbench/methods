//
// Distributed under the ITensor Library License, Version 1.1.
//    (See accompanying LICENSE file.)
//
#ifndef __AIM_MMP_ForkSites__
#define __AIM_MMP_ForkSites__

#include "forktps/fork/Fork.hpp"
#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {

  //using AIM_ForkSites = BasicSiteSet<ForkSite>;

  /**
  * SiteSet on Fork geometry with purified impurity degrees of 
  * freedom, i.e. double hilbert space. Inherits from AIM_ForkSites, because
  * many forktps function like creating MPOs are implemented with AIM_ForkSites.
  */
  class PurificationSites : public AIM_ForkSites {

    public:
    /// Default Constructor.
    PurificationSites() : AIM_ForkSites() {}

    /** Constructs the SiteSet with *N* sites in total and *NArms* arms. Use *args* to define what 
    *   conserved quantities the SiteSet has.
    * @param N      int
    *               Total number of Sites.
    * @param NArms  int
    *               Number of arms.
    * @param args   itensor::Args
    *               Parameters defining which quantum numbers are conserved. \n
    * @param conserveN    bool (default: true)
    *                     Particle number conservation.
    * @param conserveSz   bool (default: true)
    *                     Spin Sz conservation.
    */
    PurificationSites(int N, int NArms, const Args &args = Args::global());

    /** Constructs the SiteSet with *Nbath[m]* bath sites on arm *m*. Use *args* to define what 
    *   conserved quantities the SiteSet has.
    *
    * @param Nbath  std::vector<int>
    *               Number of bath sites, vector is one-indexed.
    * @param args   itensor::Args
    *               Parameters defining which quantum numbers are conserved. \n
    * @param conserveN    bool (default: true)
    *                     Particle number conservation.
    * @param conserveSz   bool (default: true)
    *                     Spin Sz conservation.
    */
    PurificationSites(const std::vector<int> &Nbath, const Args &args = Args::global());

    PurificationSites(const ForkTPS &psi, const Args &args = Args::global());

    private:
    /** Constructs the whole SiteSet including all indices. Make this virtual
    *   even though most likely this wont affect anything.
    */
    void constructSites(const Args &args) override;

    // Returns quantum numbers for thermal doubled hilbert space
    std::tuple<QN, QN, QN, QN> ThermalQNs(int arm);

    public:
    void read(std::istream &s);

    void write(std::ostream &s) const;
  };

  //void write(std::ostream &s, AIM_ForkSites) const;

} //namespace forktps

#endif
