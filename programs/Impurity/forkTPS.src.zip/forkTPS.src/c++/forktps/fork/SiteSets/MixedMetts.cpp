//
// Distributed under the ITensor Library License, Version 1.1.
//    (See accompanying LICENSE file.)
//

#include "MixedMetts.hpp"
#include "ForkSite.hpp"

#include "forktps/fork/Fork.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"
#include "forktps/fork/makros.hpp"
#include "forktps/fork/typenames.hpp"

#include <itensor/mps/siteset.h>

#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {

  AIM_MettsPurification::AIM_MettsPurification(int N, int NArms, const Args &args) : AIM_ForkSites(N, NArms, args) {
    AIM_MettsPurification::constructSites(args);
  }

  AIM_MettsPurification::AIM_MettsPurification(const std::vector<int> &Nbath, const Args &args) : AIM_ForkSites(Nbath, args) {
    AIM_MettsPurification::constructSites(args);
  }

  AIM_MettsPurification::AIM_MettsPurification(const ForkTPS &psi, const Args &args) : AIM_ForkSites(psi, args) {}

  AIM_MettsPurification::AIM_MettsPurification(bath b, const Args &args) : AIM_ForkSites(b.N(), b.NArms(), args) {
    AIM_MettsPurification::constructSites(b, args);
  }

  void AIM_MettsPurification::constructSites(const Args &args) {
    UNUSED_VAR(args);
    auto sites = SiteStore(Fork::N());

    for (auto arm : range1(NArms())) {
      auto [Emp, Occ]                = AIM_ForkSites::QNs(arm); // Normal QNs
      auto [PEmp, PPhys, PAux, PDou] = ThermalQNs(arm);         // Purified QNs

      //bath indices
      for (auto k : range1(NBath(arm))) {
        std::string tgs = "s=" + str(ArmToSite(arm, k)) + ",Site,Bath";
        Index I;
        if (!conserveSz && !conserveN) // construct index a differently when no conservation at all, not sure if this is necessary
          I = Index(QN(), 2, Out, tgs);
        else
          I = Index(Emp, 1, Occ, 1, Out, tgs);

        sites.set(ArmToSite(arm, k), ForkSite(I));
      }

      //impurity index
      std::string tgs = "s=" + str(ImpSite(arm)) + ",Site,Imp";
      Index I;
      if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
        I = Index(QN(), 4, Out, tgs);
      else
        I = Index(PEmp, 1, PPhys, 1, PAux, 1, PDou, 1, Out, tgs);

      sites.set(ImpSite(arm), ForkSite(I));
    }
    SiteSet::init(std::move(sites));
  }

  void AIM_MettsPurification::constructSites(bath b, const Args &args) {
    auto purifyScale = args.getReal("PurificationScale");
    auto sites       = SiteStore(Fork::N());

    for (auto arm : range1(NArms())) {
      auto [Emp, Occ]                = AIM_ForkSites::QNs(arm);
      auto [PEmp, PPhys, PAux, PDou] = ThermalQNs(arm);

      triqs_indx indx = b.FTPSIndxToBlock(arm);

      //bath indices
      for (auto k : range1(NBath(arm))) {
        std::string tgs = "s=" + str(ArmToSite(arm, k)) + ",Site,Bath";
        Index I;

        if (abs(b.eps(indx, k - 1)) <= purifyScale) {
          // purify this site
          if (!conserveSz && !conserveN)
            I = Index(QN(), 4, Out, tgs);
          else
            I = Index(PEmp, 1, PPhys, 1, PAux, 1, PDou, 1, Out, tgs);
        } else {
          // do not purify
          if (!conserveSz && !conserveN) // construct index a differently when no conservation at all, not sure if this is necessary
            I = Index(QN(), 2, Out, tgs);
          else
            I = Index(Emp, 1, Occ, 1, Out, tgs);
        }

        sites.set(ArmToSite(arm, k), ForkSite(I));
      }

      //impurity index
      std::string tgs = "s=" + str(ImpSite(arm)) + ",Site,Imp";
      Index I;
      if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
        I = Index(QN(), 4, Out, tgs);
      else
        I = Index(PEmp, 1, PPhys, 1, PAux, 1, PDou, 1, Out, tgs);

      sites.set(ImpSite(arm), ForkSite(I));
    }
    SiteSet::init(std::move(sites));
  }

  std::tuple<QN, QN, QN, QN> AIM_MettsPurification::ThermalQNs(int arm) const {
    QN Emp, Phy, Aux, Dou;
    int spinSign = arm % 2 == 1 ? 1 : -1;

    if (conserveN && conserveSz) {
      // N and Sz conserved
      Emp = QN({"Sz", 0}, {"Nf", 0, -1});
      Phy = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Aux = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Dou = QN({"Sz", spinSign * 2}, {"Nf", 2, -1});
    } else if (conserveN) {
      Error("conserve N only not implemented");
    } else if (conserveSz) {
      // Sz conserved only
      Error("conserve Sz only not implemented");
    } else {
      // nothing conserved
      Emp = QN();
      Phy = QN();
      Aux = QN();
      Dou = QN();
    }

    return std::make_tuple(Emp, Phy, Aux, Dou);
  }

  bool AIM_MettsPurification::isPurified(int site) const { return (dim(si(site)) == 4) ? true : false; }

} //namespace forktps
