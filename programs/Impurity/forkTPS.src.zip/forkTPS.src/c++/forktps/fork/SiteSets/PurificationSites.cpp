//
// Distributed under the ITensor Library License, Version 1.1.
//    (See accompanying LICENSE file.)
//

#include "PurificationSites.hpp"
#include "ForkSite.hpp"

#include "forktps/fork/Fork.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"
#include "forktps/fork/makros.hpp"

#include <itensor/mps/siteset.h>

#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {

  PurificationSites::PurificationSites(int N, int NArms, const Args &args) : AIM_ForkSites(N, NArms, args) {
    PurificationSites::constructSites(args);
  }

  PurificationSites::PurificationSites(const std::vector<int> &Nbath, const Args &args) : AIM_ForkSites(Nbath, args) {
    PurificationSites::constructSites(args);
  }

  PurificationSites::PurificationSites(const ForkTPS &psi, const Args &args) : AIM_ForkSites(psi, args) {}

  void PurificationSites::constructSites(const Args &args) {
    UNUSED_VAR(args);
    auto sites = SiteStore(Fork::N());

    for (auto arm : range1(NArms())) {
      Index I;
      auto [IEmp, IPhys, IAux, IDou] = ThermalQNs(arm);

      //bath indices
      for (auto i : range1(NBath(arm))) {
        std::string tgs = "s=" + str(ArmToSite(arm, i)) + ",Site,Bath";
        if (!conserveSz && !conserveN) // construct index a little different when no conservation at all, not sure if this is necessary
          I = Index(QN(), 4, Out, tgs);
        else
          I = Index(IEmp, 1, IPhys, 1, IAux, 1, IDou, 1, Out, tgs);

        sites.set(ArmToSite(arm, i), ForkSite(I));
      }

      //impurity index
      std::string tgs = "s=" + str(ImpSite(arm)) + ",Site,Imp";
      if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
        I = Index(QN(), 4, Out, tgs);
      else
        I = Index(IEmp, 1, IPhys, 1, IAux, 1, IDou, 1, Out, tgs);

      sites.set(ImpSite(arm), ForkSite(I));
    }
    SiteSet::init(std::move(sites));
  }

  std::tuple<QN, QN, QN, QN> PurificationSites::ThermalQNs(int arm) {
    QN Emp, Phy, Aux, Dou;
    int spinSign = arm % 2 == 1 ? 1 : -1;

    if (conserveN && conserveSz) {
      // N and Sz conserved
      Emp = QN({"Sz", 0}, {"Nf", 0, -1});
      Phy = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Aux = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Dou = QN({"Sz", spinSign * 2}, {"Nf", 2, -1});
    } else if (conserveN) {
      Error("conserve N only not implemented");
    } else if (conserveSz) {
      // Sz conserved only
      Error("conserve Sz only not implemented");
    } else {
      // nothing conserved
      Emp = QN();
      Phy = QN();
      Aux = QN();
      Dou = QN();
    }

    return std::make_tuple(Emp, Phy, Aux, Dou);
  }

} //namespace forktps
