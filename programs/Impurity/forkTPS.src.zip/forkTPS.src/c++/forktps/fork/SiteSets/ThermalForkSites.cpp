#include <forktps/fork/SiteSets/ForkSite.hpp>
#include <forktps/fork/SiteSets/ThermalForkSites.hpp>

#include <forktps/fork/Fork.hpp>
#include <forktps/fork/makros.hpp>

#include <itensor/mps/siteset.h>

#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {
  ThermalForkSites::ThermalForkSites(int N_, int NArms_, std::vector<int> const &doubledBath_, const Args &args)
     : Fork(N_, NArms_),
       conserveN(args.getBool("conserveN", true)),
       conserveSz(args.getBool("conserveSz", true)),
       impPurified(args.getBool("impPurified", false)),
       doubledBath(doubledBath_) {
    constructSites();
  }

  bool ThermalForkSites::ImpPurified() const { return impPurified; };

  void ThermalForkSites::constructSites() {
    auto sites = SiteStore(Fork::N());

    for (auto arm : range1(NArms())) {
      auto [Emp, Occ] = QNs(arm);

      //bath indices
      for (auto i : range1(NBath(arm))) {

        std::string tgs = "s=" + str(ArmToSite(arm, i)) + ",Site,Bath";
        Index I;
        if (!std::count(doubledBath.begin(), doubledBath.end(), ArmToSite(arm, i))) {
          if (!conserveSz && !conserveN) // construct index a little different when no conservation at all, not sure if this is necessary
            I = Index(QN(), 2, Out, tgs);
          else
            I = Index(Emp, 1, Occ, 1, Out, tgs);
        } else {
          auto [IEmp, IPhys, IAux, IDou] = ThermalQNs(arm);
          if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
            I = Index(QN(), 4, Out, tgs);
          else
            I = Index(IEmp, 1, IPhys, 1, IAux, 1, IDou, 1, Out, tgs);
        }
        sites.set(ArmToSite(arm, i), ForkSite(I));
      }

      //impurity index
      std::string tgs = "s=" + str(ImpSite(arm)) + ",Site,Imp";
      Index I;
      if (!impPurified) {
        if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
          I = Index(QN(), 2, Out, tgs);
        else
          I = Index(Emp, 1, Occ, 1, Out, tgs);
      } else {
        auto [IEmp, IPhys, IAux, IDou] = ThermalQNs(arm);
        if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
          I = Index(QN(), 4, Out, tgs);
        else
          I = Index(IEmp, 1, IPhys, 1, IAux, 1, IDou, 1, Out, tgs);
      }

      sites.set(ImpSite(arm), ForkSite(I));
    }
    SiteSet::init(std::move(sites));
  }

  std::pair<QN, QN> ThermalForkSites::QNs(int arm) {
    QN Occ, Emp;
    bool spinUpArm = (arm % 2 == 1);

    if (conserveN && conserveSz) {
      // N and Sz conserved
      Emp = QN({"Sz", 0}, {"Nf", 0, -1});
      Occ = spinUpArm ? QN({"Sz", 1}, {"Nf", 1, -1}) : QN({"Sz", -1}, {"Nf", 1, -1});
    } else if (conserveN) {
      // N conserved only
      Emp = QN({"Nf", 0, -1});
      Occ = QN({"Nf", 1, -1});
    } else if (conserveSz) {
      // Sz conserved only
      Emp = QN({"Sz", 0});
      Occ = spinUpArm ? QN({"Sz", 1}) : QN({"Sz", -1});
    } else {
      // nothing conserved
      Emp = QN();
      Occ = QN();
    }

    return std::make_pair(Emp, Occ);
  }

  std::tuple<QN, QN, QN, QN> ThermalForkSites::ThermalQNs(int arm) {
    QN Emp, Phy, Aux, Dou;
    int spinSign = arm % 2 == 1 ? 1 : -1;

    if (conserveN && conserveSz) {
      // N and Sz conserved
      Emp = QN({"Sz", 0}, {"Nf", 0, -1});
      Phy = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Aux = QN({"Sz", spinSign * 1}, {"Nf", 1, -1});
      Dou = QN({"Sz", spinSign * 2}, {"Nf", 2, -1});
    } else if (conserveN) {
      Emp = QN({"Nf", 0, -1});
      Phy = QN({"Nf", 1, -1});
      Aux = QN({"Nf", 1, -1});
      Dou = QN({"Nf", 2, -1});
      //      Error("conserve N only not implemented");
    } else if (conserveSz) {
      // Sz conserved only
      Error("conserve Sz only not implemented");
    } else {
      // nothing conserved
      Emp = QN();
      Phy = QN();
      Aux = QN();
      Dou = QN();
    }

    return std::make_tuple(Emp, Phy, Aux, Dou);
  }
  /*
  void ThermalForkSites::read(std::istream &s) {
    SiteSet::readType<ForkSite>(s);
    Fork::read(s);
  }

  void ThermalForkSites::write(std::ostream &s) const {
    SiteSet::write(s);
    Fork::write(s);
  }
  */

} // namespace forktps