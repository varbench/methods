#ifndef __AIM_FORKSITE__
#define __AIM_FORKSITE__

#include <itensor/index.h>
#include <itensor/itensor.h>

#include "forktps/fork/makros.hpp"

#include <utility>

using namespace itensor;

namespace forktps {
  class ForkSite {
    Index s;

    public:
    /// Default Constructor
    ForkSite() = default;

    /// Constructor from an Index *I*
    ForkSite(Index I) : s(std::move(I)) {}

    /// Returns the index.
    [[nodiscard]] Index index() const { return s; }

    /** Returns the IndexVal of the index with name *state*. Here, the user
    * defines what names indices have, for example that the first entry of the index is called "Emp" and the second "Occ".
    */
    IndexVal state(std::string const &state) {
      if (s.size() == 4) {
        // thermal site
        if (state == "00" || state == "Emp")
          return s(1);
        else if (state == "10")
          return s(2); // physical site occupied
        else if (state == "01")
          return s(3); // auxiliary site occupied
        else if (state == "11")
          return s(4);
        else
          throw ITError("State " + state + " not recognized");
      } else if (s.size() == 2) {
        // standard site
        if (state == "0" || state == "Emp")
          return s(1);
        else if (state == "1" || state == "Occ")
          return s(2);
        else
          throw ITError("State " + state + " not recognized");
      } else {
        Error("incorrect size");
      }

      return IndexVal{};
    }

    /** Operators defined on each site. Here the user defines what the meaning of operator "N" 
    *   is for example.
    *   @param opname     std::string
    *                     Name of the operator.
    *   @param args       itensor::Args (default: Args::global)
    *                     Because this is the implementation of an abstract function, args is necessary, but does nothing here.
    */
    [[nodiscard]] ITensor op(std::string const &opname, Args const &args = Args::global()) const {
      UNUSED_VAR(args);
      auto sP = prime(s);
      ITensor Op(dag(s), sP);

      if (s.size() == 4) {
        // thermal site with doubled hilbert space
        IndexVal Emp(s(1)), EmpP(sP(1)), Phy(s(2)), PhyP(sP(2)), Aux(s(3)), AuxP(sP(3)), Dou(s(4)), DouP(sP(4));

        if (opname == "NPhys" || opname == "N" || opname == "Nk") {
          Op.set(Phy, PhyP, 1);
          Op.set(Dou, DouP, 1);
        } else if (opname == "NAux") {
          Op.set(Aux, AuxP, 1);
          Op.set(Dou, DouP, 1);
        } else if (opname == "CPhys" || opname == "Ck") {
          Op.set(Phy, EmpP, 1);
          Op.set(Dou, AuxP, 1);
        } else if (opname == "CDPhys" || opname == "CkD") {
          Op.set(Emp, PhyP, 1);
          Op.set(Aux, DouP, 1);
        } else if (opname == "CAux") {
          Op.set(Aux, EmpP, 1);
          Op.set(Dou, PhyP, -1);
        } else if (opname == "CDAux") {
          Op.set(Emp, AuxP, 1);
          Op.set(Phy, DouP, -1);
        } else if (opname == "p" || opname == "F") {
          Op.set(Emp, EmpP, +1);
          Op.set(Phy, PhyP, -1);
          Op.set(Aux, AuxP, -1);
          Op.set(Dou, DouP, +1);
        } else {
          Error("Operator " + opname + " name not recognized on purified site");
        }
      } else {
        // usual site
        IndexVal Emp(s(1)), EmpP(sP(1)), Occ(s(2)), OccP(sP(2));

        const double half = 0.5;

        if (opname == "N" || opname == "Nk") {
          Op.set(Occ, OccP, 1);
        } else if (opname == "One-N") {
          Op.set(Emp, EmpP, 1);
        } else if (opname == "Nsym" || opname == "Nksym") {
          Op.set(Emp, EmpP, -half);
          Op.set(Occ, OccP, +half);
        } else if (opname == "Ck") {
          Op.set(Occ, EmpP, 1);
        } else if (opname == "CkD") {
          Op.set(Emp, OccP, 1);
        } else if (opname == "p" || opname == "F") {
          Op.set(Emp, EmpP, +1);
          Op.set(Occ, OccP, -1);
        } else if (opname == "Px+") { // projector onto state | + > of Sx basis
          Op.set(Emp, EmpP, +half);
          Op.set(Occ, OccP, +half);
          Op.set(Emp, OccP, +half);
          Op.set(Occ, EmpP, +half);
        } else if (opname == "Px-") { // projector onto state | - > of Sx basis
          Op.set(Emp, EmpP, +half);
          Op.set(Occ, OccP, +half);
          Op.set(Emp, OccP, -half);
          Op.set(Occ, EmpP, -half);
        } else {
          Error("Operator " + opname + " name not recognized");
        }
      }

      return Op;
    }
  };
} // namespace forktps
#endif
