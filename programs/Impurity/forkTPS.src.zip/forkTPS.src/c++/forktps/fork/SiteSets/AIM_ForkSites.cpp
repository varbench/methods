//
// Distributed under the ITensor Library License, Version 1.1.
//    (See accompanying LICENSE file.)
//

#include "AIM_ForkSites.hpp"
#include "ForkSite.hpp"

#include "forktps/fork/Fork.hpp"
#include "forktps/fork/makros.hpp"

#include <itensor/mps/siteset.h>

#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {

  AIM_ForkSites::AIM_ForkSites(int N, int NArms, const Args &args)
     : Fork(N, NArms), conserveN(args.getBool("conserveN", true)), conserveSz(args.getBool("conserveSz", true)) {
    constructSites(args);
  }

  AIM_ForkSites::AIM_ForkSites(const std::vector<int> &Nbath, const Args &args)
     : Fork(Nbath), conserveN(args.getBool("conserveN", true)), conserveSz(args.getBool("conserveSz", true)) {
    constructSites(args);
  }

  AIM_ForkSites::AIM_ForkSites(const ForkTPS &psi, const Args &args)
     : SiteSet(psi.sites()), Fork(psi), conserveN(args.getBool("conserveN", true)), conserveSz(args.getBool("conserveSz", true)) {}

  void AIM_ForkSites::constructSites(const Args &args) {
    UNUSED_VAR(args);
    auto sites = SiteStore(Fork::N());

    for (auto arm : range1(NArms())) {
      auto [Emp, Occ] = QNs(arm);

      //bath indices
      for (auto i : range1(NBath(arm))) {
        std::string tgs = "s=" + str(ArmToSite(arm, i)) + ",Site,Bath";
        Index I;
        if (!conserveSz && !conserveN) // construct index a little different when no conservation at all, not sure if this is necessary
          I = Index(QN(), 2, Out, tgs);
        else
          I = Index(Emp, 1, Occ, 1, Out, tgs);

        sites.set(ArmToSite(arm, i), ForkSite(I));
      }

      //impurity index
      std::string tgs = "s=" + str(ImpSite(arm)) + ",Site,Imp";
      Index I;
      if (!conserveSz && !conserveN) // construct index differently when no conservation at all, not sure if this is necessary
        I = Index(QN(), 2, Out, tgs);
      else
        I = Index(Emp, 1, Occ, 1, Out, tgs);

      sites.set(ImpSite(arm), ForkSite(I));
    }
    SiteSet::init(std::move(sites));
  }

  std::pair<QN, QN> AIM_ForkSites::QNs(int arm) {
    QN Occ, Emp;
    bool spinUpArm = (arm % 2 == 1);

    if (conserveN && conserveSz) {
      // N and Sz conserved
      Emp = QN({"Sz", 0}, {"Nf", 0, -1});
      Occ = spinUpArm ? QN({"Sz", 1}, {"Nf", 1, -1}) : QN({"Sz", -1}, {"Nf", 1, -1});
    } else if (conserveN) {
      // N conserved only
      Emp = QN({"Nf", 0, -1});
      Occ = QN({"Nf", 1, -1});
    } else if (conserveSz) {
      // Sz conserved only
      Emp = QN({"Sz", 0});
      Occ = spinUpArm ? QN({"Sz", 1}) : QN({"Sz", -1});
    } else {
      // nothing conserved
      Emp = QN();
      Occ = QN();
    }

    return std::make_pair(Emp, Occ);
  }

  void AIM_ForkSites::read(std::istream &s) {
    SiteSet::readType<ForkSite>(s);
    Fork::read(s);
  }

  void AIM_ForkSites::write(std::ostream &s) const {
    SiteSet::write(s);
    Fork::write(s);
  }

} //namespace forktps
