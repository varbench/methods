//
// Distributed under the ITensor Library License, Version 1.1.
//    (See accompanying LICENSE file.)
//
#ifndef __AIM_TREESITES__
#define __AIM_TREESITES__

#include "../Fork.hpp"
#include "forktps/fork/ForkTPS.hpp"

#include <itensor/mps/siteset.h>
#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {

  //using AIM_ForkSites = BasicSiteSet<ForkSite>;

  /** Base SiteSet for Fork geometry with empty/occupied degrees of freedom
  *   on each lattice site.
  */

  // Currently we treat AIM_ForkSites as the base class and inherit from it
  // to create a SiteSet with purification degrees of freedom (doubled hilbert space)
  // this is not the cleanest way of coding which would be to create an abstract
  // base class which is a SiteSet and a Fork. All other SiteSets inherit from
  // this class and implement in what they differ.
  class AIM_ForkSites : public SiteSet, public Fork {

    public:
    /// Default Constructor.
    AIM_ForkSites() : Fork() {}

    /** Constructs the SiteSet with *N* sites in total and *NArms* arms. Use *args* to define what 
    *   conserved quantities the SiteSet has.
    * @param N      int
    *               Total number of Sites.
    * @param NArms  int
    *               Number of arms.
    * @param args   itensor::Args
    *               Parameters defining which quantum numbers are conserved. \n
    * @param conserveN    bool (default: true)
    *                     Particle number conservation.
    * @param conserveSz   bool (default: true)
    *                     Spin Sz conservation.
    */
    AIM_ForkSites(int N, int NArms, const Args &args = Args::global());

    /** Constructs the SiteSet with *Nbath[m]* bath sites on arm *m*. Use *args* to define what 
    *   conserved quantities the SiteSet has.
    *
    * @param Nbath  std::vector<int>
    *               Number of bath sites, vector is one-indexed.
    * @param args   itensor::Args
    *               Parameters defining which quantum numbers are conserved. \n
    * @param conserveN    bool (default: true)
    *                     Particle number conservation.
    * @param conserveSz   bool (default: true)
    *                     Spin Sz conservation.
    */
    AIM_ForkSites(const std::vector<int> &Nbath, const Args &args = Args::global());

    AIM_ForkSites(const ForkTPS &psi, const Args &args = Args::global());

    private:
    /** Constructs the whole SiteSet including all indices. Make virtual since 
    *   different ForkSite classes overwrite this 
    *   (in practice, making it virutal has no effect, since construct )
    */
    virtual void constructSites(const Args &args);

    public:
    void read(std::istream &s);

    void write(std::ostream &s) const;

    protected:
    /** Returns two quantum number objects storing the quantum number flux for
    * the states empty and occupied at arm *arm*. It is convention that if
    * arm is odd (even), the arm is describes spin-up (spin-down) degerees of 
    * freedom. The actual values returned are determined by *conserveN* and *conserveSz*.
    */
    std::pair<QN, QN> QNs(int arm);

    bool conserveN;
    bool conserveSz;
  };

  //void write(std::ostream &s, AIM_ForkSites) const;

} //namespace forktps

#endif
