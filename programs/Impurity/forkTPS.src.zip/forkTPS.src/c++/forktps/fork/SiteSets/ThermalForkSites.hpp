#ifndef __THERMALFORKITES__
#define __THERMALFORKITES__
#include <forktps/fork/Fork.hpp>
#include <forktps/fork/ForkTPS.hpp>

#include <itensor/mps/siteset.h>
#include <itensor/util/args.h>
#include <utility>

using namespace itensor;

namespace forktps {
  class ThermalForkSites : public SiteSet, public Fork {
    public:
    ThermalForkSites() : Fork(){};
    ThermalForkSites(int N_, int NArms_, std::vector<int> const &doubledBath_, const Args &args = Args::global());

    private:
    void constructSites();
    std::pair<QN, QN> QNs(int arm);
    std::tuple<QN, QN, QN, QN> ThermalQNs(int arm);

    public:
    void read(std::istream &s);
    void write(std::ostream &s) const;
    bool ImpPurified() const;

    private:
    bool conserveN;
    bool conserveSz;
    bool impPurified = false;
    std::vector<int> doubledBath;
  };
} // namespace forktps
#endif