#include "Gates.hpp"
#include "HelperFunctions.hpp"

#include <algorithm>
#include <iostream>

using namespace itensor;

namespace forktps {

  // a gate is a tensor acting on two sites
  // this gate function also supports making MPO-like single site gates
  // which can be usefull for the impurities, but this is not used currently
  // since impurities are time evolved using MPOs

  ForkGate::ForkGate() {
    Nsites_ = 0;
    Sites_.resize(0);
  }

  ForkGate::ForkGate(ITensor G, int i, int j) {
    // produces a gate acting on site i and site j
    // with ITensor G

    j == 0 ? Nsites_ = 1 : Nsites_ = 2;

    if (j < i && j != 0) std::swap(i, j);

    Sites_.resize(0);
    Sites_.push_back(i);
    Sites_.push_back(j);
    gate_ = G;
  }

  int ForkGate::i() const { return Sites_[0]; }

  int ForkGate::j() const { return Sites_[1]; }

  int ForkGate::NSites() const { return Nsites_; }

  ITensor ForkGate::gate() const { return gate_; }

  // prime level methods:
  void ForkGate::mapPrime(int oldp, int newp) { gate_.mapPrime(oldp, newp); }

  ForkGate &ForkGate::operator*=(ForkGate &rhs) {
    // multiplies the gate of rhs onto the gate of the instance in a way that
    // first the gate of the instance acts, then the gate of rhs
    // rhs is not passed as const, since prime levels need to be changed

    // checks:
    if (rhs.NSites() != (*this).NSites()) {
      std::cout << rhs.NSites() << " " << this->NSites() << std::endl;
      Error("Gate operator *=: Number of gate sites needs to be the same");
      return (*this);
    }
    if (rhs.i() != (*this).i()) {
      std::cout << rhs.i() << " " << this->i() << std::endl;
      Error("Gate operator *=: Site i doesnt match");
      return (*this);
    }
    if (rhs.j() != (*this).j()) {
      std::cout << rhs.j() << " " << this->j() << std::endl;
      Error("Gate operator *=: Site j doesnt match");
      return (*this);
    }

    rhs.mapPrime(1, 2);
    rhs.mapPrime(0, 1);
    (*this).gate_ *= rhs.gate();

    (*this).mapPrime(2, 1);
    rhs.mapPrime(1, 0);
    rhs.mapPrime(2, 1);

    return *this;
  }

  const ForkGate ForkGate::operator*(ForkGate &other) const {
    ForkGate result = *this;
    result *= other;
    return result;
  }

  // template <typename T>
  void ForkGate::expGate(double dt, const SiteSet &sites) {
    // exponentiates the gate ie: calculates exp( -dt*gate_ )
    // note that calling this function with positive dt actually calculates exp(
    // -dt * G) sites is needed for the Identity in the series expansion of e^x =
    // 1
    // + x + x^2/2 + ...

    ITensor hh = -dt * gate_, unit = sites.op("Id", (*this).i()) * sites.op("Id", (*this).j());

    ITensor term = hh;
    hh.mapPrime(1, 2);
    hh.mapPrime(0, 1);

    for (int ord = 150; ord >= 1; --ord) {
      term /= ord;
      gate_ = unit + term;
      term  = gate_ * hh;
      term.mapPrime(2, 1);
    }
    return;
  }

  void ForkGate::expGate(Complex dt, const SiteSet &sites) {
    // complex version of expGate
    ITensor hh = -dt * gate_, unit;

    if (hasQNs(hh))
      unit = sites.op("Id", (*this).i()) * sites.op("Id", (*this).j());
    else
      unit = removeQNs(sites.op("Id", (*this).i()) * sites.op("Id", (*this).j()));

    ITensor term = hh;
    hh.mapPrime(1, 2);
    hh.mapPrime(0, 1);

    for (int ord = 150; ord >= 1; --ord) {
      term /= ord;
      gate_ = unit + term;
      term  = gate_ * hh;
      term.mapPrime(2, 1);
    }
    return;
  }

  void ForkGate::MakeSwap(int i, int j, const SiteSet &sites) {
    // makes a swapgate between sites i and j
    // ATTENTION: SWAP gates need a sign if 2 electrons are swaped past each other
    // are swaped past each other!!!!

    if (i > j) {
      std::swap(i, j);
      Error("i>j not allowed for swap gates");
    }

    Nsites_ = 2;
    Sites_.resize(0);
    Sites_.push_back(i);
    Sites_.push_back(j);

    Index si = dag(sites.si(i)), siP = sites.siP(i);
    Index sj = dag(sites.si(j)), sjP = sites.siP(j);

    gate_ = ITensor(si, siP, sj, sjP);

    if (dim(si) == 2 && dim(sj) == 2) {
      // sites i and j are the same -> make normal swap gate
      gate_.set(si(1), sj(1), siP(1), sjP(1), +1);
      gate_.set(si(1), sj(2), siP(2), sjP(1), +1);
      gate_.set(si(2), sj(1), siP(1), sjP(2), +1);
      gate_.set(si(2), sj(2), siP(2), sjP(2), -1);
    }

    else if (dim(si) == 4 && dim(sj) == 2) {
      // 4 dim hilbert space is 1->empty, 2-> physical occupied, 3-> auxiliary occupied, 4-> doubly occupied

      // this gate only swaps the first of the two spins on the site with doubled hilbert space
      gate_.set(si(1), sj(1), siP(1), sjP(1), +1); // |00>|0>   ->  |00>|0>   no sign
      gate_.set(si(2), sj(1), siP(1), sjP(2), +1); // |10>|0>   ->  |00>|1>   no sign
      gate_.set(si(3), sj(1), siP(3), sjP(1), +1); // |01>|0>   ->  |01>|0>   no sign
      gate_.set(si(4), sj(1), siP(3), sjP(2), -1); // |11>|0>   ->  |01>|1>   (-1)^1

      gate_.set(si(1), sj(2), siP(2), sjP(1), +1); // |00>|1>   ->  |10>|0>   no sign
      gate_.set(si(2), sj(2), siP(2), sjP(2), -1); // |10>|1>   ->  |10>|1>   (-1)^1
      gate_.set(si(3), sj(2), siP(4), sjP(1), -1); // |01>|1>   ->  |11>|0>   (-1)^1
      gate_.set(si(4), sj(2), siP(4), sjP(2), -1); // |11>|1>   ->  |11>|1>   (-1)^3
    } else if (dim(si) == 2 && dim(sj) == 4) {
      // site j is the impurity -> site i is up arm
      // this gate only swaps the first of the two spins on the site with doubled hilbert space
      gate_.set(si(1), sj(1), siP(1), sjP(1), +1); // |0>|00>   ->  |0>|00>   no sign
      gate_.set(si(1), sj(2), siP(2), sjP(1), +1); // |0>|10>   ->  |1>|00>   no sign
      gate_.set(si(1), sj(3), siP(1), sjP(3), +1); // |0>|01>   ->  |0>|01>   no sign
      gate_.set(si(1), sj(4), siP(2), sjP(3), +1); // |0>|11>   ->  |1>|01>   no sign

      gate_.set(si(2), sj(1), siP(1), sjP(2), +1); // |1>|00>   ->  |0>|10>   no sign
      gate_.set(si(2), sj(2), siP(2), sjP(2), -1); // |1>|10>   ->  |1>|10>   (-1)^1
      gate_.set(si(2), sj(3), siP(1), sjP(4), +1); // |1>|01>   ->  |0>|11>   no sign
      gate_.set(si(2), sj(4), siP(2), sjP(4), -1); // |1>|11>   ->  |1>|11>   (-1)^1

    } else if (dim(si) == 4 && dim(sj) == 4) {
      gate_.set(si(1), sj(1), siP(1), sjP(1), +1); // swap 0 electrons with 0 electrons
      gate_.set(si(2), sj(1), siP(1), sjP(2), +1); // swap 1 electrons with 0 electrons
      gate_.set(si(3), sj(1), siP(1), sjP(3), +1); // swap 1 electrons with 0 electrons
      gate_.set(si(4), sj(1), siP(1), sjP(4), +1); // swap 2 electrons with 0 electrons

      gate_.set(si(1), sj(2), siP(2), sjP(1), +1); // swap 0 electrons with 1 electrons
      gate_.set(si(2), sj(2), siP(2), sjP(2), -1); // swap 1 electrons with 1 electrons
      gate_.set(si(3), sj(2), siP(2), sjP(3), -1); // swap 1 electrons with 1 electrons
      gate_.set(si(4), sj(2), siP(2), sjP(4), +1); // swap 2 electrons with 1 electrons

      gate_.set(si(1), sj(3), siP(3), sjP(1), +1); // swap 0 electrons with 1 electrons
      gate_.set(si(2), sj(3), siP(3), sjP(2), -1); // swap 1 electrons with 1 electrons
      gate_.set(si(3), sj(3), siP(3), sjP(3), -1); // swap 1 electrons with 1 electrons
      gate_.set(si(4), sj(3), siP(3), sjP(4), +1); // swap 2 electrons with 1 electrons

      gate_.set(si(1), sj(4), siP(4), sjP(1), +1); // swap 0 electrons with 2 electrons
      gate_.set(si(2), sj(4), siP(4), sjP(2), +1); // swap 1 electrons with 2 electrons
      gate_.set(si(3), sj(4), siP(4), sjP(3), +1); // swap 1 electrons with 2 electrons
      gate_.set(si(4), sj(4), siP(4), sjP(4), +1); // swap 2 electrons with 2 electrons
    }

    /*
        partial swap gate:
        swaping eg up spin from impurity to the first bath site through gate G.
        it has matrix elements:

        G | 1 1 > = G | 0 0  >  =  |0 0  > = | 1 1 > ;     G | 2 1 > = G | up 0  >  =
        |0 up > = |1 3 > G | 1 2 > = G | 0 dn >  =  |0 dn > = | 1 2 > ;     G | 2 2 >
        = G | up dn >  =  |0 UD > = |1 4 > G | 1 3 > = G | 0 up >  =  |up 0 > = | 2 1
        > ;     G | 2 3 > = G | up up >  =  |up up> = |2 3 > G | 1 4 > = G | 0 UD >  =
        |up dn> = | 2 2 > ;     G | 2 4 > = G | up UD >  =  |up UD> = |2 4 >

        the meaning of the states of eg: " G | 1 4 > = G | 0 UD >  =  |up dn> = | 2 2
        > " is as follows: the first and the last bra-vector are labeled by the index
        of the corresponding state ie.: | 1 4 > means first and fourth basis state the
        second and third bra-vector on the other hand are labeled by what they are 0
        -> unoccupied, up (down) -> occupied by up (down) electron, UD -> doubly
        occupied

        swapping the down spin:

        G | 1 1 > = G | 0  0 >  =  |0 0  > = | 1 1 > ;     G | 1 2 > = G | 0  dn >  =
        | dn 0  > = | 2 1 > G | 2 1 > = G | dn 0 >  =  |0 dn > = | 1 2 > ;     G | 2 2
        > = G | dn dn >  =  | dn dn > = | 2 2 > G | 3 1 > = G | up 0 >  =  |up 0 > = |
        3 1 > ;     G | 3 2 > = G | up dn >  =  | UD 0  > = | 4 1 > G | 4 1 > = G | UD
        0 >  =  |up dn> = | 3 2 > ;     G | 4 2 > = G | UD dn >  =  | UD dn > = | 4 2
        >
        */
  }

} // namespace forktps
