#include "ForkCalculus.hpp"
#include "forktps/fork/ForkLocalOp.hpp"
#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/makros.hpp"
#include "typenames.hpp"
#include "HelperFunctions.hpp"
#include "lanczos.hpp"

#include <forktps/fork/HelperFunctions.hpp>
#include <itensor/arrow.h>
#include <itensor/global.h>
#include <itensor/iterativesolvers.h>
#include <itensor/itensor.h>
#include <limits>
#include <string>
#undef Print

#include <iterator>
#include <utility>

namespace forktps {

  /** Performs the subspace expansion discussed in Phys. Rev. B 91, 155115. It returns a pair of tensors where the first one is
  * the one that is expanded by the action of H, while the second one is just padded with zeros.
  *@param   i       int
  *                 Site which is expanded by the action of H.
  *@param   dir     OrthoState
  *                 Defines the direction in which the link is expanded.
  *@param   psi     ForkTPS
  *                 State providing the tensors to expand.
  *@param   heff    ForkLocalOp
  *                 Effective Hamiltonian providing the effective environments as well as the local FTPO tensor on site *i*.
  *@param   args    ITensor::Args
  *                 Arguments object storing the expansion strength as "SubspaceAlpha" (default 0.1)
 *                  and the maximum expanded bond dimension as "SubspaceMaxm" (default 100).
  */
  std::pair<ITensor, ITensor> SubspaceExpand(int i, OrthoState dir, const ForkTPS &psi, const ForkLocalOp &Heff, const Args &args);

  /**
  * Performs a Two-Site DMRG step on the impurity tensor of orbital *arm* and *arm+1*. 
  * The calculation minimizes the energy using the effective Hamiltonian *Heff* 
  * and stores the resulting state in *GS* and its energy in *energy*. *dir* defines 
  * the site on which the orthogonality center is placed after the update.  
  * @param GS       ForkTPS
  *                 State from which the start tensors are taken and where the updated tensors are stored.
  * @param Heff     ForkLocalOp
  *                 Effective Hamiltonian, represents the Hamiltonian.
  * @param energy   double
  *                 Updated energy after function call.
  * @param arm      int
  *                 Perform the update on arm *arm* and *arm+1*
  * @param dir      OrthoState
  *                 Defines where the orthogonality center before and more importantly after the update
  *                 is placed (dir == Downwards: *arm+1*, dir == Upwards: *arm*).
  * @param args     bool (default: false)
  *                 Parameters of the calculation, can take the following values:
  * @param UseDavidson    bool (default: false)
  *                       If true, use ITensors Davidson algorithm instead of Lanzcos.
  * @param CutoffI        double (default: Cutoff)
  *                       Truncated weight on Impurity-Impurity links. Note that this parameter 
  *                       is only active as long as subspace expansion is active. Afterwards 
  *                       it does not affect the calculation, since a single-site update is 
  *                       performed on the impurity-impurity links.
  * @param MaxmI          int (default: 200)
  *                       Maxmial bond dimension allowed for impurity-impurity links. 
  *                       Note that this parameter is only active as long as subspace 
  *                       expansion is active. Afterwards it does not affect the 
  *                       calculation, since a single-site update is performed 
  *                       on the impurity-impurity links.
  */
  double TS_DMRG_ImpStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int arm, OrthoState dir, Args &args);

  /**
  * Performs a Single-Site DMRG step on the impurity tensor on site *site*. 
  * The calculation minimizes the energy using the effective Hamiltonian *Heff* 
  * and stores the resulting state in *GS* and its energy in *energy*. *dir* 
  * defines the site on which the orthogonality center is placed after the 
  * update. *alpha* is the subspace-expansion mixing factor determining the 
  * strenght of the subspace expansion 
  * (Phys. Rev. B 91, 155115). If it is below 1E-15, no subspace expansion will 
  * be performed at all. The parameters of the calculation are stored in *args*
  * which can take the following values:     
  * @param      UseDavidson   bool (default: false)
  *                           If true, use ITensors Davidson algorithm instead of Lanzcos.
  * @param      CutoffI       double (default: Cutoff)
  *                           Truncated weight on Impurity-Impurity links. Note 
  *                           that this parameter is only active as long as subspace 
  *                           expansion is active. Afterwards it does not affect the 
  *                           calculation, since a single-site update is performed 
  *                           on the impurity-impurity links.
  * @param      MaxmI         int (default: 200)
  *                           Maxmial bond dimension allowed for impurity-impurity links. 
  *                           Note that this parameter is only active as long as 
  *                           subspace expansion is active. Afterwards it does 
  *                           not affect the calculation, since a single-site 
  *                           update is performed on the impurity-impurity links.
  */
  double SS_DMRG_ImpStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, double &alpha, Args &args);

  /**
  * Performs a Two-Site DMRG step on an impurity tensor and its neighboring bath 
  * tensor or on two bath tensors on the two sites *site* and *site+1*.
  * The calculation minimizes the energy using the effective Hamiltonian *Heff* 
  * and stores the resulting state in *GS* and its energy in *energy*. 
  * *dir* defines the site on which the orthogonality center is placed after the 
  * update. The parameters of the calculation are stored in *args*
  * which can take the following values:       
  *@param      UseDavidson    bool (default: false)
  *                           If true, use ITensors Davidson algorithm instead of Lanzcos.
  *@param      CutoffB        double (default: Cutoff)
  *                           Truncated weight on  Bath-Bath links.
  *@param      CutoffIB       double (default: Cutoff)
  *                           Truncated weight on Impurity-Bath links.
  *@param      MaxmB          int (default: 500)
  *                           Maxmial bond dimension allowed for bath-bath links.
  *@param      MaxmIB         int (default: 100)
  *                           Maxmial bond dimension allowed for impurity-bath links. 
  */
  double TS_DMRG_BathStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, Args &args);

  /**
  * Performs a Single-Site DMRG step on an impurity tensor and its neighboring 
  * bath tensor or on two bath tensors on site *site*.
  * The calculation minimizes the energy using the effective Hamiltonian *Heff* 
  * and stores the resulting state in *GS* and its energy in *energy*. 
  * *dir* defines the site on which the orthogonality center is placed after 
  * the update. *alpha* is the subspace-expansion mixing 
  * factor determining the strenght of the subspace expansion (Phys. Rev. B 91, 155115). 
  * The parameters of the calculation are stored in *args*
  * which can take the following values:       
  *@param      UseDavidson    bool (default: false)
  *                           If true, use ITensors Davidson algorithm instead of Lanzcos.
  *@param      CutoffB        double (default: Cutoff)
  *                           Truncated weight on  Bath-Bath links (only relevant if subspace expansion is active).
  *@param      CutoffIB       double (default: Cutoff)
  *                           Truncated weight on Impurity-Bath links (only relevant if subspace expansion is active).
  *@param      MaxmB          int (default: 500)
  *                           Maxmial bond dimension allowed for bath-bath links (only relevant if subspace expansion is active).
  *@param      MaxmIB         int (default: 100)
  *                           Maxmial bond dimension allowed for impurity-bath links (only relevant if subspace expansion is active). 
  */
  double SS_DMRG_BathStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, double &alpha, Args &args);

  /** Performs a Two-Site FitApply step minimizing $| |res\rangle - H | x\rangle |^2$ on sites *site* 
  * and *site+1* involving an impurity tensor and its neighboring bath tensor or on two bath tensors. 
  * *dir* defines the orthogonality center after the optimization (*site* if *dir*==Leftwards or *site+1*
  * if dir == Rightwards).
  */
  void TS_FitApply_BathStep(ForkTPS &res, const ForkTPS &x, ForkLocalOp &Heff, int site, OrthoState dir, Args &args);

  /** Performs a Single-Site FitApply step minimizing $| |res\rangle - H | x\rangle |^2$ on impurity 
  * *site*. *dir* defines the orthogonality center after the optimization.
  */
  void SS_FitApply_ImpStep(ForkTPS &res, const ForkTPS &x, ForkLocalOp &Heff, int site, OrthoState dir, Args &args);

  /// Simple dispatcher function deciding between itensor::davidson or forktps::lanzcos.
  template <typename BigMat> double Krylov(const BigMat &Heff, ITensor &A, Args &args) {
    if (args.getBool("UseDavidson", false))
      return davidson(Heff, A, args);
    else
      return forktps::ED::lanzcos(Heff, A, args);
  }
  //explicit instationation
  template double Krylov<ForkLocalOp>(const ForkLocalOp &Heff, ITensor &A, Args &args);

  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------
  // - - - - - - - - - - - - - - - - - - - - DMRG - - - - - - - - - - - - - - - - - - - -
  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------

  bool DMRGTwoSiteImp(ForkTPS &GS, const ForkTPO &H, double &energy, Args &args) {
    // arguments for fitApplyMPO
    Args argsLoc{"Cutoff", MIN_CUT, "SubspaceAlpha", 0.1, "SubspaceMaxm", 100};

    bool done = false, verbose = args.getBool("verbose", true), inclNoise = args.getBool("InclNoise", false),
         fullSweep = args.getBool("FullSweep", false);

    double maxTruncErr = 0;

    const int NSweepsAfterApplyH = 5;

    long maxsweeps = args.getInt("maxsweeps", 10), NApplyH = args.getInt("NAppH", 0), AppHdone = 0, Nbath = H.NBath(1), NArms = H.NArms(),
         totalSweepsToDo = maxsweeps + NSweepsAfterApplyH * NApplyH, sweepcounter = 0;

    ForkLocalOp Heff(H);

    if (inclNoise) error("Include noise currently not implemented in DMRG");

    if (verbose) {
      std::cout << "\n    ";
      PrintBorderLine();
      std::cout << "                                     Two-Site DMRG \n    ";
      PrintBorderLine();
    }

    while (!done) {
      Heff.ForgetContraction();
      for (auto j : range1(maxsweeps)) {
        UNUSED_VAR(j);
        maxTruncErr = 0.;

        //loop over arms
        for (auto arm : range1(NArms)) {
          Nbath = H.NBath(arm);

          // outwards arm
          for (int indx = 1; indx < Nbath; indx++) {
            auto site = H.ImpSite(arm) + indx - 1;
            auto err  = TS_DMRG_BathStep(GS, Heff, energy, site, Rightwards, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }

          // inwards arm
          for (auto indx = Nbath; indx >= 1; indx--) {
            auto site = H.ImpSite(arm) + indx - 1;
            auto err  = TS_DMRG_BathStep(GS, Heff, energy, site, Leftwards, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }

          // doing impurity
          if (arm != NArms) {
            auto err = TS_DMRG_ImpStep(GS, Heff, energy, arm, Downwards, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }
        }

        if (fullSweep) {
          // go up the impurity tensors
          for (auto arm = NArms - 1; arm >= 1; --arm) {
            auto err = TS_DMRG_ImpStep(GS, Heff, energy, arm, Upwards, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }
        }

        if (verbose) {
          const int NSpaces = 4;
          sweepcounter++;
          ForkTPS test = GS;

          std::cout << std::string(NSpaces, ' ') << "Sweep " << sweepcounter << "/" << totalSweepsToDo << "\n";
          test.PrintImpOcc(NSpaces);
          test.PrintImpM(NSpaces);
          std::cout << std::string(NSpaces, ' ') << std::setprecision(10) << "Energy: " << energy << std::endl
                    << std::string(NSpaces, ' ') << "TruncErr: " << maxTruncErr << "\n\n\n";
        }
      }

      if (AppHdone < NApplyH) {
        GS = FitApplyMPO(GS, H, argsLoc);
        GS.normalize();
        AppHdone++;
        maxsweeps = NSweepsAfterApplyH;
      } else {
        done = true;
      }
    }

    return true;
  }

  /**
  * Performes a DMRG calculation using single site updates on the impurity-impurity links and two-site updates on all other links. 
  * The calculation is performed with FTPO *H* and calculates the groundstate *GS* and its energy *energy*. 
  * Parameters are defined in *args* which takes the following entries. To avoid getting trapped in local minima, this function
  * uses the so-called subspace-expansion method (Phys. Rev. B 91, 155115) 
  *@param      verbose        bool (default: true)
  *                           Writes information about the DMRG run in the console.
  *@param      maxsweeps      int (default: 10)      
  *                           Number of DMRG sweeps.
  *@param      NAppH          int (default: 0)       
  *                           After maxsweeps sweeps apply the MPO and set maxsweeps to 5. 
  *                           Then restart DMRG (now with 5 sweeps). In total apply H *NAppH*-times.
  *@param      UseDavidson    bool (default: false)
  *                           If true, use ITensors Davidson algorithm instead of Lanzcos.
  *@param      Cutoff         double (default: 1E-10)
  *                           Truncated weight on all links unless otherwise specified by one of the cutoffs below.
  *@param      CutoffI        double (default: Cutoff)
  *                           Truncated weight on Impurity-Impurity links. Note 
  *                           that this parameter is only active as long as subspace 
  *                           expansion is active. Afterwards it does not affect 
  *                           the calculation, since a single-site update is 
  *                           performed on the impurity-impurity links.
  *@param      CutoffB        double (default: Cutoff)
  *                           Truncated weight on  Bath-Bath links.
  *@param      CutoffIB       double (default: Cutoff)
  *                           Truncated weight on Impurity-Bath links.
  *@param      MaxmI          int (default: 200)
  *                           Maxmial bond dimension allowed for impurity-impurity links. 
  *                           Note that this parameter is only active as long as subspace 
  *                           expansion is active. Afterwards it does not affect the 
  *                           calculation, since a single-site update is performed 
  *                           on the impurity-impurity links.
  *@param      MaxmB          int (default: 400)
  *                           Maxmial bond dimension allowed for bath-bath links.
  *@param      MaxmIB         int (default: 200)
  *                           Maxmial bond dimension allowed for impurity-bath links. 
  */
  bool DMRGSSImp_SubspaceExp(ForkTPS &GS, const ForkTPO &H, double &energy, Args &args) {

    Args argsLoc{"Cutoff", MIN_CUT, "SubspaceAlpha", 0.1, "SubspaceMaxm", 100};
    bool done = false, verbose = args.getBool("verbose", true);
    double maxTruncErr             = 0.;
    double alpha                   = 0.1;
    const double fracWoSubspaceExp = 0.6;

    if (verbose) {
      std::cout << "\n    ";
      PrintBorderLine();
      std::cout << "                                   DMRG (using subspace expansion)\n    ";
      PrintBorderLine();
    }

    auto maxsweeps = args.getInt("maxsweeps", 10);
    auto NApplyH   = args.getInt("NAppH", 0);
    auto AppHdone  = 0;
    auto Nbath = H.NBath(1), NArms = H.NArms();
    const int NSweepsAfterApplyH = 5;
    auto totalSweepsToDo         = maxsweeps + NSweepsAfterApplyH * NApplyH;
    int sweepcounter             = 0;

    Spectrum spec;
    ForkLocalOp Heff(H);

    while (!done) {
      Heff.ForgetContraction();

      for (auto j : range1(maxsweeps)) {
        maxTruncErr = 0.;

        if (double(j) / maxsweeps > fracWoSubspaceExp) alpha = 0.;

        //loop over arms
        for (auto arm : range1(NArms)) {
          //std::cout << "Arm = " << arm << std::endl;
          Nbath = H.NBath(arm);

          // outwards arm
          for (int indx = 1; indx < Nbath; indx++) {
            //std::cout << "   Bath = " << indx << std::endl;
            auto site  = H.ImpSite(arm) + indx - 1;
            double err = 0.;

            //if(indx != 1)
            err = TS_DMRG_BathStep(GS, Heff, energy, site, Rightwards, args);
            //else
            //  err = SS_DMRG_BathStep(GS, Heff, energy, site, Rightwards, alpha, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }

          // inwards arm
          for (int indx = Nbath; indx >= 1; indx--) {
            //std::cout << "   Bath = " << indx << std::endl;
            auto site = H.ImpSite(arm) + indx - 1;

            double err = 0.;
            //if(indx != 1)
            err = TS_DMRG_BathStep(GS, Heff, energy, site, Leftwards, args);
            //else
            //  err = SS_DMRG_BathStep(GS, Heff, energy, site, Rightwards, alpha, args); // use rightwards

            if (err > maxTruncErr) maxTruncErr = err;
          }

          //impurity - impurity
          if (arm != NArms) {
            //std::cout << "   Impurity = " << arm << std::endl;
            auto site = GS.ImpSite(arm);
            auto err  = SS_DMRG_ImpStep(GS, Heff, energy, site, Downwards, alpha, args);
            if (err > maxTruncErr) maxTruncErr = err;
          }
        }

        if (verbose) {
          const int NSpaces = 4;
          sweepcounter++;
          ForkTPS test = GS;

          std::cout << std::string(NSpaces, ' ') << "Sweep " << sweepcounter << "/" << totalSweepsToDo << "\n";
          test.PrintImpOcc(NSpaces);
          test.PrintImpM(NSpaces);
          std::cout << std::string(NSpaces, ' ') << std::setprecision(10) << "Energy: " << energy << std::endl
                    << std::string(NSpaces, ' ') << "TruncErr: " << maxTruncErr << "\n\n\n";
        }
      }

      if (AppHdone < NApplyH) {
        GS = FitApplyMPO(GS, H, argsLoc);
        GS.normalize();
        AppHdone++;
        maxsweeps = NSweepsAfterApplyH;
      } else {
        done = true;
      }
    }

    return true;
  }

  // Two-Site DMRG Bath step
  double TS_DMRG_BathStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, Args &args) {
    //std::cout<< "Two-site bath step "<<site <<" " << site+1<<std::endl<< "    ";

    auto OC      = (dir == forktps::Rightwards) ? site : site + 1;
    auto TagName = SetSVDParams(OC, GS, dir, args);

    GS.position(OC);
    Heff.position(site, site + 1, GS);

    ITensor AA = GS.A(site) * GS.A(site + 1);
    //for(auto i : AA.inds())
    //  std::cout << i.dim() << " ";
    //std::cout << "\n ";

    energy = Krylov(Heff, AA, args);

    ITensor U = GS.A(site), S, V;
    itensor::Spectrum spec;

    if (dir == forktps::Rightwards) {
      spec = svd(AA, U, S, V, {args, "LeftTags", TagName});
      V *= S;
    } else if (dir == forktps::Leftwards) {
      spec = svd(AA, U, S, V, {args, "RightTags", TagName});
      U *= S;
    } else {
      Error("Invalid dir in TS_DMRG_BathStep: " + to_string(dir));
    }

    GS.InsertOrthoTensors(std::move(U), std::move(V), site, site + 1, dir);
    GS.normalize();
    return spec.truncerr();
  }

  double TS_DMRG_ImpStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int arm, OrthoState dir, Args &args) {
    //std::cout<< "Two-site Imp step "<<arm <<" " << arm+1<<std::endl;

    auto site     = GS.ImpSite(arm);
    auto nextSite = GS.ImpSite(arm + 1);

    auto OC      = (dir == Downwards) ? site : nextSite;
    auto TagName = SetSVDParams(site, GS, dir, args);

    GS.position(OC);
    Heff.position(site, nextSite, GS);

    auto AA = GS.A(site) * GS.A(nextSite);
    energy  = Krylov(Heff, AA, args);

    // svd
    Spectrum spec;
    ITensor U = GS.A(site), D, V;
    if (dir == forktps::Downwards) {
      spec = svd(AA, U, D, V, {args, "LeftTags", TagName});
      V *= D;
    } else if (dir == forktps::Upwards) {
      spec = svd(AA, U, D, V, {args, "RightTags", TagName});
      U *= D;
    } else {
      Error("Invalid dir in TS_DMRG_ImpStep: " + to_string(dir));
    }

    //place tensors in GS
    GS.InsertOrthoTensors(std::move(U), std::move(V), site, nextSite, dir);
    GS.normalize();

    return spec.truncerr();
  }

  // Single-Site DMRG Bath step
  double SS_DMRG_BathStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, double &alpha, Args &args) {
    //std::cout<<"Bath step "<< OSI2String(dir)<< " on site "<<site<<std::endl;
    int nextSite = GS.Neighbor(site, dir);
    auto TagName = SetSVDParams(site, GS, dir, args);

    auto origCutoff = args.getReal("Cutoff");
    if (std::abs(alpha) < TOOSMALL) args.add("Cutoff", MIN_CUT);

    // make sure ortho center is right
    GS.position(site);
    Heff.position(site, GS);

    // solve eigenvalue problem
    ITensor A    = GS.A(site);
    energy       = Krylov(Heff, A, args);
    GS.Anc(site) = A;

    // subspace expand if alpha != 0
    auto [Anew, Bnew] = SubspaceExpand(site, dir, GS, Heff, {"SubspaceAlpha", alpha, "SubspaceMaxm", 100});

    // do svd and put tensors into forkTPS
    ITensor U, S, V;
    U         = ITensor(AllExcept(Anew, itensor::commonIndex(Anew, Bnew)));
    auto spec = svd(Anew, U, S, V, {args, "LeftTags", TagName});

    Bnew *= V * S;
    GS.InsertOrthoTensors(std::move(U), std::move(Bnew), site, nextSite, Rightwards); // nextsite is always ortho center
    GS.normalize();
    args.add("Cutoff", origCutoff);
    return spec.truncerr();
  }

  // Single-Site DMRG Imp step
  double SS_DMRG_ImpStep(ForkTPS &GS, ForkLocalOp &Heff, double &energy, int site, OrthoState dir, double &alpha, Args &args) {
    if (dir != forktps::Downwards) Error("SS_DMRG_ImpStep: Only dir = Downwards implemented");
    //std::cout<<"Imp step on site "<< site <<std::endl << "    ";
    auto nextSite = GS.Neighbor(site, dir);
    auto tagName  = SetSVDParams(site, GS, dir, args);

    auto origCutoff = args.getReal("Cutoff");
    if (std::abs(alpha) < TOOSMALL) args.add("Cutoff", MIN_CUT);

    // make sure ortho center is right
    GS.position(site);
    Heff.position(site, GS);

    // solve eigenvalue problem
    ITensor A = GS.A(site);

    //for(auto i : A.inds())
    //  std::cout << i.dim() << " ";
    //std::cout << "\n ";

    energy       = Krylov(Heff, A, args);
    GS.Anc(site) = A;

    // subspace expand if alpha != 0
    auto [Anew, Bnew] = SubspaceExpand(site, dir, GS, Heff, {"SubspaceAlpha", alpha, "SubspaceMaxm", 100});

    // do svd and put tensors into forkTPS
    ITensor U, S, V;
    U = ITensor(AllExcept(Anew, itensor::commonIndex(Anew, Bnew)));

    auto spec = svd(Anew, U, S, V, {args, "LeftTags", tagName});

    Bnew *= V * S;

    GS.InsertOrthoTensors(std::move(U), std::move(Bnew), site, nextSite, dir);
    GS.normalize();

    args.add("Cutoff", origCutoff);
    return spec.truncerr();
  }

  std::pair<ITensor, ITensor> SubspaceExpand(int i, OrthoState dir, const ForkTPS &expandWith, const ForkTPS &toExpand, const ForkLocalOp &Heff,
                                             const Args &args) {

    auto j     = toExpand.Neighbor(i, dir);
    auto A     = toExpand.A(i);
    auto B     = toExpand.A(j);
    auto indAB = commonIndex(A, B);
    auto alpha = args.getReal("SubspaceAlpha", 0.1);
    auto maxM  = args.getInt("SubspaceMaxm", 200);

    // dont do anything if alpha is zero
    if (std::abs(alpha) < TOOSMALL) return std::make_pair(A, B);

    //calculate expansion tensor and the link that expands indAB.
    auto [P, c] = Heff.ExpansionTensor(dir, expandWith);

    // dont take all entries of P, but only the first maxM of index c
    auto [proj, reducedC] = nonSquareDiag(c, maxM);
    P *= proj * alpha;
    P /= norm(P);
    c = reducedC;

    //Get zeros to expand B
    auto zeros = itensor::ITensor(div(B), AllExcept(B, dag(indAB), dag(c)));

    //expand A
    auto [newA, ca] = directSum(A, P, indAB, c, {"Tags", itensor::tags(indAB)});
    // multiply combiner to get rid of double entries
    auto [combA, NewIndAB] = combiner(ca);
    newA *= combA;

    //expand B
    auto [newB, cb] = directSum(B, zeros, dag(indAB), dag(c), {"Tags", itensor::tags(indAB)});
    // multiply combiner get rid of double entries
    auto [combB, indBnew] = combiner(cb);
    newB *= combB;

    // NewB needs the correct index identifier
    newB *= delta(dag(indBnew), dag(NewIndAB));

    return std::make_pair(newA, newB);
  }

  std::pair<ITensor, ITensor> SubspaceExpand(int i, OrthoState dir, const ForkTPS &psi, const ForkLocalOp &Heff, const Args &args) {
    return SubspaceExpand(i, dir, psi, psi, Heff, args);
  }

  bool DMRG(ForkTPS &GS, const ForkTPO &H, double &energy, Args &args) {
    auto method = args.getString("DMRGMethod", "SSImp");

    if (method == "SSImp") {
      return DMRGSSImp_SubspaceExp(GS, H, energy, args);
    } else if (method == "TwoSite") {
      return DMRGTwoSiteImp(GS, H, energy, args);
    } else {
      Error("Invalid DMRG method provided: " + method);
      return false;
    }
  }

  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------
  // - - - - - - - - - - - Application of operators and Measurements - - - - - - - - - -
  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------

  ForkTPS exactApplyMPO(ForkTPS const &x, ForkTPO const &K, Args &args) {

    auto orthog = args.getBool("Orthog", true);
    int NArms   = x.NArms();

    auto N = x.N();
    if (K.N() != N) {
      std::cout << x.N() << " " << K.N() << "\n";
      Error("exactApplyMPO: Mismatched N");
    }

    auto res = ForkTPS(x.sites(), x.NBathVec());

    for (auto arm : range1(NArms)) {
      int site      = x.ArmToSite(arm, 1);
      res.Anc(site) = x.A(site) * K.A(site);
      int NBath     = x.NBath(arm);
      for (auto indx : range1(NBath - 1)) {
        site         = x.ArmToSite(arm, indx);
        int nextsite = x.ArmToSite(arm, indx + 1);

        res.Anc(nextsite) = x.A(nextsite) * K.A(nextsite);

        // Add common IQIndices to combiner
        auto [comb, c] = LinkCombiner(res.A(site), res.A(nextsite));

        // Apply combiner to product tensors
        res.Anc(site)     = res.A(site) * comb;          // m^3 k^3 d
        res.Anc(nextsite) = dag(comb) * res.A(nextsite); // m^3 k^3 d
      }
    }

    // all bonds connecting bath sites only have been treated now we need to
    // combine the indices of bath-impurity bonds and of imp-imp bonds:
    int Isite      = x.ImpSite(1);
    res.Anc(Isite) = x.A(Isite) * K.A(Isite);

    for (auto Iindx : range1(NArms)) {
      Isite       = x.ImpSite(Iindx);
      int ArmSite = Isite + 1;

      // treat Down Arm index:
      auto [combArm, cArm] = LinkCombiner(res.A(Isite), res.A(ArmSite));
      res.Anc(Isite)       = res.A(Isite) * combArm;
      res.Anc(ArmSite)     = dag(combArm) * res.A(ArmSite);

      // treat impurity link
      if (Iindx != NArms) {

        int NextIsite      = x.ImpSite(Iindx + 1);
        res.Anc(NextIsite) = x.A(NextIsite) * K.A(NextIsite);

        auto [combImp, cImp] = LinkCombiner(res.A(Isite), res.A(NextIsite));
        res.Anc(Isite)       = res.A(Isite) * combImp;
        res.Anc(NextIsite)   = dag(combImp) * res.A(NextIsite);
      }
    }

    res.mapPrime(1, 0, "Site");

    if (orthog) { res.orthogonalize(args); }
    return res;
  }

  void TS_FitApply_BathStep(ForkTPS &res, const ForkTPS &x, ForkLocalOp &Heff, int site, OrthoState dir, Args &args) {
    // ortho center
    int OC       = (dir == Rightwards) ? site : site + 1;
    auto TagName = SetSVDParams(OC, x, dir, args);
    res.position(OC);
    Heff.position(site, site + 1, res, x);

    ITensor AA, U = res.UTensor(site, Rightwards), V, D;
    Heff.product(x.A(site) * x.A(site + 1), AA);

    if (dir == Rightwards) {
      auto spec = svd(AA, U, D, V, {args, "LeftTags", TagName});
      res.InsertOrthoTensors(std::move(U), D * V, site, site + 1, dir);
    } else if (dir == Leftwards) {
      auto spec = svd(AA, U, D, V, {args, "RightTags", TagName});
      res.InsertOrthoTensors(U * D, std::move(V), site, site + 1, dir);
    } else
      throw ITError("Invalid direction in TS_FitApply_BathStep: " + to_string(dir));
  }

  void SS_FitApply_BathStep(ForkTPS &res, const ForkTPS &x, ForkLocalOp &Heff, int site, OrthoState dir, Args &args) {
    auto TagName = SetSVDParams(site, x, dir, args);

    // dont truncate without subspace expansion
    auto origCutoff = args.getReal("Cutoff");
    if (std::abs(args.getReal("SubspaceAlpha")) < TOOSMALL) args.add("Cutoff", MIN_CUT);

    int nextSite = x.Neighbor(site, dir);
    res.position(site);
    Heff.position(site, res, x);
    ITensor AA;
    Heff.product(x.A(site), AA);

    res.Anc(site)     = AA;
    auto [Anew, Bnew] = SubspaceExpand(site, dir, x, res, Heff, args);

    ITensor U, D, V;
    U         = ITensor(AllExcept(Anew, itensor::commonIndex(Anew, Bnew)));
    auto spec = svd(Anew, U, D, V, {args, "LeftTags", TagName});

    Bnew *= V * D;

    res.InsertOrthoTensors(std::move(U), std::move(Bnew), site, nextSite, dir);
    res.normalize();

    Heff.UpdateMe(nextSite);

    args.add("Cutoff", origCutoff);
  }

  void SS_FitApply_ImpStep(ForkTPS &res, const ForkTPS &x, ForkLocalOp &Heff, int site, OrthoState dir, Args &args) {
    auto TagName = SetSVDParams(site, x, dir, args);
    // dont truncate without subspace expansion
    auto origCutoff = args.getReal("Cutoff");
    if (std::abs(args.getReal("SubspaceAlpha")) < TOOSMALL) args.add("Cutoff", MIN_CUT);

    auto nextsite = res.Neighbor(site, dir);
    res.position(site);
    Heff.position(site, res, x);

    ITensor AA;
    Heff.product(x.A(site), AA);

    res.Anc(site)     = AA;
    auto [Anew, Bnew] = SubspaceExpand(site, dir, x, res, Heff, args);

    // do svd and put tensors into forkTPS
    ITensor U, D, V;
    U         = ITensor(AllExcept(Anew, itensor::commonIndex(Anew, Bnew)));
    auto spec = svd(Anew, U, D, V, {args, "LeftTags", TagName});

    Bnew *= V * D;

    res.InsertOrthoTensors(std::move(U), std::move(Bnew), site, nextsite, dir);
    res.normalize();

    // Tensor on nextsite changed, tell effective H
    Heff.UpdateMe(nextsite);

    args.add("Cutoff", origCutoff);

    return;
  }

  ForkTPS FitApplyMPO(ForkTPS &x, const ForkTPO &H, Args args) {
    // for subspace expantion, orthocenter of x must be on site NBath(1)+1, hence x is not const-ref
    x.position(x.NBath(1) + 1);
    auto res = x;
    ForkLocalOp Heff(H);

    double oldVal = 100, origAlpha = args.getReal("SubspaceAlpha", 0.1);
    const double fracWoSubspaceExp = 0.6;
    int countConv = 0, maxsweeps = args.getInt("maxsweeps", 10);
    auto doSS = args.getBool("SSAlgo", false);

    args.add("SubspaceAlpha", origAlpha); // add alpha in case it does not exist
    for (auto sw : range1(maxsweeps)) {
      if (double(sw) / maxsweeps > fracWoSubspaceExp) args.add("SubspaceAlpha", 0.);

      for (auto arm : range1(x.NArms())) {
        // loop over bath
        for (auto k : range1(x.NBath(arm))) {
          if (doSS) {
            //single site algorithm
            if (arm != 1) {
              auto site = x.ImpSite(arm) + k - 1;
              SS_FitApply_BathStep(res, x, Heff, site, forktps::Rightwards, args);
            } else {
              auto site = x.ArmToSite(arm, k);
              SS_FitApply_BathStep(res, x, Heff, site, forktps::Leftwards, args);
            }
          } else { //TS algorithm
            if (arm != 1) {
              auto site = x.ImpSite(arm) + k - 1;
              TS_FitApply_BathStep(res, x, Heff, site, forktps::Rightwards, args);
            } else {
              auto site = x.ArmToSite(arm, k) - 1;
              TS_FitApply_BathStep(res, x, Heff, site, forktps::Leftwards, args);
            }
          }
        }

        // Impurity
        if (arm != res.NArms()) {
          auto site = res.ImpSite(arm);
          //SS_FitApply_ImpStep(res, x, Heff, site, forktps::Downwards);
          SS_FitApply_ImpStep(res, x, Heff, site, forktps::Downwards, args);
        }
      }

      // get convergence criterium <x|H|res> - <res|H|x> = 2 Re(<res|H|x>)
      res.position(1);
      Heff.position(1, res, x);
      auto val = std::real(Heff.ContractAll(res, x));
      //std::cout<< "Convergence: "<< oldVal-val <<std::endl;

      if (std::abs(oldVal - val) < args.getReal("ErrGoal", 1E-12)) {
        countConv++;
        if (countConv >= 2) {
          //std::cout<< "FitApply MPO converged."<<std::endl;
          break;
        }
      } else {
        countConv = 0;
        oldVal    = val;
      }
    }

    args.add("SubspaceAlpha", origAlpha);

    return res;
  }

  void CombineMPOs(ForkTPO const &W1, ForkTPO const &W2, ForkTPO &res, Args &args) {

    auto orthog = args.getBool("Orthog", true);
    int NArms   = W1.NArms();

    auto N = W1.N();
    if (W2.N() != N) {
      ITENSOR_Print(W1.N());
      ITENSOR_Print(W2.N());
      Error("exactApplyMPO: Mismatched N");
    }

    res = W1;

    for (auto arm : range1(NArms)) {
      int site      = W1.ArmToSite(arm, 1);
      res.Anc(site) = W1.A(site) * prime(W2.A(site), "Site");
      int NBath     = W1.NBath(arm);
      for (int indx = 1; indx < NBath; indx++) {
        site         = W1.ArmToSite(arm, indx);
        int nextsite = W1.ArmToSite(arm, indx + 1);

        res.Anc(nextsite) = W1.A(nextsite) * prime(W2.A(nextsite), "Site");

        // Add common IQIndices to combiner
        auto [comb, c] = LinkCombiner(res.A(site), res.A(nextsite));

        // Apply combiner to product tensors
        res.Anc(site)     = res.A(site) * comb;          // m^3 k^3 d
        res.Anc(nextsite) = dag(comb) * res.A(nextsite); // m^3 k^3 d
      }
    }

    // all bonds connecting bath sites only have been treated now we need to
    // combine the indices of bath-impurity bonds and of imp-imp bonds:
    int Isite      = W1.ImpSite(1);
    res.Anc(Isite) = W1.A(Isite) * prime(W2.A(Isite), "Site");

    for (auto Iindx : range1(NArms)) {
      Isite       = W1.ImpSite(Iindx);
      int ArmSite = Isite + 1;

      // treat Down Arm index:
      auto [combArm, cA] = LinkCombiner(res.A(Isite), res.A(ArmSite));
      res.Anc(Isite)     = res.A(Isite) * combArm;
      res.Anc(ArmSite)   = dag(combArm) * res.A(ArmSite);

      // treat impurity link
      if (Iindx != NArms) {
        int NextIsite      = W1.ImpSite(Iindx + 1);
        res.Anc(NextIsite) = W1.A(NextIsite) * prime(W2.A(NextIsite), "Site");

        auto [combImp, cI] = LinkCombiner(res.A(Isite), res.A(NextIsite));
        res.Anc(Isite)     = res.A(Isite) * combImp;
        res.Anc(NextIsite) = dag(combImp) * res.A(NextIsite);
      }
    }

    res.mapPrime(1, 0, "Site");
    res.mapPrime(2, 1, "Site");

    if (orthog) { res.orthogonalize(args); }
  }

  double Measure(ForkTPS &psi, std::string OpName, int i) {
    psi.position(i);
    ITensor M = psi.A(i) * psi.sites().op(OpName, i) * dag(prime(psi.A(i), "Site"));
    return std::real(M.cplx());
  }

  double MeasureImp(ForkTPS &psi, std::vector<std::string> Ops) {
    if (Ops.size() != psi.NArms()) Error("MeasureImp: Number of Operators does not match the number of Arms of the forktps.");

    Index BathLink;
    ITensor A, M;
    const SiteSet &sites = psi.sites();
    psi.position(1);

    BathLink = commonIndex(psi.A(1), psi.A(2));
    A        = psi.A(1);
    M        = A;
    M *= sites.op(Ops.at(0), 1);
    M *= dag(prime(prime(A), -1, prime(BathLink)));

    for (auto indx : range1(2, psi.NArms())) {
      int site = psi.ImpSite(indx);
      BathLink = commonIndex(psi.A(site), psi.A(site + 1));
      A        = psi.A(site);

      M *= A;
      M *= sites.op(Ops.at(indx - 1), site);
      M *= dag(prime(prime(A), -1, prime(BathLink)));
    }

    return std::real(M.cplx());
  }

  Complex MeasureImp(const ForkTPS &bra, std::vector<std::string> Ops, const ForkTPS &ket) {
    // calculates the expectation value < bra | Ops | ket >
    // Ops.at(0) is the name of the first operator,
    // Ops.at(1) the name of the second etc.
    if (Ops.size() != ket.NArms()) Error("MeasureImp: Number of Operators does not match the number of Arms of the forktps.");
    if (bra.N() != ket.N()) Error("MeasureImp: Bra and Ket operator need to have the same number of sites.");

    ITensor M;
    std::vector<ITensor> ContractedArms(ket.NArms() + 1);
    const SiteSet &sites = ket.sites();

    for (auto arm : range1(ket.NArms())) {
      int site    = ket.ArmToSite(arm, 1);
      ITensor res = ket.A(site) * dag(prime(bra.A(site), "Link"));

      for (auto indx : range1(2, ket.NBath(arm))) {
        site = ket.ArmToSite(arm, indx);
        res *= ket.A(site);
        res *= dag(prime(bra.A(site), "Link"));
      }
      ContractedArms.at(arm) = res;
    }

    M = ket.A(1);
    M *= ContractedArms.at(1);
    M *= sites.op(Ops.at(0), 1);
    M *= dag(prime(bra.A(1)));

    for (auto indx : range1(2, ket.NArms())) {
      int site = ket.ImpSite(indx);

      M *= ket.A(site);
      M *= ContractedArms.at(indx);
      M *= sites.op(Ops.at(indx - 1), site);
      M *= dag(prime(bra.A(site)));
    }

    return M.cplx();
  }

  std::pair<double, double> GSConvergence(const ForkTPS &GS, const ForkTPO &H) {
    Args args{"Cutoff", MIN_CUT, "Orthog", false};

    auto HGS = exactApplyMPO(GS, H, args);
    std::cout << "variacne:    H |GS> has bond dimension " << std::endl;
    HGS.PrintImpM(3);
    auto psiHpsi  = std::real(overlap(GS, HGS));
    auto psiHHpsi = std::real(overlap(HGS, HGS));

    return std::make_pair(psiHpsi, psiHHpsi);
  }

  double PrintGSConvergence(const ForkTPS &GS, const ForkTPO &H) {
    auto [psiHpsi, psiHHpsi] = GSConvergence(GS, H);

    double var = psiHHpsi - psiHpsi * psiHpsi;

    std::cout << "Ground-state convergence: \n   <GS| H |GS> = " << psiHpsi << std::endl;
    std::cout << "   <GS|H^2|GS> = " << psiHHpsi << std::endl;
    std::cout << "   <GS|H^2|GS> - <GS|H|GS>^2 = " << var << "\n\n";

    return var;
  }

  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------
  // - - - - - - - - - - - - - - - - - - - Other - - - - - - - - - - - - - - - - - - - -
  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------

  void ApplyGate(ForkTPS &psi, const ForkGate &G, OrthoState dir, Args args) {
    double maxTruncErr = 0.;

    if (psi.IsImp(G.i()) && psi.IsImp(G.j())) { Error("When applying a two site gate i and j cant both be Impurities"); }
    if (psi.IsImp(G.j())) { Error("When applying a two site gate j cant be an Impurity"); }

    (dir == Leftwards) ? psi.position(G.i()) : psi.position(G.j());

    auto tags = SetSVDParams(std::min(G.i(), G.j()), psi, Rightwards, args);

    ITensor AA = psi.A(G.i()) * psi.A(G.j());
    AA *= G.gate();
    AA.noPrime();

    ITensor D, U = psi.A(G.i()), V;
    Spectrum spec;

    if (dir == Rightwards) {
      spec = svd(AA, U, D, V, {args, "LeftTags", tags.c_str()});
      V *= D;
    } else {
      spec = svd(AA, U, D, V, {args, "RightTags", tags.c_str()});
      U *= D;
    }

    psi.InsertOrthoTensors(std::move(U), std::move(V), G.i(), G.j(), dir);

    if (maxTruncErr < spec.truncerr()) maxTruncErr = spec.truncerr();

    if (args.getReal("MaxTruncErr", 1.) < maxTruncErr) { args.add("MaxTruncErr", maxTruncErr); }
    return;
  }

  void PrintVector(const ForkTPS &T) {

    std::cout << "Printing MPS as vector: " << std::endl;
    int N = T.N(), NArms = T.NArms();
    if (N > 14) {
      std::cout << "Hilbertspace larger than 14 sites do not print\n";
      return;
    }
    int N_states = std::pow(2, N);
    std::vector<int> local_dim;
    std::vector<std::string> bsite_levels;

    bsite_levels.emplace_back("Emp");
    bsite_levels.emplace_back("Occ");

    local_dim.resize(N + 1);
    for (auto j : range1(N)) { local_dim[j] = 2; }

    for (auto j : itertools::range(N_states)) {
      std::vector<int> ind_j;
      ind_j.push_back(-1);
      int numberj = j;
      for (auto site : range1(N)) {
        ind_j.push_back((int)(numberj % local_dim[site]));
        numberj -= ind_j[site];
        numberj /= local_dim[site];
      }

      InitState init_phi(T.sites(), "Emp");
      for (auto site : range1(N)) { init_phi.set(site, bsite_levels[ind_j[site]]); }

      ForkTPS phi(init_phi, NArms);
      double val(0.);
      val = overlap(phi, T).real();

      if (fabs(val) < TOOSMALL) {
        val = 0;
      } else {
        std::cout << j << " " << val << std::endl;
      }
    }
    PrintBorderLine(2);
    std::cout << std::endl;
    return;
  }

} // namespace forktps
