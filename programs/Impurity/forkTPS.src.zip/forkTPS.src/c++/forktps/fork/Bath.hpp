#ifndef __FORKBATHH__
#define __FORKBATHH__

#include "./../types.hpp"
#include "typenames.hpp"

#include <nda/nda.hpp>
//#include <h5/h5.hpp>
#include <h5/h5.hpp>

#include <complex>
#include <string>
#include <iomanip>
#include <vector>
#include <map>

using namespace itensor;
namespace forktps {

  /** A bath site consists of an on-site energy eps
  * and hopping amplitudes V. The vector structure in V are the
  * hoppings of the bath site to the different impurity sites.
  */
  struct bath_site {
    double eps;
    cvec V;

    /// Write to hdf5
    friend void h5_write(h5::group h5group, std::string subgroup_name, bath_site const &b);
    /// Read from hdf5
    friend void h5_read(h5::group h5group, std::string subgroup_name, bath_site &b);
  };

  /// For each block, a vector of pairs representing the minimum and maximum energy.
  using BandWidths = std::map<std::string, std::vector<std::pair<double, double>>>;

  /// Write Bandwidths to stream, since this is a standard container this might be unsafe.
  std::ostream &operator<<(std::ostream &os, const BandWidths &bw);

  /// A bath block is a collection of bath_sites. The outer vector defines the arm where the site is located, while the inner vector defines the actual site on the arm (often this is denoted as k-index).

  using bath_block = std::vector<std::vector<bath_site>>;

  /// A bath is a collection of bath sites in a block structure similar to what is used for triqs Green's functions.
  class bath {
    public:
    bath() = default;

    /**
     * Create an empty bath with the block structure give by gfstruct. This is the usual constructer used from triqs.
     * All other constructors are for backwards compatibility/convenience. SO determines how this block structure
     * is interpreted. If false (usual case), one block is a spin-up block while the other represents the spin-down
     * degrees of freedom. If true, the block structure is that of a spin-orbit coupled impurity which mixes spin channels.
     *
     * @param gfstruct  triqs gf_struct_t 
     *                  Definies the block structure, i.e, the names and number of orbitals of the bath.
     *
     * @param SO        bool (default false) 
     *                  If false, use spin-up and spin-down blocks, otherwise use spin-orbit coupled block structure.
     */
    bath(gf_struct_t gfstruct, bool SO = false);

    /**
     * Creates the bath of a fully degenerate AIM with the same bath parameters on each arm.
     *
     * @param eps         std::vector<double>
     *                    Vector of on-site energies. 
     * @param V           std::vector<double>
     *                    Vector of hopping amplitudes to the bath. 
     * @param blockSize   int
     *                    Size of each block such that the forktps has 2*blocksize arms.
     * @param bNameUp        std::string (default: up)
     *                    Name of spin-up block.
     * @param bNameDn        std::string (default: dn)
     *                    Name of spin-down block.
     */
    bath(const dvec &eps, const dvec &V, int blockSize, std::string bNameUp = "up", std::string bNameDn = "dn");

    /**
     * Creates the bath of an AIM with different parameters for each arm.
     *
     * @param eps         Dmat aka std::vector<std::vector<double>>
     *                    Matrix with on-site energies (one indexed in the second dimension) i.e.: eps[0][3] is the on-site energy of the third bath site on the first arm.
     * @param V           Cmat aka std::vector<std::vector<Complex>>
     *                    Complex matrix of hopping amplitudes (zero indexed in both dimensions). 
     *                    i.e., V[0][2] is the amplitude of the hopping of the first impurity site to the third bath site.
     * @param blockSize   int
     *                    Size of each block such that the forktps has 2*blocksize arms
     * @param bNameUp        std::string (default: up)
     *                    Name of spin-up block.
     * @param bNameDn        std::string (default: dn)
     *                    Name of spin-down block.             
     */
    bath(const Dmat &eps, const Cmat &V, int blockSize, std::string bNameUp = "up", std::string bNameDn = "dn", bool isOffDiag = false);

    /// Returns the number of Arms.
    [[nodiscard]] int NArms() const;
    /// Returns the number of Bath sites on the arm *arm*.
    [[nodiscard]] int NBath(triqs_indx indx) const;

    /// TODO remove this again
    //[[nodiscard]] int NBath() const{ return NBath(blockNames_.at(0),0); };

    /// Returns the total Number of sites ( $N= NArms*(NBath +1)$ ).
    [[nodiscard]] int N() const;

    /**
     * Access diagonal hopping amplitude, equivalent to *V(bName, bIndx, bIndx, k)*.
     * The returned value is the amplitude of the hopping onto the impurity ($c^/dagger$ operator on impurity),
     * while the amplitude onto the bath site is the complex conjugate of this value.
     *
     * @param indx        triqs_indx
     *                    Block name and index.
     * @param k           int
     *                    Bath index.    
     */
    [[nodiscard]] Complex V(triqs_indx indx, int k) const;

    /**
     * Access the hopping amplitude between a bath site and an impurity site.
     * The bath site is defined by *indxI* and *k* while the impurity site is 
     * defined by indxJ*.
     * The returned value is the amplitude of the hopping ONTO the impurity ($c^/dagger$ operator on impurity),
     * while the amplitude onto the bath site is the complex conjugate of this value.
     *
     * @param indxI       triqs_indx
     *                    Block name and index of bath site.
     * @param indxJ       triqs_indx
     *                    Block name and index of impurity site.
     * @param k           int
     *                    Bath index.
     */
    [[nodiscard]] Complex V(triqs_indx indxI, triqs_indx indxJ, int k) const;

    /**
     * Returns on-site energy of the bath site in block *bName* defined by *bIndx* and *k*.
     *
     * @param indx        triqs_indx
     *                    Block name and index.
     * @param k           int
     *                    Bath index.    
     */
    [[nodiscard]] double eps(triqs_indx indx, int k) const;

    /// Returns the size of the block *bName*
    [[nodiscard]] int blockSize(std::string bName) const;

    /** Returns the forktps-impurity-index of the triqs_indx *indx*.
    * For example the block "up" with bI = 0 is described by the first arm, i.e, it has index 1.
    */
    [[nodiscard]] int blockToFTPSIndx(triqs_indx indx) const;

    /** Returns the forktps-impurity-index of the triqs_indx *indx*.
    * For example the block "up" with bI = 0 is described by the first arm, i.e, it has index 1.
    */
    [[nodiscard]] triqs_indx FTPSIndxToBlock(int arm) const;

    /// Returns a vector containing the names of the blocks.
    [[nodiscard]] std::vector<std::string> blockNames() const;

    /// Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_0".
    [[nodiscard]] std::string blockNameUp() const;

    /// Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_1".
    [[nodiscard]] std::string blockNameDn() const;

    /** Calculates and returns the hybridization function defined by the discrete bath.
     * @param w       gf_mesh<refreq>
     *                Real frequency mesh used for the hybridization function. 
     * @param eta     double
     *                Lorentzian broadening used to broaden the delta-peaks.    
     */
    g_w_t reconstructDelta(const gf_mesh<refreq> &w, double eta);

    /**
     * Adds the bath to the block *indx* and parameters *eps* and *V*
     *
     * @param indx        triqs_indx
     *                    Block name and index.
     * @param eps         double         
     *                    On-site energy  of the site.
     * @param V           std::vector<Complex>         
     *                    Hopping parameters of the site.          
     */
    void addSite(triqs_indx indx, double eps, cvec V);

    /** Returns a copy of this bath with only diagonal entries.
    */
    [[nodiscard]] bath todiag() const;

    /** Returns a BandWidths object containing the bandwidth of each spin-orbital.
    */
    [[nodiscard]] BandWidths bandwidth() const;

    /// Returns one-indexed vector of number of bath sites
    [[nodiscard]] std::vector<int> NBathVec();

    /** Enforces particle hole-symmetry by symmetrizing the bath parameters. Fails
    * for off-diagonal baths, because in that case no particle hole symmetry 
    * exists.
    */
    void MakePHSymmetric();

    /** Returns the number of bath sites with negative on-site energy in form of a vector of integers suitable for the FTPS solver. */
    [[nodiscard]] std::vector<int> numNegative() const;

    /// Determines whether bath is off-diagonal or not by checking all hopping amplitudes.
    [[nodiscard]] bool isOffDiag() const;

    /// Returns true if bath block structure results from spin-orbit coupling.
    [[nodiscard]] bool isSpinOrbit() const;

    [[nodiscard]] bool hasOnlyOneBlock() const;

    /// Returns the gf_struct of the bath.
    gf_struct_t gf_struct() const;

    public:
    /// Stores the actual parameters.
    std::map<std::string, bath_block> b;

    private:
    std::vector<std::string> blockNames_;

    /// Flag for spin-orbit coupling.
    bool SpinOrbit{};

    /// The TRIQS gf-struct object.
    gf_struct_t gf_struct_;

    public:
    /// Write to hdf5.
    friend void h5_write(h5::group h5group, std::string subgroup_name, bath const &bath);
    /// Read from hdf5.
    friend void h5_read(h5::group h5group, std::string subgroup_name, bath &bath);
    /// hdf5 scheme to identify the bath when writing to hdf5.
    static std::string hdf5_format() { return "FORKTPS_Bath"; }

    /// Pass to ostream
    friend std::ostream &operator<<(std::ostream &out, const bath &b);
  };

  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // ---------------------------------- hloc -------------------------------
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------

  /// Non-interacting impurity Hamiltonian.
  class hloc {
    public:
    hloc() = default;

    /**
     * Create an empty local Hamiltonian with the block structure give by gfstruct. This is the usual constructer used by triqs.
     * All other constructors are for backwards compatibility/convenience. \n
     * SO determines how this block structure is interpreted. If false (usual case), one block is a spin-up block while the other represents the spin-down
     * degrees of freedom. If true, the block structure is that of a spin-orbit coupled impurity which mixes spin channels.
     * @param gfstruct  triqs gf_struct_t 
     *                  Definies the block structure and the block names of the bath
     * @param SO        bool (default false) 
     *                  If false, use spin-up and spin-down blocks, otherwise use spin-orbit coupled block structure.
     */
    hloc(gf_struct_t gfstruct, bool SO = false);

    /**
     * Creates the local Hamiltonian of a fully degenerate AIM with the same bath parameters on each arm.
     * Uses the zeroth entry of the vector *eps* as on-site energy.
     * @param eps         std::vector<double>
     *                    Zeroth *eps[0]* entry is the on-site energy.
     * @param blockSize   int
     *                    Size of each block such that the forktps has 2*blocksize arms
     * @param bNameUp        std::string (default: up)
     *                    Name of spin-up block.
     * @param bNameDn        std::string (default: dn)
     *                    Name of spin-down block.
     */
    hloc(const dvec &eps, int blockSize, std::string blockNameUp = "up", std::string blockNameDn = "dn");

    /**
     * Creates the local Hamiltonian of a diagonal non-degenerate AIM.
     * *eps[i][0]* is the on-site energy of the impurity on the forktps arm *i+1*.
     * @param eps         std::vector< std::vector<double> >
     *                    Zeroth *eps[0]* entry is the on-site energy.
     * @param blockSize   int
     *                    Size of each block such that the forktps has 2*blocksize arms
     * @param bNameUp        std::string (default: up)
     *                    Name of spin-up block.
     * @param bNameDn        std::string (default: dn)
     *                    Name of spin-down block.
     */
    hloc(const Dmat &eps, int blockSize, std::string blockNameUp = "up", std::string blockNameDn = "dn");

    /// Matrix of on-site energies and hopping amplitudes.
    std::map<std::string, array<Complex, 2>> e;

    private:
    /// Vector containing all names of the blocks.
    std::vector<std::string> blockNames_;

    /// Flag for spin-orbit coupling.
    bool SpinOrbit{};

    gf_struct_t gf_struct_;

    public:
    /// Fills the local Hamiltonian of block *bName* with the matrix *e0*.
    void Fill(std::string bName, array<Complex, 2> e0);

    /// Fills both blocks of the local Hamiltonian with the matrix *e0*.
    void Fill(array<Complex, 2> e0);

    /// Returns the local Hamiltonian of block *bName*.
    array<Complex, 2> operator()(std::string bName) const;

    /// Returns on-site energy of block *indx*.
    Complex operator()(triqs_indx indx) const;

    /** Returns matrix entry of hloc between indices *i* and *j*. \n
    * For $i==j$: on-site energy. \n
    * For $i \neq j$: hopping amplitude of the term $c_i^\dagger c_j$ (note order of indices).
    */
    Complex operator()(triqs_indx indxI, triqs_indx indxJ) const;

    /// Checks if off-diagonal hoppings are present, i.e, if $e0(i,j) /neq 0$ for $i /neq j$
    [[nodiscard]] bool isOffDiag() const;

    /// Returns true if h0loc's block structure results from spin-orbit coupling
    [[nodiscard]] bool isSpinOrbit() const;

    /// Returns a vector containing the names of the blocks.
    [[nodiscard]] std::vector<std::string> blockNames() const;

    /// Returns the block name of the block with spin up. In case of Spin-orbit coupling, returns "ud_0".
    [[nodiscard]] std::string blockNameUp() const;

    /// Returns the block name of the block with spin down. In case of Spin-orbit coupling, returns "ud_1".
    [[nodiscard]] std::string blockNameDn() const;

    [[nodiscard]] hloc todiag() const;

    public:
    /// Write to hdf5
    friend void h5_write(h5::group h5group, std::string subgroup_name, hloc const &e0);
    /// Read from hdf5
    friend void h5_read(h5::group h5group, std::string subgroup_name, hloc &e0);
    /// hdf5 scheme to identify the local Hamiltonian when writing to hdf5
    static std::string hdf5_format() { return "FORKTPS_Hloc"; }

    /// stream operator to quickly write the local Hamiltonian.
    friend std::ostream &operator<<(std::ostream &out, const hloc &e0);
  };

  /// Tests whether *bath* and *hloc* are compatible with the forkTPS solver and with each other.
  void check(const bath &b, const hloc &e0);

} // namespace forktps

#endif
