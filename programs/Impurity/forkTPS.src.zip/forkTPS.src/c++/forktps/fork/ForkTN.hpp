#ifndef __FORKTN__
#define __FORKTN__

#include "Fork.hpp"
#include "typenames.hpp"

#include <itensor/itensor.h>
#include <itensor/mps/mps.h>
#include <itensor/mps/siteset.h>
#undef Print

#include <vector>

using namespace itensor;

namespace forktps {

  class ForkTN : public Fork {
    public:
    /// Virtual destructor.
    virtual ~ForkTN() = default;

    // Constructors
    /// Default constructor
    ForkTN() = default;

    /** Constructs a TN with *NArms* arms using the site indices from *sites*.
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param NArms    int
    *                 Number of arms.
    */
    ForkTN(const SiteSet &sites, int NArms);

    /** Constructs a TN with *NBath[m]* bath sites on arm *m* using the site indices from *sites*. 
    * @param sites    itensor::SiteSet
    *                 Defines the indices as well as the operators on each site.
    * @param NBath    std::vector<int>
    *                 Vector containing the number of bath sites for each arm (one-indexed, i.e, NBath[1] is the number of bath sites of the first arm).
    */
    ForkTN(const SiteSet &sites, std::vector<int> NBath);

    private:
    /** Called by the constructors, this function actually fills the tensors.
    *   The ForkTN (base class) implementation is for a ForkTPS, so the ForkTPO needs to override this.
    */
    void init_tensors();

    public:
    /** Returns a reference to the tensor on site *i*. If the TN has an orthogonality center other than *i*, the orthogonality conditions of the TN
    * are modified as if the tensor on site *i* would have changed. Hence use this function only when the TN should be modified. 
    * @param i  int
    *           Site index of the returned ITensor reference.
    */
    ITensor &Anc(int i);

    /** Returns a constant reference to the site tensor on site *i*, i.e, read-only acces to the site tensor. 
    * @param i  int
    *           Site index of the returned ITensor.
    */
    ITensor const &A(int i) const;

    /** Returns an empty tensor with all indices of the tensor on site *site* except for the link shared with the neighbor in direction *towards*.
    *   The ForkTN (base class) implementation is for a ForkTPS, so the ForkTPO needs to override this.
    * @param site     int
    *                 Site index, specifying the tensor form which the indices are taken.
    * @param towards  OrthoState
    *                 Direction, specifying the link that is NOT included in the returned tensor.
    */
    virtual ITensor UTensor(int site, OrthoState towards) const;

    /** Replaces the tensors on sites *siteA* and *siteB* with *A* and *B* respectively and moves the orthogonality center according to *dir*.
    *   When using this function, the user has to make sure that A and B have the correct orthogonality properties. Usually one
    *   of the two is U (Vdag) and the other S*Vdag (U*S) of an svd M = U*S*Vdag. If this function is called with siteA > siteB, siteA is swaped
    *   with siteB and also A is swaped with B, while dir is unchanged.
    * @param A      ITensor
    *               New Tensor of *siteA*.
    * @param B      ITensor
    *               New Tensor of *siteA*.
    * @param siteA  int
    *               Site of tensor *A*.
    * @param siteB  int
    *               Site of tensor *B*.
    * @param dir    OrthoState
    *               Defines the new orthogonality center.
    *               If siteA and siteB are both impurity sites, *dir* = Downwards (Upwards) means *siteB* (*siteA*) is the new orthgonality center.
    *               Otherwise, *dir* = Rightwards (Leftwards) means *siteB* (*siteA*) is the new orthgonality center.
    */
    void InsertOrthoTensors(ITensor &&A, ITensor &&B, int siteA, int siteB, OrthoState dir);

    /** Replaces the tensor on site *site* with *A* and moves the orthogonality center to the neighbor in direction *dir*.
    *   When using this function, the user has to make sure that A has the correct orthogonality property. Usually A is
    *   either U or Vdag of an svd M = U*S*Vdag.
    * @param A      ITensor
    *               New Tensor of *site*.
    * @param site   int
    *               Site in which tensor *A* is placed.
    * @param dir    OrthoState
    *               Defines the new orthogonality center.
    *               If site is an impurity site, *dir* = Downwards (Upwards) means that the below (above) is the new orthgonality center, while *dir* = Rightwards means that the first bath site attached to this impurity is the new orthogonality center (*site*+1).
    *               Otherwise, *dir* = Rightwards (Leftwards) means that *site*+1 (*site*-1) is the new orthgonality center which is to the right (left) of *site*.
    */
    void InsertOrthoTensor(ITensor &A, int site, OrthoState dir);

    /// Returns true if an orthogonality center exists, false otherwise.
    bool IsOrtho() const;

    /// Returns the site of the orthogonality center.
    int OrthoCenter() const;

    /** Returns the link-index between the site at ```site``` and its neighbor in direction ```dir```.
    * @param site   int
    *               Site Index.
    * @param dir    OrthoState
    *               Decides which link is returned. *dir* = Rightwards, returns the link to the bath site attached to this impurity. *dir* = Downwards (Upwards) returns the link to the impurity below (above).
    */
    Index GetImpLink(int indx, OrthoState dir) const;

    /// Returns the link-index conecting the two neighboring tensors on sites *siteI* and *siteJ*.
    Index GetLink(int siteI, int siteJ) const;

    /// Returns the link-index conecting *site* to its neighbor in direction *dir*
    Index GetLink(int site, OrthoState dir) const;

    /// Returns the SiteSet of the TN.
    SiteSet const &sites() const { return sites_; }

    // svd related methods
    protected:
    /** Fully orthogonalizes the arm *arm*, such that for all bath tensors $A_{lr}^s$: 
    * $(AA^\dagger)_{ll'} = \sum_{rs} A_{lr}^s (A_{l'r}^s)^* = \delta_{l,l'}$.
    * This means that all bath tensors on arm *arm* are orthgonalized towards the impurity.
    * @param arm    int
    *               Arm index.
    * @param args   itensor::Args (default: ())
    *               Parameters, forwarded to the functions *svdArm*, hence:
    *
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB or CutoffIB respectively.
    * @param CutoffB      double (default: Cutoff)
    *                     Truncated weight used for the bath-bath links.
    * @param CutoffIB     double (default: Cutoff)
    *                     Truncated weight used for the impurity-bath links.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB or MaxmIB respectively.
    * @param MaxmB        double (default: MaxDim)
    *                     Maximal bond dimension for the bath-bath links.
    * @param MaxmIB       double (default: MaxDim)
    *                     Maximal bond dimension for the impurity-bath links.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decompositions, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the state at every tensor decomposition.
    */
    void CompOrthoArm(int arm, Args &args = Args::global());

    /** Orthogonalizes arm *arm* such that the bath site with index *indx* is the orthogonality center.
    *   Hence, the tensors $A_{lr}^s$ for all sites s except *indx* have the property:
    *   $sum_{rs} A_{lr}^s (A_{l'r}^s)^* = \delta_{l,l'}$ (s < indx)
    *   $sum_{ls} A_{lr}^s (A_{lr'}^s)^* = \delta_{r,r'}$ (s > indx)
    *
    * @param arm        int
    *                   Arm index.
    * @param indx       int
    *                   Bath index of on of the two sites.
    * @param args       itensor::Args (default: ())
    *                   Parameters, forwarded to the function *svdArm* and, hence:
    *
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB.
    * @param CutoffB      double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB.
    * @param MaxmB        double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the state at every tensor decomposition.
    */
    void OrthoArm(int arm, int indx, Args &args = Args::global());

    /** Performs a tensor decomposition of the bath site on arm *arm* with index *indx* to 
    * orthogonalize that site in direction *towards*. Depending on *towards*, the non-orthogonal part
    * of the tensor is multiplied onto the site at *indx+1* (*dir* == Fromleft) or onto *indx-1* 
    * (*dir*==Fromright). After the decomposition, the tensor at *indx* $A_{lr}^s$ has the property: 
    * $\sum_{rs} A_{lr}^s (A_{l'r}^s)^* = \delta_{l,l'}$ (dir==Fromleft) or
    * $\sum_{ls} A_{lr}^s (A_{lr'}^s)^* = \delta_{r,r'}$ (dir==Fromright).
    * @param arm        int
    *                   Arm index.
    * @param indx       int
    *                   Bath index of one of the sites,
    * @param AA         ITensor
    *                   Tensor to decompose.
    * @param dir        itensor::Direction
    *                   Defines on which tensor is orthogonal.
    * @param PH         template
    *                   Used for the noise-term in DMRG (currently no used in TN).
    * @param args       itensor::Args (default: ())
    *                   Parameters, possible args include:
    *
    * @param Noise        double (default: 0)
    *                     Strength of noise term (currently no used in TN).
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB or CutoffIB respectively.
    * @param CutoffIB     double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition for impurity-bath links.
    * @param CutoffB      double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition for bath-bath links.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB or MaxmIB respectively.
    * @param MaxmIB       double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition for impurity-bath links.
    * @param MaxmB        double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition for bath-bath links.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the orthogonality center.
    */
    template <class BigMatrixT> Spectrum svdArm(int arm, int indx, OrthoState towards, const BigMatrixT &PH, Args &args = Args::global());

    /** Orthogonalizes all impurity tensors towards the tensor at index *ImpIndex*. Afterwards, it 
    * orthogonalizes the tensor at *ImpIndex* in direction *towards*. 
    * @param ImpIndex   int
    *                   Arm index.
    * @param towards    TN::OrthoState
    *                   Specifies the direction in which the tensor at *ImpIndex* is orthogonalized.
    * @param args       itensor::Args (default: ())
    *                   Parameters forwarded to the function svdImp() hence shares the same arguments:
    *
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffI.
    * @param CutoffI      double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmI.
    * @param MaxmI        double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the orthogonality center at each decomposition.
    */
    void OrthoImps(int ImpIndex, OrthoState towards, Args &args = Args::global());

    /** Orthogonalizes the impurity on arm *arm* towards its neighbor in direction *towards*. After 
    * the decomposition, the impurity tensor $A_{udr}^s$ has the following properties i.e.:
    * $\sum_{sud} A_{udr}^s (A_{udr'}^s)^* = \delta_{r,r'}$ (towards == Rightwards).
    * $\sum_{srd} A_{udr}^s (A_{u'dr}^s)^* = \delta_{u,u'}$ (towards == Upwards).
    * $\sum_{sru} A_{udr}^s (A_{ud'r}^s)^* = \delta_{d,d'}$ (towards == Downwards).
    * @param arm        int
    *                   Arm index.
    * @param towards    TN::OrthoState
    *                   Specifies the direction in which the tensor is orthogonalized.
    * @param PH         template
    *                   Used for the noise-term in DMRG (currently no used in TN).
    * @param args       itensor::Args (default: ())
    *                   Parameters, possible args include:
    *
    * @param Noise        double (default: 0)
    *                     Strength of noise term (currently no used in TN).
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffI or CutoffIB respectively.
    * @param CutoffI      double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition for impurity-impurity links.
    * @param CutoffIB     double (default: Cutoff)
    *                     Truncated weight used in the tensor decomposition for impurity-bath links.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmI or MaxmIB respectively.
    * @param MaxmI        double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition for impurity-impurity links.
    * @param MaxmIB       double (default: MaxDim)
    *                     Maximal bond dimension for the tensor decomposition for impurity-bath links.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the orthogonality center.
    */
    template <class BigMatrixT> Spectrum svdImp(int arm, OrthoState towards, const BigMatrixT &PH, Args &args = Args::global());

    public:
    /** Sets the orthogonality center to site *i* by performing the necessary tensor decompositions
    * based on the existing orthogonality conditions without truncation.
    * @param i   int
    *            New orthogonality center.
    */
    void position(int i);

    /** Sets the orthogonality center to site *i* by performing the necessary tensor decompositions
    *   based on the existing orthogonality conditions. The tensor network is truncated with 
    *   parameters specified in *args*.
    *
    * @param i      int
    *               New orthogonality center.
    * @param args   itensor::Args
    *               Parameters, forwarded to the functions *CompOrthoArm*, *OrthoArm* and *OrthoImps*, hence:
    *
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB, CutoffIB, or CutoffI respectively.
    * @param CutoffI      double (default: Cutoff)
    *                     Truncated weight used for the impurity-impurity links.
    * @param CutoffB      double (default: Cutoff)
    *                     Truncated weight used for the bath-bath links.
    * @param CutoffIB     double (default: Cutoff)
    *                     Truncated weight used for the impurity-bath links.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB, MaxmIB or MaxmI respectively.
    * @param MaxmI        double (default: MaxDim)
    *                     Maximal bond dimension for the impurity-impurity links.    
    * @param MaxmB        double (default: MaxDim)
    *                     Maximal bond dimension for the bath-bath links.
    * @param MaxmIB       double (default: MaxDim)
    *                     Maximal bond dimension for the impurity-bath links.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the orthogonality center at each decomposition.  
    */
    void position(int i, Args &args);

    /**
    * Orthogonalizes the whole TN tensor network and truncates based on the parameters specified 
    * in *args*. This happens in a two-step process: First, an orthogonality center is established using 
    * a low truncation. Then, the orthogonality center is moved to the first site using the truncation 
    * specified in *args*.
    * @param args   itensor::Args
    *               Parameters, forwareded to function *position*, hence:
    *
    * @param Cutoff       double (default: -1)
    *                     Truncated weight used in the tensor decomposition. Overwritten by CutoffB, CutoffIB, or CutoffI respectively.
    * @param CutoffI      double (default: Cutoff)
    *                     Truncated weight used for the impurity-impurity links.
    * @param CutoffB      double (default: Cutoff)
    *                     Truncated weight used for the bath-bath links.
    * @param CutoffIB     double (default: Cutoff)
    *                     Truncated weight used for the impurity-bath links.
    * @param MaxDim       double (default: 30000)
    *                     Maximal bond dimension for the tensor decomposition. Overwritten by MaxmB, MaxmIB or MaxmI respectively.
    * @param MaxmI        double (default: MaxDim)
    *                     Maximal bond dimension for the impurity-impurity links.    
    * @param MaxmB        double (default: MaxDim)
    *                     Maximal bond dimension for the bath-bath links.
    * @param MaxmIB       double (default: MaxDim)
    *                     Maximal bond dimension for the impurity-bath links.
    * @param UseSVD       bool (default: true)
    *                     If true, use an svd for the tensor decomposition, otherwise use itensors denmatDecomp() if precision is not too high (<1E-12).
    * @param DoNormalize  bool (default: false)
    *                     If true, normalizes the orthogonality center at each decomposition.
    */
    void orthogonalize(Args &args = Args::global());

    /// Removes any knowledge of orthogonality in the TN. The next time position is called, orthogonality center is recalculated from the start.
    void ForgetOrtho();

    /** Writes the TN to stream *s*
    * @param s      std::ostream
    *               Stream to which the TN is written.
    */
    void write(std::ostream &s) const;

    /** Reads the TN from stream *s* using SiteSet *sites*. Note that sites needs to be the
    *   exact same SiteSet with which the TN was written to stream.
    * @param s      std::istream
    *               Stream from which the TN is read.
    * @param sites  itensor::SiteSet
    *               Itensor SiteSet defining the indices- as well as the operators on each site. Needs to be the same SiteSet with which the TN was saved.
    */
    void read(std::istream &s, const SiteSet &sites);

    /** Copies all tensors as well as the orthogonality conditions from TN *other*.
    * @param other  ForkTPS
    *               TN from which to copy.
    */
    //void copyTensors(const ForkTN &other);

    /// For all link-indices: prime them to prime level *newp* if they have prime level *oldp*.
    void primeLinks(int oldp, int newp);

    /// For all indices: if they have the tag *tags* and if they have prime level *oldp*, prime them to prime level *newp*.
    void mapPrime(int oldp, int newp, std::string tags);

    /// Sets the prime level of all links to zero.
    void noprimelink();

    /// *= operator with a real number
    ForkTN &operator*=(Real a) {
      OC_ != -1 ? Anc(OC_) *= a : Anc(NBath() + 1) *= a;
      return *this;
    }

    /// /= operator with a real number
    ForkTN &operator/=(Real a) {
      OC_ != -1 ? Anc(OC_) /= a : Anc(NBath() + 1) /= a;

      return *this;
    }

    /// Multiplication by a real number
    ForkTN operator*(Real r) const {
      ForkTN res(*this);
      res *= r;
      return res;
    }

    /// *= operator with a complex number
    ForkTN &operator*=(Complex z) {
      OC_ != -1 ? Anc(OC_) *= z : Anc(NBath() + 1) *= z;

      return *this;
    }

    /// Division by a complex number
    ForkTN &operator/=(Complex z) {
      OC_ != -1 ? Anc(OC_) /= z : Anc(NBath() + 1) /= z;

      return *this;
    }

    /// Multiplication by a complex number
    ForkTN operator*(Complex z) const {
      ForkTN res(*this);
      res *= z;
      return res;
    }

    // Other functions

    /// Returns the maximal bond dimension
    long MaxM() const;

    /** Prints all bond dimensions between sites *i* and *j* and returns the maximum.
    * @param  i int (default: 1)
    *         First site printed.
    * @param  j int (default: 0)
    *         Last site printed, if not provided print up to last site.    
    */
    long PrintM(int i = 1, int j = 0) const;

    /// Returns a vector containing all bond dimensions.
    std::vector<int> BondDims() const;

    ///  Prints bond dimensions of the impurity tensors.
    void PrintImpM(int numSpaces = 0) const;

    /// Prints current orthogonality conditions.
    void PrintOrthoConditions() const;

    /// Prints all tensors.
    void PrintTensors() const;

    /// Prints the quantum number divergence of each tensor.
    void PrintDivs() const;

    protected:
    /// ITensor SiteSet defining the indices- as well as the operators on each site.
    SiteSet sites_;

    /// Orthogonality center. OC_=-1 means that there is no orthogonality center.
    int OC_{};

    /// Vector of Arms representing the bath tensors.
    std::vector<Arm> Arms_;

    /// Vector of ITensors representing the impurity tensors.
    mutable std::vector<ITensor> A_;

    /// Vector of OrthoState representing the orthogonality properties of each impurity tensor.
    std::vector<OrthoState> OSI_;
  };

} // namespace forktps

#endif
