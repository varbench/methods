#pragma once
#include "params.hpp"
#include <itensor/util/args.h>

using namespace forktps;
using namespace itensor;

namespace forktps {
  /** Adds relevant parameters from *p* to the itensor Args object, including truncation parameters and number of sweeps.
    */
  void SetArgs(Args &args, const DMRG_params &p);

  /** Adds relevant parameters from *p* to the itensor Args object, including truncation parameters and TDVP method if applicabel.
    */
  void SetArgs(Args &args, const Tevo_params &p);

  /** Adds truncation parameters from *p* to the itensor Args object.
    */
  void SetArgs(Args &args, const tn_approx &p);

  /** Adds krylov approximation parameters from *p* to the itensor Args object.
    */
  void SetArgs(Args &args, const krylov_params &p);

  /** Adds basis extension parameters from *p* to the itensor Args object.
   */
  void SetArgs(Args &args, const basisExpansion_params &p);

  void SetArgs(Args &args, const sampling_params &p);

  /*
    template <typename T, typename... Types> 
    void SetArgs(Args& args, const T var1, const Types... var2) 
    { 
        SetArgs(args, var1);

        SetArgs(args, var2...);
    } */
} // namespace forktps
