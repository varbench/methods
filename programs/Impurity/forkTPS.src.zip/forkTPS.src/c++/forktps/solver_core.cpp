/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************************************/

#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <iomanip>
#include <itensor/global.h>
#include <itensor/mps/mps.h>
#include <itensor/qn.h>
#include <itensor/util/readwrite.h>
#include <limits>
#include <mpi.h>
#include <mpi/mpi.hpp>
#include <csignal>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>

#include "./solver_core.hpp"

#include "fork/FTPO/AIM.hpp"
#include "fork/FTPO/AIM_OffDiag.hpp"
#include "fork/FTPO/AIM_SpinOrbit.hpp"
#include "fork/FTPO/AIM_SingleBlock.hpp"
#include "fork/FTPO/AIM_SelfEnergyTrick.hpp"
#include "fork/FTPO/ExpectationValues.hpp"
#include "fork/makros.hpp"

#include "fork/TevoMethods.hpp"
#include "fork/Bath.hpp"
#include "fork/Fork.hpp"
#include "fork/ForkCalculus.hpp"
#include "fork/ForkLocalOp.hpp"
#include "fork/ForkTPS.hpp"
#include "fork/HelperFunctions.hpp"

#include "fork/SiteSets/AIM_ForkSites.hpp"

#include "fork/typenames.hpp"
#include <cmath>
#include "params.hpp"
#include "setargs.hpp"
#include "types.hpp"

#include <fstream>
#include <functional>
#include <itensor/index.h>
#include <itensor/mps/sites/electron.h>
#include <itensor/types.h>
#include <itensor/util/error.h>
#include <itensor/util/itertools.h>
#include <itertools/itertools.hpp>
#include <numeric>
#include <string>
#include <system_error>
#include <triqs/gfs/gf/targets.hpp>
#include <triqs/mesh/refreq.hpp>
#include <triqs/mesh/retime.hpp>
#include <triqs/gfs/transform/fourier.hpp>
#include <h5/h5.hpp>
#include <triqs/utility/exceptions.hpp>
#include <tuple>
#include <unistd.h>
#include <utility>
#include <vector>

//access GFs the following way:
//int val = 0 ... Nblocks
//w ... omega index
//i,j ... matrix indies
// G_w[val][w] (i,j);

// TODO: remove all checks whether bath is valid from bath class and put it
// into solver or MPOs
// TODO: check imag tevo

//TODO: h5read/write new containers think about what to do

using namespace itensor;

namespace forktps {

  // is a global variable because signal_handler must call cleanup
  std::string HASH;

  solver_core::solver_core(const constr_params_t &p) : constr_params(p), SectorEnergies(0), SectorImpOccs(0), indent(0) {
    // Initialize the result containers
    E0 = std::numeric_limits<double>::max();

    // G_w            = block_gf<refreq>{{p.w_min, p.w_max, p.n_w}, p.gf_struct};
    // F_w            = G_w;
    // Sigma_w        = G_w;
    Delta_cont_w   = block_gf<refreq>{{p.w_min, p.w_max, p.n_w}, p.gf_struct};
    Delta_recons_w = Delta_cont_w;

    // initialize MPI if not already done
    int initialized = 0;
    MPI_Initialized(&initialized);
    if (!initialized) MPI_Init(nullptr, nullptr);
  }

  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------
  // ------------------------------- Solve Call ------------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------

  void solver_core::solve(const solve_params_t &solve_params) {
    ReportOnce("\n\nStarting FTPS solver\n\n");
    ReportOnce(solve_params, "\n");
    ReportOnce(b.bandwidth());
    ReportOnce(e0);

    // check if solver is in valid state
    checkSolver(solve_params);
    last_solve_params = solve_params;

    // Merge constr_params and solve_params
    params_t params(constr_params, solve_params);

    // Reset the results and initialize parameters
    reset_gf(params);
    init(params);

    //GS search dont do if user provided a gs
    if (world.rank() == 0 && !params.path_to_gs) {
      // Reconstruct Delta from the discrete bath
      Delta_recons_w = b.reconstructDelta(Delta_cont_w[0].mesh(), solve_params.eta);

      find_gs(params);
      saveGS(folderBase + "GS", gs, sites, E0);
      MeasureObservables(params);
      MeasureSingleParticleDensity(params);
    }
    world.barrier(0);

    // read in GS on all ranks either from folder base or from path provide by user.
    if (!params.path_to_gs) {
      loadGS(folderBase + "GS", gs, sites, E0);
    } else {
      ReportOnce("\n\n\n--------------------------------------------------------------------------\n");
      ReportOnce("Path to ground state provided by user.\n Skip DMRG and load ground state from file: ", *params.path_to_gs, '\n');
      loadGS(*params.path_to_gs, gs, sites, E0);
      ReportOnce("Ground state successfully loaded, energy = ", E0, "\n");
      ReportOnce("--------------------------------------------------------------------------\n");
      saveGS(folderBase + "GS", gs, sites, E0); // write gs to folderBase
    }

    // check that ground state loaded fits to the bath
    for (auto arm : range1(gs.NArms())) {
      if (gs.NBath(arm) != b.NBath(b.FTPSIndxToBlock(arm))) {
        std::cout << "Ground state bath size on arm " << arm << ": " << gs.NBath(arm)
                  << " bath size of bath object: " << b.NBath(b.FTPSIndxToBlock(arm)) << std::endl;
        TRIQS_RUNTIME_ERROR << "Ground state bath size does not fit to bath object provided!";
      }
    }

    ReportOnce("\n\n\n--------------------------------------------------------------------------\n");
    ReportOnce("-------------------------- Start Time Evolution --------------------------\n");
    ReportOnce("--------------------------------------------------------------------------\n\n");
    world.barrier(0);

    if (!params.calc_gf) { GFsTodo.clear(); }
    for (auto comp : mpi::chunk(GFsTodo.getComponents(), world)) { calc_gf(params, comp); }
    world.barrier(0);

    post_process(params);
  }

  void solver_core::solve(const solve_params_t &solve_params, const ForkTPS &GS) {

    ReportOnce("Starting FTPS solver with user provided GS \n");
    ReportOnce(solve_params, "\n");
    ReportOnce(b.bandwidth());

    // check if solver is in valid state
    checkSolver(solve_params);
    last_solve_params = solve_params;

    // Merge constr_params and solve_params
    params_t params(constr_params, solve_params);
    sites = GS;

    // Reset the results and initialize parameters
    reset_gf(params);
    init(params);

    if (world.rank() == 0) {
      // Reconstruct Delta from the discrete bath
      Delta_recons_w = b.reconstructDelta(Delta_cont_w[0].mesh(), params.eta);
    }
    world.barrier(0);
    gs = GS;
    ForkLocalOp Heff(H);
    Heff.position(1, gs);
    E0 = Heff.ContractAll(gs).real();
    ReportOnce("Ground state energy: ", E0, "\n\n Start Time evolution\n\n");

    for (auto comp : mpi::chunk(GFsTodo.getComponents(), world)) { calc_gf(params, comp); }
    world.barrier(0);

    post_process(params);
  }

  void solver_core::checkSolver(const solve_params_t &sp) {
    // check wheter gfstruct used in construction is the same as the one used for the bath
    if (constr_params.gf_struct != b.gf_struct()) {
      TRIQS_RUNTIME_ERROR << "This solver was constructed with a different block structure than what was used for the bath!";
    }

    // check wheter bath b and e0 are compatible with each other (defined in bath.cpp)
    check(b, e0);
    // check if valid tevo method was provided
    if (sp.tevo.method != "TDVP" && sp.tevo.method != "TDVP_2" && sp.tevo.method != "TEBD" && sp.tevo.method != "TDVP_2Experimental")
      TRIQS_RUNTIME_ERROR << "Invalid tevo_method in solve params: " + sp.tevo.method + ". Only TDVP, TDVP_2 or TEBD  TDVP_2Experimental are allowed";

    if (sp.tevo.method == "TEBD" && (b.isOffDiag() || e0.isOffDiag()))
      TRIQS_RUNTIME_ERROR << "Time evolution method TEBD does not work for an off-diagonal bath or impurity.";

    // check calc_me
    auto bN = b.blockNames();
    for (auto [name, indx] : sp.calc_me) {
      auto iter = std::find(bN.cbegin(), bN.cend(), name);
      if (iter == bN.cend()) { TRIQS_RUNTIME_ERROR << "An invalid blockname: " << name.c_str() << " was provided to calc_me."; }

      if (indx >= b.NArms()) { TRIQS_RUNTIME_ERROR << "An invalid blockindex: " << indx << " was provided to calc_me."; }
    }

    // number of times MPO is applied in preparation
    if (sp.params_partSector.prep.napp_h == 0 || sp.params_GS.prep.napp_h == 0) {
      ReportOnce("\n\nWarning, in DMRG preparation, the number of times the MPO is applied is set to zero. This can be very dangerous!\n\n");
    }

    // GF input:
    std::vector<std::string> validGFs{"S", "F", "N"};
    for (auto gf : sp.GFs) {
      bool notFound = std::find(validGFs.begin(), validGFs.end(), gf) == validGFs.end();
      if (notFound) { TRIQS_RUNTIME_ERROR << "Invalid GF " << gf << " provided to solve_params GFs."; }
    }
  }

  void solver_core::init(const params_t &p) {
    args = Args();

    E0 = std::numeric_limits<double>::max();

    // the impurity model is uniquely defined by its interaction part, as well as the bath and the Hloc.
    // Also use the DMRG parameters as well as dt and approx of tevo. Note do not use Number of time steps
    // to be able to post_process with a smaller time step size
    auto hash = CreateHash(p.h_int, b, e0, p.params_partSector, p.params_GS, p.tevo.dt, p.tevo.approx);
    SetHash(hash);
    folderBase = p.state_storage + "MPS" + HASH + "/";

    FillGFComponents(p);

    ReportOnce("Storing states to ", folderBase, "\n");
    if (world.rank() == 0) {
      // delete folders before starting
      system(("rm -rf " + folderBase).c_str());

      // create the necessary folders for time evolution using the hash
      auto status                 = mkdir(folderBase.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
      const int errorFolderExists = 17;
      // errno = 17 means folder already exists ... this is no problem for us
      if (status == -1 && errno != errorFolderExists) TRIQS_RUNTIME_ERROR << "Error in creating the folders: " + std::string(strerror(errno));

      for (auto c : GFsTodo.getComponents()) {
        status = mkdir((folderBase + c.FolderName()).c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        if (status == -1 && errno != errorFolderExists) TRIQS_RUNTIME_ERROR << "Error in creating the folders: " + std::string(strerror(errno));
      }
    }

    // initilize not done for each type with false for all indices
    notDone.resize(make_shape(GFsTodo.getComponents().size()));
    notDone = 0;

    SectorEnergies.resize(0);
    SectorImpOccs.resize(0);
    NPartGS.resize(b.NArms());

    world.barrier(0);
  }

  void solver_core::FillGFComponents(const params_t &p) {

    double max_t = p.tevo.dt * 2 * p.tevo.time_steps;
    gf_mesh<retime> tmesh{0., max_t, 2 * p.tevo.time_steps + 1};
    GFsTodo.clear();

    //create vector of all standard Green's functions to calculate
    for (auto type : TypesToDo(p)) {
      for (auto [siteI, siteJ] : itertools::product(AllTriqsInds(), AllTriqsInds())) {

        if (MustBeDone(siteI, p.calc_me) && MustBeDone(siteJ, p.calc_me)) {
          // single particle GFs can only be block diagonal
          if (isSingleParticle(type) && siteI.first != siteJ.first) continue;
          GFsTodo.emplace_back(siteI, siteJ, type, p.tevo.imag_tevo, tmesh);
        }
      }
    }

    // create vector of all custom GFs
    for (auto [A, B] : p.customGF) {
      // need to dagger A, because FTPS calculates ( e^{iHt/2} A^dag |0> ) ^ dagger    * ( e^{-iHt/2} B |0>  )
      A = dagger(A);
      for (auto [mA, mB] : itertools::product(A, B)) {
        // dont calculate trivial monomials Id * B or A * Id, they will be dealt with later
        if (mA.monomial.size() == 0 || mB.monomial.size() == 0) continue;

        GFsTodo.emplace_back(mA.monomial, mB.monomial, p.tevo.imag_tevo, tmesh);
      }
    }

    for (auto c : GFsTodo.getComponents()) ReportOnce(c, "\n");
  }

  void solver_core::reset_gf(const params_t &p) {
    double max_t = p.tevo.dt * 2 * p.tevo.time_steps;

    gf_mesh<retime> tmesh{0., max_t, 2 * p.tevo.time_steps + 1};
    gf_mesh<refreq> wmesh{p.w_min, p.w_max, p.n_w};

    for (auto defaultGF : p.GFs) {
      if (defaultGF == "S") {
        G_ret = block_gf<retime>{tmesh, p.gf_struct};
        G_le  = G_ret;
        G_gr  = G_ret;

        G_w     = block_gf<refreq>{wmesh, p.gf_struct};
        Sigma_w = G_w;
      } else if (defaultGF == "F") {
        F_ret = block_gf<retime>{tmesh, p.gf_struct};
        F_le  = F_ret;
        F_gr  = F_ret;

        F_w = block_gf<refreq>{wmesh, p.gf_struct};
        ;
        Sigma_w = F_w;
      } else if (defaultGF == "N") {
        // N does not adhere to block-structure but is a full 2*orbs x 2*orbs matrix
        N_t = gf(tmesh, {b.NArms(), b.NArms()});

        N_w = gf(wmesh, {b.NArms(), b.NArms()});
      }
    }

    // custom GFs
    customGF.resize(0);
    customGF.resize(p.customGF.size());
    customGF() = gf<retime, scalar_valued>(tmesh);
  }

  ForkTPS solver_core::get_gs() { return gs; };

  // map the arm index to triqs index
  triqs_indx solver_core::ArmToTriqsIndx(int const &iarm) {
    if (!b.isSpinOrbit()) {
      std::string bN_up = "up", bN_dn = "dn";
      std::string blockName = (iarm % 2 == 1) ? bN_up : bN_dn;
      auto blockI           = static_cast<int>((iarm - 1 - (iarm - 1) % 2) / 2);
      triqs_indx ind        = {blockName, blockI};
      return ind;
    } else {
      //currently, spin-orbital coupling works only for 3-orbital systems
      std::vector<triqs_indx> indices(6);
      indices[0] = {"ud_0", 0}; // arm 1
      indices[3] = {"ud_0", 1}; // arm 4
      indices[5] = {"ud_0", 2}; // arm 6

      indices[1] = {"ud_1", 0}; // arm 2
      indices[2] = {"ud_1", 1}; // arm 3
      indices[4] = {"ud_1", 2}; // arm 5
      return indices[iarm - 1];
    }
  };

  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------- GS search ------------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------

  void solver_core::find_gs(const params_t &p) {
    SetArgs(args, p.params_partSector);
    find_gs_sector(p);

    //output
    ReportOnce("\n\n\n--------------------------------------------------------------------------\n");
    ReportOnce("---------------------- Ground State Sector Found -------------------------\n");
    ReportOnce("--------------------------------------------------------------------------\n\n");
    ReportOnce("\nStart DMRG for total ground state.\n");

    //DMRG in sector of lowest energy
    SetArgs(args, p.params_GS);
    prepare_DMRG(gs, p);

    //args.add("DMRGMethod","TwoSite");
    DMRG(gs, H, E0, args);
    gs.normalize();

    //measure impurity energy
    auto bath_zero = b;
    for (auto arm : range1(sites.NArms())) {
      triqs_indx ind = ArmToTriqsIndx(arm);
      for (auto k : itertools::range(bath_zero.NBath(ind))) {
        //onsite energies, always diagonal
        bath_zero.b.at(ind.first).at(ind.second).at(k).eps = 0.0;
        //hopping terms
        for (auto arm_J : range1(sites.NArms())) {
          triqs_indx ind_J = ArmToTriqsIndx(arm_J);
          //must in the same block
          if (ind.first == ind_J.first) { bath_zero.b.at(ind.first).at(ind.second).at(k).V.at(ind_J.second) = 0.0; }
        }
      }
    }

    auto e0_zero = e0;
    for (auto block : p.gf_struct) {
      for (int iorb(0); iorb < block.second; iorb++) {
        for (int jorb(0); jorb < block.second; jorb++) { e0_zero.e.at(block.first)(iorb, jorb) = 0.0; }
      }
    }
    auto hint_zero = H_int(0.0, 0.0, 0.0, p.h_int.dd_only);

    // set up the respond FTPO for impurity measurement
    auto Hhyb_ = whichFTPO(p, b, e0_zero, hint_zero);
    auto He0_  = whichFTPO(p, bath_zero, e0, hint_zero);
    auto Hint_ = whichFTPO(p, bath_zero, e0_zero, p.h_int);

    // measure hyb, e0, and hint
    auto gs_   = gs;
    auto Heff_ = ForkLocalOp(Hhyb_);
    Heff_.position(1, gs_);
    Ehyb = std::real(Heff_.ContractAll(gs_));

    gs_   = gs;
    Heff_ = ForkLocalOp(He0_);
    Heff_.position(1, gs_);
    Ee0 = std::real(Heff_.ContractAll(gs_));

    gs_   = gs;
    Heff_ = ForkLocalOp(Hint_);
    Heff_.position(1, gs_);
    Ehint = std::real(Heff_.ContractAll(gs_));

    // output
    ReportOnce("\n\n\n--------------------------------------------------------------------------\n");
    ReportOnce("------------------------- Ground State Calculated ------------------------\n");
    ReportOnce("--------------------------------------------------------------------------\n\n");
    ReportOnce("Energy: ", E0);
    auto ImpOccs = gs.ImpOccs();
    ReportOnce("\nOrbital resolved impurity occupation: ", ImpOccs);
    ReportOnce("\nTotal impurity occupation: ", std::accumulate(ImpOccs.begin(), ImpOccs.end(), 0.), "\n");
    try { // ground state variance can cause bad_alloc exceptions or other problems in some cases
      GSVariance = PrintGSConvergence(gs, H);
    } catch (...) {
      std::cout
         << "\n\n\n\nEncountered an error during the computation of the ground state variance. This can happen if the FTPO/FTPS bond dimensions are large. Computation of variance will be skipped!!!! "
         << "\n\n\n\n";
    }
  }

  void solver_core::find_gs_sector(const params_t &p) {
    auto particleNumbers = p.NPart;

    if (particleNumbers.size() == 0) {
      SectorSearch_woQN(p);
      // generate SiteSet with QN conservation used in the following
      sites = GetSiteSet();
      H     = whichFTPO(p);
      gs    = InitProductState(NPartGS);
    } else {
      SectorSearch_NProvided(p);
    }

    return;
  }

  void solver_core::prepare_DMRG(ForkTPS &psi, const params_t &p) {
    indent = 4;
    ReportOnce("Preparing for DMRG: \n");
    indent += 2;
    Args args_prep({args, "TrackNorm", true, ""});

    auto NH = args_prep.getInt("NAppHPrep");
    ReportOnce("Apply MPO ", NH, " times.\n");

    //apply MPO a couple of times
    for (int i : range1(NH)) {
      UNUSED_VAR(i);
      psi = forktps::exactApplyMPO(psi, H, args_prep);
      psi.normalize();
    }

    //imaginary time evolution
    if (args_prep.getBool("DoImagTevo", false)) {
      auto method     = args_prep.getString("TevoMethod");
      auto dtau       = args_prep.getReal("dtau");
      auto NTimeSteps = args_prep.getInt("NTimeSteps");

      ReportOnce("Imaginary time evolution. Perform ", NTimeSteps, " steps using ", method, " algorithm.\n");

      if (method == "TEBD") {
        auto Ops = TEBD_container(p.h_int, b.todiag(), e0.todiag(), dtau, sites);
        for (auto i : range1(NTimeSteps)) {
          UNUSED_VAR(i);
          TEBD(psi, Ops, args_prep);
          psi.normalize();
        }
      } else {
        ForkLocalOp heff(H);
        args_prep.add("MaxIter", 100); // hard code 100 for Number of Krylov vectors
        for (auto i : range1(NTimeSteps)) {
          UNUSED_VAR(i);
          TDVP(psi, heff, dtau, args_prep);
          psi.normalize();
        }
      }
    }
    indent -= 2;
    ReportOnce("Preparation done.\n");
    indent = 0;
  }

  void solver_core::SectorSearch_woQN(const params_t &p) {
    // if NPart is not given by the user look for the sector
    std::vector<int> particleNumbers{};

    ReportOnce("Finding GS sector by doing DMRG without QNs.\n");

    const int initialBondDim = 20;
    const double tooLargeVar = 1E-2;

    sites = GetSiteSet(false);
    H     = whichFTPO(p);

    ForkTPS gs_noqn;

    //Filling init state
    InitState init(sites);
    for (auto bN : p.block_names()) {
      int bs = b.blockSize(bN);
      //loop over matrix entries in each block
      for (auto i : itertools::range(bs)) {
        int arm = b.blockToFTPSIndx({bN, i});
        for (auto k : itertools::range(b.NBath({bN, i}))) {
          if (b.eps({bN, i}, k) < 0) init.set(sites.ArmToSite(arm, k + 1), "Occ");
        }
        init.set(sites.ImpSite(arm), "Occ");
      }
    }

    gs_noqn = ForkTPS(init, b.NBathVec());
    gs_noqn.randomize(initialBondDim);
    Args locArgs{"DoNormalize", true};
    gs_noqn.position(1, locArgs);
    gs_noqn.normalize();

    prepare_DMRG(gs_noqn, p);
    DMRG(gs_noqn, H, E0, args);

    // look at particle number variance
    auto totOcc  = MeasureTotN(gs_noqn);
    auto occs    = MeasureAllArmN(gs_noqn);
    auto varNtot = std::pow(totOcc.first, 2) - totOcc.second;

    ReportOnce("Variance of total N: ", varNtot, "\n");
    if (std::fabs(varNtot) > tooLargeVar) {
      PrintBorderLine(3);
      std::cout << "Warning, variance of N is large, was the ground state sector found properly??\n";
      PrintBorderLine(3);
    }

    SectorEnergies.push_back(E0);
    SectorImpOccs.push_back(gs_noqn.ImpOccs());

    NPartGS.resize(0);
    for (auto mp : occs) { NPartGS.push_back(std::round(mp.first)); }
    ReportOnce("Particle Sector found: ", NPartGS, "\n");

    return;
  }

  void solver_core::SectorSearch_NProvided(const params_t &p) {
    double Emin = std::numeric_limits<double>::max();

    sites = GetSiteSet();
    H     = whichFTPO(p);

    ReportOnce("\nStarting search through user defined sectors.\n");
    for (auto NPart : p.NPart) {
      ReportOnce("\n\nLooking in sector: ", NPart, "\n");

      double currE{};
      ForkTPS psi = InitProductState(NPart);
      prepare_DMRG(psi, p);

      DMRG(psi, H, currE, args);
      ReportOnce("Energy in this sector: ", roundVal(currE, 4), "\n");
      SectorEnergies.push_back(currE);
      SectorImpOccs.push_back(psi.ImpOccs());

      if (currE < Emin) {
        ReportOnce("So far this sector has the smallest Energy! \n");
        Emin    = currE;
        gs      = psi;
        NPartGS = NPart;
      }
    }

    ReportOnce("\n\nSearch through user defined sectors resulted in:\n");
    for (auto [indx, NPart] : itertools::enumerate(p.NPart)) {
      ReportOnce("NPart = ", NPart, ", energy = ", roundVal(SectorEnergies.at(indx), 4),
                 ", Impurity Occupation: ", roundVec(SectorImpOccs.at(indx), 2), "\n");
    }
    ReportOnce("\nUse sector ", NPartGS, "!\n");

    return;
  }

  ForkTPS solver_core::InitProductState(std::vector<int> NPart) {
    if (NPart.size() != b.NArms()) {
      TRIQS_RUNTIME_ERROR << "When a particle number is provided, the number entries must be equal to the number of chains!";
    }

    // initialize GS with correct number of particles
    InitState init(sites);
    for (auto arm : itertools::range(b.NArms())) {
      int n        = NPart.at(arm);                                     // number of particles on that particular arm
      int baseSite = sites.ImpSite(arm + 1) + sites.NBath(arm + 1) + 1; // last site of particular arm
      while (n > 1) {
        init.set(baseSite - n, "Occ");
        n--;
      }
      if (n >= 1) init.set(sites.ImpSite(arm + 1), "Occ");
    }

    return ForkTPS(init, b.NBathVec());
  }

  void solver_core::MeasureObservables(const params_t &p) {
    measurement_results.resize(0);
    if (p.measurements.size() == 0) return;

    ReportOnce("\nGround State Measurements\n");
    indent += 2;
    if (world.rank() == 0) {
      for (auto op : p.measurements) {
        Complex res = 0;
        for (const auto &m : op) {
          auto OpGS = gs;
          ApplyOperator(m.monomial, OpGS, b);
          res += overlap(gs, OpGS) * std::complex<double>(m.coef);
        }

        measurement_results.push_back(res.real());
        ReportOnce("Measure operator ", op, ", result: ", res, "\n");
      }
    }
    ReportOnce("\n");
    indent -= 2;
  }

  void solver_core::MeasureSingleParticleDensity(const params_t &p) {
    singleParticleDensity.resize(0);
    if (world.rank() == 0 && p.measure_single_particle_density) {
      for (int site_i = 1; site_i <= gs.N(); ++site_i) {
        for (int site_j = 1; site_j <= gs.N(); ++site_j) {
          auto bra = gs;
          auto ket = gs;
          ket.ApplySingleSiteOp(sites.op("Ck", site_i), site_i, true);
          ket.ApplySingleSiteOp(sites.op("CkD", site_j), site_j, true);
          singleParticleDensity.push_back(overlap(bra, ket));
        }
      }

      for (int site_i = 1; site_i <= gs.N(); ++site_i) {
        for (int site_j = 1; site_j <= gs.N(); ++site_j) {
          auto bra = gs;
          auto ket = gs;
          ket.ApplySingleSiteOp(sites.op("CkD", site_i), site_i, true);
          ket.ApplySingleSiteOp(sites.op("Ck", site_j), site_j, true);
          singleParticleDensity.push_back(overlap(bra, ket));
        }
      }
      gs.PrintOccs();
    }
  }

  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------
  // ------------------------------ Time evolution ---------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------

  void solver_core::calc_gf(const params_t &p, GFComponent c) {
    component = c;
    std::cout << "Rank " << world.rank() << " time evolves GF component " << to_string(component.braket) << " " << c.op << " with " << p.tevo.method
              << ": " << p.tevo.time_steps << " steps, dt = " << p.tevo.dt << "\n";

    //apply operator
    ApplyGFOperator(p);

    SetArgs(args, p.tevo);
    bool doTDVP = (p.tevo.method.find("TDVP") != std::string::npos);

    // Decide on tevo method
    if (doTDVP)
      TDVPTevo(p);
    else
      TEBDTevo(p);
  }

  void solver_core::ApplyGFOperator(const params_t &p) {
    /*
    if(component.isSelfEnergy()){
      // Self Energy Gf
      auto indx = b.blockToFTPSIndx(component.site);
      auto F = ForkTPO(AIM_SelfEnergyMPO(sites, p.h_int, indx, b.NArms(), args));
      if (component.type == selfEnergy_greater) F.HermitianConjugate(); // apply F^dag for bra state

      //auto state = FitApplyMPO(gs, F, {args, "alpha", 0.}); //F< = ( ... )^dag * ( exp( +iHt/2 ) F |0> )   
      Tstate = exactApplyMPO(gs, F, args); //F< = ( ... )^dag * ( exp( +iHt/2 ) F |0> ) 
      return; 
    }*/
    UNUSED_VAR(p);
    Tstate = gs;
    ApplyOperator(component.op, Tstate, b);

    //ForkTPS temp = Tstate;

    //temp.normalize();
    //temp.position(1);

    //auto MyHeff = ForkLocalOp(whichFTPO(p));
    //MyHeff.position(1, temp );
    //auto excitationE = MyHeff.ContractAll(temp).real() - E0;

    //std::cout<< "Energy of excitation with "<< OpName <<  " in orbital " << component.site<< ": "  <<excitationE <<"\n";
  }

  void solver_core::TDVPTevo(const params_t &p) {

    auto norm = Tstate.norm();
    auto dt   = static_cast<int>(component.tdir) * p.tevo.dt;
    if (CheckGFNorm(norm) == false) return;

    // get hamiltonian shifted by E0, (H-E0)
    args.add("E0Shift", -E0);
    ForkLocalOp heff(whichFTPO(p));

    int t = 0;
    SaveGFState(Tstate, t);

    //loop over times
    while (t < p.tevo.time_steps) {
      t++;
      if (component.imag_tevo) {
        TDVP(Tstate, heff, dt, args);
      } else {
        TDVP(Tstate, heff, Complex_i * dt, args);
        Tstate *= norm / Tstate.norm();
      }

      SaveGFState(Tstate, t);

      //if( t % (int)(p.tevo.time_steps/20) == 0 ){
      //  std::cout<< world.rank() << " t = " << t << std::endl << state.BondDims() << std::endl;
      //}
    }
    args.add("E0Shift", 0);
    std::cout << "Rank " << world.rank() << " finished time evolution." << std::endl;
  }

  void solver_core::TEBDTevo(const params_t &p) {

    auto dt   = static_cast<int>(component.tdir) * p.tevo.dt;
    auto norm = Tstate.norm();
    if (CheckGFNorm(norm) == false) return;

    // tevo sign not needed for imag tevo, because in imaginary time, we calculate the time ordered GF, so G<(t<0) and G>(t>0)
    TEBD_container ops;
    if (component.imag_tevo)
      ops = TEBD_container(p.h_int, b, e0, dt, sites);
    else
      ops = TEBD_container(p.h_int, b, e0, Complex_i * dt, sites);

    //loop over times
    int t = 0;
    SaveGFState(Tstate, 0);
    while (t < p.tevo.time_steps) {
      t++;
      // time evolve, take care of e^(+- i*E0*t) and normalize state if real tevo
      TEBD(Tstate, ops, args);
      if (component.imag_tevo) {
        Tstate *= std::exp(E0 * dt);
      } else {
        Tstate *= std::exp(Complex_i * E0 * dt);
        Tstate *= norm / Tstate.norm();
      }

      SaveGFState(Tstate, t);
    }
    std::cout << "Rank " << world.rank() << " finished." << std::endl;
  }

  void solver_core::SaveGFState(const ForkTPS &psi, int step) {
    std::string fname = folderBase;
    fname += component.FileNameBase() + std::to_string(step);

    save(fname, psi);
  }

  bool solver_core::CheckGFNorm(double norm) {
    if (norm < 1E-10) {
      PrintBorderLine(2);
      std::cout << "\n\n Warning norm of state to time evolve is very small tevo cannot be performed and GF will be zero, norm: "
            + std::to_string(norm)
                << "\n\n"
                << std::endl;

      notDone(componentIndex(component)) = 1;

      return false;
    }
    return true;
  }

  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------
  // ------------------------------- Post Process ----------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------

  void solver_core::post_process(const params_t &p) {
    // non-diagonal greensfunction is defined as:
    // G_ij = -i*theta(t)* < {A_i(t), B_j } > = -i*theta(t)*(  < A_i(t) B_j > + < B_j A_i(t) > )
    // hence we define the greater (G>) and lesser (G<) Greensfunctions as:
    // G>_ij(t) = < A_i(t) B_j > ,       G<_ij(t) = < B_j A_i(t) >
    // note order of indices in G<_ij
    //
    // For real-time evolution and using the usual half time evolution trick, we need to evalute:
    // G>_ij(t) = ( exp( i (H-E0) t/2) A_i^d |gs> )^d * ( exp(-i (H-E0) t/2) B_j |gs> )
    // G<_ij(t) = ( exp(-i (H-E0) t/2) B_j^d |gs> )^d * ( exp( i (H-E0) t/2) A_i |gs> )
    //
    // For imaginary-time evolution the half time evolution trick is not necessary because the Green's function is:
    // G>_ij(t) = ( exp(-(H-E0) tau/2) A_i^d |gs> )^d * ( exp(-(H-E0) tau/2) B_j |gs> )
    // G<_ij(t) = ( exp( (H-E0) tau/2) B_j^d |gs> )^d * ( exp( (H-E0) tau/2) A_i |gs> )
    // and we hence only need to time evolve B_j and A_i^d forwards- and B_j^d and A_i backwards in time (instead of both directions for each operator).

    ReportOnce("\n\n\n--------------------------------------------------------------------------\n");
    ReportOnce("-------------------------- Post Processing ...  --------------------------\n");
    ReportOnce("--------------------------------------------------------------------------\n\n");
    reset_gf(p);

    // notDone contains all components that should have been done but were not for some reason (0-norm for example)
    notDone = mpi::all_reduce(notDone, world);

    // loop over all green's function that need to be done and fill the TRIQS gf with the correct values
    for (auto &gf : mpi::chunk(GFsTodo)) {
      std::cout << "Rank " << world.rank() << " calculates " << gf << std::endl;
      fill_gf(p, gf);
    }
    world.barrier();

    // every node needs the same gfs
    for (auto &gf : GFsTodo) { gf.TRIQSgf = mpi::all_reduce(gf.TRIQSgf, world); }
    world.barrier();

    // now its time to place the entries of GFsTodo into the right containers
    collect_gfs(p);

    // finally calculate retarded GFs if necessary
    for (auto gftodo : p.GFs) {
      if (gftodo == "S")
        *G_ret = ((*G_gr) + (*G_le)) * (-Complex_i);
      else if (gftodo == "F")
        *F_ret = ((*F_gr) + (*F_le)) * (-Complex_i);
    }

    if (world.rank() == 0 && p.del_states) { system(("rm -rf " + folderBase).c_str()); }
  }

  void solver_core::collect_gfs(const params_t &p) {
    // Single Particle Green's function:
    // ----------------------------------------
    //
    // We define the retarded GF as G^R_ij(t) = -i \Theta(t) ( G>_ij(t) + G<_ij(t) )
    // For real-time evolution, the greater and lesser components are given bys:
    // G>_ij(t) = ( exp( i (H-E0) t/2) c_i^d |gs> )^d  *  ( exp(-i (H-E0) t/2) c_j^d |gs> )
    // G<_ij(t) = ( exp(-i (H-E0) t/2) c_j   |gs> )^d  *  ( exp( i (H-E0) t/2) c_i   |gs> ) // note order of indices ij!!!
    //
    // For imaginary-time evolution the half time evolution trick is not necessary:
    // G>_ij(tau) = ( exp(-(H-E0) tau/2) c_i^d |gs> )^d  *  ( exp(-(H-E0) tau/2) c_j^d |gs> )
    // G<_ij(tau) = ( exp(-(H-E0) tau/2) c_j   |gs> )^d  *  ( exp(-(H-E0) tau/2) c_i   |gs> ) // note order of indices ij!!!
    // i.e. we need to time evolve all c^d operators forward in time and all c-operators backwards.
    //
    //
    // **************************************************************************************************
    // **************************************************************************************************
    //
    //
    // Self Energy Green's function:
    // ----------------------------------------
    //
    // F is defined as F_i = [ Hint, c_i ]
    // Hence for real-time evolution we need to calculate:
    //                                                            From G> (t)
    //                                                                ||
    //                                                               \||/
    //                                                                \/
    // F>_ij(t) = ( exp( +i (H-E0) t/2 ) F_i^d |0> )^d   *   ( exp( -i (H-E0) t/2 ) c_j^d |0> )
    // F<_ij(t) = ( exp( -i (H-E0) t/2 ) c_j   |0> )^d   *   ( exp( +i (H-E0) t/2 ) F_i   |0> ) // note order of indices ij!!!
    //                      /\     text to avoid compiler warning
    //                     /||\    text to avoid compiler warning
    //                      ||
    //                  From G< (t)
    //
    // **************************************************************************************************
    //
    // For imaginary-time evolution we have to compute:
    //                                                         From G> (tau)
    //                                                                ||
    //                                                               \||/
    //                                                                \/
    // F>_ij(tau) = ( exp(-(H-E0) tau/2) F_i^d |gs> )^d * ( exp(-(H-E0) tau/2) c_j^d |gs> )
    // F<_ij(tau) = ( exp(-(H-E0) tau/2) c_j   |gs> )^d * ( exp(-(H-E0) tau/2) F_i   |gs> )
    //                      /\     text to avoid compiler warning
    //                     /||\    text to avoid compiler warning
    //                      ||
    //                 From G< (tau)
    // i.e. we need to time evolve F_i^d forwards- and F_i backwards in time.

    ReportOnce("Collecting GFs\n");
    // fill default gfs
    int customOffset = 0; // the first entries of the vector GFsTodo contains all default Gfs and then the custom ones.
                          // since they have to end up in different containers, we first iterate over the whole container
                          // until we arrive at the first custom GF and then iterate over all custom GFs
    for (const auto &gf : GFsTodo) {
      if (gf.type == custom) break;
      customOffset++;

      auto siteBra = gf.siteBra(), siteKet = gf.siteKet();

      // swap bra- and ket sites for lesser GF
      if (isLesser(gf.type)) std::swap(siteBra, siteKet);

      auto bI          = p.block_index(siteKet.first);
      auto FillGFEntry = [&](auto &G) { slice_target_to_scalar((*G)[bI], siteBra.second, siteKet.second) = gf.TRIQSgf; };

      //std::cout << to_string(gf.type) << " bI: " << bI << " i: "<< siteBra.second<< " j: " << siteKet.second <<"\n";

      if (gf.type == singlePart_greater)
        FillGFEntry(G_gr);
      else if (gf.type == singlePart_lesser)
        FillGFEntry(G_le);
      else if (gf.type == selfEnergy_greater)
        FillGFEntry(F_gr);
      else if (gf.type == selfEnergy_lesser)
        FillGFEntry(F_le);
      else if (gf.type == density) {
        auto indxBra = b.blockToFTPSIndx(siteBra), indxKet = b.blockToFTPSIndx(siteKet);
        slice_target_to_scalar((*N_t), indxBra - 1, indxKet - 1) = gf.TRIQSgf; // use FTPS indices here
      }
    }

    // fill custom gfs, length of vector should match already
    for (auto [indx, OpPair] : itertools::enumerate(p.customGF)) {
      // need to dagger A, because FTPS calculates ( e^{iHt/2} A^dag |0> ) ^ dagger    * ( e^{-iHt/2} B |0>  )
      auto A = dagger(OpPair.first);
      auto B = OpPair.second;

      //std::cout << A << "     " << B << "  " << indx <<std::endl<<std::endl;
      for (auto [mA, mB] : itertools::product(A, B)) {
        // need to conjugate the coefficient from A because we daggered it above
        auto coef = std::conj(std::complex<double>(mA.coef));
        coef *= std::complex<double>(mB.coef);

        if (mA.monomial.size() == 0 || mB.monomial.size() == 0) {
          // trivial case <0|A|0> or <0|B|0> or even only <0|0>
          // no real GF was computed, so it was not added to GFsTodo
          ForkTPS braState = gs, ketState = gs;

          ApplyOperator(mA.monomial, braState, b);
          ApplyOperator(mB.monomial, ketState, b);
          auto val = overlap(braState, ketState) * coef;
          for (auto t : customGF[indx].mesh()) customGF[indx][t] += val;
        } else {
          // non-trivial case
          customGF[indx] += coef * GFsTodo.gf_at(customOffset);
          customOffset++; //increase customOffset only in this branch of if/else not in the other
        }
      }
    }
  }

  void solver_core::post_process(const solve_params_t &solve_params) {

    params_t p{constr_params, solve_params};

    // the impurity model is uniquely defined by its interaction part, as well as the bath and the Hloc.
    // Also use the DMRG parameters as well as dt and approx of tevo. Note do not use Number of time steps
    // to be able to post_process with a smaller time step size
    auto hash = CreateHash(p.h_int, b, e0, p.params_partSector, p.params_GS, p.tevo.dt, p.tevo.approx);

    SetHash(hash);
    struct stat st {};
    folderBase = p.state_storage + "MPS" + hash + "/";
    if (stat(folderBase.c_str(), &st) != 0) { TRIQS_RUNTIME_ERROR << "No folder found containing time evolved states: " << folderBase.c_str(); }

    ReportOnce("Manuelly triggered post processing using hash ", hash, "\n");

    FillGFComponents(p);

    notDone.resize(make_shape(GFsTodo.getComponents().size()));
    notDone = 0;

    if (!p.path_to_gs) {
      loadGS(folderBase + "GS", gs, sites, E0);
    } else {
      loadGS(*p.path_to_gs, gs, sites, E0);
    }

    if (b.N() != gs.N()) {
      std::cout << "Bath number of sites: " << b.N() << " GS number of sites: " << gs.N() << "\n";
      TRIQS_RUNTIME_ERROR << "Bath and ground state loaded from disk have different sizes.";
    }

    post_process(p);
  }

  void solver_core::fill_gf(const params_t &p, FTPS_GF &gf) {

    if (notDone(componentIndex(gf.CBra)) || notDone(componentIndex(gf.CKet))) return;

    const std::string fnameKet = folderBase + gf.CKet.FileNameBase();
    const std::string fnameBra = folderBase + gf.CBra.FileNameBase();

    auto optimalTimes = [](int s) {
      // returns the smallest values x and y such that x+y = s
      int a{};
      if (s % 2 == 0)
        a = std::round(s / 2);
      else
        a = std::round((s - 1) / 2);
      return std::make_tuple(a, s - a);
    };

    //loop over times
    ForkTPS bra, ket;

    for (int tindx = 0; tindx <= 2 * p.tevo.time_steps; tindx++) {
      auto [timeBra, timeKet] = optimalTimes(tindx);

      // improves symmetry of off-diag GF (ij -> ji)
      // if( siteKet.second < siteBra.second ) std::swap(timeBra,timeKet);

      load(fnameBra + std::to_string(timeBra), bra, sites);
      load(fnameKet + std::to_string(timeKet), ket, sites);

      Complex val = overlap(bra, ket);
      //std::cout << "[ " << tindx * p.tevo.dt << ", " << val.real() << "+ 1j* " << val.imag() << " ]," << std::endl;

      gf.TRIQSgf[tindx] = val;
    }
  }

  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------
  // ---------------------------------- Other --------------------------------------
  // -------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------

  bool solver_core::MustBeDone(triqs_indx site, const std::vector<triqs_indx> &todo) const {
    // todo empty means user did not provide it -> do everything
    if (todo.size() == 0) return true;

    auto found = std::find(todo.begin(), todo.end(), site);
    return (found == todo.end()) ? false : true;
  }

  bool solver_core::MustBeDone(triqs_indx siteI, triqs_indx siteJ, GFtype type, const std::vector<triqs_indx> &todo) {
    bool doit = true;

    // first check if both are in calc_me
    doit = doit && MustBeDone(siteI, todo);
    doit = doit && MustBeDone(siteJ, todo);

    // single particle GF and self energy GF only have block diagonal entries
    if (isSingleParticle(type) || isSelfEnergy(type)) {
      if (siteI.first != siteJ.first) doit = false;
    }

    return doit;
  }

  AIM_ForkSites solver_core::GetSiteSet(bool conserve) {
    if (conserve == false)
      return AIM_ForkSites(b.NBathVec(), {"conserveN", false, "conserveSz", false});

    else if (b.isSpinOrbit() || b.hasOnlyOneBlock())
      return AIM_ForkSites(b.NBathVec(), {"conserveN", true, "conserveSz", false});

    else
      return AIM_ForkSites(b.NBathVec(), {"conserveN", true, "conserveSz", true});
  }

  void solver_core::SetHash(std::string hash) { HASH = hash; }

  int solver_core::componentIndex(GFComponent c) {
    int indx = 0;
    for (const auto &comp : GFsTodo.getComponents()) {
      if (comp.FileNameBase() == c.FileNameBase()) return indx;
      indx++;
    }

    // should always find something!
    TRIQS_RUNTIME_ERROR << " Error in componentIndex: didnt find the component!";
    return 0;
  }

  template <typename T, typename... Types> void solver_core::ReportOnce(const T var1, const Types... var2) {
    int oldIndent = 0;
    if (indent != 0) {
      std::cout << std::string(indent, ' ');
      oldIndent = indent;
      indent    = 0;
    }
    reportOnceNoIndent(var1);
    ReportOnce(var2...);

    // this works always
    indent = oldIndent;
  }

  template <typename T> void solver_core::reportOnceNoIndent(T s) {
    if (world.rank() == 0) { std::cout << s; }
  }

  template <typename T> void solver_core::ReportOnce(T s) {
    if (world.rank() == 0) { std::cout << std::string(indent, ' ') << s; }
  }

  ForkTPO solver_core::whichFTPO(const params_t &p) {
    // use different MPO depending on whether the bath has only a single block, is spin-orbit coupled, off-diagonal or diagonal
    if (b.hasOnlyOneBlock()) return ForkTPO(AIM_FullOffDiag(sites, b, e0, p.h_int, args));

    if (b.isSpinOrbit()) return ForkTPO(AIM_SpinOrbit(sites, b, e0, p.h_int, args));

    if (b.isOffDiag() || e0.isOffDiag()) return ForkTPO(AIM_OffDiag(sites, b, e0, p.h_int, args));

    // In all other cases
    return ForkTPO(AIM(sites, b, e0, p.h_int, args));
  }

  ForkTPO solver_core::whichFTPO(const params_t &p, bath const &bath_, hloc const &e0_, H_int const &h_int_) {
    // use different MPO depending on whether the bath has only a single block, is spin-orbit coupled, off-diagonal or diagonal
    if (bath_.hasOnlyOneBlock()) return ForkTPO(AIM_FullOffDiag(sites, bath_, e0_, h_int_, args));

    if (bath_.isSpinOrbit()) return ForkTPO(AIM_SpinOrbit(sites, bath_, e0_, h_int_, args));

    if (bath_.isOffDiag() || e0_.isOffDiag()) return ForkTPO(AIM_OffDiag(sites, bath_, e0_, h_int_, args));

    // In all other cases
    return ForkTPO(AIM(sites, bath_, e0_, h_int_, args));
  }

  std::vector<GFtype> solver_core::TypesToDo(const params_t &p) {
    std::vector<forktps::GFtype> types(0);
    for (auto gf : p.GFs) {
      if (gf == "S") {
        types.push_back(singlePart_greater);
        types.push_back(singlePart_lesser);
      }
      if (gf == "F" && !p.h_int == false) {
        //only add F if problem is interacting
        types.push_back(selfEnergy_greater);
        types.push_back(selfEnergy_lesser);
      }
      if (gf == "N") { types.push_back(density); }
    }

    return types;
  }

  std::vector<triqs_indx> solver_core::AllTriqsInds() {

    std::vector<triqs_indx> allInds(0);
    for (auto name : b.blockNames()) {
      for (auto i : itertools::range(b.blockSize(name))) { allInds.emplace_back(name, i); }
    }

    return allInds;
  }

  void h5_write(h5::group h5group, std::string subgroup_name, const solver_core &s) {
    auto grp = h5group.create_group(subgroup_name);
    h5_write_attribute(grp, "Format", solver_core::hdf5_format());
    h5_write_attribute(grp, "TRIQS_GIT_HASH", std::string(AS_STRING(TRIQS_GIT_HASH)));
    h5_write_attribute(grp, "FORKTPS_GIT_HASH", std::string(AS_STRING(FORKTPS_GIT_HASH)));
    // container set
    h5_write(grp, "", s.result_set());

    // construction and solve params
    h5_write(grp, "constr_params", s.constr_params);
    h5_write(grp, "last_solve_params", s.last_solve_params);

    // bath and hloc
    h5_write(grp, "bath", s.b);
    h5_write(grp, "hloc", s.e0);
    h5_write(grp, "Delta_cont_w", s.Delta_cont_w);
    h5_write(grp, "Delta_recons_w", s.Delta_recons_w);

    h5_write(grp, "GSVariance", s.GSVariance);
    h5_write(grp, "NotDone", s.notDone);

    // Info about the Ground state search
    h5_write(grp, "MeasurementResults", s.measurement_results);
    h5_write(grp, "NPartGS", s.NPartGS);
    h5_write(grp, "SectorEnergies", s.SectorEnergies);
    h5_write(grp, "SectorImpOccs", s.SectorImpOccs);

    // in future maybe ground state and Hamiltonian etc.
  }

  solver_core solver_core::h5_read_construct(h5::group h5group, std::string subgroup_name) {

    auto grp           = h5group.open_group(subgroup_name);
    auto constr_params = h5_read<constr_params_t>(grp, "constr_params");
    auto s             = solver_core{constr_params};

    h5_read(grp, "", s.result_set());

    solve_params_t solvp;
    h5_try_read(grp, "last_solve_params", solvp);
    h5_try_read(grp, "bath", s.b);
    h5_try_read(grp, "hloc", s.e0);

    h5_try_read(grp, "Delta_cont_w", s.Delta_cont_w);
    h5_try_read(grp, "Delta_recons_w", s.Delta_recons_w);
    h5_try_read(grp, "MeasurementResults", s.measurement_results);

    std::cout << "removed NotDone from reading\n";
    //h5_try_read(grp, "NotDone", s.notDone);
    h5_try_read(grp, "NPartGS", s.NPartGS);

    h5_try_read(grp, "SectorEnergies", s.SectorEnergies);
    h5_try_read(grp, "SectorImpOccs", s.SectorImpOccs);
    h5_try_read(grp, "GSVariance", s.GSVariance);

    s.last_solve_params = solvp;
    params_t p(constr_params, solvp);

    return s;
  }

} // namespace forktps
