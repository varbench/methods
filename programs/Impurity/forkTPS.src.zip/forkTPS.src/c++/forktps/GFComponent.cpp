

#include "forktps/GFComponent.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"
#include <algorithm>
#include <string>
#include <triqs/operators/many_body_operator.hpp>
#include <triqs/utility/exceptions.hpp>
#include <utility>
#include <variant>

//TODO implement N and make foldername use it

namespace forktps {

  using variantVec = std::vector<std::variant<long, std::string>>;
  using OpList     = std::vector<std::pair<std::string, int>>;

  /// Sorts the list of operators *l* into the fermionic order used by the FTPS solver.
  int sortOperatorList(OpList &l);

  /** Combines operators in the list *l* into a single non-trivial operator at each site.
  *   For example if *l* contains c_dag*c on one site, it replaces these two entries by 
  *   the particle number operator. For this to work, the list l needs to be sorted first,
  *   using the function sortOperatorList.  
  */
  void reduceOperatorList(OpList &l);

  /// Checks whether this operator is valid for given bath
  bool isValid(const monomial_t &op, const bath &b);

  // Checks wheter inds is a correct vector of variants with exactly two entries,
  // the first being a string and the second being an int.
  bool CheckInds(variantVec inds);

  void ApplyOperator(const monomial_t &op, ForkTPS &psi, const bath &b) {
    // first check if this is a valid component for bath b
    if (!isValid(op, b))
      TRIQS_RUNTIME_ERROR << " Invalid operator" << op << " provided. Operators need to be defined on the same block structure as the bath.";

    // do nothing when monomial is trivial
    if (op.size() == 0) return;

    // list of operatornames used in the SiteSet and impurity index
    OpList OpNames(0);

    // TRIQS monomials need reverse iteration to get the order in
    // which operators are applied
    for (auto o = op.rbegin(); o != op.rend(); ++o) {
      auto blockName  = std::get<std::string>(o->indices[0]);
      auto blockIndex = std::get<long>(o->indices[1]);

      int ArmIndex       = b.blockToFTPSIndx({blockName, blockIndex});
      std::string opname = o->dagger ? "CkD" : "Ck";

      OpNames.emplace_back(opname, ArmIndex);
    }

    // sort list of operators into FTPS fermionic order and reduce them eg Cdag*C -> N etc
    //std::cout << OpNames <<  " " << std::endl;
    int totalSign = sortOperatorList(OpNames);
    reduceOperatorList(OpNames);

    psi *= totalSign;
    auto sites = psi.sites();
    for (auto o : OpNames) {
      auto actualSite = psi.ImpSite(o.second);
      bool sign       = (o.first == "Ck" || o.first == "CkD") ? true : false;

      auto actualOp = sites.op(o.first, actualSite);
      psi.ApplySingleSiteOp(actualOp, actualSite, sign);
    }
  }

  GFComponent::GFComponent(triqs_indx s, BraKet b, GFtype type, bool im) : braket(b), imag_tevo(im) {
    if (braket == Bra) reverse(tdir);

    if (type == singlePart_lesser) {
      reverse(tdir);
      op = c(s.first, s.second).begin()->monomial;
    } else if (type == singlePart_greater) {
      op = c_dag(s.first, s.second).begin()->monomial;
    } else if (type == density) {
      op = n(s.first, s.second).begin()->monomial;
    } else if (type == selfEnergy_greater) {
      tdir = Back;
      Error("type self energy currently not supported");
    } else if (type == selfEnergy_lesser) {
      tdir = Back;
      Error("type self energy currently not supported");
    } else {
      std::cout << type << std::endl;
      Error("Constructor with triqs index and type does not work for this type");
    }

    // no matter what imaginary time evolution always needs positve tevo sign e^{-tau H}
    if (imag_tevo) tdir = Forward;
  }

  GFComponent::GFComponent(monomial_t op, BraKet b, TevoDir d, bool im) : op(std::move(op)), braket(b), tdir(d), imag_tevo(im) {

    //TODO this is a little ugly since user can call constructor with some tevoSign, but we just set it to 1 if imag_tevo is true
    if (imag_tevo) tdir = Forward;
  }

  [[nodiscard]] std::string GFComponent::FolderName() const {
    std::string folder = "";

    for (const auto &o : op) {
      if (o.dagger)
        folder += "Cdag_";
      else
        folder += "C_";

      for (auto val : o.indices) folder += std::to_string(val);
      folder += "_";
    }

    return folder + "/";
  };

  [[nodiscard]] std::string GFComponent::FileNameBase() const {
    std::string filename = FolderName();

    // Imaginary time evolution is special because it does two-sided time evolution is not necessary
    // Because of this, when used in a std::set, imaginary time evolutin is done only for
    // either the bra- or ket vector depending which one is inserted first, since
    // the set uses FileNameBase as comparator.
    if (imag_tevo)
      filename += "Imag";
    else
      filename += to_string(braket);
    filename += "_dir" + std::to_string(tdir) + "_";
    return filename;
  };

  bool GFComponent::operator<(const GFComponent &other) const {
    std::string key1 = FileNameBase();
    std::string key2 = other.FileNameBase();

    // for convenience sort first by length
    if (key1.length() < key2.length()) return true;
    if (key1.length() > key2.length()) return false;

    // same length
    return key1 < key2;
  }

  std::ostream &operator<<(std::ostream &os, const GFComponent &c) {
    os << "Component: ";
    if (c.imag_tevo)
      os << "Imag, " << c.op;
    else
      os << to_string(c.braket) << ",  " << c.op << ",  Time Evolution direction: " << c.tdir;

    return os;
  }

  int sortOperatorList(OpList &l) {
    // simple bubble sort. stl algorithms dont work since we want to keep track of the number of
    // swaps for the fermionic sign
    int sign  = 1;
    auto curr = l.begin();

    while (true) {
      auto next = curr + 1;
      if (next == l.end()) break;
      if (curr->second < next->second) {
        sign *= -1;
        std::swap(*curr, *next);
        curr = l.begin();
      } else
        curr++;
    }

    return sign;
  }

  void reduceOperatorList(OpList &l) {
    //list should be sorted, make sure it is. if it is unsorted but sign = 1
    // sorting does not matter, so we dont care about this case.
    int sign = sortOperatorList(l);
    if (sign != 1) TRIQS_RUNTIME_ERROR << "Unsorted list provided to reduceOperatorList()";

    auto curr = l.begin();
    while (true) {
      auto next = curr + 1;
      if (next == l.end()) break;

      auto s1 = curr->first;
      auto s2 = next->first; // s2 can only be Ck or CkD

      if (curr->second == next->second) {
        // same site, can be combined, not the order in which operators appear
        // in the list is the order in which they need to be applied. Hence
        // s1 = Ck and s2 = CkD becomes N not the other way around
        if (s1 == "Ck") {
          if (s2 == "CkD") {
            curr        = l.erase(curr); // curr points to next
            curr->first = "N";
          } else
            TRIQS_RUNTIME_ERROR << s1 + " " + s2 + " Operator combination is zero.";
        } else if (s1 == "CkD") {
          if (s2 == "Ck") {
            curr        = l.erase(curr); // curr points to next
            curr->first = "One-N";
          } else
            TRIQS_RUNTIME_ERROR << s1 + " " + s2 + " Operator combination is zero.";
        } else if (s1 == "N") {
          if (s2 == "Ck") {
            curr        = l.erase(curr); // curr points to next
            curr->first = "Ck";
          } else
            TRIQS_RUNTIME_ERROR << s1 + " " + s2 + " Operator combination is zero.";
        } else if (s1 == "One-N") {
          if (s2 == "CkD") {
            curr        = l.erase(curr); // curr points to next
            curr->first = "CkD";
          } else
            TRIQS_RUNTIME_ERROR << s1 + " " + s2 + " Operator combination is zero.";
        } else {
          TRIQS_RUNTIME_ERROR << s1 + " invalid operator name ... should never happen!";
        }
      } else {
        curr++;
      }
    }
  }

  bool CheckInds(variantVec inds) {
    if (inds.size() != 2) return false;

    if (!std::holds_alternative<string>(inds[0])) return false;
    if (!std::holds_alternative<long>(inds[1])) return false;

    return true;
  }

  bool isValid(const monomial_t &op, const bath &b) {
    for (auto fop : op) {
      auto inds = fop.indices;

      if (!CheckInds(inds)) return false;

      auto bN = std::get<std::string>(inds[0]);
      //check if name is valid
      bool nameValid = false;
      for (auto name : b.blockNames()) {
        if (name == bN) nameValid = true;
      }
      if (!nameValid) return false;

      //check index
      auto bI = std::get<long>(inds[1]);
      if (bI < 0 || bI > b.blockSize(bN)) return false;
    }

    return true;
  }

  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------
  // ---------------------------------- FTPS GF -----------------------------------------
  // ------------------------------------------------------------------------------------
  // ------------------------------------------------------------------------------------

  FTPS_GF::FTPS_GF(triqs_indx siteBra, triqs_indx siteKet, GFtype t, bool imag_tevo, gf_mesh<retime> tmesh)
     : CBra(siteBra, Bra, t, imag_tevo), CKet(siteKet, Ket, t, imag_tevo), type(t), TRIQSgf(tmesh) {}

  FTPS_GF::FTPS_GF(monomial_t b, monomial_t k, bool imag_tevo, gf_mesh<retime> tmesh)
     : CBra(b, BraKet::Bra, Back, imag_tevo), CKet(k, BraKet::Ket, Forward, imag_tevo), TRIQSgf(tmesh) {}

  [[nodiscard]] triqs_indx FTPS_GF::siteBra() const {
    if (type == custom) {
      std::cout << "\n\nWarning siteBra does not make sense for custom GF!!\n\n";
      return std::make_pair(std::string(), int());
    }

    auto inds = CBra.op.begin()->indices;
    if (!CheckInds(inds)) TRIQS_RUNTIME_ERROR << "siteBra something is wrong with inds: " << inds;

    return {std::get<std::string>(inds[0]), std::get<long>(inds[1])};
  }

  [[nodiscard]] triqs_indx FTPS_GF::siteKet() const {
    if (type == custom) {
      std::cout << "\n\nWarning siteKet does not make sense for custom GF!!\n\n";
      return std::make_pair(std::string(), int());
    }

    auto inds = CKet.op.begin()->indices;
    if (!CheckInds(inds)) TRIQS_RUNTIME_ERROR << "siteKet something is wrong with inds: " << inds;

    return {std::get<std::string>(inds[0]), std::get<long>(inds[1])};
  }

  std::ostream &operator<<(std::ostream &os, const FTPS_GF &gf) {
    os << "Green's function of type " << to_string(gf.type) << ":\n";
    os << "    " << gf.CBra << "\n";
    os << "    " << gf.CKet << "\n";

    return os;
  }

  void FTPS_GFList::clear() { gfs.clear(); };

} // end of namespace forktps
