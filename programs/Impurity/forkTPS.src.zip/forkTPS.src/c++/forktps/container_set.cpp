/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************************************/
#include "./container_set.hpp"

namespace forktps {
  // clang-format off
  void h5_write(h5::group h5group, std::string subgroup_name, container_set const &c) {
    auto grp = h5group.create_group(subgroup_name);

    h5_write(grp, "G_gr",  c.G_gr);
    h5_write(grp, "G_le",  c.G_le);
    h5_write(grp, "G_ret", c.G_ret);
    h5_write(grp, "G_w",   c.G_w);
    
    h5_write(grp, "F_gr",  c.F_gr);
    h5_write(grp, "F_le",  c.F_le);
    h5_write(grp, "F_ret", c.F_ret);
    h5_write(grp, "F_w",   c.F_w);
    
    h5_write(grp, "N_t",   c.N_t); 
    h5_write(grp, "N_w",   c.N_w); 

    h5_write(grp, "Sigma_w", c.Sigma_w);
  }

  void h5_read(h5::group h5group, std::string subgroup_name, container_set &c) {
    auto grp = h5group.open_group(subgroup_name);

    h5_read(grp, "G_gr",  c.G_gr);
    h5_read(grp, "G_le",  c.G_le);
    h5_read(grp, "G_ret", c.G_ret);
    h5_read(grp, "G_w",   c.G_w);

    h5_read(grp, "F_gr",  c.F_gr);
    h5_read(grp, "F_le",  c.F_le);
    h5_read(grp, "F_ret", c.F_ret);
    h5_read(grp, "F_w",   c.F_w);

    h5_read(grp, "N_t",   c.N_t);
    h5_read(grp, "N_w",   c.N_w);

    h5_read(grp, "Sigma_w", c.Sigma_w);
  }
  // clang-format on

} // namespace forktps
