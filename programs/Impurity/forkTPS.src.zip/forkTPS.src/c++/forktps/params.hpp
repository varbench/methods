/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http:///www.gnu.org/licenses/>.
 *
 ******************************************************************************/
#pragma once
#include "./types.hpp"
#include "fork/typenames.hpp"
#include "fork/Bath.hpp"

#include <optional>
#include <string>
#include <triqs/operators/many_body_operator.hpp>
#include <utility>
#include <vector>

namespace forktps {

  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------
  // ------------------------- Construction params ----------------------------------
  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------

  /// Parameters provided at solver construction.
  struct constr_params_t {
    /// Energy interval borders.
    double w_min, w_max;

    /// Number of grid points.
    int n_w;

    /// Block structure of the Green's function.
    gf_struct_t gf_struct;

    /// Returns the number of blocks of the Green's function.
    [[nodiscard]] int n_blocks() const { return gf_struct.size(); }

    /// Returns the names of blocks of the Green's function.
    [[nodiscard]] auto block_names() const {
      std::vector<std::string> v;
      for (auto const &bl : gf_struct) v.push_back(bl.first);
      return v;
    }

    /// Returns the index of the block with name *name*.
    [[nodiscard]] int block_index(std::string name) const {
      auto names = block_names();
      auto iter  = std::find(names.cbegin(), names.cend(), name);

      return std::distance(names.cbegin(), iter);
      ;
    }

    /** Write constr_params_t to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param cp:              constr_params_t to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, constr_params_t const &cp);

    /** Read construction parameters from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param cp:              construction parameters to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, constr_params_t &cp);
  };

  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------
  // -------------------------------- Solve params ----------------------------------
  // --------------------------------------------------------------------------------
  // --------------------------------------------------------------------------------

  /** Approximation parameters of the forktps tensor network. Sets the truncated weight as well as the maximally allowed bond dimension separately for the three different kinds of links: impurity-impurity, bath-bath and impurity-bath.
  */
  struct tn_approx {
    /// Truncated weight on impurity-impurity links (default $10^{-10}$)
    double tw_i = 1E-10;
    /// Truncated weight on bath-bath links (default $10^{-10}$)
    double tw_b = 1E-10;
    /// Truncated weight on impurity-bath links (default $10^{-10}$)
    double tw_ib = 1E-10;
    /// Maximal bond dimension on impurity-impurity links (default $200$)
    int maxm_i = 200;
    /// Maximal bond dimension on bath-bath links (default $500$)
    int maxm_b = 500;
    /// Maximal bond dimension on impurity-bath links (default $300$)
    int maxm_ib = 300;

    tn_approx() = default;

    /** Constructor setting all truncated weigths to *tw* and all maximal bond dimensions to *maxm*
     * @param tr:     double
     *                Value of all truncated weights
     * @param maxm:   int
     *                Value of all maximal bond dimensions
     */
    tn_approx(double tr, int maxm) : tw_i(tr), tw_b(tr), tw_ib(tr), maxm_i(maxm), maxm_b(maxm), maxm_ib(maxm) {}

    /** Constructor setting every parameter individually.
     * @param mi:     int
     *                Maximal bond dimension of impurity-impurity links.
     * @param mb:     int
     *                Maximal bond dimension of bath-bath links.
     * @param mib:    int
     *                Maximal bond dimension of impurity-bath links.
     * @param twi:    double
     *                Truncated weight of impurity-impurity links.
     * @param twb:    double
     *                Truncated weight of bath-bath links.
     * @param twib:   double
     *                Truncated weight of impurity-bath links.
     */
    tn_approx(int mi, int mb, int mib, double twi, double twb, double twib);

    /** Write approximation parameters to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param tw:             tn_approx to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, tn_approx const &tw);

    /** Read approximation parameters from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param tw:              construction parameters to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, tn_approx &tw);

    friend std::ostream &operator<<(std::ostream &os, const tn_approx &tw);

    static std::string hdf5_format() { return "FORKTPS_TNApprox"; }
  };

  /// Parameters for krylov methods. Used in lanczos during DMRG and in Krylov exponentiation TDVP (time evolution).
  struct krylov_params {
    /// Maximal number of Krylov vectors generated (default $100$)
    int nmax = 100;
    /// Norm of new Krylov vector must be bigger than this value, otherwise terminate the generation of new vectors (default $10^{-13}$)
    double norm_err = 1E-13;
    /// Convergence criterium (default $10^{-12}$)
    double conv = 1E-12;

    krylov_params() = default;

    /** Constructor setting every parameter individually.
    * @param nmax:      int
    *                   Maximum number of Krylov vectors generated..
    * @param norm_err:  double
    *                   Termination criterea based on norm of new Krylov vector.
    * @param conv:      double
    *                   Convergence criteria.
    */
    krylov_params(int nmax, double norm_err, double conv);

    /** Write Krylov parameters to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param kp:             krylov_params to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, krylov_params const &kp);

    /** Read Krylov parameters from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param kp:             krylov_parameters to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, krylov_params &kp);

    friend std::ostream &operator<<(std::ostream &os, const krylov_params &kp);

    static std::string hdf5_format() { return "FORKTPS_KrylovParams"; }
  };

  struct DMRG_prep_params {
    int napp_h = 3;

    bool imag_tevo = false;
    //std::optional<double> dtau = std::nullopt;
    //std::optional<int>  time_steps = std::nullopt;
    //std::optional<std::string> method = std::nullopt;

    double dtau        = 0.;
    int time_steps     = 0;
    std::string method = "TDVP";

    DMRG_prep_params() = default;

    DMRG_prep_params(int napp_h);

    DMRG_prep_params(int napp_h, bool imag_tevo, double dtau, int time_steps, std::string method);

    /** Write Krylov parameters to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param p:              DMRG_prep_params to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, DMRG_prep_params const &p);

    /** Read Krylov parameters from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param p:             DMRG_prep_params to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, DMRG_prep_params &p);

    static std::string hdf5_format() { return "FORKTPS_DMRGPrepParams"; }
  };

  /** Interaction Hamiltonian. Currently only Kanamori Hamiltonians with and without spin-flip and pair-hopping terms are implemented.
  * @param U        :   double
  *
  * @param J        :   double
  *
  * @param Up       :   double
  *
  * @param dd_only  :   bool
  */
  struct H_int {
    /// Coulomb repulsion between spin-up and spin-down electrons on the same orbital
    double U{};
    /// Hund's coupling
    double J{};
    /// Coulomb repulsion between spin-up and spin-down electrons on different orbitals (usually Up = U-2J)
    double Up{};
    /// If true, perform the calculations with density-density terms only, i.e., neglect spin-flip and pair hopping terms (default true)
    bool dd_only = true;

    /// Default constructor
    H_int() = default;

    /// Creates an *H_int* objects with U=u only, all other parameters are set to zero
    H_int(double u) : U(u), dd_only(false){};

    /// Creates an *H_int* objects with U=u, J=j, Up = up and dd_only = dd
    H_int(double u, double j, double up, bool dd) : U(u), J(j), Up(up), dd_only(dd){};

    /// Returns *false* if model is non-interacting (every interaction parameter < 1E-15), *true* otherwise
    bool operator!() const;

    /// Pass To a stream
    friend std::ostream &operator<<(std::ostream &out, const H_int &h_int);

    /** Write the interaction Hamiltonian to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param h_int:          H_int to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, H_int const &h_int);
    /** Read the interaction Hamiltonian from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param h_int:          H_int to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, H_int &h_int);
    static std::string hdf5_format() { return "FORKTPS_Hint"; }
  };

  /** Set of parameters used for DMRG calculations.
  * @param approx   :   forktps::tn_approx
  *                     Tensor network approximation parameters.
  * @param krylov   :   forktps::krylov_params
  *                     Krylov approximation parameters for the local groundstate search.
  * @param sweeps   :   int
  *                     Number of DMRG sweeps.
  * @param napp_h   :   int
  *                     Number of times the hamiltonian gets applied during DMRG.
  * @param DMRG_method: std::string
  *                     DMRG_method used, either "SSImp" or "TwoSite"
  */
  struct DMRG_params {
    tn_approx approx;

    krylov_params krylov;

    DMRG_prep_params prep;

    int sweeps;
    int napp_h;
    std::string DMRG_method;

    /// Default constructor
    DMRG_params();

    /** Constructor setting every parameter except preparation. *m* are bond dimensions, tw are truncated weights, nmax, err and conv are the 
    *   krylov parameters, sw is the number of sweeps and nh the number of applications of H. Kept for backwards compatibility.
    */
    DMRG_params(int mi, int mb, int mib,                  // maxm
                double twi, double twb, double twib,      //tws
                int nmax, double err, double conv,        // krylov
                int sw, int nh, std::string dmrg_method); // other

    /** Constructor setting every parameter including preparation. *m* are bond dimensions, tw are truncated weights, nmax, err and conv are the 
    *   krylov parameters, sw is the number of sweeps and nh the number of applications of H.
    */
    DMRG_params(int mi, int mb, int mib,                                                            // maxm
                double twi, double twb, double twib,                                                //tws
                int nmax, double err, double conv,                                                  // krylov
                int sw, int nh, std::string dmrg_method,                                            // other
                int prep_nh, bool imag_tevo, double dtau, int time_steps, std::string prep_method); // prep

    /** Write the interaction Hamiltonian to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param dmrg_p:         DMRG_params to be written
    */
    friend void h5_write(h5::group h5group, std::string subgroup_name, DMRG_params const &dmrg_p);
    /** Read the interaction Hamiltonian from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param dmrg_p:         DMRG_params to be read
    */
    friend void h5_read(h5::group h5group, std::string subgroup_name, DMRG_params &dmrg_p);

    friend std::ostream &operator<<(std::ostream &os, const DMRG_params &dmrg_p);

    static std::string hdf5_format() { return "FORKTPS_DMRG_params"; }
  };

  /** Set of parameters used for the time evolution.
  * @param dt          : double
  *                      Size of time step.
  * @param time_steps  : forktps::tn_approx
  *                      Half the number of time steps, i.e., perform *timeSteps* steps for the bra as well as the ket vector
  * @param approx      : forktps::tn_approx
  *                      Tensor network approximation parameters.
  * @param krylov      : forktps::krylov_params
  *                      Krylov approximation parameters for the local matrix exponentiation (only for TDVP).
  * @param imag_tevo   : bool
  *                      If true, perform imaginary time evolution.
  * @param method      : std::string
  *                      Time evolution method, either "TDVP" (default) for single-site TDVP, "TDVP_2" for two-site TDVP or "TEBD" for TEBD-like time evolution using gates. Note "TEBD" only works for diagonal hybridizations..
  */
  struct Tevo_params {
    ///
    double dt;

    /// Half number of total time steps i.e.: perform *timeSteps* steps for the bra as well as the ket vector
    int time_steps;

    /// Order of TDVP integration.
    int TDVPOrder = 2;

    /// TN approximation
    tn_approx approx = {};
    /// Krylov parameters for TDVP only
    krylov_params krylov = {};

    /// If true, perform imaginary time evolution instead of real time evolution.
    bool imag_tevo = false;

    /// Method of time evolution, either "TDVP" (default) for single-site TDVP, "TDVP_2" for two-site TDVP or "TEBD" for TEBD-like time evolution using gates. Note "TEBD" only works for diagonal hybridizations.
    std::string method = "TDVP";

    Tevo_params();

    /// Constructor for all possible parameters.
    Tevo_params(double dt, int steps, int order, int mi, int mb, int mib, double twi, double twb, double twib, int nmax, double err, double conv,
                bool imagT, std::string method);

    /** Write Tevo_params to hdf5
    * @param h5group:        hdf5 group to which the object should be written
    *
    * @param subgroup_name:  Name of the object
    *
    * @param tevo_p:          Tevo_params to be written
    */
    friend void h5_write(h5::group h5group, std::string subgroup_name, Tevo_params const &tevo_p);
    /** Read the interaction Hamiltonian from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param tevo_p:          Tevo_params to be read
    */
    friend void h5_read(h5::group h5group, std::string subgroup_name, Tevo_params &tevo_p);

    friend std::ostream &operator<<(std::ostream &os, const Tevo_params &tevo_p);

    static std::string hdf5_format() { return "FORKTPS_Tevo_params"; }
  };

  /// The parameters for the solve function
  struct solve_params_t {

    // ----------- System Specific -----------

    /// Interaction Hamiltonian
    H_int h_int;

    // ----------- Solver Specific -----------

    /// DMRG parameters used during the search for the ground state particle number sector.
    DMRG_params params_partSector = {};

    /// DMRG parameters used to find the true groundstate once the sector is found.
    DMRG_params params_GS = {};

    /// Particle number sector in which GS should be calculated, if none, auto detect sector
    Imat NPart = {};

    /// Use ground state from this file is provided.
    std::optional<std::string> path_to_gs = {};

    // ---------------------------------- tevo -------------------------------------
    Tevo_params tevo = {};

    /** Vector containing all GFs to calculate: 
    *   "S" for single particle
    *   "F" for self-energy trick
    *   "N" for density-density
    */
    std::vector<std::string> GFs = std::vector<std::string>{"S"};

    /// whether to calculate Green's function or not
    bool calc_gf = true;

    /// A list of pairs of TRIQS many-body operators A_i and B_i for which the
    /// Green's function <A_i(t) B_i> should to be calculated.
    std::vector<std::pair<many_body_operator, many_body_operator>> customGF = {};

    /// Lorentzian broadening during fourier transform
    double eta = 0.1;

    /// ----- other -----

    /// Vector containing all the Green's functions that need to be calculated. If empty, everything is calculated.
    std::vector<triqs_indx> calc_me = {};

    /// Vector TRIQS many_body_operators for specifying the obeservables measured in the Groundstate.
    std::vector<many_body_operator> measurements = {};

    /// Path where to stor tevo states, default is execution directory
    std::string state_storage = "";

    ///whether to measure the single particle density
    bool measure_single_particle_density = true;

    // new stuff might change

    /// If true (default), deletes the states stored to disk after post processing.
    bool del_states = true;

    /// Verbosity
    //int verbosity = mpi::communicator().rank() == 0 ? 3 : 0;

    /** Write solve parameters to hdf5
     * @param h5group:        hdf5 group to which the object should be written
     *
     * @param subgroup_name:  Name of the object
     *
     * @param sp:             solve_params_t to be written
     */
    friend void h5_write(h5::group h5group, std::string subgroup_name, solve_params_t const &sp);
    /** Read solve parameters from hdf5
     * @param h5group:        hdf5 group from which the object should be read
     *
     * @param subgroup_name:  Name of the object
     *
     * @param sp:             solve_params_t to be read
     */
    friend void h5_read(h5::group h5group, std::string subgroup_name, solve_params_t &sp);

    /// hdf5 scheme
    static std::string hdf5_format() { return "FORKTPS_sovle_params"; }

    friend std::ostream &operator<<(std::ostream &os, const solve_params_t &sp);
  };

  /// A struct combining both constr_params_t and solve_params_t
  struct params_t : constr_params_t, solve_params_t {

    params_t(constr_params_t const &constr_params_, solve_params_t const &solve_params_)
       : constr_params_t(constr_params_), solve_params_t(solve_params_) {}
  };

  /// Parameters for basis extension. Used to perform a basis expansion for forktps
  struct basisExpansion_params {
    // whether to use basis expansion for time evolution
    bool useBE = true;
    /// cut off threshold
    double cutoffBE = 1E-6;
    /// number of krylov vectors uesed to expand the state basis
    int nKrylovBE = 2;
    /// print verbose
    bool verbose = false;
    /// whether to use variantial fit algorithm in applying an TPO
    bool fitApplyTPO = false;
    /// make a basis expansion every *expand_every" steps
    int expand_every = 1;
    // provide a list of times to expand the basis
    std::vector<double> BETimeList;
    // expand the basis every *expand_everyList" steps
    std::vector<int> expand_everyList;
    /// method to generate reference states
    std::string BEMethod = "ApplyH";
    // bond dimension of the expanded basis
    int bondBE = 30;
    // minimum bond dimension to stop basis expansion
    int minBond = 0;
    // whether to expand the basis at critical times
    bool expand_critical = false;
    // critical times to expand the basis
    std::vector<double> critical_time;

    //specify at when to make basis expansion
    std::vector<double> timeToExpand;

    basisExpansion_params() = default;
    basisExpansion_params(double cutoff, int nKrylov, int expand_every) : cutoffBE(cutoff), nKrylovBE(nKrylov), expand_every(expand_every){};
    basisExpansion_params(double cutoff, int nKrylov, int expand_every, std::string BEMethod)
       : cutoffBE(cutoff), nKrylovBE(nKrylov), expand_every(expand_every), BEMethod(BEMethod){};
    basisExpansion_params(bool useBE, double cutoff, int nKrylov, int expand_every, std::string BEMethod)
       : useBE(useBE), cutoffBE(cutoff), nKrylovBE(nKrylov), expand_every(expand_every), BEMethod(BEMethod){};
    basisExpansion_params(bool useBE, double cutoff, int nKrylov, std::vector<double> BETimeList, std::vector<int> expand_everyList,
                          std::string BEMethod)
       : useBE(useBE), cutoffBE(cutoff), nKrylovBE(nKrylov), BETimeList(BETimeList), expand_everyList(expand_everyList), BEMethod(BEMethod){};

    basisExpansion_params(bool useBE, double cutoff, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod)
       : useBE(useBE), cutoffBE(cutoff), nKrylovBE(nKrylov), timeToExpand(timeToExpand), BEMethod(BEMethod){};

    basisExpansion_params(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod)
       : useBE(useBE), cutoffBE(cutoff), bondBE(bondBE), nKrylovBE(nKrylov), timeToExpand(timeToExpand), BEMethod(BEMethod){};

    basisExpansion_params(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond)
       : useBE(useBE), cutoffBE(cutoff), bondBE(bondBE), nKrylovBE(nKrylov), timeToExpand(timeToExpand), BEMethod(BEMethod), minBond(minBond){};
    basisExpansion_params(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond,
                          bool expand_critical)
       : useBE(useBE),
         cutoffBE(cutoff),
         bondBE(bondBE),
         nKrylovBE(nKrylov),
         timeToExpand(timeToExpand),
         BEMethod(BEMethod),
         minBond(minBond),
         expand_critical(expand_critical){};

    basisExpansion_params(bool useBE, double cutoff, int bondBE, int nKrylov, std::vector<double> timeToExpand, std::string BEMethod, int minBond,
                          bool expand_critical, std::vector<double> critical_time)
       : useBE(useBE),
         cutoffBE(cutoff),
         bondBE(bondBE),
         nKrylovBE(nKrylov),
         timeToExpand(timeToExpand),
         BEMethod(BEMethod),
         minBond(minBond),
         expand_critical(expand_critical),
         critical_time(critical_time){};

    // basisExpansion_params(double CutoffBE_, int NKrylovBE_);
  };
  /// sampling parameters
  struct sampling_params {
    /// number of thermalization
    int n_thermal = 5;
    /// sampling number
    int n_sampling = 10;
    /// make a measurement every *MeasureEvery* sampling
    int measure_every = 1;
    /// purification energy threshold
    double purification_threshold = 0.0;
    int purificationSites         = 0;
    // the method to determine the purified bath sites
    std::string puriMethod = "Energy";
    // minimal two site steps
    int minTwoSiteStep    = 30;
    double minTwoSiteTime = 0.0;
    double BETime         = 0.0;
    int minTwoSiteStepGf  = 0;

    // minimal two site time for generating measured metts
    double minTwoSiteTimeGf = 0.0;
    // minimal Two site time for generating not measured metts
    double TSTime = 0.0;

    //whether to save the intermedia infos
    bool saveIntermedia = false;
    //whether to perform an unitary time evolution during the sampling precess
    bool uniEvo = false;
    // unitary time evolution steps
    int uniEvoSteps = 0;
    // unitary time evolution time dt
    double uniEvodt = 0.;
    /// the exponential grid points
    int exp_grid_steps = 0;
    // fixed bath sites
    int fixedSites = 0;
    //min number of Gfs function to be calculated on each rank
    int minNumGfEachRank = 100000;
    //number of shifted imaginary time steps in calculating Green's function
    int shiftedSteps = 0;
    //fluctuating bath sites in SampleFermi
    int n_fluctuating_sites = 1;

    sampling_params() = default;
    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites,
                    int minNumGfEachRank)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, int minTwoSiteStep,
                    int minTwoSiteStepGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites,
                    int minNumGfEachRank, int shiftedSteps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteStep(minTwoSiteStep),
         minTwoSiteStepGf(minTwoSiteStepGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double minTwoSiteTime,
                    double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites,
                    int minNumGfEachRank, int shiftedSteps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteTime(minTwoSiteTime),
         minTwoSiteTimeGf(minTwoSiteTimeGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double BETime,
                    double TSTime, double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps,
                    int fixedSites, int minNumGfEachRank, int shiftedSteps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         BETime(BETime),
         TSTime(TSTime),
         minTwoSiteTimeGf(minTwoSiteTimeGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, double purification_threshold, std::string puriMethod, double minTwoSiteTimeGf,
                    bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites, int minNumGfEachRank,
                    int shiftedSteps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purification_threshold(purification_threshold),
         puriMethod(puriMethod),
         minTwoSiteTimeGf(minTwoSiteTimeGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, int purificationSites, double TSTime, std::string puriMethod,
                    double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites,
                    int minNumGfEachRank, int shiftedSteps)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purificationSites(purificationSites),
         TSTime(TSTime),
         puriMethod(puriMethod),
         minTwoSiteTimeGf(minTwoSiteTimeGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps){};

    sampling_params(int n_thermal, int n_sampling, int measure_every, int purificationSites, double TSTime, std::string puriMethod,
                    double minTwoSiteTimeGf, bool saveIntermedia, bool uniEvo, int uniEvoSteps, double uniEvodt, int exp_grid_steps, int fixedSites,
                    int minNumGfEachRank, int shiftedSteps, int n_fluctuating_sites)
       : n_thermal(n_thermal),
         n_sampling(n_sampling),
         measure_every(measure_every),
         purificationSites(purificationSites),
         TSTime(TSTime),
         puriMethod(puriMethod),
         minTwoSiteTimeGf(minTwoSiteTimeGf),
         saveIntermedia(saveIntermedia),
         uniEvo(uniEvo),
         uniEvoSteps(uniEvoSteps),
         uniEvodt(uniEvodt),
         exp_grid_steps(exp_grid_steps),
         fixedSites(fixedSites),
         minNumGfEachRank(minNumGfEachRank),
         shiftedSteps(shiftedSteps),
         n_fluctuating_sites(n_fluctuating_sites){};
  };

  //global krylov time evolution parameters
  struct globalKrylov_params {
    // perform global krylov evolution or not
    bool gKrylov = false;
    //size of the krylov space
    int nKrylov = 8;
    //size of the orthogonal states space
    int orthoSize = 2;
    //minimum weight threshold
    double threshold = 1E-4;

    globalKrylov_params() = default;
    globalKrylov_params(bool gKrylov, int nKrylov, int orthoSize, double threshold)
       : gKrylov(gKrylov), nKrylov(nKrylov), orthoSize(orthoSize), threshold(threshold){};
  };

  /// Parameters for finite temperature solver construction
  struct finiteT_constr_params_t {
    /// inverse temperature
    double beta;
    /// number of Matzsubara frequency
    int n_iw;
    /// Green's function structure
    gf_struct_t gf_struct;
    ///sampling files folder
    std::string samplingFolder = "";
  };

  //quick dmrg parameters
  struct quickDMRG_params {
    //perform a quick dmrg or not
    bool quickDMRG = false;
    //quickDMRG sweeps
    int nDMRGSweep = 5;
    //quickDMRG warm up iteration
    int nWarmUp = 2;
    //quickDMRG bond dimension
    int mDMRG = 50;
    //quickDMRG truncation weight
    double twDMRG = 1E-9;
    //quickDMRG method
    std::string DMRGMethod = "SSImp";

    quickDMRG_params() = default;
    quickDMRG_params(bool quickDMRG) : quickDMRG(quickDMRG){};
    quickDMRG_params(bool quickDMRG, int nDMRGSweep) : quickDMRG(quickDMRG), nDMRGSweep(nDMRGSweep){};
    quickDMRG_params(bool quickDMRG, int nDMRGSweep, int mDMRG) : quickDMRG(quickDMRG), nDMRGSweep(nDMRGSweep), mDMRG(mDMRG){};
    quickDMRG_params(bool quickDMRG, int nDMRGSweep, int nWarmUp, int mDMRG, double twDMRG, std::string DMRGMethod)
       : quickDMRG(quickDMRG), nDMRGSweep(nDMRGSweep), nWarmUp(nWarmUp), mDMRG(mDMRG), twDMRG(twDMRG), DMRGMethod(DMRGMethod){};
  };

  /// Parameters for finite temperature solver calculation
  struct finiteT_solve_params_t {

    //the impurities are purified or not
    bool impPurified = true;
    // print out verbose
    int verbose = 0;
    // type of time grid
    std::string timeGrid = "Even";

    H_int h_int;
    //imaginary time evolution parameters
    Tevo_params tevo = {};
    // basis expansion parameters
    basisExpansion_params basisExpansion;
    // sampling parameters
    sampling_params sampling;
    // quick dmrg parameters
    quickDMRG_params quickDMRG;
    // global krylov time evolution parameters
    globalKrylov_params gKrylov;
    // calculate green's function components
    std::vector<std::vector<triqs_indx>> calc_me;
    // measured static operators
    std::vector<std::vector<std::pair<std::string, triqs_indx>>> measured_static_op;
    // the DLR tau grid
    std::vector<double> tau_grid;
  };

  /// a combined parameters set for finite temperature calculation
  struct finiteT_params_t : finiteT_constr_params_t, finiteT_solve_params_t {
    finiteT_params_t(finiteT_constr_params_t const &finiteT_constr_params_, finiteT_solve_params_t const &finiteT_solve_params_)
       : finiteT_constr_params_t(finiteT_constr_params_), finiteT_solve_params_t(finiteT_solve_params_){};
  };

} // namespace forktps
