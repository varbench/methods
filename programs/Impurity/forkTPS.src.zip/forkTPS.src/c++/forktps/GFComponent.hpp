
#ifndef __FORK_GFCOMPONENT__
#define __FORK_GFCOMPONENT__

#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/typenames.hpp"
#include "forktps/fork/Bath.hpp"
#include <triqs/gfs/gf/targets.hpp>

namespace forktps {
  /** Applies the operator *op* before onto state *psi*. The bath  
    *  provides information about the geometry and is used to check wheter 
    *  *op* is a valid operator.
    */
  void ApplyOperator(const monomial_t &op, ForkTPS &psi, const bath &b);

  /** A GFComponent represents information about one particular time evolution 
    * that needs to be preformed to calculate a Green's function. It consists of an operator 
    * that is applied, whether it is used as bra- or ket-vector. Additionally it 
    * has information on the time-evolution direction and wheter time evolution 
    * is imaginary or real.
    */
  struct GFComponent {
    GFComponent() = default;
    GFComponent(monomial_t op, BraKet b, TevoDir d = Forward, bool im = false);
    GFComponent(triqs_indx s, BraKet b, GFtype type, bool im = false);

    /// The operator to apply.
    monomial_t op;

    /// The component describes either a Bra- or a Ket-vector.
    BraKet braket = Ket;

    /// Forward or backward time evolution. Note forwards means an overall "-" sign in the exponenent: e^{-iHt}.
    TevoDir tdir = Forward;

    /// If true, perform imaginary time evolution. In that case, tdir will be forward independent of what else is provided.
    bool imag_tevo{};

    /** Returns the folder name of this component. Used to store time 
        *   evolved states to disk.
        */
    [[nodiscard]] std::string FolderName() const;

    /** Returns the base filename of this component used to store time 
        *   evolved states to disk. The filename consists of the folder (see FolderName())
        *   and either "Bra_" or "Ket_" (*imag_tevo*=false) or "Imag_" (*imag_tevo*=true).
        */
    [[nodiscard]] std::string FileNameBase() const;

    // Comparison operator for std::set. std::set does not need == operator but determines uniqueness by !(a<b) && !(b<a)
    bool operator<(const GFComponent &other) const;

    friend std::ostream &operator<<(std::ostream &os, const GFComponent &c);
  };

  /** A Green's function consists of a component for the bra- and the ket
    *   vector and an additional GFtype as well as the actual TRIQS Green's function.
    */
  struct FTPS_GF {
    // Default Constructor
    FTPS_GF() = default;

    /// Constructor used for the default type GFs like single-particle or density-density
    FTPS_GF(triqs_indx siteBra, triqs_indx siteKet, GFtype t, bool imag_tevo, gf_mesh<retime> tmesh = {});

    /// Constructor using monomials *b* and *k* for the bra- and ket-vector.
    FTPS_GF(monomial_t b, monomial_t k, bool imag_tevo, gf_mesh<retime> tmesh = {});

    ///Bra Component
    GFComponent CBra;
    ///Ket Component
    GFComponent CKet;

    ///Type of Green function
    GFtype type = custom;

    /// The actual TRIQS Green function
    gf<retime, scalar_valued> TRIQSgf;

    /** Returns the triqs_index of the Bra-component. 
        *   Only makes sense if the Green function is not a custom-type Green function.
        *   Fails otherwise.
        */
    [[nodiscard]] triqs_indx siteBra() const;

    /** Returns the triqs_index of the Bra-component. 
        *   Only makes sense if the Green function is not a custom-type Green function.
        *   Fails otherwise.
        */
    [[nodiscard]] triqs_indx siteKet() const;

    friend std::ostream &operator<<(std::ostream &os, const FTPS_GF &gf);
  };

  /** A list of FTPS Green's functions and corresponding components. These 
    *   are put in a separate object since several FTPS_GFs might need the 
    *   same components. 
    */
  struct FTPS_GFList {

    /// Emulate STL container syntax
    template <class... Args> void emplace_back(Args &&...args) { gfs.emplace_back(args...); }

    auto &gf_at(int indx) { return gfs.at(indx).TRIQSgf; }

    [[nodiscard]] int size() const { return gfs.size(); }

    void clear();

    /// Iteration over Green's functions.
    auto begin() noexcept { return gfs.begin(); }
    [[nodiscard]] auto begin() const noexcept { return gfs.cbegin(); }
    [[nodiscard]] auto cbegin() const noexcept { return gfs.cbegin(); }
    auto end() noexcept { return gfs.end(); }
    [[nodiscard]] auto end() const noexcept { return gfs.cend(); }
    [[nodiscard]] auto cend() const noexcept { return gfs.cend(); }

    /** Vector of unique components needed for all the monomial Green's functions in *gfs* (hence std::set).
        *   This is different than all the bra- and ket- components of *gfs* because several Green's functions might need to calculate the same component.
        */
    std::set<GFComponent> getComponents() {
      std::set<GFComponent> components;
      for (const auto &gf : gfs) {
        // std::set takes care of not adding components that already exist again
        components.insert(gf.CBra);
        components.insert(gf.CKet);
      }

      return components;
    };

    private:
    // Made members private to make it more difficult to change entries, because both containers have to be consistent.
    // Iteration over gfs (also non-const) is still allowed and also the .at() function
    // returns a non-const reference because we need write access to the FTPS_GF.TRIQSgf member.

    /// Vector of FTPS_GFs storing all monomial Green's functions that need to be calculated.
    std::vector<FTPS_GF> gfs;
  };

} // end of namespace forktps

#endif