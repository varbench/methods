/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http:///www.gnu.org/licenses/>.
 *
 ******************************************************************************/

///TODO factor 2 in timesteps

#pragma once
#include "./container_set.hpp"
#include "./params.hpp"
#include "./types.hpp"

#include "./post_process.hpp"
//#include "fork/ForkCalculus.hpp"
//#include "fork/HelperFunctions.hpp"
#include "fork/ForkTPS.hpp"
#include "fork/ForkTPO.hpp"
#include "fork/SiteSets/AIM_ForkSites.hpp"
#include "fork/Bath.hpp"
#include "GFComponent.hpp"

#include <forktps/fork/typenames.hpp>
#include <nda/nda.hpp>
#include <triqs/gfs/gf/targets.hpp>
#include <triqs/mesh/refreq.hpp>
#include <utility>
#include <vector>
#include <sys/stat.h>
#include <set>

namespace forktps {

  /// Removes all folders used to store time evolved states
  //void Cleanup();

  //// The Solver class
  class solver_core : public container_set {

    public:
    /**
     * Construct a FORKTPS solver
     *
     * @param construct_parameters Set of parameters specific to the FORKTPS solver
     */
    CPP2PY_ARG_AS_DICT
    solver_core(constr_params_t const &constr_params_);

    /// Delete assignement operator because of const members
    solver_core(solver_core const &p)            = default;
    solver_core(solver_core &&p)                 = default;
    solver_core &operator=(solver_core const &p) = delete;
    solver_core &operator=(solver_core &&p)      = default;

    private:
    /// Mpi Communicator
    mpi::communicator world;

    /// Return reference to container_set
    container_set &result_set() { return static_cast<container_set &>(*this); }
    container_set const &result_set() const { return static_cast<container_set const &>(*this); }

    /// Function to perform the post-processing steps
    void post_process(params_t const &p);

    public:
    /// Struct containing the parameters relevant for the solver construction
    constr_params_t constr_params;

    /// Struct containing the parameters relevant for the solve process
    std::optional<solve_params_t> last_solve_params;

    /// Ground state energy after DMRG
    double E0;
    /// hybridization, impurity single-particle energy, impurity interaction
    double Ehyb, Ee0, Ehint;

    double GSVariance;

    /// Bath object containing the bath parameters
    bath b;
    /// Non-interacting impurity Hamiltonian
    hloc e0;

    /// Bath spectral function from which the bath is calculated
    g_w_t Delta_cont_w;

    /// Bath spectral function reconstructed from the bath parameters
    g_w_t Delta_recons_w;

    /// Vector containing the results of the measurements defined in solve_params_t's measurements member
    std::vector<double> measurement_results;
    std::vector<std::complex<double>> singleParticleDensity;

    /// Ground state sector of particle number.
    std::vector<int> NPartGS;

    /// For each sector of particle number DMRG searches, stores the energy.
    std::vector<double> SectorEnergies;

    /// For each sector of particle number DMRG searches, stores the occupation.
    std::vector<std::vector<double>> SectorImpOccs;

    /// After solve call stores a vector of all custom Green's functions, defined in sovle_params.
    array<gf<retime, scalar_valued>, 1> customGF;

    private:
    /// All Green's functions that need to be calculated
    //std::vector<FTPS_GF> GFsTodo;
    FTPS_GFList GFsTodo;

    /// Stores all components that need to be calculated. Use std::set so that entries are unique.
    //std::set<GFComponent> componentsTodo;

    /// The ground state
    ForkTPS gs;
    /// Time evolved state
    ForkTPS Tstate;
    /// ITensor site set defining the indices and local operators at each site
    AIM_ForkSites sites;
    /// Itensor Args object used to communicate calculation parameters
    Args args;
    /// The hamiltonian in forkTPO-form
    ForkTPO H;

    /// Folder name unique to each calculation; store the time evolved states in this folder.
    std::string folderBase;

    /** Contains for each GFtype a boolean variable showing if this particular 
    * GF could not be calculated (zero norm in most cases). The usage of this
    * is a bit awkward, since the information about which components have not
    * been calculated needs to be available for all threads
    */
    array<int, 1> notDone{};

    /// stores the component of the Green's function that is currently calculated
    GFComponent component{};

    /// Number of spaces for output formating.
    int indent;

    private:
    /// Fills the vectors GFsTodo and componentsTodo,
    void FillGFComponents(const params_t &p);

    /// Called immediately after solve_call, checks if the solver is in a valid state.
    void checkSolver(const solve_params_t &sp);

    /** Initializes the solver members.
    * 
    * @param p:   params_t,
    *             Construction and solve parameters in one object
    */
    void init(const params_t &p);

    /** Sets all Green's functions to zero, but reshapes them to the appropriate shape given by *p*. 
    * @param p:   params_t,
    *             Construction and solve parameters in one object
    */
    void reset_gf(const params_t &p);

    /** Measures the user-define ground-state observables.
    * @param p:   params_t,
    *             Construction and solve parameters in one object.
    */
    void MeasureObservables(const params_t &p);
    void MeasureSingleParticleDensity(const params_t &p);

    /** Returns a SiteSet without quantum number conservation if *conserve==false* or
    * with QN conservation (default). The exact conservation depends on whether 
    * spin-orbit coupling is active or not.
    */
    AIM_ForkSites GetSiteSet(bool conserve = true);

    /** Helper function deciding which MPO to take
    * @param p:   params_t,
    *             Construction and solve parameters in one object.
    */
    ForkTPO whichFTPO(const params_t &p);
    ForkTPO whichFTPO(const params_t &p, bath const &bath_, hloc const &e0_, H_int const &h_int_);
    // map the iarm to triqs index
    triqs_indx ArmToTriqsIndx(int const &iarm);

    /** First finds the sector of particle number and then performs a DMRG calculation in this sector. 
    * @param p:   params_t,
    *             Construction and solve parameters in one object.
    */
    void find_gs(const params_t &p);

    /** Finds the sector of particle number using one of several methods defined by *p*.
    * @param p:   params_t,
    *             Construction and solve parameters in one object.
    */
    void find_gs_sector(const params_t &p);

    /**
    * Prepares the state *psi* for a DMRG calculation by applying the MPO a couple of
    * times and/or performing imaginary time evolution. Especially the former is very 
    * important, since otherwise DMRG often fails completely.
    * @param psi:           ForkTPS,
    *                       State to be prepared
    * @param p:             params_t,
    *                       Construction and solve parameters in one object.
    */
    CPP2PY_IGNORE
    void prepare_DMRG(ForkTPS &psi, const params_t &p);

    /** Finds the sector of particle number by performing a DMRG calculation without quantum number conservation
    * @param p:   params_t,
    *             Construction and solve parameters in one object
    */
    void SectorSearch_woQN(const params_t &p);

    /** Finds the sector of particle number out of a set of sectors provided by the user in *p.Npart*.
    * @param p:   params_t,
    *             Construction and solve parameters in one object
    */
    void SectorSearch_NProvided(const params_t &p);

    /** Initializes and returns a ForkTPS in a product state with particle number *NPart[a-1]* on  
    *   arm *a*.
    */
    CPP2PY_IGNORE
    ForkTPS InitProductState(std::vector<int> NPart);

    /** Applies the correct operator to the ground state to prepare for the time 
    *   evolution.
    */
    void ApplyGFOperator(const params_t &p);

    /** performs two time evolutions of $e^{ \pm iHt } \hat{O} | \psi_0 \rangle$ in positive and negative time.
    * The operator used changes depending on *c*.
    * @param p:      params_t,
    *                parameters of this calculation
    * @param c:      GFComponent
    *                Defines which component of what Green's function to calculate
    */
    void calc_gf(const params_t &p, GFComponent c);

    /// Time evolution for Green's functions using TDVP.
    void TDVPTevo(const params_t &p);

    /// Time evolution for Green's functions using TDVP.
    void TEBDTevo(const params_t &p);

    /// Returns false and prints a warning if norm of state to time evolve for the Green's function is too small;
    bool CheckGFNorm(double norm);

    /** Saving time evolved states
    * @param psi:    ForkTPS
    *                State to be saved.
    * @param step:   int
    *                Number of time steps already performed on the bra- and ket vector
    */
    CPP2PY_IGNORE
    void SaveGFState(const ForkTPS &psi, int step);

    /** Collects time evolved states to calculate Green's function gf.
    * @param p:      params_t,
    *                parameters of this calculation
    * @param gf      FTPS_GF
    *                Information about the GF.
    */
    void fill_gf(const params_t &p, FTPS_GF &gf);

    /// Takes the calculated Green's functions from the array GFsTodo and puts them in the correct output Green's functions.
    void collect_gfs(const params_t &p);

    /** Checks if the Greens function for *site* needs to be calculated i.e.: whether it is in the vector *todo*.
    * @param site:   triqs_indx aka std::pair<std::string,int>,
    *                specifying the site at which the operator acts
    * @param todo:   std::vector<triqs_indx>
    *                contains all sites for which the GF needs to be calculated
    */
    bool MustBeDone(triqs_indx site, const std::vector<triqs_indx> &todo) const;

    /** Returns true if the Green's function of type *type* between siteI and 
    *   siteJ needs to be calculated. Meaning that both must be in todo and 
    *   block off-diagonal components only exist for certain types.
    * @param siteI:  triqs_indx aka std::pair<std::string,int>,
    *                Index i of Green's function matrix.
    * @param siteI:  triqs_indx aka std::pair<std::string,int>,
    *                Index j of Green's function matrix.
    * @param type:   GFtype,
    *                Type of Green's function.
    * @param todo:   std::vector<triqs_indx>
    *                Contains all sites for which the GF needs to be calculated
    */
    bool MustBeDone(triqs_indx siteI, triqs_indx siteJ, GFtype type, const std::vector<triqs_indx> &todo);

    /** Sets the global variable HASH to the value of hash */
    void SetHash(std::string hash);

    /// Returns the index of component *c* in the set componentsTodo.
    int componentIndex(GFComponent c);

    /** Only mpi-rank 0 prints the object *s* to standard output (<< operator must be defined).
    */
    template <typename T, typename... Types> void ReportOnce(const T var1, const Types... var2);

    template <typename T> void reportOnceNoIndent(T s);

    template <typename T> void ReportOnce(T s);

    /// Returns all GFtypes that need to be calculated.
    std::vector<GFtype> TypesToDo(const params_t &p);

    /// Returns all possible triqs-indices
    std::vector<triqs_indx> AllTriqsInds();

    public:
    /**
     * Solve method that performs FORKTPS calculation
     *
     * @param solve_params_t Set of parameters specific to the FORKTPS run
     */
    CPP2PY_ARG_AS_DICT
    void solve(const solve_params_t &solve_params);

    /** Solve with user defined groundstate *GS*. */
    CPP2PY_IGNORE
    void solve(const solve_params_t &solve_params, const ForkTPS &GS);

    /// Returns the ground state.
    CPP2PY_IGNORE
    ForkTPS get_gs();

    /// Allow the user to retrigger post-processing with the last set of parameters
    CPP2PY_ARG_AS_DICT
    void post_process(const solve_params_t &solve_params);

    /// hdf5_format for storing solver to hdf5
    static std::string hdf5_format() { return "FORKTPS_SolverCore"; }

    /// Writes a solver object to a hdf5 file
    friend void h5_write(h5::group h5group, std::string subgroup_name, solver_core const &s);

    /// Constructs a solver object from an hdf5 file
    CPP2PY_IGNORE
    static solver_core h5_read_construct(h5::group h5group, std::string subgroup_name);
  };

} // namespace forktps
