#include "setargs.hpp"
#include "forktps/params.hpp"

using namespace forktps;
using namespace itensor;

namespace forktps {

  void SetArgs(Args &args, const DMRG_params &p) {
    SetArgs(args, p.approx);
    SetArgs(args, p.krylov);

    args.add("maxsweeps", p.sweeps);
    args.add("NAppH", p.napp_h);
    args.add("DMRGMethod", p.DMRG_method);

    // preparation
    args.add("NAppHPrep", p.prep.napp_h);
    if (p.prep.imag_tevo) {
      args.add("DoImagTevo", p.prep.imag_tevo);
      args.add("TevoMethod", p.prep.method);
      args.add("dtau", p.prep.dtau);
      args.add("NTimeSteps", p.prep.time_steps);
    }
  }

  void SetArgs(Args &args, const Tevo_params &p) {
    SetArgs(args, p.approx);
    SetArgs(args, p.krylov);
    args.add("TevoMethod", p.method);
    args.add("TDVPOrder", p.TDVPOrder);
  }

  void SetArgs(Args &args, const tn_approx &p) {
    args.add(Names::MAXMI, p.maxm_i);
    args.add(Names::MAXMIB, p.maxm_ib);
    args.add(Names::MAXMB, p.maxm_b);

    args.add(Names::TWI, p.tw_i);
    args.add(Names::TWIB, p.tw_ib);
    args.add(Names::TWB, p.tw_b);
  }

  void SetArgs(Args &args, const krylov_params &p) {
    args.add("ErrGoal", p.conv);
    args.add("MaxIter", p.nmax);
    args.add("NormCutoff", p.norm_err);
  }

  void SetArgs(Args &args, const basisExpansion_params &p) {
    args.add("cutoffBE", p.cutoffBE);
    args.add("nKrylovBE", p.nKrylovBE);
    args.add("fitApplyTPO", p.fitApplyTPO);
    args.add("expand_every", p.expand_every);
    args.add("verbose", p.verbose);
    args.add("BEMethod", p.BEMethod);
    args.add("bondBE", p.bondBE);
  }

  void SetArgs(Args &args, const sampling_params &p) {
    args.add("n_thermal", p.n_thermal);
    args.add("n_sampling", p.n_sampling);
    args.add("measure_every", p.measure_every);
    args.add("purification_threshold", p.purification_threshold);
  }
} // namespace forktps
