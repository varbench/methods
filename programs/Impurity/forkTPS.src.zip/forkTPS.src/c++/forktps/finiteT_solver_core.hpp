#pragma once
#include <array>
#include <chrono>
#include <forktps/fork/ForkTPO.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>

#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/FTPO/AIM_OffDiag.hpp>
#include <forktps/fork/FTPO/AIM_SpinOrbit.hpp>
#include <forktps/fork/FTPO/AIM_SingleBlock.hpp>
#include <forktps/fork/ForkCalculus.hpp>

#include <forktps/fork/FTPO/ExpectationValues.hpp>
#include <forktps/fork/Tevo/AIM_ForkGates.hpp>
#include <forktps/fork/TevoMethods.hpp>

#include <forktps/fork/Fork.hpp>
#include <forktps/fork/ForkLocalOp.hpp>
#include <forktps/fork/Bath.hpp>

#include <forktps/fork/ForkTPS.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/fork/typenames.hpp>
#include <forktps/setargs.hpp>
#include <forktps/params.hpp>
#include <forktps/types.hpp>
#include <h5/h5.hpp>

#include <algorithm>
#include <cmath>
#include <fstream>
#include <omp.h>

#include <iomanip>
#include <itensor/itensor.h>
#include <itensor/mps/mps.h>
#include <itensor/util/input.h>
#include <itensor/global.h>
#include <itensor/itensor_impl.h>
#include <itensor/types.h>
#include <itensor/util/iterate.h>
#include <itensor/util/readwrite.h>

#include <random>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include <complex>
#include <sys/stat.h>
#include <ctime>

#include <forktps/fork/SiteSets/ThermalForkSites.hpp>

namespace forktps {
  /**
   * @brief struct for storing the time evolution state
   */
  struct ImagTimeState {
    ForkTPS state;     //the state
    double normFactor; //the norm factor
  };
  /**
   * @brief struct for storing the basis information
   */
  struct BasisInfos {
    std::vector<ForkTPS> states_metts; //the unorthonormalized basis states
    ITensor R;                         // the rotation matrix
    ITensor C;                         // the coefficient matrix
    ITensor Heff;                      // the effective hamiltonian
    ITensor Heff_R;                    // the effective hamiltonian after rotation
    int basisSize;                     // the size of the basis
    int stateSize;                     // the size of the state
    int multiplyFactor = 1;            // the multiply factor
  };

  /**
   * @brief enum class for unitary time evolution type
   */
  enum class UniEvoType {
    None,       // no unitary time evolution
    Odd,        // for odd step, U^\dagger e^{-beta H /2} |cps>
    Even,       // for even step, e^{-beta H /2}  U |cps>
    Hamiltonian // for all step, U^\dagger e^{-beta H} U |cps>
  };

  /**
   * @brief struct for storing the metts data
   */
  struct MettsData {
    //the initial product state
    ForkTPS productState;
    //the metts at beta/2
    ForkTPS state;
    //stored states and norm factors along the imaginary time evolution
    std::vector<ImagTimeState> statesPath;
    //the evolution tau list
    std::vector<double> evoTauList;
    //energy of this metts
    double energy;
    //occupation of this metts
    std::vector<double> occs;
    //calculated green's function of this metts
    //imaginary time Green's function containor
    g_tau_t g_tau;
    //imaginary frequency Green's function containor
    g_iw_t g_iw;
    //real time Green's function containor
    g_t_t g_t;
    //containor for the raw g(tau)
    std::vector<std::vector<std::complex<double>>> GfRaw;
    //quantum number of the system
    int quantumNumber;
    //label of this metts
    std::string label;
    //label hash
    std::size_t labelHash;
    //accumulated log norm of this metts
    double bigNorm;
    //repeated times
    int repeated = 0;
    //bond dimesnion growth of the metts and Green's function
    std::vector<int> bondGrowth, bondGrowthGt;
    //int unitary type
    int uniType = 0;
  };
  /**
     * @brief METTS impurity solver using a hybrid purification and sampling approach for finite temperature calculations
     * 
     */
  class finiteT_solver_core {
    public:
    CPP2PY_ARG_AS_DICT
    /// Constructor with construction parameters
    finiteT_solver_core(finiteT_constr_params_t const &constr_params_);

    finiteT_solver_core(finiteT_solver_core const &p)            = default;
    finiteT_solver_core(finiteT_solver_core &&p)                 = default;
    finiteT_solver_core &operator=(finiteT_solver_core const &p) = delete;
    finiteT_solver_core &operator=(finiteT_solver_core &&p)      = default;

    public:
    // mpi communicator
    mpi::communicator world;
    // bath on-site and hopping amplitudes
    bath b;
    // bath on-site and hopping amplitudes for unitary gates
    bath bUni;
    // local impurity one-particle part
    hloc e0;
    //impurity interaction
    //H_int hint;
    // collection of calculation args
    Args args;
    // print indent
    int indent = 1;
    // construction parameters
    finiteT_constr_params_t constr_params;
    //solve parameters
    finiteT_solve_params_t solve_params;

    // a constant energy shift
    double E0Shift = 0.0;
    // purified bath sites
    std::vector<int> doubledBath;
    //E infity
    double EInfty = 0.0;

    // imaginary time green's function containor for calculated one by sampling and weighting
    g_tau_t G_tau, G_tau_by_norm;
    // imaginary frequency green's function containor for calculated one by sampling
    g_iw_t G_iw;
    // real time green's function containor for calculated one by sampling
    g_t_t G_t;
    // containor for imaginary time green's function of the metts calculated on each rank and repeated times
    std::vector<std::pair<int, g_tau_t>> g_tau_list_info;
    // variance of imaginary time green's function
    g_tau_t G_tau_var;
    //time grid
    std::vector<double> TimeGrid;
    // average bond dimension growth of the metts
    std::vector<double> BondGrowthAve;
    // containor of the repeated times of each metts
    std::vector<int> DistributionCount;
    // containor of the log norm of each metts
    std::vector<double> DistributionLogNorm;
    // containor of the measured static quantities
    std::vector<std::complex<double>> MeasuredStatic;

    //metts sampling information
    // Energies of the sampled states
    std::vector<double> Energy;
    // occupation of the sampled states
    Dmat Occs;
    // total quantum number of the sampled states
    std::vector<int> QuantumNumber;
    // labels of the sampled states
    std::vector<std::string> Label;
    // label hash of the sampled states
    std::vector<std::size_t> LabelHash;
    // norm of the sampled states
    std::vector<double> BigNorm;
    // total number of metts on each rank
    int totalCount = 0;
    // track of transition probability |<i|phi>|^2
    std::vector<double> transitionProb;

    private:
    //whether this step is a measure step
    //the time grid for Green's function, real time, linear and exponential growth calculations in [0, beta/2]
    std::vector<double> tList, tListExcited, tListLin, tListExp, tListDLR;
    //file name of the intermedia information storage
    std::string fileNameIntermedia;
    // a vector of a state and a norm used to keep track of the norm of a state during the imaginary time evolution
    std::vector<ImagTimeState> phitau;
    //a pool of states which have been visited during the monte carlo sampling, accessed by the label
    std::map<std::string, MettsData> statesPool;
    //basis related quantities
    BasisInfos basisInfos;
    ThermalForkSites sites, sitesUni;
    // the state of this metts, which is imaginary time evolved from 0 to beta/2
    ForkTPS state;
    // the Hamiltonian
    ForkTPO H;
    // the Hamiltonian for unitary gates
    ForkTPO Huni;
    // the Hamiltonian for basis expansion and the one only has off-diagonal terms
    ForkTPO HBasis, HOffDia;

    // ITensor object to store the old site tensor
    ITensor Aold;
    // the containor of the effective Hamiltonian for generating the metts
    ForkLocalOp HeffState;
    // the containor of the effective Hamiltonian for generating the greater green's function
    ForkLocalOp HeffGr;
    ForkLocalOp HeffGrb;
    // the containor of the effective Hamiltonian for generating the lesser green's function
    ForkLocalOp HeffLe;
    ForkLocalOp HeffLeb;
    double prob;
    int currSite;
    ITensor siteProjector;
    // Measurment output file
    std::string outfileName;
    //counts number
    //std::vector<int> RepeatedTimes;

    public:
    // map the iarm to triqs index
    triqs_indx ArmToTriqsIndx(int const &iarm);
    // map the triqs index to iarm
    int TriqsIndxToArm(triqs_indx const &indx_triqs);
    // find the block name index of a given triqs index
    int BlockNameIndx(triqs_indx const &indx, finiteT_params_t const &params_);
    //determine which FTPO will be used p.h_int and E0Shift are needed
    ForkTPO whichFTPO(const finiteT_params_t &p, ThermalForkSites const &sites_);
    ForkTPO whichFTPO(const finiteT_params_t &p, ThermalForkSites const &sites_, bath const &bath_, hloc const &e0_, H_int const &h_int_);

    void initializeState();

    //a quick dmrg which helps to varify the Hamiltonian from bath fitting and estimates and provide the energy shift
    double QuickDMRG(finiteT_params_t params_);

    // Sets the state on the impurities to (| 01 > + |1 0>)/sqrt(2)
    void ResetPurifiedTensors(ForkTPS &psi_, ThermalForkSites const &sites_, std::vector<int> const &doubledBath_);

    //Projects a single site
    void ProjectSite(InitState &init);

    // Decides on an outcome for a single site
    void DecideOutcome(InitState &init);

    // Project a state into a new product state
    void Project(finiteT_params_t const &params_);
    // Project a state into a new product state with fixSites_ number of bath sites in the conduction and valence bands fixed
    void ProjectRestric(finiteT_params_t const &params_, int const &fixSites_);

    // Monte Carlo thermalization
    void Thermalize(finiteT_params_t const &params_);
    // Monte Carlo thermalization with unitary gates
    void ThermalizeUnitary(finiteT_params_t const &params_);

    // Monte Carlo sampling
    void Sampling(finiteT_params_t const &params_);
    // Monte Carlo sampling with unitary gates
    void SamplingUnitary(finiteT_params_t const &params_);
    // Monte Carlo sampling with unitary gates and distributed calculations of Green's function based on finding unique states of the sampled metts over MPI ranks
    void SamplingUnitaryMPI(finiteT_params_t const &params_);
    // Monte Carlo sampling with unitary gates and distributed calculations of Green's function COMPONENT based on finding unique states of the sampled metts over MPI ranks
    void SamplingUnitaryMPISplit(finiteT_params_t const &params_);

    // Monte Carlo sampling for basis construction
    void SamplingBasis(finiteT_params_t const &params_);
    void SamplingReal(finiteT_params_t const &params_);
    void SamplingRealUnitary(finiteT_params_t const &params_);

    void GenerateBasisInfos(finiteT_params_t const &params_, ThermalForkSites const &sites_);
    ITensor ExponentialMatrix(double tau_, ITensor const &h_);
    g_tau_t CalcGFBasis(int const &metts_i, finiteT_params_t const &params_);
    g_tau_t CalcGFBasis(finiteT_params_t const &params_);

    std::vector<int> intersection(std::vector<int> &v1_, std::vector<int> &v2_);
    std::vector<std::vector<int>> nonZeroIndices(ITensor const &T_);

    // Generates a single METTS
    void GenerateMetts(std::string const &label, bool const &reg, finiteT_params_t const &params_, UniEvoType const &uniEvoType = UniEvoType::None);
    void GenerateMettsBasisExpansion(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                                     UniEvoType const &uniEvoType = UniEvoType::None);

    void GenerateMettsBasisExpansionSingleSite(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                                               UniEvoType const &uniEvoType = UniEvoType::None);
    void GenerateMettsHybrid(std::string const &label, bool const &reg, finiteT_params_t const &params_,
                             UniEvoType const &uniEvoType = UniEvoType::None);

    /**
     * @brief Generate a Metts with basis expansion
     * 
     * @param label label of the metts
     * @param reg whether to regenerate the metts or not
     * @param params_ finiteT_params_t
     * @param uniEvoType unitary evolution type
     * @param measurement_ whether this metts is used for measurement, if yes, the metts will be calculated on a linear mesh, otherwise on a logarithmic mesh
     */
    void GenerateMettsBE(std::string const &label, bool const &reg, finiteT_params_t const &params_, UniEvoType const &uniEvoType = UniEvoType::None,
                         bool measurement_ = true);

    // Perform some measurements
    void Measure(std::string const &label, bool const &reg);

    // generate the imaginary time mesh
    gf_mesh<imtime> GenerateImMesh(finiteT_params_t const &params_);

    // calculate the imaginary time Green's function
    g_tau_t CalcGF(std::string const &label, finiteT_params_t const &params_);

    /**
     * @brief Calculate the Green's function with a imaginary time shift
     * 
     * @param label the label of the metts
     * @param params_ finiteT_params_t
     * @param shiftedSteps_ number of imaginary time steps to shift
     * @return g_tau_t 
     */
    g_tau_t CalcGFShifted(std::string const &label, finiteT_params_t const &params_, int const &shiftedSteps_);

    /**
     * @brief Calculate the Green's function COMPONENT with a imaginary time shift
     * 
     * @param label label of the metts
     * @param params_ finiteT_params_t
     * @param shiftedSteps_ number of imaginary time steps to shift
     * @param calc_me_component_ Green's function COMPONENT to calculate
     * @return g_tau_t Green's function with the given COMPONENT calculated
     */
    g_tau_t CalcGFShiftedSplit(std::string const &label, finiteT_params_t const &params_, int const &shiftedSteps_,
                               std::vector<triqs_indx> const &calc_me_component_);

    /**
     * @brief Calculate the Green's function COMPONENT on a given DLR Grid
     * 
     * @param label , label of the metts
     * @param params_ , finiteT_params_t
     * @param calc_me_component_ , Green's function COMPONENT to calculate
     * @return g_tau_t 
     */
    g_tau_t CalcGFDLR(std::string const &label, finiteT_params_t const &params_, std::vector<triqs_indx> const &calc_me_component_);

    // Calculate the Green's function on a whole imaginary time grid
    g_tau_t CalcGFWholeImagTimeGrid(std::string const &label, finiteT_params_t const &params_);

    //return the state and norm at time t from a list of states and times
    std::pair<double, ForkTPS> pickState(double const &dt_, double const &time_, std::vector<ImagTimeState> phiList_);
    // Calculate the Green's function on a shifted imaginary time grid
    g_tau_t CalcGFShiftedCombined(std::string const &label, finiteT_params_t const &params_, double const &shiftedTime_);

    //calculate the Green's function on an exponential grid
    g_tau_t CalcGFExponential(std::string const &label, finiteT_params_t const &params_);
    // Calculate the Green's function on a real time grid
    g_t_t CalcGFReal(std::string const &label, finiteT_params_t const &params_);

    // Write to a HDFArchive
    void WriteSamplingInfo(std::string const &filename_, std::string const &label_);
    // Collect sampling infomation
    void CollectSamplingInfo();

    /**
     * @brief construct a product state from a filling vector
     * 
     * @param filling_ the filling vector
     * @param sites_ site object
     * @param doubledBath_ purify bath sites
     * @return ForkTPS the product state
     */
    ForkTPS productStateFromFilling(std::vector<double> const &filling_, ThermalForkSites const &sites_, std::vector<int> const &doubledBath_);

    // return the filling vector of a product state
    std::vector<double> fillingFromProductState(ForkTPS &psi_);

    // generate a label for a product state based on the density distribution in the bath
    std::string generateLabel(ForkTPS &psi, finiteT_params_t const &params_);
    std::string generateLabel(ForkTPS &psi, finiteT_params_t const &params_, UniEvoType const &uniType_);

    // check if a product state is already registered in the database
    bool isRegistered(ForkTPS &psi, finiteT_params_t const &params_);
    bool isRegistered(ForkTPS &psi, finiteT_params_t const &params_, UniEvoType const &uniType_);

    //decide purified bath sites by evolving a product state to 1.
    std::vector<int> DeterminePurificeBathSites(finiteT_params_t params_);

    /**
     * @brief Determine the bath sites to be purified for each orbital
     * @note the purified bath sites are determined by specifed method:
     * "Energy" which starts the purification from the lowest ABSOLUTE on-site energy, 
     * "EnergyReverse" which starts the pufication from the largest ABSOLUTE on-site energy
     * "EnergyReverseConduction" which starts the pufication from the lowest on-site energy
     * "EnergyReverseValence" which starts the pufication from the largest on-site energy
     * "SampleFermi" which leaves n_fluctuating_sites bath sites closest to the Fermi level to be fluctuating (unpurified)
     * @param params_ finiteT parameters
     * @return std::vector<int> sites to be purified for each orbital
     */
    std::vector<int> DeterminePurificeBathSitesEachOrb(finiteT_params_t params_);

    // print out the impurity density matrix
    void PrintBigDensity();

    /**
     * @brief spare the exponential time grid with restricted largest time step
     * 
     * @param timeGrid_ time grid to be spared
     * @return std::vector<double> spared time grid
     */
    std::vector<double> spareExpTimeGrid(std::vector<double> const &timeGrid_);

    /**
     * @brief Construct the 1 - dt * H operator for basis expansion
     * 
     * @param params_ finiteT parameters
     * @param b_ bath object containing the bath parameters
     * @param e0_ local single-particle Hamiltonian on the impurity
     * @param dt_ time step
     * @return ForkTPO the 1 - dt * H operator
     */
    ForkTPO taylorFTPO(finiteT_params_t const &params_, bath const &b_, hloc const &e0_, double const &dt_);

    /**
     * @brief Add two ForkTPS without truncation
     * 
     * @param psi_ state to be added
     * @param phi_ state to be added
     * @return ForkTPS added state
     */
    ForkTPS DirectSum(ForkTPS const &psi_, ForkTPS const &phi_);

    /**
     * @brief Orthogonalize a state with respect to a list of states by using the arithmetic method
     * 
     * @param psi_ state to be orthogonalized
     * @param states_ states to be orthogonalized with
     * @return ForkTPS orthogonalized state
     */
    ForkTPS ArithmeticOrth(ForkTPS &psi_, std::vector<ForkTPS> &states_);

    /**
     * @brief Global Krylov time evolution method
     * 
     * @tparam T datatype of the time step, complex<double> or double representing imaginary time or real time evolution
     * @param heff the effective hamiltonian
     * @param krylovSpace the generated krylov vectors
     * @param H_ Hamiltonian
     * @param t time step
     * @param params_ finiteT parameters
     * @return std::pair<bool, ForkTPS> represent whether the time evolution is converged and the evolved state
     */
    template <class T>
    std::pair<bool, ForkTPS> GlobalKrylovTimeEvo(ITensor &heff, std::vector<ForkTPS> &krylovSpace, ForkTPO const &H_, T t, finiteT_params_t params_);

    /**
     * @brief Generate N different product state configurations from a given state
     * 
     * @param psi_ the input state, the product states are generated from this state by projection <i|psi_>
     * @param params_ finiteT parameters
     * @param purifiedSites_ containor of the purified bath sites
     * @param N_ number of product states to be generated
     * @return std::tuple<std::vector<std::size_t>, std::vector<int>, std::vector<std::vector<int>>> represent the lable hash, times appeared, and filling
     */
    std::tuple<std::vector<std::size_t>, std::vector<int>, std::vector<std::vector<int>>>
    GenerateUniqueConfs(ForkTPS const &psi_, finiteT_params_t const &params_, std::vector<int> purifiedSites_, int const &N_);

    /**
     * @brief Construct a new Product State object fron a given filling
     * 
     * @param filling_ the input filling
     * @param purifiedSites containor of the purified bath sites_ 
     * @param sites_ site obejct
     * @param params_ finiteT parameters
     * @return ForkTPS the constructed product state
     */
    ForkTPS ConstructProductState(std::vector<int> const &filling_, std::vector<int> const &purifiedSites_, ThermalForkSites const &sites_,
                                  finiteT_params_t const &params_);

    // bool PaticleNumberFluctuation(ForkTPS &state_);
    // ForkTPS labelToState(std::string const &label, AIM_ForkSites const &sites);

    private:
    // check whether a file exists
    inline bool fileExists(const std::string &name) {
      struct stat buffer;
      return (stat(name.c_str(), &buffer) == 0);
    };

    // create a directory
    inline int CreateDir(const std::string &name) {
      if (fileExists(name)) {
        //std::cout << "Directory " << name << " already exists!" << std::endl;
        return 1;
      } else {
        if (mkdir(name.c_str(), 0777) == -1) {
          std::cerr << "\nError :  " << strerror(errno) << std::endl;
          return -1;
        } else {
          std::cout << "\nDirectory " << name << " created." << std::endl;
          return 0;
        }
      }
    };

    std::string currenttime() {
      time_t rawtime;
      struct tm *timeinfo;
      char buffer[80];
      time(&rawtime);
      timeinfo = localtime(&rawtime);
      strftime(buffer, 80, "%Y-%m-%d-%H-%M-%S", timeinfo);
      return std::string(buffer);
    }

    public:
    // Only mpi-rank 0 prints the object *s* to standard output (<< operator must be defined).
    template <typename T, typename... Types> void ReportOnce(const T var1, const Types... var2);
    template <typename T> void reportOnceNoIndent(T s);
    template <typename T> void ReportOnce(T s);

    /// hdf5_format for storing solver to hdf5
    static std::string hdf5_format() { return "FORKTPS_FiniteTSolverCore"; }

    CPP2PY_ARG_AS_DICT
    // imaginary time solver at finite temperature
    void solve(finiteT_solve_params_t const &solve_params_);
    //imaginary time solver at finite temperature with DLR tau Grid
    void solveDLR(finiteT_solve_params_t const &solver_params_);
    // real time solver at finite temperature with basis reconstruction
    void solveBasis(finiteT_solve_params_t const &solve_params_);
    // real time solver at finite temperature
    void solveReal(finiteT_solve_params_t const &solve_params_);
    // estimate the E_infty defined in the varbench paper
    void EinftyEstimate(finiteT_solve_params_t const &solve_params_);

    // tests functions
    public:
    void testProject(finiteT_solve_params_t const &solve_params_);
    void testsum(finiteT_solve_params_t const &solve_params_);
    void testKrylov(finiteT_solve_params_t const &solve_params);
    //void solveEnumerate(finiteT_solve_params_t const &solve_params_);
  };
} // namespace forktps