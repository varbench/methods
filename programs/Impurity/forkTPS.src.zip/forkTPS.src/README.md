# forktps


## Installation
1. Install [TRIQS](https://triqs.github.io/triqs/latest/)
2. Install [ITensor](https://github.com/ITensor/ITensor)
3. Set environment variable ```export ITENSOR_ROOT=/Path/To/ITensor``` to the root directory of the ITensor installation.
4. Rest of the installation follows the same path as every other TRIQS application:

```bash
#!/bin/bash

# Set the number of cores for the compilation
NCORES=4

# Clone the git repository
git clone https://github.com/TRIQS/forktps.git forktps.src

# Use cmake to configure the build process, installation prefix will be the one used for TRIQS
mkdir -p forktps.build && cd forktps.build
cmake ../forktps.src

# Build, test and install
make -j$NCORES && make test && make install
```

ToDo: 
1. How to set up parallel contract ITensor with FTPS
