Version 2.2.0
-------------

App4triqs Version 2.2.0 provides a project
skeleton for TRIQS applications based on
the TRIQS Library Version 2.2.0.
It is intended for applications with both
Python and C++ components.

This is the initial release for this project.
