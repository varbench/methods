import unittest
import numpy as np

from triqs.gf import *
from h5 import *

from forktps.DiscreteBath import *
from forktps.Helpers import *
from forktps import Solver
from forktps.solver import DMRGParams, TevoParams


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))
    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[1])

    dup[0, 0] << SemiCircular(half_bandwidth=1.3)
    dup[1, 1] << SemiCircular(half_bandwidth=1.3)
    ddn[0, 0] << SemiCircular(half_bandwidth=2.0)
    ddn[1, 1] << SemiCircular(half_bandwidth=2.0)

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)


class Test_RetriggerPP(unittest.TestCase):
    '''Tests retriggering of post-processing also, even with a lower number of time 
       steps used in the original solver used to create the GF.'''
    Norbs = 2
    blockNames = ['up', 'dn']

    Delta = getDelta(blockNames, Norbs)

    Nb = 4  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb)

    # give the local Hamiltonian the right block structure
    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
    # put the same 2x2 matrix on both blocks
    e0.Fill(np.zeros((Norbs, Norbs), dtype=np.complex128))

    Hint = ftps.solver_core.HInt(u=0., j=0., up=0., dd=False)

    # initialize the solver
    S = Solver(gf_struct=MakeGFstruct(Delta), nw=3001, wmin=-3., wmax=3.)
    S.b = bath
    S.e0 = e0

    # store solver before solve call
    with HDFArchive('S.h5', 'a') as a:
        a['Solver'] = S
        S2 = a['Solver']

    # number of time steps for original time evolution and post-process time evolution
    TSteps = 5
    PP_TSteps = 3

    paramsTevo = TevoParams(dt=0.1, time_steps=TSteps)
    S.solve(h_int=Hint, tevo=paramsTevo, del_states=False)

    # trigger post processing only
    paramsTevo = TevoParams(dt=0.1, time_steps=PP_TSteps)
    S2.post_process(h_int=Hint, tevo=paramsTevo, del_states=True)

    print(S.G_gr['up'].data)
    print(S2.G_gr['up'].data)

    # check if GFs are the same
    for name, g in S2.G_gr:
        difference = np.abs(
            S2.G_gr[name].data[:PP_TSteps, :, :] - S.G_gr[name].data[:PP_TSteps, :, :])
        difference = difference.flatten()
        assert all(t < 1E-10 for t in difference)


if __name__ == '__main__':
    unittest.main()
