from forktps.DiscreteBath import *
from forktps.Helpers import MakeGFstruct
from forktps.solver import DMRGParams, TevoParams
from forktps import Solver

import numpy as np
import unittest

from triqs.gf import *


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))

    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[1])

    for i in inds:
        dup[i, i] << SemiCircular(half_bandwidth=1.3)
        ddn[i, i] << SemiCircular(half_bandwidth=2.0)

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)


class Test_TevoMethodComparison(unittest.TestCase):
    '''Compares the different time evolution methods to each other for a 
       two-orbital model.'''
    Norbs = 2
    blockNames = ['up', 'dn']

    Delta = getDelta(blockNames, Norbs)

    Nb = 5  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb)
    eta = 0.1

    DeltaDiscrete = bath.reconstructDelta(w=Delta.mesh, eta=eta)

    # give the local Hamiltonian the right block structure
    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
    e0.Fill([[0, 0], [0, 0]])  # put the same 2x2 matrix on both blocks

    Hint = ftps.solver_core.HInt(u=0.5, j=0.05, up=0.4, dd=False)

    methods = ['TDVP', 'TDVP_2', 'TEBD']
    Solvers = {}

    paramsDMRG = DMRGParams(maxm=50, tw=1E-8)

    for method in methods:
        S = ftps.Solver(gf_struct=MakeGFstruct(
            Delta), nw=3001, wmin=-3., wmax=3.)
        S.b = bath
        S.e0 = e0
        paramsTevo = TevoParams(dt=0.05, time_steps=10,
                                tw=1E-8, maxm=50, method=method)

        S.solve(h_int=Hint,
                calc_me=[['up', 0]],
                params_GS=paramsDMRG,
                params_partSector=paramsDMRG,
                tevo=paramsTevo,
                NPart=[[3, 3, 3, 3]])

        Solvers[method] = S

    # check that all gfs are equal
    name = blockNames[0]
    for m1, m2 in itertools.product(methods, methods):
        if m1 == m2:
            continue

        g1 = Solvers[m1].G_gr[name][0, 0].data
        g2 = Solvers[m2].G_gr[name][0, 0].data
        difference = np.abs(g1 - g2)

        print(m1, m2, difference)

        # check that G is non-zeroT
        assert all(np.abs(t) > 1E-8 for t in g1)
        # check that difference is small
        assert all(t < 1E-3 for t in difference)


if __name__ == '__main__':
    unittest.main()
