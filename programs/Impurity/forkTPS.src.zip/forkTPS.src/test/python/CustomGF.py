from forktps.DiscreteBath import *
from forktps.Helpers import MakeGFstruct
from forktps.solver import DMRGParams, TevoParams
from forktps import Solver

import numpy as np
import unittest

from triqs.gf import *
from triqs.operators import *


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))

    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[1])

    for ind in inds:
        dup[ind, ind] << SemiCircular(half_bandwidth=2.0)
        ddn[ind, ind] << SemiCircular(half_bandwidth=2.0)

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)


class Test_TevoMethodComparison(unittest.TestCase):
    '''Compares the different time evolution methods to each other for a 
       two-orbital model.'''
    Norbs = 1
    blockNames = ['up', 'dn']

    Delta = getDelta(blockNames, Norbs)

    Nb = 5  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb)
    eta = 0.1

    DeltaDiscrete = bath.reconstructDelta(w=Delta.mesh, eta=eta)

    # give the local Hamiltonian the right block structure
    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
    e0.Fill([[0.]])  # put the same 1x1 matrix on both blocks

    Hint = ftps.solver_core.HInt(u=0.)

    paramsDMRG = DMRGParams(maxm=50, tw=1E-10)
    paramsTevo = TevoParams(dt=0.2, time_steps=10, tw=1E-10, maxm=50)

    S = ftps.Solver(gf_struct=MakeGFstruct(Delta), nw=3001, wmin=-3., wmax=3.)
    S.b = bath
    S.e0 = e0

    Sz = 0.5 * (n('up', 0) - n('dn', 0))
    Sx = 0.5 * (c_dag('up', 0)*c('dn', 0) + c_dag('dn', 0)*c('up', 0))
    Sy = 0.5j*(c_dag('up', 0)*c('dn', 0) - c_dag('dn', 0)*c('up', 0))

    S.solve(h_int=Hint,
            params_GS=paramsDMRG,
            params_partSector=paramsDMRG,
            tevo=paramsTevo,
            GFs=['N'],
            customGF=[[Sz, Sz],
                      [Sx, Sx],
                      [Sy, Sy]])

    Nt = S.N_t
    NNExact = CalcN(bath=bath, hloc=e0, mesh=S.N_t.mesh)

    # compare < N(t) N > to exact solution
    for i, j in product(range(2*Norbs), range(2*Norbs)):
        g1 = NNExact[i, j].data
        g2 = Nt[i, j].data
        difference = np.abs(g1 - g2)
        assert any(np.abs(t) > 0.1 for t in g1)
        assert all(np.abs(t) < 1E-5 for t in difference)

    # compare < N(t) N > from ftps to < Sz(t) Sz > custom GF
    Sz_FromN = 0.25*(Nt[0, 0]+Nt[1, 1] - Nt[0, 1] - Nt[1, 0])
    difference = np.abs(S.customGF[0].data - Sz_FromN.data)
    assert all(np.abs(t) < 1E-12 for t in difference)

    # compare < Sx(t) Sx > to < Sy(t) Sy >
    difference = np.abs(S.customGF[1].data - S.customGF[2].data)
    assert all(np.abs(t) < 1E-12 for t in difference)

    # compare < Sx(t) Sx > to < Sz(t) Sz >
    difference = np.abs(S.customGF[0].data - S.customGF[1].data)
    assert all(np.abs(t) < 1E-5 for t in difference)


if __name__ == '__main__':
    unittest.main()
