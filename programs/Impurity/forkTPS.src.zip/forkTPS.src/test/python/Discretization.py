import unittest
import numpy as np
from forktps.DiscreteBath import *
from triqs.gf import *
from itertools import product


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))

    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[1])

    dup[0, 0] << SemiCircular(half_bandwidth=1.3)
    dup[1, 1] << SemiCircular(half_bandwidth=1.3)
    ddn[0, 0] << SemiCircular(half_bandwidth=2.0)
    ddn[1, 1] << SemiCircular(half_bandwidth=2.0)

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)

# Tests the gap parameter used in the Discretization


class Test_DiscrGap(unittest.TestCase):
    Norbs = 2
    blockNames = ['up', 'dn']
    Delta = getDelta(blockNames, Norbs)

    # gap we want to enforce in discretization
    gap = [-1., 1.]

    Nb = 50  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb, gap=gap)

    for name, _ in Delta:
        for indx, k in product(range(Norbs), range(Nb)):
            eps = bath.eps([name, indx], k)
            insideGap = eps > gap[0] and eps < gap[1]
            assert insideGap == False

# Tests the PlaceAt parameter used in the Discretization


class Test_DiscrPlaceAt(unittest.TestCase):
    Norbs = 2
    blockNames = ['up', 'dn']
    Delta = getDelta(blockNames, Norbs)

    # define energies at which we want to enforce to have a bath sites
    PlaceSiteAt = {blockNames[0]: [-0.3, 0.25749],
                   blockNames[1]: [-1.0, 0.741]}
    Nb = 25
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb, PlaceAt=PlaceSiteAt)

    # check that there really is a bath site with the correct energy
    for name in blockNames:
        found = False
        for indx, k in product(range(Norbs), range(Nb)):
            Ediff = np.abs(
                np.abs(bath.eps([name, indx], k) - PlaceSiteAt[name][indx]))
            if(Ediff < 1E-14):
                found = True
                continue

        assert found


if __name__ == '__main__':
    unittest.main()
