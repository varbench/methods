import numpy as np
import copy
from forktps.DiscreteBath import *
from forktps.solver import DMRGParams, TevoParams
from forktps import Solver

from triqs.gf import *
import unittest


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))

    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name=blockNames[1])

    BWup = [1.3, 1.4, 1.5]
    BWdn = [2.0, 2.1, 2.2]

    for i in range(Norbs):
        dup[i, i] << SemiCircular(half_bandwidth=BWup[i])
        ddn[i, i] << SemiCircular(half_bandwidth=BWdn[i])

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)


class Test_SpinOrbit(unittest.TestCase):
    '''Tests the spin-orbit calculation for a diagonal bath by comparison to the exact solution.'''
    Norbs = 3
    blockNames = ['ud_0', 'ud_1']

    Delta = getDelta(blockNames, Norbs)

    Nb = 5  # number of bath sites
    bath = DiscretizeBath(Delta=Delta, Nb=Nb, SO=True)

    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta), True)
    e0.Fill(np.zeros((Norbs, Norbs), dtype=np.complex128))

    Hint = ftps.solver_core.HInt(u=0., j=0., up=0., dd=False)

    S = ftps.Solver(gf_struct=MakeGFstruct(Delta), nw=3001, wmin=-3., wmax=3.)
    S.b = bath
    S.e0 = e0

    paramsDMRG = DMRGParams(maxm=50, tw=1E-10, nmax=10, conv=1E-12)
    paramsTevo = TevoParams(dt=0.1, time_steps=5)
    S.solve(h_int=Hint,
            params_GS=paramsDMRG,
            params_partSector=paramsDMRG,
            tevo=paramsTevo)

    # compare to exact solution
    Ggr_exact = CalcGgr(bath=bath, hloc=e0, mesh=S.G_gr.mesh)
    for name, g in Ggr_exact:
        difference = np.abs(g.data[:] - S.G_gr[name].data[:])
        difference = difference.flatten()

        assert all(t < 1E-9 for t in difference)

    Gle_exact = CalcGle(bath=bath, hloc=e0, mesh=S.G_le.mesh)
    for name, g in Gle_exact:
        difference = np.abs(g.data[:] - S.G_le[name].data[:])
        difference = difference.flatten()

        assert all(t < 1E-9 for t in difference)


if __name__ == '__main__':
    unittest.main()
