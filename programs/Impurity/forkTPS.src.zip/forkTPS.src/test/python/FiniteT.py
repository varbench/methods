import numpy as np
import copy
from forktps.DiscreteBath import *
from forktps.solver import DMRGParams, TevoParams
import forktps as ftps

from triqs.gf import *
import unittest


class Test_FiniteT(unittest.TestCase):
    Norb = 3
    inds = list(range(Norb))
    blockNames = ['up', 'dn']

    # some hybridization
    dup = GfReFreq(indices=inds, window=(-3., 3.),
                   n_points=3001, name="up")
    for indx in inds:
        dup[indx, indx] << SemiCircular(half_bandwidth=1.)

    Delta = BlockGf(name_list=blockNames, block_list=(
        dup, dup), make_copies=True)

    Nb = 3  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb)
    eta = 0.1

    # give the local Hamiltonian the right block structure
    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
    # put the same 2x2 matrix on both blocks
    e0.Fill(np.zeros((Norb, Norb), dtype=np.complex128))

    Hint = ftps.solver_core.HInt(u=1.234, j=0., up=0., dd=True)

    paramsTevo = TevoParams(dt=0.2, time_steps=1, tw=1E-8, maxm=10)

    S = ftps.FiniteTSolver(beta=10, n_iw=1001, gf_struct=[
                           ["up", 3], ["dn", 3]])
    S.b = bath
    S.e0 = e0

    # first orbital 2 particles per spin, rest empty

    # S.solve(h_int=Hint, eta=eta,
    #        calc_me=[['up', 0]],
    #        params_GS=paramsDMRG,
    #        params_partSector=paramsDMRG,
    #        tevo=paramsTevo,
    #        NPart=[numPart])
