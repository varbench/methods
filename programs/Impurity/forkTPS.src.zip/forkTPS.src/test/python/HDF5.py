###############################################################################
#
# forktps: A TRIQS based impurity solver
#
# Copyright (c) 2019 The Simons foundation
#   authors: Nils Wentzell
#
# forktps is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# forktps is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# forktps. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
#!/usr/bin/env python


import numpy as np
import unittest

from forktps.DiscreteBath import *
from forktps.Helpers import MakeGFstruct
from forktps.solver import DMRGParams, TevoParams
from forktps import Solver

from h5 import *
from triqs.gf import *


def getDelta(blockNames, Norbs):
    inds = list(range(Norbs))

    dup = GfReFreq(indices=inds, window=(-10., 10.),
                   n_points=10001, name=blockNames[0])
    ddn = GfReFreq(indices=inds, window=(-10., 10.),
                   n_points=10001, name=blockNames[1])

    dup[0, 0] << SemiCircular(half_bandwidth=1.3)
    dup[1, 1] << SemiCircular(half_bandwidth=1.3)
    ddn[0, 0] << SemiCircular(half_bandwidth=1.3)
    ddn[1, 1] << SemiCircular(half_bandwidth=1.3)

    return BlockGf(name_list=blockNames, block_list=(dup, ddn), make_copies=False)


class Test_HDF5(unittest.TestCase):
    '''Tests HDF5 reading and writing of the Solver object.'''

    def CompareGfs(G1, G2):
        for name, _ in G1:
            difference = abs(G1[name].data[:] - G2[name].data[:])
            difference = difference.flatten()
            assert all(t < 1E-12 for t in difference)

    Norbs = 2
    blockNames = ['up', 'dn']

    Delta = getDelta(blockNames, Norbs)

    Nb = 3  # number of bath sites
    # bath object storing all relevant information for the bath
    bath = DiscretizeBath(Delta=Delta, Nb=Nb)
    eta = 0.1

    # give the local Hamiltonian the right block structure
    e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
    e0.Fill([[0., 0.],
             [0., 0.]]
            )  # put the same 2x2 matrix on both blocks

    Hint = ftps.solver_core.HInt(u=0., j=0., up=0., dd=False)

    S = Solver(gf_struct=MakeGFstruct(Delta), nw=3001, wmin=-3., wmax=3.)
    S.b = bath
    S.e0 = e0

    paramsDMRG = DMRGParams(maxm=50, tw=1E-8)
    paramsTevo = TevoParams(dt=0.05, time_steps=5, tw=1E-10, maxm=50)

    S.solve(h_int=Hint, eta=eta,
            calc_me=[['up', 0]],
            params_GS=paramsDMRG,
            params_partSector=paramsDMRG,
            tevo=paramsTevo
            )

    # store solver and read it again
    with HDFArchive('Solver.h5', 'w') as A:
        A["Solver"] = S
        S2 = A["Solver"]

    # compare Gfs directly after reading
    CompareGfs(S.G_gr, S2.G_gr)
    CompareGfs(S.G_le, S2.G_le)

    S2.solve(**S2.last_solve_params)

    # compare Gfs after second solve call
    CompareGfs(S.G_gr, S2.G_gr)
    CompareGfs(S.G_le, S2.G_le)


# class test_hdf5_bath_E0(unittest.TestCase):
#     Norbs = 2
#     gfstruct = [ ['up',2], ['dn',2]]

#     dup = GfReFreq(indices = [0,1], window = (-10., 10.), n_points =  10001, name = "up")
#     ddn = GfReFreq(indices = [0,1], window = (-10., 10.), n_points =  10001, name = "dn")


#     dup['0','0'] << SemiCircular(half_bandwidth = 1.3)
#     dup['1','1'] << SemiCircular(half_bandwidth = 1.3)
#     ddn['0','0'] << SemiCircular(half_bandwidth = 2.0, chem_potential=5)
#     ddn['1','1'] << SemiCircular(half_bandwidth = 2.0, chem_potential=5)


#     Delta = BlockGf(name_list = ('up','dn'), block_list = (dup,ddn), make_copies = False)

#     Nb = 5 #number of bath sites
#     bath = DiscretizeBath(Delta=Delta, Nb=Nb) #bath object storing all relevant information for the bath

#     hloc = ftps.solver_core.Hloc(gfstruct) #give the local Hamiltonian the right block structure
#     hloc.Fill([[1,0],[1,0]]) # put the same 2x2 matrix on both blocks

#     # store bath and e0
#     with HDFArchive('H0.h5', 'w') as A:
#         #A['bath'] = bath
#         A['e0'] = hloc

#         #bath2 = A['bath']
#         e02 = A['e0']

#     print(e0.e['up'])
#     print(type(e02) )
#     #print(bath.V('up',0,0))
#     #for name, g in S.G_gr:
#     #    assert np.max(abs( g.data[:] - S2.G_gr[name].data[:] )) < 1e-12
if __name__ == '__main__':
    unittest.main()
