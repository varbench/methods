import numpy as np
import copy
from forktps.DiscreteBath import *
from forktps.solver import DMRGParams, TevoParams
from forktps import Solver

from triqs.gf import *
import unittest


class Test_FiveOrbs(unittest.TestCase):
    ''' Checks that 5-band solver works on the python level. Compares a five band calculation
    to a three band calculation by only populating the first orbital with particles. 
    As a by-product also checks that GSVariance is set.
     '''
    Norbs = [3, 5]
    Solvers = {}

    for Norb in Norbs:
        inds = list(range(Norb))
        blockNames = ['up', 'dn']

        # some hybridization
        dup = GfReFreq(indices=inds, window=(-3., 3.),
                       n_points=3001, name="up")
        for indx in inds:
            dup[indx, indx] << SemiCircular(half_bandwidth=1.3)

        Delta = BlockGf(name_list=blockNames, block_list=(
            dup, dup), make_copies=True)

        Nb = 3  # number of bath sites
        # bath object storing all relevant information for the bath
        bath = DiscretizeBath(Delta=Delta, Nb=Nb)
        eta = 0.1

        # give the local Hamiltonian the right block structure
        e0 = ftps.solver_core.Hloc(MakeGFstruct(Delta))
        # put the same 2x2 matrix on both blocks
        e0.Fill(np.zeros((Norb, Norb), dtype=np.complex128))

        Hint = ftps.solver_core.HInt(u=1.234, j=0., up=0., dd=True)

        paramsDMRG = DMRGParams(maxm=50, tw=1E-8)
        paramsTevo = TevoParams(dt=0.05, time_steps=10, tw=1E-8, maxm=50)

        S = Solver(gf_struct=MakeGFstruct(Delta), nw=3001, wmin=-3., wmax=3.)
        S.b = bath
        S.e0 = e0

        # first orbital 2 particles per spin, rest empty
        numPart = [2, 2]
        numPart.extend([0] * (2*(Norb-1)))

        S.solve(h_int=Hint, eta=eta,
                calc_me=[['up', 0]],
                params_GS=paramsDMRG,
                params_partSector=paramsDMRG,
                tevo=paramsTevo,
                NPart=[numPart])

        Solvers[Norb] = S

        # check Ground state variance is set
        assert(S.GSVariance > 1E-20)

    difference = np.abs(Solvers[3].G_gr['up']
                        [0, 0].data - Solvers[5].G_gr['up'][0, 0].data)

    # check that GF is not identical to 0 and that the difference is small
    assert any(np.abs(t) > 0 for t in Solvers[3].G_gr['up'][0, 0].data)
    assert all(t < 1E-12 for t in difference)


if __name__ == '__main__':
    unittest.main()
