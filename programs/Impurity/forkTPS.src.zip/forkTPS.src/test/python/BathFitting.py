from triqs.gf import *

from forktps.Helpers import getX
from forktps.BathFitting import BathFitter

import numpy as np


def broadenGF(G, eta):
    for name, g in G:
        w = getX(g.mesh)
        im = g[0, 0].imag.data

        # convolution with a lorentzian of width η
        im = np.convolve(im, (eta/np.pi)/(w**2 + eta**2), 'same')*(w[1]-w[0])
        re = kramersKronig_Im2Re(im, w)

        g.data[:, 0, 0] = (re + 1j*im)
    return G


def kramersKronig_Im2Re(fIm, omega):
    # use Kramers Kronig relation to compute the real part from Imaginary part (very crude but it precision is not needed here)
    fRe = np.zeros(len(fIm), dtype=np.float128)
    for om, indx in zip(omega, range(len(omega))):
        omInt = omega[omega != om]
        fImInt = fIm[omega != om]

        fRe[indx] = -1/np.pi*np.trapz(x=omInt, y=fImInt/(om-omInt))
    return fRe


Norbs = 1                          # number of orbitals
D, mu1, mu2 = 1., -0.8, +0.8       # parameters of Δ
bw = [mu1 - D, mu2+D]               # bandwidth
Nb = 29                            # Number of bath sites
eta = (bw[1]-bw[0])/Nb * 1.2       # broadening

# generate Delta
dup = GfReFreq(indices=list(range(Norbs)),
               window=(-5., 5.), n_points=3001, name="up")

for i in range(Norbs):
    dup[i, i] << SemiCircular(half_bandwidth=D, chem_potential=-mu1) + \
        SemiCircular(half_bandwidth=D, chem_potential=-mu2)

# true unbroadened Δ
Delta = BlockGf(name_list=('up', 'dn'),
                block_list=(dup, dup), make_copies=True)

# Δ broadened by η
DeltaBroad = Delta.copy()
DeltaBroad = broadenGF(DeltaBroad, eta)


fitter = BathFitter(Nb)
bath = fitter.FitBath(Delta=DeltaBroad, eta=eta)

# check that bandwidth is reasonable
deps = bath.eps(['up', 0], 1) - bath.eps(['up', 0], 0)
fitbw = [bath.eps(['up', 0], 0) - deps/2., bath.eps(['up', 0], Nb-1)+deps/2.]

assert np.abs(fitbw[0] - bw[0]) < eta
assert np.abs(fitbw[1] - bw[1]) < eta


# check that fit reproduces broadened Δ
DeltaFit = bath.reconstructDelta(Delta.mesh, eta)

for name, g1 in DeltaBroad:
    g2 = DeltaFit[name]

    # compare imaginary part only, since real-part was obtained by trapz integration
    diff = g1.imag.data - g2.imag.data
    assert all(np.abs(diff) < 0.01)
