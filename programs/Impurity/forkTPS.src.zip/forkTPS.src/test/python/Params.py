import unittest
from forktps.solver import DMRGParams, TevoParams

# Check the python wrapper for the DMRGParams constructor


class DMRGParamsTest(unittest.TestCase):
    '''Tests all parameters of the DMRGParams object.'''
    print('testing DMRGParams')
    p = DMRGParams(maxmI=50, maxmIB=1, maxmB=7,            # bond dims
                   twI=0.555, twIB=1E-14, twB=0.99,        # truncations
                   nmax=80, normErr=0.0047, conv=1E-12,    # krylov
                   sweeps=78, napph=2,                   # other
                   prep_napph=7, prep_imagTevo=True, prep_dtau=0.154, prep_time_steps=297, prep_method='TEBD'
                   )

    assert p.approx.maxm_i == 50
    assert p.approx.maxm_ib == 1
    assert p.approx.maxm_b == 7

    assert abs(p.approx.tw_i - 0.555) < 1E-15
    assert abs(p.approx.tw_ib - 1E-14) < 1E-15
    assert abs(p.approx.tw_b - 0.99) < 1E-15

    assert p.krylov.nmax == 80
    assert abs(p.krylov.norm_err - 0.0047) < 1E-15
    assert abs(p.krylov.conv - 1E-12) < 1E-15

    assert p.sweeps == 78
    assert p.napp_h == 2

    assert p.prep.napp_h == 7
    assert p.prep.imag_tevo == True
    assert abs(p.prep.dtau - 0.154) < 1E-15
    assert p.prep.time_steps == 297
    assert p.prep.method == 'TEBD'


class TevoParamsTest(unittest.TestCase):
    '''Tests all parameters of the TevoParams object.'''
    print('testing TevoParams')
    p = TevoParams(dt=0.15, method='TDVP_2', imag_tevo=True, time_steps=187,   # other
                   maxmI=50, maxmIB=1, maxmB=7,                                # bond dims
                   twI=0.555, twIB=1E-14, twB=0.99,                            # truncations
                   nmax=80, normErr=0.0047, conv=1E-12)                       # krylov

    assert (p.dt - 0.15) < 1E-15
    assert p.method == 'TDVP_2'
    assert p.imag_tevo
    assert p.time_steps == 187

    assert p.approx.maxm_i == 50
    assert p.approx.maxm_ib == 1
    assert p.approx.maxm_b == 7

    assert abs(p.approx.tw_i - 0.555) < 1E-15
    assert abs(p.approx.tw_ib - 1E-14) < 1E-15
    assert abs(p.approx.tw_b - 0.99) < 1E-15

    assert p.krylov.nmax == 80
    assert abs(p.krylov.norm_err - 0.0047) < 1E-15
    assert abs(p.krylov.conv - 1E-12) < 1E-15


if __name__ == '__main__':
    unittest.main()
