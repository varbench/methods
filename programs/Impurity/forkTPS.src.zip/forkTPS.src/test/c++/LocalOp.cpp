//#include <forktps/fork/ForkTPO.hpp>
#include <forktps/fork/ForkTPO.hpp>
#include <forktps/fork/ForkTPS.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/ForkLocalOp.hpp>

#include "TestHelpers.hpp"

#include "gtest/gtest.h"

#include <cmath>

#include <iterator>
#include <ctime>
#include <iomanip>
#include <vector>
#include <complex>

using namespace itensor;
using namespace std;
using namespace forktps;

namespace forktps {
  //Note that having the indices correct is already a very thorough check, since
  //this is the biggest challenge in the effective Hamiltonians, the rest is just
  //multiplying terms like A*H*dag(A) on top of each other

  TEST(LocalOP, Indices_2Site_PositionImpBath) {
    //Checks that the L, R, U, D Tensors of 2-site Heff have the correct indices
    //when position is on impurity site and bath site
    const int N = 20, NArms = 4;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      Heff.ForgetContraction();
      int site = psi.ImpSite(ch);

      //set position at impurity and first bath site
      Heff.position(site, site + 1, psi);
      EXPECT_FALSE(Heff.L);
      EXPECT_EQ(Heff.i(), site);
      EXPECT_EQ(Heff.j(), site + 1);

      //R exists always
      Index stateLink_R = psi.GetLink(site + 1, site + 2);
      Index opLink_R    = H.GetLink(site + 1, site + 2);
      ExpectTensorToHaveLinks(Heff.R, stateLink_R, prime(stateLink_R), opLink_R);

      if (ch == 1) {
        EXPECT_FALSE(Heff.U);

        Index stateLink_D = psi.GetImpLink(ch, Downwards);
        Index opLink_D    = H.GetImpLink(ch, Downwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
      } else if (ch == NArms) {
        EXPECT_FALSE(Heff.D);

        Index stateLink_U = psi.GetImpLink(ch, Upwards);
        Index opLink_U    = H.GetImpLink(ch, Upwards);

        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);
      } else {
        Index stateLink_U = psi.GetImpLink(ch, Upwards);
        Index stateLink_D = psi.GetImpLink(ch, Downwards);

        Index opLink_U = H.GetImpLink(ch, Upwards);
        Index opLink_D = H.GetImpLink(ch, Downwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);
      }
    }
  }

  TEST(LocalOP, Indices_2Site_PositionImpImp) {
    //Checks that the L, R, U, D Tensors of 2-site Heff have the correct indices
    //when position is on two impurity sites
    const int N = 24, NArms = 6;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    for (auto ch : range1(NArms - 1)) {
      ForkLocalOp Heff(H);
      int site     = psi.ImpSite(ch);
      int nextsite = psi.ImpSite(ch + 1);

      //set position at impurity and first bath site
      Heff.position(site, nextsite, psi);
      EXPECT_EQ(Heff.i(), site);
      EXPECT_EQ(Heff.j(), nextsite);

      //L and R exists always
      Index stateLink_R = psi.GetLink(site, site + 1);
      Index stateLink_L = psi.GetLink(nextsite, nextsite + 1);
      Index opLink_R    = H.GetLink(site, site + 1);
      Index opLink_L    = H.GetLink(nextsite, nextsite + 1);

      ExpectTensorToHaveLinks(Heff.R, stateLink_R, prime(stateLink_R), opLink_R);
      ExpectTensorToHaveLinks(Heff.L, stateLink_L, prime(stateLink_L), opLink_L);

      if (ch == 1) {
        EXPECT_FALSE(Heff.U);

        Index stateLink_D = psi.GetImpLink(ch + 1, Downwards);
        Index opLink_D    = H.GetImpLink(ch + 1, Downwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
      } else if (ch == NArms - 1) {
        EXPECT_FALSE(Heff.D);

        Index stateLink_U = psi.GetImpLink(ch, Upwards);
        Index opLink_U    = H.GetImpLink(ch, Upwards);

        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);

      } else {
        Index stateLink_D = psi.GetImpLink(ch + 1, Downwards);
        Index stateLink_U = psi.GetImpLink(ch, Upwards);

        Index opLink_D = H.GetImpLink(ch + 1, Downwards);
        Index opLink_U = H.GetImpLink(ch, Upwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);
      }
    }
  }

  TEST(LocalOP, Indices_2Site_PositionBathBath) {
    //Checks that the L, R, U, D Tensors of 2-site Heff have the correct indices
    //when position is on two impurity sites
    const int N = 24, NArms = 6, NBath = static_cast<int>(std::round(N / NArms) - 1);

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      for (auto k : range1(NBath - 1)) {
        Heff.ForgetContraction();
        int site     = psi.ArmToSite(ch, k) - 1;
        int nextsite = site + 1;
        Heff.position(site, nextsite, psi);
        EXPECT_EQ(Heff.i(), site);
        EXPECT_EQ(Heff.j(), nextsite);
        EXPECT_FALSE(Heff.U);
        EXPECT_FALSE(Heff.D);

        //L exists always
        Index stateLink_L = psi.GetLink(site - 1, site);
        Index opLink_L    = H.GetLink(site - 1, site);
        ExpectTensorToHaveLinks(Heff.L, stateLink_L, prime(stateLink_L), opLink_L);

        if (k != 1) {
          Index stateLink_R = psi.GetLink(nextsite, nextsite + 1);
          Index opLink_R    = H.GetLink(nextsite, nextsite + 1);
          ExpectTensorToHaveLinks(Heff.R, stateLink_R, prime(stateLink_R), opLink_R);
        } else {
          //at the end of Arm -> no R
          EXPECT_FALSE(Heff.R);
        }
      }
    }
  }

  TEST(LocalOP, Indices_1Site_PositionImp) {
    //Checks that the L, R, U, D Tensors of 1-site Heff have the correct indices
    //when position is on any impurity site
    const int N = 24, NArms = 6;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      Heff.ForgetContraction();
      int site = psi.ImpSite(ch);

      //set position at impurity and first bath site
      Heff.position(site, psi);
      EXPECT_FALSE(Heff.L);
      EXPECT_EQ(Heff.i(), site);

      //R exists always
      Index stateLink_R = psi.GetLink(site, site + 1);
      Index opLink_R    = H.GetLink(site, site + 1);
      ExpectTensorToHaveLinks(Heff.R, stateLink_R, prime(stateLink_R), opLink_R);

      if (ch == 1) {
        EXPECT_FALSE(Heff.U);

        Index stateLink_D = psi.GetImpLink(ch, Downwards);
        Index opLink_D    = H.GetImpLink(ch, Downwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
      } else if (ch == NArms) {
        EXPECT_FALSE(Heff.D);

        Index stateLink_U = psi.GetImpLink(ch, Upwards);
        Index opLink_U    = H.GetImpLink(ch, Upwards);

        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);
      } else {
        Index stateLink_U = psi.GetImpLink(ch, Upwards);
        Index stateLink_D = psi.GetImpLink(ch, Downwards);

        Index opLink_U = H.GetImpLink(ch, Upwards);
        Index opLink_D = H.GetImpLink(ch, Downwards);

        ExpectTensorToHaveLinks(Heff.D, stateLink_D, prime(stateLink_D), opLink_D);
        ExpectTensorToHaveLinks(Heff.U, stateLink_U, prime(stateLink_U), opLink_U);
      }
    }
  }

  TEST(LocalOP, Indices_1Site_PositionBath) {
    //Checks that the L, R, U, D Tensors of 1-site Heff have the correct indices
    //when position is on any Bath site
    const int N = 24, NArms = 6, NBath = static_cast<int>(std::round(N / NArms)) - 1;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      for (auto k : range1(NBath)) {
        Heff.ForgetContraction();
        int site = psi.ArmToSite(ch, k);

        Heff.position(site, psi);
        EXPECT_EQ(Heff.i(), site);
        EXPECT_FALSE(Heff.U);
        EXPECT_FALSE(Heff.D);

        //L exists always
        Index stateLink_L = psi.GetLink(site - 1, site);
        Index opLink_L    = H.GetLink(site - 1, site);
        ExpectTensorToHaveLinks(Heff.L, stateLink_L, prime(stateLink_L), opLink_L);

        if (k != 1) {
          Index stateLink_R = psi.GetLink(site, site + 1);
          Index opLink_R    = H.GetLink(site, site + 1);

          ExpectTensorToHaveLinks(Heff.R, stateLink_R, prime(stateLink_R), opLink_R);
        } else {
          //at the end of Arm -> no R
          EXPECT_FALSE(Heff.R);
        }
      }
    }
  }

  TEST(LocalOP, Product_2Site_PositionImpBath) {
    //That product works for two site effective Hamiltonian
    //when position is on impurity site and bath site
    const int N = 24, NArms = 6;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      Heff.ForgetContraction();
      int site   = psi.ImpSite(ch);
      ITensor AA = psi.A(site) * psi.A(site + 1), res;

      //set position at impurity and first bath site
      Heff.position(site, site + 1, psi);
      Heff.product(AA, res);

      ExpectSameLinks(AA, res);
    }
  }

  TEST(LocalOP, Product_2Site_PositionImpImp) {
    //That product works for two site effective Hamiltonian
    //when position is on two impurity sites
    const int N = 24, NArms = 6;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms - 1)) {
      Heff.ForgetContraction();
      int site     = psi.ImpSite(ch);
      int nextsite = psi.ImpSite(ch + 1);
      ITensor AA   = psi.A(site) * psi.A(nextsite), res;

      //set position at impurity and first bath site
      Heff.position(site, nextsite, psi);
      Heff.product(AA, res);

      ExpectSameLinks(AA, res);
    }
  }

  TEST(LocalOP, Product_2Site_PositionBathBath) {
    //That product works for two site effective Hamiltonian
    //when position is on two bath sites
    const int N = 24, NArms = 6, NBath = static_cast<int>(std::round(N / NArms)) - 1;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      for (auto k : range1(NBath - 1)) {
        Heff.ForgetContraction();
        int site     = psi.ArmToSite(ch, k) - 1;
        int nextsite = site + 1;

        ITensor AA = psi.A(site) * psi.A(nextsite), res;

        Heff.position(site, nextsite, psi);
        Heff.product(AA, res);

        ExpectSameLinks(AA, res);
      }
    }
  }

  TEST(LocalOP, Product_1Site_PositionImp) {
    //That product works for one site effective Hamiltonian
    //when position is on impurity site
    const int N = 24, NArms = 6;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      Heff.ForgetContraction();
      int site   = psi.ImpSite(ch);
      ITensor AA = psi.A(site), res;

      //set position at impurity and first bath site
      Heff.position(site, psi);
      Heff.product(AA, res);

      ExpectSameLinks(AA, res);
    }
  }

  TEST(LocalOP, Product_1Site_PositionBath) {
    //That product works for two site effective Hamiltonian
    //when position is on two bath sites
    const int N = 24, NArms = 6, NBath = static_cast<int>(std::round(N / NArms)) - 1;

    AIM_ForkSites sites(N, NArms);

    ForkTPO H(sites, NArms);
    ForkTPS psi(sites, NArms);

    ForkLocalOp Heff(H);

    for (auto ch : range1(NArms)) {
      for (auto k : range1(NBath)) {
        Heff.ForgetContraction();
        int site = psi.ArmToSite(ch, k);

        ITensor AA = psi.A(site), res;

        Heff.position(site, psi);
        Heff.product(AA, res);

        ExpectSameLinks(AA, res);
      }
    }
  }

} // namespace forktps
