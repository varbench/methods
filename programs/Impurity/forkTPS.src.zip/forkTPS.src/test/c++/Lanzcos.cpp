
#include "gtest/gtest.h"

#include <itensor/iterativesolvers.h>
#include <forktps/fork/lanczos.hpp>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

namespace forktps {

  const int SEED_RNG(1598745);

  class MyMatrix {
    public:
    ITensor Mat;

    MyMatrix(ITensor m) { Mat = m; }

    void product(const ITensor &phi, ITensor &res) const {
      res = phi;
      res *= Mat;
      res.noPrime();
    };

    unsigned long size() const { return dim(Mat.inds()[1]); };
  };

  TEST(Lanczos, T1_4x4_Diag) {
    itensor::seedRNG(SEED_RNG);
    Index i(4), ip = prime(i);
    ITensor t(i, ip);

    const std::vector<double> diag = {0., 5.789, -3.25, 0.1896, 1.364888};
    for (auto indx : range1(4)) t.set(i(indx), ip(indx), diag[indx]);

    auto found    = std::min_element(diag.begin(), diag.end());
    auto GSenergy = *found;

    MyMatrix mat(t);
    ITensor vec(i);

    vec.randomize();
    vec /= norm(vec);

    double energy = forktps::ED::lanzcos(mat, vec);

    EXPECT_FLOAT_EQ(energy, GSenergy);

    for (auto indx : range1(4)) {
      if (indx == 2)
        EXPECT_NEAR(std::abs(vec.elt(i(indx))), 1., 1E-10);
      else
        EXPECT_NEAR(vec.elt(i(indx)), 0., 1E-10);
    }
  }

  TEST(Lanczos, T2_6x6) {
    //test of lanzcos routine for a 6x6 real matrix.
    //Exact solution can be obtained from the python code:
    //  mat = [ [ 1.35, 2.90, 0.10, 9.36, 7.00, 2.35],
    //         [ 2.9,  0.04, 5.14, 2.67, 3.33, 0.21],
    //         [ 0.1,  5.14, 77.0, 6.21, 4.66, 8.10],
    //         [ 9.36, 2.67, 6.21, 2.63, 1.00, 3.18],
    //         [ 7.00, 3.33, 4.66, 1.00, 9.01, 6.45],
    //         [ 2.35, 0.21, 8.10, 3.18, 6.45, 5.70]]

    // D,V = np.linalg.eigh(mat)
    // np.set_printoptions(precision=16)

    // print(D)
    // print(V[:,0])

    itensor::seedRNG(SEED_RNG);
    Index i(6), ip = prime(i);
    ITensor t(i, ip);
    Args args;
    const std::vector<std::vector<double>> matDat = {{1.35, 2.90, 0.10, 9.36, 7.00, 2.35}, {2.90, 0.04, 5.14, 2.67, 3.33, 0.21},
                                                     {0.10, 5.14, 77.0, 6.21, 4.66, 8.10}, {9.36, 2.67, 6.21, 2.63, 1.00, 3.18},
                                                     {7.00, 3.33, 4.66, 1.00, 9.01, 6.45}, {2.35, 0.21, 8.10, 3.18, 6.45, 5.70}};

    for (auto indxi : range1(6)) {
      for (auto indxj : range1(6)) { t.set(ip(indxi), i(indxj), matDat[indxi - 1][indxj - 1]); }
    }

    const double GSenergy        = -9.087111748597259;
    const std::vector<double> GS = {
       0., -0.7159123807889558, -0.0344637465947639, -0.0460096568185016, 0.6121182326200463, 0.3060740397489255, -0.1256772698982137};

    MyMatrix mat(t);
    ITensor vec(i);

    vec.randomize();
    vec /= norm(vec);

    double energy = forktps::ED::lanzcos(mat, vec, args);

    EXPECT_FLOAT_EQ(energy, GSenergy);

    for (auto indx : range1(6)) { EXPECT_NEAR(std::abs(GS[indx]), std::abs(vec.elt(i(indx))), 1E-10); }
  }

  TEST(Lanczos, T3_Complex) {
    //test of lanzcos routine for a 6x6 complex matrix.
    //Exact solution can be obtained from the python code:
    //  mat = [ [ 1.35, 2.90+0.3*1j, 0.10, 9.36, 7.00, 2.35],
    //         [ 2.9-0.3*1j,  0.04, 5.14, 2.67, 3.33, 0.21],
    //         [ 0.1,  5.14, 77.0, 6.21, 4.66, 8.10],
    //         [ 9.36, 2.67, 6.21, 2.63, 1.00, 3.18],
    //         [ 7.00, 3.33, 4.66, 1.00, 9.01, 6.45],
    //         [ 2.35, 0.21, 8.10, 3.18, 6.45, 5.70]]
    // D,V = np.linalg.eigh(mat)
    // np.set_printoptions(precision=16)
    // print(D)
    // print(V[:,0])

    itensor::seedRNG(SEED_RNG);
    const Index i(6), ip = prime(i);
    ITensor t(i, ip);
    Args args;
    const std::vector<std::vector<Complex>> matDat = {{1.35, 2.90 + 0.3 * Complex_i, 0.10, 9.36, 7.00, 2.35},
                                                      {2.90 - 0.3 * Complex_i, 0.04, 5.14, 2.67, 3.33, 0.21},
                                                      {0.10, 5.14, 77.0, 6.21, 4.66, 8.10},
                                                      {9.36, 2.67, 6.21, 2.63, 1.00, 3.18},
                                                      {7.00, 3.33, 4.66, 1.00, 9.01, 6.45},
                                                      {2.35, 0.21, 8.10, 3.18, 6.45, 5.70}};

    for (auto indxi : range1(6)) {
      for (auto indxj : range1(6)) { t.set(ip(indxi), i(indxj), matDat[indxi - 1][indxj - 1]); }
    }

    const double GSenergy         = -9.093175276866448;
    const std::vector<Complex> GS = {0.0,
                                     -0.7158404079242332 + 0. * Complex_i,
                                     -0.0342564804610704 - 0.0282195446301587 * Complex_i,
                                     -0.045994055089189 + 0.0013031685512342 * Complex_i,
                                     0.6116458698723914 + 0.0063937203759156 * Complex_i,
                                     0.3058458246758313 + 0.0060420351815647 * Complex_i,
                                     -0.1254476293885445 - 0.0043217711824956 * Complex_i};

    MyMatrix mat(t);
    ITensor vec(i);

    vec.randomize();
    vec /= norm(vec);

    double energy = forktps::ED::lanzcos(mat, vec, args);

    EXPECT_FLOAT_EQ(energy, GSenergy);

    for (auto indx : range1(6)) { EXPECT_NEAR(std::abs(GS[indx]), std::abs(vec.eltC(i(indx))), 1E-10); }
  }

  TEST(ExpM, T1_4x4_Diag) {
    itensor::seedRNG(SEED_RNG);
    Args args;
    Index i(4), ip = prime(i);
    ITensor t(i, ip);

    const std::vector<double> diag = {0., 5.789, -3.25, 0.1896, 1.364888};
    const double dt                = 0.13;
    for (auto indx : range1(4)) t.set(i(indx), ip(indx), diag[indx]);
    MyMatrix mat(t);

    for (auto k : range1(4)) {

      std::vector<double> vecData = {0., 0, 0, 0, 0};
      vecData[k]                  = 1.;

      ITensor vec(i);
      for (auto indx : range1(4)) vec.set(i(indx), vecData[indx]);

      Complex expectedValue = std::exp(-Complex_i * dt * diag[k]);
      itensor::applyExp(mat, vec, -Complex_i * dt, args);

      EXPECT_FLOAT_EQ(std::real(expectedValue), std::real(vec.eltC(i(k))));
      EXPECT_FLOAT_EQ(std::imag(expectedValue), std::imag(vec.eltC(i(k))));
    }
  }

  TEST(ExpM, T2_6x6) {
    //test of expM routine for a 6x6 real matrix.
    //Exact solution can be obtained from the python code:
    // mat = np.array( [ [ 1.35, 2.90, 0.10, 9.36, 7.00, 2.35],
    //         [ 2.9,  0.04, 5.14, 2.67, 3.33, 0.21],
    //         [ 0.1,  5.14, 77.0, 6.21, 4.66, 8.10],
    //         [ 9.36, 2.67, 6.21, 2.63, 1.00, 3.18],
    //         [ 7.00, 3.33, 4.66, 1.00, 9.01, 6.45],
    //         [ 2.35, 0.21, 8.10, 3.18, 6.45, 5.70]] )
    // dt = 0.17
    // U = expm(-1j*dt*mat);
    // vec = np.array( [0, 1/np.sqrt(2), 0., 1/np.sqrt(2), 0, 0] )

    // vec = U.dot(vec)
    // print(vec)

    itensor::seedRNG(SEED_RNG);
    const Index i(6), ip = prime(i);
    ITensor t(i, ip);
    Args args;
    const double dt                               = 0.17;
    const std::vector<std::vector<double>> matDat = {{1.35, 2.90, 0.10, 9.36, 7.00, 2.35}, {2.90, 0.04, 5.14, 2.67, 3.33, 0.21},
                                                     {0.10, 5.14, 77.0, 6.21, 4.66, 8.10}, {9.36, 2.67, 6.21, 2.63, 1.00, 3.18},
                                                     {7.00, 3.33, 4.66, 1.00, 9.01, 6.45}, {2.35, 0.21, 8.10, 3.18, 6.45, 5.70}};
    for (auto indxi : range1(6)) {
      for (auto indxj : range1(6)) { t.set(ip(indxi), i(indxj), matDat[indxi - 1][indxj - 1]); }
    }
    MyMatrix mat(t);

    std::vector<double> vecData = {0., 1 / std::sqrt(2), 0, 1 / std::sqrt(2), 0, 0};
    ITensor vec(i);
    for (auto indx : range1(6)) vec.set(i(indx), vecData.at(indx - 1));

    const std::vector<Complex> expectedVec = {
       -0.2368245379762352 - 0.5197647369949384 * Complex_i, 0.4646370807393633 + 0.0732729284716245 * Complex_i,
       0.1032537132289066 - 0.1405793773480729 * Complex_i,  -0.0248633301789133 - 0.056999808508503 * Complex_i,
       -0.4632326222883237 + 0.3298873940876988 * Complex_i, -0.1498651255619272 + 0.2689636640247474 * Complex_i};

    itensor::applyExp(mat, vec, -Complex_i * dt, args);

    for (auto indx : range1(6)) {
      EXPECT_FLOAT_EQ(std::real(expectedVec.at(indx - 1)), std::real(vec.eltC(i(indx))));
      EXPECT_FLOAT_EQ(std::imag(expectedVec.at(indx - 1)), std::imag(vec.eltC(i(indx))));
    }
  }

  TEST(ExpM, T3_Complex) {
    //test of expm routine for a 6x6 complex matrix.
    //Exact solution can be obtained from the python code:
    //  mat = [ [ 1.35, 2.90+0.3*1j, 0.10, 9.36, 7.00, 2.35],
    //         [ 2.9-0.3*1j,  0.04, 5.14, 2.67, 3.33, 0.21],
    //         [ 0.1,  5.14, 77.0, 6.21, 4.66, 8.10],
    //         [ 9.36, 2.67, 6.21, 2.63, 1.00, 3.18],
    //         [ 7.00, 3.33, 4.66, 1.00, 9.01, 6.45],
    //         [ 2.35, 0.21, 8.10, 3.18, 6.45, 5.70]]
    // D,V = np.linalg.eigh(mat)
    // np.set_printoptions(precision=16)
    // print(D)
    // print(V[:,0])

    itensor::seedRNG(SEED_RNG);
    const Index i(6), ip = prime(i);
    ITensor t(i, ip);
    const double dt = 0.17;
    Args args;
    const std::vector<std::vector<Complex>> matDat = {{1.35, 2.90 + 0.3 * Complex_i, 0.10, 9.36, 7.00, 2.35},
                                                      {2.90 - 0.3 * Complex_i, 0.04, 5.14, 2.67, 3.33, 0.21},
                                                      {0.10, 5.14, 77.0, 6.21, 4.66, 8.10},
                                                      {9.36, 2.67, 6.21, 2.63, 1.00, 3.18},
                                                      {7.00, 3.33, 4.66, 1.00, 9.01, 6.45},
                                                      {2.35, 0.21, 8.10, 3.18, 6.45, 5.70}};

    for (auto indxi : range1(6)) {
      for (auto indxj : range1(6)) { t.set(ip(indxi), i(indxj), matDat[indxi - 1][indxj - 1]); }
    }
    MyMatrix mat(t);
    //PrintDat(mat.Mat);

    std::vector<double> vecData = {0., 1 / std::sqrt(2), 0, 1 / std::sqrt(2), 0, 0};
    ITensor vec(i);
    for (auto indx : range1(6)) vec.set(i(indx), vecData.at(indx - 1));

    const std::vector<Complex> expectedVec = {
       -0.2204157624196768 - 0.5189848075880602 * Complex_i, 0.4661455780750006 + 0.0913778769621906 * Complex_i,
       0.1046025564548483 - 0.1394956287226202 * Complex_i,  -0.0267572119821804 - 0.075090972563763 * Complex_i,
       -0.4686089915264411 + 0.3205219744656143 * Complex_i, -0.1587092516095041 + 0.2686212340979196 * Complex_i};

    itensor::applyExp(mat, vec, -Complex_i * dt, args);

    for (auto indx : range1(6)) {
      EXPECT_FLOAT_EQ(std::real(expectedVec.at(indx - 1)), std::real(vec.eltC(i(indx))));
      EXPECT_FLOAT_EQ(std::imag(expectedVec.at(indx - 1)), std::imag(vec.eltC(i(indx))));
    }
  }

} // namespace forktps
