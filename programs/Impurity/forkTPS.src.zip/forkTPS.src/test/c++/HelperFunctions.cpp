#include <forktps/fork/HelperFunctions.hpp>
#include "gtest/gtest.h"
#include <algorithm>
#include <cstdio>
#include <climits>
#include <vector>

using namespace forktps;

namespace forktps {

  // Step 2. Use the TEST macro to define your tests.
  //
  // TEST has two parameters: the test case name and the test name.
  // After using the macro, you should define your test logic between a
  // pair of braces.  You can use a bunch of macros to indicate the
  // success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
  // examples of such macros.  For a complete list, see gtest.h.
  //
  // <TechnicalDetails>
  //
  // In Google Test, tests are grouped into test cases.  This is how we
  // keep test code organized.  You should put logically related tests
  // into the same test case.
  //
  // The test case name and the test name should both be valid C++
  // identifiers.  And you should not use underscore (_) in the names.
  //
  // Google Test guarantees that each test you define is run exactly
  // once, but it makes no guarantee on the order the tests are
  // executed.  Therefore, you should write your tests in such a way
  // that their results don't depend on their order.
  //
  // </TechnicalDetails>

  TEST(HelperFunctions, LinkCombiner) {
    // Tests basic fork structure of a fork with 16 sites and 4 arms.
    // On a fork with an equal number of bath sites on each arm

    Index a(3), b(5), c(2), d(3);

    ITensor T1(a, b, c), T2(b, c, d);

    T1 = T1.randomize();
    T2 = T2.randomize();

    auto [comb, link] = forktps::LinkCombiner(T1, T2);

    auto T1combined = T1 * comb;
    auto T2combined = T2 * comb;

    auto v1 = T1 * T2;
    auto v2 = T1combined * T2combined;

    for (auto i : range1(dim(a))) {
      for (auto j : range1(dim(d))) { EXPECT_DOUBLE_EQ(std::real(v1.eltC(a(i), d(j))), std::real(v2.eltC(a(i), d(j)))); }
    }
  }

  TEST(HelperFunctions, MaxDim) {
    // Tests basic fork structure of a fork with 16 sites and 4 arms.
    // On a fork with an equal number of bath sites on each arm

    Index a(3), b(5), c(2), d(3), e(7);
    int maxDimension = std::max({dim(a), dim(b), dim(c), dim(d), dim(e)});
    ITensor T1(a, b, c, d, e);

    EXPECT_EQ(maxDimension, forktps::MaxDim(T1));
  }

} // namespace forktps
