#include "forktps/fork/ForkLocalOp.hpp"
#include <forktps/fork/Bath.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/params.hpp>
#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/FTPO/AIM_OffDiag.hpp>
#include <forktps/fork/FTPO/AIM_SpinOrbit.hpp>

#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/makros.hpp>

#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/Tevo/AIM_ForkGates.hpp>

#include "gtest/gtest.h"
#include "math.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <itensor/mps/mps.h>
#include <itertools/itertools.hpp>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

//In these tests we compare MPOs in using parameter regimes where they should agree
//to do so, we look at the ground state energy as well as the ground state
//correlation matrix  <GS| cidag cj |GS>

namespace forktps {

  const int SEED_RNG(1598745);

  struct IntParams {
    double U;
    double Up;
    double J;
  };

  double calcGS_OffDiagH(Dmat eps, Cmat V, IntParams Ip, int NArms, const SiteSet &sites, ForkTPS &GS, Args &args);
  double calcGS_DiagH(dvec eps, dvec V, IntParams Ip, int NArms, const SiteSet &sites, ForkTPS &GS, Args &args);
  double DD_Energy(std::vector<std::string> i, double e0, IntParams Ip);

  //checks that for diagonal baths, the off-diagonal Hamiltonian
  //produceses the same result as the diagonal for both cases
  //with and without spin flip and pair hoppings
  TEST(AIM_vs_AIM_NonDiagBath, 2orb_DDonly) {

    itensor::seedRNG(SEED_RNG);

    const int N = 12, NArms = 4;
    const dvec eps_diag = {0., -1, 0};
    const dvec V_diag   = {0.1, 0.2};

    Dmat eps_odiag(NArms + 1);
    for (auto i : itertools::range(NArms)) eps_odiag.at(i) = eps_diag;

    const Cmat V_odiag = {{0.1, 0.2, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.1, 0.2}};

    Args args{"Cutoff", 1E-15, "maxsweeps", 10, "verbose", false, "NAppH", 2, "DDonly", true, "MaxIter", 5};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_diag, GS_odiag;

    const IntParams Ip = {1.0, 0.8, 0.1};

    auto E_diag  = calcGS_DiagH(eps_diag, V_diag, Ip, NArms, sites, GS_diag, args);
    auto E_odiag = calcGS_OffDiagH(eps_odiag, V_odiag, Ip, NArms, sites, GS_odiag, args);

    EXPECT_NEAR(E_diag, E_odiag, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_diag = GS_diag, ket_diag = GS_diag, bra_odiag = GS_odiag, ket_odiag = GS_odiag;

        ket_diag.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_odiag.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_diag.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_odiag.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_diag  = forktps::overlap(bra_diag, ket_diag).real();
        auto val_odiag = forktps::overlap(bra_odiag, ket_odiag).real();

        //std::cout << i <<" " << j << " vd "<< val_diag << "     diff: "<< val_diag-val_odiag<<std::endl;
        EXPECT_NEAR(val_odiag, val_diag, 1E-13);
      }
    }
  }

  TEST(AIM_vs_AIM_NonDiagBath, 2orb_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 12, NArms = 4;
    const dvec eps_diag = {0., -1, 0};
    const dvec V_diag   = {0.1, 0.2};

    Dmat eps_odiag(NArms + 1);
    for (auto i : itertools::range(NArms)) eps_odiag.at(i) = eps_diag;

    const Cmat V_odiag = {{0.1, 0.2, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.1, 0.2}};

    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-15, "maxsweeps", 15, "verbose", false, "NAppH", 3, "DDonly", false, "MaxIter", 5};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_diag, GS_odiag;

    auto E_diag  = calcGS_DiagH(eps_diag, V_diag, Ip, NArms, sites, GS_diag, args);
    auto E_odiag = calcGS_OffDiagH(eps_odiag, V_odiag, Ip, NArms, sites, GS_odiag, args);

    EXPECT_NEAR(E_diag, E_odiag, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_diag = GS_diag, ket_diag = GS_diag, bra_odiag = GS_odiag, ket_odiag = GS_odiag;

        ket_diag.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_odiag.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_diag.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_odiag.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_diag  = forktps::overlap(bra_diag, ket_diag).real();
        auto val_odiag = forktps::overlap(bra_odiag, ket_odiag).real();

        //std::cout << i <<" " << j << " vd "<< val_diag << "     diff: "<< val_diag-val_odiag<<std::endl;
        EXPECT_NEAR(val_odiag, val_diag, 1E-13);
      }
    }
  }

  TEST(AIM_vs_AIM_NonDiagBath, 3orb_DDonly) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps_diag = {0., -1, 0};
    const dvec V_diag   = {0.1, 0.2};

    Dmat eps_odiag(NArms + 1);
    for (auto i : itertools::range(NArms)) eps_odiag.at(i) = eps_diag;

    const Cmat V_odiag = {{0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2, 0.0, 0.0},
                          {0.0, 0.0, 0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}};

    Args args{"Cutoff", 1E-15, "maxsweeps", 15, "verbose", false, "NAppH", 3, "DDonly", true, "MaxIter", 5};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_diag, GS_odiag;

    const IntParams Ip = {1.0, 0.8, 0.1};

    auto E_diag  = calcGS_DiagH(eps_diag, V_diag, Ip, NArms, sites, GS_diag, args);
    auto E_odiag = calcGS_OffDiagH(eps_odiag, V_odiag, Ip, NArms, sites, GS_odiag, args);

    EXPECT_NEAR(E_diag, E_odiag, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_diag = GS_diag, ket_diag = GS_diag, bra_odiag = GS_odiag, ket_odiag = GS_odiag;

        ket_diag.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_odiag.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_diag.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_odiag.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_diag  = forktps::overlap(bra_diag, ket_diag).real();
        auto val_odiag = forktps::overlap(bra_odiag, ket_odiag).real();

        //std::cout << i <<" " << j << " vd "<< val_diag << "     diff: "<< val_diag-val_odiag<<std::endl;
        EXPECT_NEAR(val_odiag, val_diag, 1E-13);
      }
    }
  }

  TEST(AIM_vs_AIM_NonDiagBath, 3orb_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps_diag = {0., -1, 0};
    const dvec V_diag   = {0.1, 0.2};

    Dmat eps_odiag(NArms + 1);
    for (auto i : itertools::range(NArms)) eps_odiag.at(i) = eps_diag;

    const Cmat V_odiag = {{0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2, 0.0, 0.0},
                          {0.0, 0.0, 0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-15, Names::MAXMI, 50, "maxsweeps", 20, "verbose", false, "NAppH", 3, "DDonly", false, "MaxIter", 5};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_diag, GS_odiag;

    auto E_diag  = calcGS_DiagH(eps_diag, V_diag, Ip, NArms, sites, GS_diag, args);
    auto E_odiag = calcGS_OffDiagH(eps_odiag, V_odiag, Ip, NArms, sites, GS_odiag, args);

    EXPECT_NEAR(E_diag, E_odiag, 1E-9);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_diag = GS_diag, ket_diag = GS_diag, bra_odiag = GS_odiag, ket_odiag = GS_odiag;

        ket_diag.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_odiag.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_diag.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_odiag.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_diag  = forktps::overlap(bra_diag, ket_diag).real();
        auto val_odiag = forktps::overlap(bra_odiag, ket_odiag).real();

        //std::cout << i <<" " << j << " vd "<< val_diag << "     diff: "<< val_diag-val_odiag<<std::endl;
        EXPECT_NEAR(val_odiag, val_diag, 1E-05);
      }
    }
  }

  TEST(U0_5vs3vs2, U05vs4vs2) {
    // for a non-interacting model and for two, three and 5 orbitals, calculate
    // the ground state energy of a single particle in each spin-orbital and
    // compare to the exact solution.

    const std::vector<int> Arms   = {4, 6, 10};
    const std::vector<double> eps = {0.0, -0.2, 0.2};
    const std::vector<Complex> V  = {0.1, 0.1};

    std::vector<double> energies;

    Args args{"Cutoff", 1E-12, "maxsweeps", 20, "verbose", false};

    const double referenceEnergy = -0.24494897427831774;
    const int NBath              = 2;

    for (auto NArms : Arms) {
      std::cout << NArms << std::endl;
      int N = NArms * (NBath + 1);
      Dmat epsMat(0);
      Cmat VMat(0);

      AIM_ForkSites sites(N, NArms);

      for (auto i : range1(NArms)) {
        UNUSED_VAR(i);
        epsMat.push_back(eps);
        VMat.push_back(V);
      }

      auto H = ForkTPO(AIM(sites, epsMat, VMat, 0., 0., 0., NArms, args));

      // place a single particle in each spin-orbital, and calculate the energy
      for (auto orb : range1(NArms)) {
        InitState init(sites, "Emp");
        init.set(H.ImpSite(orb), "Occ");

        ForkTPS psi(init, NArms);

        double energy = 0;
        DMRG(psi, H, energy, args);
        energies.push_back(energy);
      }
    }

    for (auto energy : energies) { EXPECT_NEAR(energy, referenceEnergy, 1E-13); }
  }

  //checks that for J = 0 it does not matter whether one includes
  //spinflip and pair hopping terms or not
  TEST(AIM, J0_2orb_DDonly_vs_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 12, NArms = 4;
    const dvec eps = {0., -1, 0};
    const dvec V   = {0.1, 0.2};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_1, GS_2;

    const IntParams Ip = {1.0, 0.8, 0.};
    args.add("DDonly", true);
    auto E_1 = calcGS_DiagH(eps, V, Ip, NArms, sites, GS_1, args);
    args.add("DDonly", false);
    auto E_2 = calcGS_DiagH(eps, V, Ip, NArms, sites, GS_2, args);

    EXPECT_NEAR(E_1, E_2, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_1 = GS_1, ket_1 = GS_1, bra_2 = GS_2, ket_2 = GS_2;

        ket_1.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_2.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_1.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_2.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_1 = forktps::overlap(bra_1, ket_1).real();
        auto val_2 = forktps::overlap(bra_2, ket_2).real();

        //std::cout << i <<" " << j << " vd "<< val_1 << "     diff: "<< val_1-val_2<<std::endl;
        EXPECT_NEAR(val_2, val_1, 1E-13);
      }
    }
  }

  TEST(AIM_NonDiagBath, J0_2orb_DDonly_vs_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 12, NArms = 4;
    const dvec e = {0., -1, 0};

    Dmat eps(NArms + 1);
    for (auto i : itertools::range(NArms)) eps.at(i) = e;

    const Cmat V       = {{0.1, 0.2, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.1, 0.2}};
    const IntParams Ip = {1.0, 0.8, 0.0};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_1, GS_2;

    args.add("DDonly", true);
    auto E_1 = calcGS_OffDiagH(eps, V, Ip, NArms, sites, GS_1, args);
    args.add("DDonly", false);
    auto E_2 = calcGS_OffDiagH(eps, V, Ip, NArms, sites, GS_2, args);

    EXPECT_NEAR(E_1, E_2, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_1 = GS_1, ket_1 = GS_1, bra_2 = GS_2, ket_2 = GS_2;

        ket_1.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_2.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_1.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_2.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_1 = forktps::overlap(bra_1, ket_1).real();
        auto val_2 = forktps::overlap(bra_2, ket_2).real();

        //std::cout << i <<" " << j << " vd "<< val_1 << "     diff: "<< val_1-val_2<<std::endl;
        EXPECT_NEAR(val_2, val_1, 1E-13);
      }
    }
  }

  TEST(AIM, J0_3orb_DDonly_vs_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps = {0., -1, 0};
    const dvec V   = {0.1, 0.2};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_1, GS_2;

    const IntParams Ip = {1.0, 0.8, 0.};
    args.add("DDonly", true);
    auto E_1 = calcGS_DiagH(eps, V, Ip, NArms, sites, GS_1, args);
    args.add("DDonly", false);
    auto E_2 = calcGS_DiagH(eps, V, Ip, NArms, sites, GS_2, args);

    EXPECT_NEAR(E_1, E_2, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_1 = GS_1, ket_1 = GS_1, bra_2 = GS_2, ket_2 = GS_2;

        ket_1.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_2.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_1.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_2.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_1 = forktps::overlap(bra_1, ket_1).real();
        auto val_2 = forktps::overlap(bra_2, ket_2).real();

        //std::cout << i <<" " << j << " vd "<< val_1 << "     diff: "<< val_1-val_2<<std::endl;
        EXPECT_NEAR(val_2, val_1, 1E-12);
      }
    }
  }

  TEST(AIM_NonDiagBath, J0_3orb_DDonly_vs_SFPH) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec e = {0., -1, 0};

    Dmat eps(NArms + 1);
    for (auto i : itertools::range(NArms)) eps.at(i) = e;

    const Cmat V = {{0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.1, 0.2, 0.0, 0.0, 0.0, 0.0}, {0.0, 0.0, 0.1, 0.2, 0.0, 0.0},
                    {0.0, 0.0, 0.1, 0.2, 0.0, 0.0}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}, {0.0, 0.0, 0.0, 0.0, 0.1, 0.2}};

    const IntParams Ip = {1.0, 0.8, 0.0};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS_1, GS_2;

    args.add("DDonly", true);
    auto E_1 = calcGS_OffDiagH(eps, V, Ip, NArms, sites, GS_1, args);
    args.add("DDonly", false);
    auto E_2 = calcGS_OffDiagH(eps, V, Ip, NArms, sites, GS_2, args);

    EXPECT_NEAR(E_1, E_2, 1E-10);

    for (auto i : range1(N)) {
      for (auto j : range1(i, N)) {
        forktps::ForkTPS bra_1 = GS_1, ket_1 = GS_1, bra_2 = GS_2, ket_2 = GS_2;

        ket_1.ApplySingleSiteOp(sites.op("CkD", i), i, true);
        ket_2.ApplySingleSiteOp(sites.op("CkD", i), i, true);

        bra_1.ApplySingleSiteOp(sites.op("CkD", j), j, true);
        bra_2.ApplySingleSiteOp(sites.op("CkD", j), j, true);

        auto val_1 = forktps::overlap(bra_1, ket_1).real();
        auto val_2 = forktps::overlap(bra_2, ket_2).real();

        //std::cout << i <<" " << j << " vd "<< val_1 << "     diff: "<< val_1-val_2<<std::endl;
        EXPECT_NEAR(val_2, val_1, 1E-13);
      }
    }
  }

  // --------------------------------------------------------------------------------------------------
  // ------------------------------------- Atomic Limit -----------------------------------------------
  // --------------------------------------------------------------------------------------------------
  TEST(AIM, atomicLimit_DDonly) {
    //calculates the atomic limit groundstate energy for all sectors
    //of spin and particle number for the Kanamori Hamiltonian without
    //spin flip and pair hopping terms. Compares these calculations to
    //the analytic results.

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps = {-0.1, 1000, 1000};
    const dvec V   = {0., 0.};

    Args args{"Cutoff", 1E-15, "maxsweeps", 3, "verbose", false, "NAppH", 0};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS;

    const IntParams Ip = {1.0, 0.8, 0.1};
    args.add("DDonly", true);

    ForkTPO H = ForkTPO(AIM(sites, eps, V, Ip.U, Ip.Up, Ip.J, NArms, args));

    std::vector<std::string> eo{"Emp", "Occ"};
    for (auto [i1, i2, i3, i4, i5, i6] : itertools::product(eo, eo, eo, eo, eo, eo)) {
      //continue if all empty
      if (i1 == i2 && i2 == i3 && i3 == i4 && i4 == i5 && i5 == i6 && i6 == "Emp") continue;

      InitState init(sites);
      for (auto i : range1(H.N())) init.set(i, "Emp");

      init.set(H.ImpSite(1), i1);
      init.set(H.ImpSite(2), i2);
      init.set(H.ImpSite(3), i3);
      init.set(H.ImpSite(4), i4);
      init.set(H.ImpSite(5), i5);
      init.set(H.ImpSite(6), i6);

      GS = ForkTPS(init, NArms);
      ForkLocalOp Heff(H);
      Heff.position(1, GS);
      auto energy = std::real(Heff.ContractAll(GS));

      //calculate expected energy
      double expectedEnergy = DD_Energy({i1, i2, i3, i4, i5, i6}, -0.1, Ip);

      EXPECT_NEAR(energy, expectedEnergy, 1E-12);
    }
  }

  TEST(AIM, atomicLimit_SFPH) {
    //calculates the atomic limit groundstate energy for several sectors
    //of spin and particle number for the Kanamori Hamiltonian including
    //spin flip and pair hopping terms. Compares these calculations to
    //the analytic results.

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps     = {-0.1, 1000, 1000};
    const dvec V       = {0., 0.};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-15, "maxsweeps", 3, "verbose", false, "NAppH", 0, "DDonly", false};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS;

    ForkTPO H = ForkTPO(AIM(sites, eps, V, Ip.U, Ip.Up, Ip.J, NArms, args));

    const std::vector<double> expectedEnergies = {
       //2 Part
       Ip.U - Ip.J + 2 * (eps[0]),     //double Occ
       Ip.U - 3 * Ip.J + 2 * (eps[0]), //up-down
       Ip.U - 3 * Ip.J + 2 * (eps[0]), //up-down
       Ip.U - 3 * Ip.J + 2 * (eps[0]), //up-down
       Ip.U - 3 * Ip.J + 2 * (eps[0]), //up-up
       Ip.U - 3 * Ip.J + 2 * (eps[0]), //dn-dn

       //3 Part
       3 * Ip.U - 9 * Ip.J + 3 * (eps[0]), //up-up-up
       3 * Ip.U - 9 * Ip.J + 3 * (eps[0]), //dn-dn-dn
       3 * Ip.U - 6 * Ip.J + 3 * (eps[0]), //double-up
       3 * Ip.U - 9 * Ip.J + 3 * (eps[0])  //up-dn-dn
    };

    const std::vector<std::vector<int>> occSites = {{1, 2}, {1, 4}, {1, 6}, {3, 6}, {1, 3}, {2, 4}, {1, 3, 5}, {2, 4, 6}, {1, 2, 3}, {1, 4, 6}};

    for (auto i : itertools::range(expectedEnergies.size())) {
      auto expectedEnergy = expectedEnergies.at(i);

      InitState init(sites);
      for (auto j : range1(H.N())) init.set(j, "Emp");

      for (auto site : occSites.at(i)) init.set(H.ImpSite(site), "Occ");

      GS = ForkTPS(init, NArms);
      for (int j = 0; j < 5; ++j) {
        UNUSED_VAR(j);
        GS = forktps::exactApplyMPO(GS, H, args);
        GS.normalize();
      }

      double energy(0.);
      forktps::DMRG(GS, H, energy, args);

      EXPECT_NEAR(energy, expectedEnergy, 1E-12);
    }
  }

  TEST(AIM, atomicLimit_DDonly_5Band) {
    //calculates the atomic limit groundstate energy for all sectors
    //of spin and particle number for the Kanamori Hamiltonian without
    //spin flip and pair hopping terms. Compares these calculations to
    //the analytic results.

    itensor::seedRNG(SEED_RNG);

    const int N = 30, NArms = 10;
    const double e0    = -0.1;
    const dvec eps     = {e0, 1000, 1000};
    const dvec V       = {0., 0.};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-15, "maxsweeps", 1, "verbose", false, "NAppH", 0, "DDonly", true};
    AIM_ForkSites sites(N, NArms);
    ForkTPS GS;

    ForkTPO H = ForkTPO(AIM(sites, eps, V, Ip.U, Ip.Up, Ip.J, NArms, args));

    //Impurity sites are 1, 4, 7, 10, 13, 16, 20, 24, 28
    std::vector<std::string> eo{"Emp", "Occ"};
    for (auto [i1, i2, i3, i4, i5] : itertools::product(eo, eo, eo, eo, eo)) {
      for (auto [i6, i7, i8, i9, i10] : itertools::product(eo, eo, eo, eo, eo)) {
        //continue if all empty
        if (i1 == i2 && i2 == i3 && i3 == i4 && i4 == i5 && i5 == i6 && i6 == i7 && i7 == i8 && i8 == i9 && i9 == i10 && i10 == "Emp") continue;

        std::vector<string> is = {i1, i2, i3, i4, i5, i6, i7, i8, i9, i10};

        InitState init(sites, "Emp");
        for (auto [indx, i] : itertools::enumerate(is)) { init.set(H.ImpSite(indx + 1), i); }

        GS = ForkTPS(init, NArms);

        ForkLocalOp Heff(H);
        Heff.position(1, GS);
        auto energy = std::real(Heff.ContractAll(GS));

        //calculate expected energy
        double expectedEnergy = DD_Energy(is, e0, Ip);

        EXPECT_NEAR(energy, expectedEnergy, 1E-12);
      }
    }
  }

  // --------------------------------------------------------------------------------------------------
  // ---------------------------------- Tests for the Spin-Orbit MPO ----------------------------------
  // --------------------------------------------------------------------------------------------------

  // Impurity hopping real - Check GS energy
  TEST(AIM_SpinOrbit, NoBath_ImpImpHoppings) {
    const int N = 18, NArms = 6;
    const dvec eps = {0., 1000, 1000};
    const dvec V   = {0., 0.};
    const H_int hint(0, 0, 0, false);

    Args args{"Cutoff", 1E-15, "maxsweeps", 3, "verbose", false, "NAppH", 0};
    AIM_ForkSites sites(N, NArms, {"conserveSz", false});
    ForkTPS GS;

    bath b(eps, V, 3, "up", "dn");
    hloc e0({0, 0, 0}, 3, "up", "dn");

    e0.e["up"](1, 0) = .3;
    e0.e["up"](0, 1) = .3;
    e0.e["up"](1, 2) = .5;
    e0.e["up"](2, 1) = .5;
    e0.e["up"](0, 2) = .4;
    e0.e["up"](2, 0) = .4;
    e0.e["dn"]       = e0.e["up"];

    ForkTPO H = ForkTPO(AIM_SpinOrbit(sites, b, e0, hint));
    // single particle energies are:
    //[-0.5180267791324229 -0.2875542568200942  0.8055810359525173]
    const double E1 = -0.5180267791324229;
    const double E2 = E1 + -0.2875542568200942;

    const std::vector<double> expectedEnergies     = {E1, E1, E1, E1, E1, E1, E2, E2, E2, E2, E2, E2, 2 * E1};
    const std::vector<std::vector<int>> occSiteses = {{1}, {2}, {3}, {4}, {5}, {6}, {1, 4}, {1, 6}, {4, 6}, {2, 3}, {2, 5}, {3, 5}, {1, 2}};

    for (auto [indx, occsites] : itertools::enumerate(occSiteses)) {
      //initialize MPS with the current number of particles
      InitState init(sites);
      for (auto site : occsites) init.set(H.ImpSite(site), "Occ");
      GS = ForkTPS(init, NArms);

      for (int j = 0; j < 2; ++j) {
        GS = forktps::exactApplyMPO(GS, H, args);
        GS.normalize();
      }
      double energy = 0;
      forktps::DMRG(GS, H, energy, args);

      EXPECT_NEAR(energy, expectedEnergies[indx], 1E-14);
    }
  }

  // Impurity hopping cplx - Check GS energy
  TEST(AIM_SpinOrbit, NoBath_ImpImpHoppings_Imag) {
    const int N = 18, NArms = 6;
    const dvec eps = {0., 1000, 1000};
    const dvec V   = {0., 0.};

    Args args{"Cutoff", 1E-15, "maxsweeps", 3, "verbose", false, "NAppH", 0};
    AIM_ForkSites sites(N, NArms, {"conserveSz", false});
    ForkTPS GS;

    const H_int hint(0, 0, 0, false);
    const bath b(eps, V, 3, "up", "dn");
    hloc e0({0, 0, 0}, 3, "up", "dn");

    e0.e["up"](1, 0) = .3 + 2.3 * 1_i;
    e0.e["up"](0, 1) = .3 - 2.3 * 1_i;
    e0.e["up"](1, 2) = .5;
    e0.e["up"](2, 1) = .5;
    e0.e["up"](0, 2) = .4 + 1.2 * 1_i;
    e0.e["up"](2, 0) = .4 - 1.2 * 1_i;
    e0.e["dn"]       = e0.e["up"];

    ForkTPO H = ForkTPO(AIM_SpinOrbit(sites, b, e0, hint));
    // single particle energies are:
    //[[-2.8556079320510888  0.3722815817033649  2.483326350347723 ]]
    const double E1 = -2.8556079320510888;

    const std::vector<double> expectedEnergies     = {E1, E1, E1, E1, E1, E1};
    const std::vector<std::vector<int>> occSiteses = {{1}, {2}, {3}, {4}, {5}, {6}};

    for (auto [indx, occsites] : itertools::enumerate(occSiteses)) {
      //initialize MPS with the current number of particles
      InitState init(sites);
      for (auto site : occsites) init.set(H.ImpSite(site), "Occ");
      GS = ForkTPS(init, NArms);

      for (int j = 0; j < 2; ++j) {
        GS = forktps::exactApplyMPO(GS, H, args);
        GS.normalize();
      }
      double energy = 0;
      forktps::DMRG(GS, H, energy, args);

      EXPECT_NEAR(energy, expectedEnergies[indx], 1E-14);
    }
  }

  // Impurity hopping + Hybridization
  TEST(AIM_SpinOrbit, OffDiagHyb) {
    // to verify run following python code
    // V1diag = [0.1, 0.2, 0.3]
    // V2diag = [0.3,  0.2,  0.10]
    // V3diag = [0.3,  0.2,  0.10]
    // Vod12 = [0.05, 0.06, 0.07]
    // Vod13 = [0.05, 0.06, 0.07]
    // Vod23 = [0.05, 0.06, 0.07]

    // eps = [0., 0. , 0., -1, -1,-1, 0., 0., 0., 1., 1., 1.];
    // mat = np.zeros( (12,12), dtype = np.complex128 )
    // for i in range(3):
    //     mat[0, 3 + 3*i ] = V1diag[i]
    //     mat[3 + 3*i, 0 ] = V1diag[i]

    //     mat[1, 3 + 3*i +1 ] = V2diag[i]
    //     mat[3 + 3*i+1, 1 ] = V2diag[i]

    //     mat[2, 3 + 3*i +2 ] = V2diag[i]
    //     mat[3 + 3*i+2, 2 ] = V2diag[i]

    //     mat[1, 3 + 3*i ] = Vod12[i]
    //     mat[3 + 3*i, 1 ] = Vod12[i]

    //     mat[2, 3 + 3*i ] = Vod13[i]
    //     mat[3 + 3*i, 2 ] = Vod13[i]

    //     mat[2, 3 + 3*i+1 ] = Vod23[i]
    //     mat[3 + 3*i+1, 2 ] = Vod23[i]

    // mat[1,0] = .3 + .3*1j;
    // mat[0,1] = .3 - .3*1j;
    // mat[1,2] = .5;
    // mat[2,1] = .5;
    // mat[0,2] = .4 + .2*1j;
    // mat[2,0] = .4 - .2*1j;
    // for i in range(12):
    //     mat[i,i] = eps[i]

    // D,V = np.linalg.eigh(mat)

    const int N = 24, NArms = 6;
    const dvec e   = {0., -1, 0, 1};
    const Dmat eps = {e, e, e, e, e, e};
    const Cmat V   = {{0.10, 0.20, 0.30, 0.00, 0.00, 0.00, 0.0, 0.0, 0.0}, {0.10, 0.20, 0.30, 0.00, 0.00, 0.00, 0.0, 0.0, 0.0},
                    {0.05, 0.06, 0.07, 0.30, 0.20, 0.10, 0.0, 0.0, 0.0}, {0.05, 0.06, 0.07, 0.30, 0.20, 0.10, 0.0, 0.0, 0.0},
                    {0.05, 0.06, 0.07, 0.05, 0.06, 0.07, 0.3, 0.2, 0.1}, {0.05, 0.06, 0.07, 0.05, 0.06, 0.07, 0.3, 0.2, 0.1}};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 0};
    AIM_ForkSites sites(N, NArms, {"conserveSz", false});
    ForkTPS GS;

    const H_int hint(0, 0, 0, false);
    const bath b(eps, V, 3, "up", "dn", true);
    hloc e0({0, 0, 0}, 3, "up", "dn");

    e0.e["up"](1, 0) = .3 + .3 * 1_i;
    e0.e["up"](0, 1) = .3 - .3 * 1_i;
    e0.e["up"](1, 2) = .5;
    e0.e["up"](2, 1) = .5;
    e0.e["up"](0, 2) = .4 + .2 * 1_i;
    e0.e["up"](2, 0) = .4 - .2 * 1_i;
    e0.e["dn"]       = e0.e["up"];

    ForkTPO H = ForkTPO(AIM_SpinOrbit(sites, b, e0, hint));
    // single particle energies are:
    const double E1 = -1.1609311831569378;

    const std::vector<double> expectedEnergies     = {E1, E1};
    const std::vector<std::vector<int>> occSiteses = {{1}, {2}};

    for (auto [indx, occsites] : itertools::enumerate(occSiteses)) {
      //initialize MPS with the current number of particles
      InitState init(sites);
      for (auto site : occsites) init.set(H.ImpSite(site), "Occ");
      GS = ForkTPS(init, NArms);

      for (int j = 0; j < 5; ++j) {
        UNUSED_VAR(j);
        GS = forktps::exactApplyMPO(GS, H, args);
        GS.normalize();
      }
      double energy = 0;
      forktps::DMRG(GS, H, energy, args);

      EXPECT_NEAR(energy, expectedEnergies[indx], 1E-10);
    }
  }

  // Check only interaction terms
  TEST(AIM_SpinOrbit, atomicLimit) {
    //calculates the atomic limit groundstate energy for several sectors
    //of spin and particle number for the Kanamori Hamiltonian including
    //spin flip and pair hopping terms. Compares these calculations to
    //the analytic results.

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps = {-0.1, 1000, 1000};
    const dvec V   = {0., 0.};

    const H_int hint(1., 0.1, 0.8, false);
    const bath b(eps, V, 3, "up", "dn");
    hloc e0({0, 0, 0}, 3, "up", "dn");

    Args args{"Cutoff", 1E-15, "maxsweeps", 3, "verbose", false, "NAppH", 0};
    AIM_ForkSites sites(N, NArms, {"conserveSz", false});
    ForkTPS GS;

    ForkTPO H = ForkTPO(AIM_SpinOrbit(sites, b, e0, hint));

    const std::vector<double> expectedEnergies = {
       //2 Part
       hint.U - 1 * hint.J, //double Occ
       hint.U - 3 * hint.J, //up-down
       hint.U - 3 * hint.J, //up-down
       hint.U - 3 * hint.J, //up-down
       hint.U - 3 * hint.J, //up-up
       hint.U - 3 * hint.J, //dn-dn

       //3 Part
       3 * hint.U - 9 * hint.J, //up-up-up
       3 * hint.U - 9 * hint.J, //dn-dn-dn
       3 * hint.U - 6 * hint.J, //double-up
       3 * hint.U - 9 * hint.J  //up-dn-dn
    };

    const std::vector<std::vector<int>> occImps = {{1, 2}, {1, 4}, {1, 6}, {3, 6}, {1, 3}, {2, 4}, {1, 3, 5}, {2, 4, 6}, {1, 2, 3}, {1, 4, 6}};

    for (auto i : itertools::range(expectedEnergies.size())) {
      auto expectedEnergy = expectedEnergies.at(i);
      InitState init(sites);
      for (auto site : occImps.at(i)) init.set(H.ImpSite(site), "Occ");

      GS = ForkTPS(init, NArms);
      for (int j = 0; j < 3; ++j) {
        GS = forktps::exactApplyMPO(GS, H, args);
        GS.normalize();
      }

      double energy = 0;
      forktps::DMRG(GS, H, energy, args);

      EXPECT_NEAR(energy, expectedEnergy, 1E-12);
    }
  }

  /// Compares the groundstate of the Spin-Orbit FTPO with the ground state of the NonDiagBath FTPO
  /// In this comparison we include interactions of strength U between all orbitals i.e, Up = U, J=0.
  /// Note that for any finite J these two calculations should not give the same result.
  /// Even in this case, the orbitals are not really equivalent to each other (although they are in the
  /// expectation values we look at). For example site Bdn in the NonDiagBath calculation is equivalent
  /// to site Bup in the SpinOrbit calculation.
  TEST(AIM_SpinOrbit, OffDiagHyb_CompareToOffdiag) {

    const int N = 18, NArms = 6, NBath = 2;
    const dvec e   = {0., -0.5, 0.};
    const Dmat eps = {e, e, e, e, e, e};
    const Cmat V   = {{0.10, 0.20, 0.00, 0.00, 0.0, 0.0}, {0.10, 0.20, 0.00, 0.00, 0.0, 0.0}, {0.05, 0.06, 0.10, 0.20, 0.0, 0.0},
                    {0.05, 0.06, 0.10, 0.20, 0.0, 0.0}, {0.05, 0.06, 0.05, 0.06, 0.1, 0.2}, {0.05, 0.06, 0.05, 0.06, 0.1, 0.2}};

    const H_int hint(1.0, 0.0, 1.0, true);
    const bath b(eps, V, 3, "up", "dn", true);
    hloc e0({0, 0, 0}, 3, "up", "dn");

    itensor::seedRNG(SEED_RNG);
    Args args{"Cutoff", 1E-15, "maxsweeps", 25, "verbose", false, "NAppH", 2};
    AIM_ForkSites sites_SO(N, NArms, {"conserveSz", false});
    AIM_ForkSites sites_OD(N, NArms);
    ForkTPS GS_SO, GS_OD;

    ForkTPO H_SO = ForkTPO(AIM_SpinOrbit(sites_SO, b, e0, hint));
    ForkTPO H_OD = ForkTPO(AIM_OffDiag(sites_OD, b, e0, hint));

    const std::vector<std::vector<int>> occSiteses = {{1}, {2}, {1, 2, 3, 4}};

    for (auto [indx, occsites] : itertools::enumerate(occSiteses)) {
      //initialize MPS with the current number of particles
      InitState init(sites_SO);
      for (auto site : occsites) init.set(H_SO.ImpSite(site), "Occ");
      GS_SO = ForkTPS(init, NArms);

      init = itensor::InitState(sites_OD);
      for (auto site : occsites) init.set(H_OD.ImpSite(site), "Occ");
      GS_OD = ForkTPS(init, NArms);

      for (auto j : range1(10)) {
        UNUSED_VAR(j);
        GS_SO = forktps::exactApplyMPO(GS_SO, H_SO, args);
        GS_SO.normalize();

        GS_OD = forktps::exactApplyMPO(GS_OD, H_OD, args);
        GS_OD.normalize();
      }
      double energy_SO = 0, energy_OD = 0;
      forktps::DMRG(GS_SO, H_SO, energy_SO, args);
      forktps::DMRG(GS_OD, H_OD, energy_OD, args);

      EXPECT_NEAR(energy_SO, energy_OD, 1E-10);

      for (auto arm : range1(NArms)) {
        int arm_SO = 0; // arm_SO is the arm in the SO calculation which is equivalent to arm in OD
        if (arm == 1 || arm == 2)
          arm_SO = arm;
        else if (arm % 2 == 0)
          arm_SO = arm - 1;
        else
          arm_SO = arm + 1;

        //Bath
        for (auto indx2 : range1(NBath)) {
          auto val_OD = forktps::Measure(GS_OD, "Nk", GS_OD.ArmToSite(arm, indx2));
          auto val_SO = forktps::Measure(GS_SO, "Nk", GS_SO.ArmToSite(arm_SO, indx2));
          EXPECT_NEAR(val_OD, val_SO, 1E-05);
        }

        //Imp
        auto val_OD = forktps::Measure(GS_OD, "Nk", GS_OD.ImpSite(arm));
        auto val_SO = forktps::Measure(GS_SO, "Nk", GS_SO.ImpSite(arm_SO));
        EXPECT_NEAR(val_OD, val_SO, 1E-05);
      }
    }
  }

  double calcGS_DiagH(dvec eps, dvec V, IntParams Ip, int NArms, const SiteSet &sites, ForkTPS &GS, Args &args) {

    ForkTPO H = ForkTPO(AIM(sites, eps, V, Ip.U, Ip.Up, Ip.J, NArms, args));

    //PrintBorderLine(2);
    H.position(1);
    H.position(length(sites));

    std::vector<int> occSites = {1, 2, 4, 5, 7, 8, 10, 11};
    if (NArms == 6) {
      occSites.push_back(13);
      occSites.push_back(14);
      occSites.push_back(16);
      occSites.push_back(17);
    }

    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    GS = ForkTPS(init, NArms);

    for (int i = 0; i < 10; ++i) {
      GS = forktps::exactApplyMPO(GS, H, args);
      GS.normalize();
    }

    double energy(0.);
    forktps::DMRG(GS, H, energy, args);

    Args argsLoc = args;
    argsLoc.add("NAppH", 0);
    DMRG(GS, H, energy, argsLoc);

    return energy;
  }

  double calcGS_OffDiagH(Dmat eps, Cmat V, IntParams Ip, int NArms, const SiteSet &sites, ForkTPS &GS, Args &args) {
    bath b(eps, V, int(NArms / 2), "up", "dn", true);
    hloc e0(eps, int(NArms / 2), "up", "dn");
    ForkTPO H = ForkTPO(AIM_OffDiag(sites, b, e0, Ip.U, Ip.Up, Ip.J, args));

    //PrintBorderLine(2);
    H.position(1);
    H.position(length(sites));

    std::vector<int> occSites = {1, 2, 4, 5, 7, 8, 10, 11};
    if (NArms == 6) {
      occSites.push_back(13);
      occSites.push_back(14);
      occSites.push_back(16);
      occSites.push_back(17);
    }
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    GS = ForkTPS(init, NArms);

    for (int i = 0; i < 10; ++i) {
      UNUSED_VAR(i);
      GS = forktps::exactApplyMPO(GS, H, args);
      GS.normalize();
    }

    double energy(0.);
    forktps::DMRG(GS, H, energy, args);

    Args argsLoc = args;
    argsLoc.add("NAppH", 0);
    DMRG(GS, H, energy, argsLoc);

    return energy;
  }

  double DD_Energy(std::vector<std::string> i, double e0, IntParams Ip) {

    double expectedEnergy = 0;
    int Norbs             = int(i.size() / 2);

    //on-site energies
    for (auto str : i) {
      if (str == "Occ") expectedEnergy += e0;
    }

    //U
    for (auto orb : itertools::range(Norbs)) {
      if (i[2 * orb] == "Occ" && i[2 * orb + 1] == "Occ") expectedEnergy += Ip.U;
    }

    // U - 2J
    for (auto orb1 : itertools::range(Norbs)) {
      auto s1 = 2 * orb1;
      for (auto orb2 : itertools::range(orb1 + 1, Norbs)) {
        auto s2 = 2 * orb2 + 1;
        if (i[s1] == "Occ" && i[s2] == "Occ") expectedEnergy += Ip.U - 2 * Ip.J;
      }

      s1 = 2 * orb1 + 1;
      for (auto orb2 : itertools::range(orb1 + 1, Norbs)) {
        auto s2 = 2 * orb2;
        if (i[s1] == "Occ" && i[s2] == "Occ") expectedEnergy += Ip.U - 2 * Ip.J;
      }
    }

    //U - 3J
    for (auto orb1 : itertools::range(Norbs)) {
      auto s1 = 2 * orb1;
      for (auto orb2 : itertools::range(orb1 + 1, Norbs)) {
        auto s2 = 2 * orb2;
        if (i[s1] == "Occ" && i[s2] == "Occ") expectedEnergy += Ip.U - 3 * Ip.J;
      }

      s1 = 2 * orb1 + 1;
      for (auto orb2 : itertools::range(orb1 + 1, Norbs)) {
        auto s2 = 2 * orb2 + 1;
        if (i[s1] == "Occ" && i[s2] == "Occ") expectedEnergy += Ip.U - 3 * Ip.J;
      }
    }

    return expectedEnergy;
  }

} // namespace forktps
