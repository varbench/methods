#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/FTPO/AIM_OffDiag.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/Tevo/AIM_ForkGates.hpp>
#include <forktps/fork/TevoMethods.hpp>
#include <forktps/fork/ForkLocalOp.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/fork/makros.hpp>

#include "gtest/gtest.h"
#include "TestHelpers.hpp"
#include "forktps/fork/HelperFunctions.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>

#include <iomanip>
#include <itensor/types.h>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

const int SEED_RNG(1598745);

TEST(TDVP, AllButOneChannelEmpty) {
  //Checks the TDVP time evolution for a 2 orbital model with
  //diagonal hybridizations, where only on channel is occupied
  //at a time. The following python code produces the comparison
  // def calcExactGF(T, t, Np, indx=0):
  //     D,V = np.linalg.eigh(T)
  //     Vdag = np.conj( V.transpose() )
  //     GF = np.zeros(t.shape, dtype=np.complex128)

  //     print(sum(D[:Np]) )

  //     for o in range(len(t)):
  //         expon = np.exp(  -1j*t[o]*D )
  //         expon[:Np] = 0

  //         mat = np.dot(V, np.dot( np.diag(expon), Vdag) )
  //         GF[o] = mat[indx,indx]
  //     return  GF

  // eps = [0., 1 , 0  ,-1  ]
  // V   = [0.3, 0.2, 0.1]
  // mat = np.diag(eps)
  // for i in range(len(V)):
  //     mat[0,i+1] = V[i]
  //     mat[i+1,0] = V[i]

  // D,V = np.linalg.eigh(mat)

  // Vdag = np.conj( V.transpose() )
  // FS = np.ones(len(D), dtype=np.float64);
  // FS[2:] = 0
  // t = np.array(range(5001))*0.001
  // Ggr = calcExactGF(mat, t, 2)

  itensor::seedRNG(SEED_RNG);
  const int N = 16, NArms = 4;
  const std::vector<double> eps = {0., -1, 0, 1};
  const std::vector<double> V   = {0.1, 0.2, 0.3};

  const double dt = 0.5, dt_ex = 0.001;
  int NTimeSteps   = static_cast<int>(std::round(5 / dt));
  int CompareEvery = static_cast<int>(std::round(dt / dt_ex));
  Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3, "TevoMethod", "TDVP_2"};

  std::vector<Complex> ExactGF;
  GetExactGF(ExactGF, "TestGF.ref.txt");

  AIM_ForkSites sites(N, NArms);

  for (auto ch : {1, 2, 3, 4}) {

    std::vector<int> occSites = {4 * (ch - 1) + 1, 4 * (ch - 1) + 2};

    std::vector<double> times(0);

    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");
    ForkTPS psi(init, NArms);

    double U = 0, Up = 0, J = 0;
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, {"DDonly", true}));

    for (auto i : range1(5)) {
      UNUSED_VAR(i);
      psi = forktps::exactApplyMPO(psi, H, args);
      psi.normalize();
    }

    double energy(0.);
    forktps::DMRG(psi, H, energy, args);

    psi.ApplySingleSiteOp(sites.op("CkD", psi.ImpSite(ch)), psi.ImpSite(ch), true);
    ForkTPS psiT = psi, psiT_Bra = psi;
    double StartNorm = psiT.norm();

    std::vector<Complex> GF(0);

    times.push_back(0);
    GF.push_back(forktps::overlap(psiT_Bra, psiT));

    forktps::ForkLocalOp Heff(H);

    for (auto i : range1(NTimeSteps)) {
      TDVP(psiT, Heff, Complex_i * dt, args);
      psiT *= StartNorm / psiT.norm();
      CheckLinks(psiT);
      GF.push_back(overlap(psi, psiT) * std::exp(Complex_i * energy * i * dt));
      times.push_back(i * dt);
    }

    for (auto i : range1(NTimeSteps)) {
      auto diff = std::abs(ExactGF.at(CompareEvery * i) - GF.at(i));
      EXPECT_NEAR(diff, 0, 1E-13);
    }
  }
}

TEST(TDVP, AllChannelsFilled) {
  //same test as "AllButOneChannelEmpty", just
  //that all particles in all Arms are present
  //not they still do not interact with each other
  const int N = 16, NArms = 4;
  const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14};
  const std::vector<double> eps   = {0., -1, 0, 1};
  const std::vector<double> V     = {0.1, 0.2, 0.3};
  Args args{"Cutoff", 1E-16, "maxsweeps", 20, "verbose", false, "NAppH", 3, "TevoMethod", "TDVP_2"};
  const double dt = 1.0, dt_ex = 0.001;
  int NTimeSteps   = static_cast<int>(std::round(5 / dt));
  int CompareEvery = static_cast<int>(std::round(dt / dt_ex));
  std::vector<Complex> ExactGF;
  GetExactGF(ExactGF, "TestGF.ref.txt");

  itensor::seedRNG(SEED_RNG);

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  double U = 0, Up = 0, J = 0;

  ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, {"DDonly", true}));

  for (auto i : range1(5)) {
    UNUSED_VAR(i);
    psi = forktps::exactApplyMPO(psi, H, args);
    psi.normalize();
  }

  double energy(0.);
  forktps::DMRG(psi, H, energy, args);

  for (auto ch : range1(NArms)) {
    int site       = psi.ImpSite(ch);
    ForkTPS CkDpsi = psi;
    CkDpsi.ApplySingleSiteOp(sites.op("CkD", site), site, true);
    ForkTPS psiT     = CkDpsi;
    double StartNorm = psiT.norm();
    std::vector<Complex> GF(0);
    GF.push_back(0 * Complex_i);

    forktps::ForkLocalOp Heff(H);

    for (auto i : range1(NTimeSteps)) {
      TDVP(psiT, Heff, Complex_i * dt, args);
      psiT *= StartNorm / psiT.norm();
      if (i % 1 == 0) GF.push_back(overlap(CkDpsi, psiT) * std::exp(Complex_i * energy * (i)*dt));
    }

    for (auto i : range1(NTimeSteps)) {
      auto diff = std::abs(ExactGF[CompareEvery * i] - GF[i]);
      EXPECT_NEAR(diff, 0, 1E-12);
    }
  }
}

TEST(TDVP, CompareToGateTevo) {
  //Compares Gate time evolution to TDVP for a 2 orbital model

  itensor::seedRNG(SEED_RNG);
  const int N = 16, NArms = 4;
  const std::vector<double> eps = {0., -1, 0, 1};
  const std::vector<double> V   = {0.1, 0.2, 0.3};

  const double dtTDVP = 0.5, dtGates = 0.01;
  const int compEvery       = static_cast<int>(std::round(dtTDVP / dtGates));
  const int NTimeStepsTDVP  = static_cast<int>(std::round(5 / dtTDVP));
  const int NTimeStepsGates = static_cast<int>(std::round(5 / dtGates));
  Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3, "TevoMethod", "TDVP_2"};

  AIM_ForkSites sites(N, NArms);

  const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14};

  std::vector<double> timesGate(0), timesTDVP(0);

  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");
  ForkTPS psi(init, NArms);

  double U = 1, Up = U, J = 0;
  ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, {"DDonly", true}));

  for (auto i : range1(5)) {
    UNUSED_VAR(i);
    psi = forktps::exactApplyMPO(psi, H, args);
    psi.normalize();
  }

  double energy(0.);
  forktps::DMRG(psi, H, energy, args);

  psi.ApplySingleSiteOp(sites.op("CkD", psi.ImpSite(1)), psi.ImpSite(1), true);
  ForkTPS psiT_TDVP = psi, psiT_Gate = psi;

  double StartNorm = psi.norm();

  std::vector<Complex> GF_TDVP(0), GF_Gate(0);
  timesGate.push_back(0);
  timesTDVP.push_back(0);
  GF_TDVP.push_back(forktps::overlap(psi, psiT_TDVP));
  GF_Gate.push_back(forktps::overlap(psi, psiT_Gate));

  forktps::ForkLocalOp Heff(H);

  bath b(eps, V, NArms / 2);
  hloc e0(eps, NArms / 2);
  auto gates  = createAIMGates(Complex_i * dtGates, b, e0, sites);
  auto ImpMPO = DD_MPO(Complex_i * dtGates / 2, {U, J, Up, false}, sites);

  Complex factor;
  for (auto i : range1(NTimeStepsTDVP)) {
    TDVP(psiT_TDVP, Heff, Complex_i * dtTDVP, args);
    psiT_TDVP *= StartNorm / psiT_TDVP.norm();

    factor = std::exp(Complex_i * energy * i * dtTDVP);
    GF_TDVP.push_back(overlap(psi, psiT_TDVP) * factor);
    timesTDVP.push_back(i * dtTDVP);
  }
  for (auto i : range1(NTimeStepsGates)) {
    psiT_Gate.ZipUpImpurityMPO(ImpMPO, args);
    for (auto g : gates) ApplyGate(psiT_Gate, g, Rightwards, args);
    psiT_Gate.ZipUpImpurityMPO(ImpMPO, args);

    factor = std::exp(Complex_i * energy * i * dtGates);
    GF_Gate.push_back(overlap(psi, psiT_Gate) * factor);
    timesGate.push_back(i * dtGates);
  }

  for (auto i : range1(std::min(NTimeStepsGates, NTimeStepsTDVP))) {
    auto diff = std::abs(GF_Gate.at(compEvery * i) - GF_TDVP.at(i));
    EXPECT_NEAR(diff, 0, 1E-5);
  }
}

TEST(TDVP, OffDiagHyb_2Band) {
  //Tests TDVP for an off-diagonal 2 orbital model with
  //hybridizations diagonal in spin space.
  //The exact solution is written to the file "Comparison/TestGF_offDiag.txt"
  //and can be obtained from the following python code using the "calcExactGF"
  //function defined in the test "AllButOneChannelEmpty".
  //note that the off-diagonl hybridizations break orbital degeneracy and hence
  //two different GFs exist
  // V1diag = [0.1, 0.2, 0.3]
  // V2diag = [0.3,  0.2,  0.10]
  // Vod = [0.05, 0.06, 0.07]

  // eps = [0., 0. , -1, -1, 0., 0., 1., 1.];
  // mat = np.zeros( (8,8), dtype = np.float64 )
  // for i in range(3):
  //     mat[0, 2 + 2*i ] = V1diag[i]
  //     mat[2 + 2*i, 0 ] = V1diag[i]
  //     mat[1, 2 + 2*i +1 ] = V2diag[i]
  //     mat[2 + 2*i+1, 1 ] = V2diag[i]
  //     mat[1, 2 + 2*i ] = Vod[i]
  //     mat[2 + 2*i, 1 ] = Vod[i]

  // for i in range(8):
  //     mat[i,i] = eps[i]
  // t = np.array(range(5001))*0.001
  // Ggr1 = calcExactGF(mat, t, 4,0)
  // Ggr2 = calcExactGF(mat, t, 4,1)
  const int N = 16, NArms = 4;
  const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14};

  std::vector<double> e = {0., -1, 0, 1};
  Dmat eps(NArms);
  for (auto i : itertools::range(NArms)) eps.at(i) = e;
  const Cmat V = {
     {0.10, 0.20, 0.30, 0.0, 0.0, 0.0}, {0.10, 0.20, 0.30, 0.0, 0.0, 0.0}, {0.05, 0.06, 0.07, 0.3, 0.2, 0.1}, {0.05, 0.06, 0.07, 0.3, 0.2, 0.1}};

  Args args{"Cutoff", 1E-13, "maxsweeps", 20, "verbose", false, "NAppH", 1, "TevoMethod", "TDVP_2"};

  const double dt = 1.0, dt_ex = 0.001;
  const int NTimeSteps   = static_cast<int>(std::round(5 / dt));
  const int CompareEvery = static_cast<int>(std::round(dt / dt_ex));

  itensor::seedRNG(SEED_RNG);

  std::vector<std::vector<Complex>> ExactGF;
  GetExactGF_offDiag(ExactGF, "OffDiag_2Orbs.ref.txt");

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  double U = 0, Up = 0, J = 0;
  ITENSOR_Print("create bath");
  bath b(eps, V, int(NArms / 2), "up", "dn", true);
  hloc e0(eps, int(NArms / 2));
  ITENSOR_Print("create mpo");
  ForkTPO H = ForkTPO(AIM_OffDiag(sites, b, e0, U, Up, J, args));

  std::cout << b << std::endl << e0 << std::endl;

  for (auto i : range1(5)) {
    UNUSED_VAR(i);
    psi = forktps::exactApplyMPO(psi, H, args);
    psi.normalize();
  }
  double energy(0.);
  forktps::DMRG(psi, H, energy, args);

  int GFcount = 1;

  for (auto ch : {1, 3}) {
    int site       = psi.ImpSite(ch);
    ForkTPS CkDpsi = psi;
    CkDpsi.ApplySingleSiteOp(sites.op("CkD", site), site, true);
    ForkTPS psiT     = CkDpsi;
    double StartNorm = psiT.norm();
    std::vector<Complex> GF(0);
    GF.push_back(0 * Complex_i);

    forktps::ForkLocalOp Heff(H);

    for (auto i : range1(NTimeSteps)) {
      TDVP(psiT, Heff, Complex_i * dt, args);
      psiT *= StartNorm / psiT.norm();
      GF.push_back(overlap(CkDpsi, psiT) * std::exp(Complex_i * energy * (i)*dt));
    }

    for (auto i : range1(NTimeSteps)) {
      auto diff = std::abs(ExactGF.at(GFcount)[CompareEvery * i] - GF[i]);
      EXPECT_NEAR(diff, 0, 1E-6);
    }

    GFcount++;
  }
}

TEST(TwoSiteTDVP, OffDiagHyb_2Band) {
  //Tests TDVP for an off-diagonal 2 orbital model with
  //hybridizations diagonal in spin space.
  //The exact solution is written to the file "Comparison/TestGF_offDiag.txt"
  //and can be obtained from the following python code using the "calcExactGF"
  //function defined in the test "AllButOneChannelEmpty".
  //note that the off-diagonl hybridizations break orbital degeneracy and hence
  //two different GFs exist
  // V1diag = [0.1, 0.2, 0.3]
  // V2diag = [0.3,  0.2,  0.10]
  // Vod = [0.05, 0.06, 0.07]

  // eps = [0., 0. , -1, -1, 0., 0., 1., 1.];
  // mat = np.zeros( (8,8), dtype = np.float64 )
  // for i in range(3):
  //     mat[0, 2 + 2*i ] = V1diag[i]
  //     mat[2 + 2*i, 0 ] = V1diag[i]
  //     mat[1, 2 + 2*i +1 ] = V2diag[i]
  //     mat[2 + 2*i+1, 1 ] = V2diag[i]
  //     mat[1, 2 + 2*i ] = Vod[i]
  //     mat[2 + 2*i, 1 ] = Vod[i]

  // for i in range(8):
  //     mat[i,i] = eps[i]
  // t = np.array(range(5001))*0.001
  // Ggr1 = calcExactGF(mat, t, 4,0)
  // Ggr2 = calcExactGF(mat, t, 4,1)
  const int N = 16, NArms = 4;
  const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14};

  const std::vector<double> e = {0., -1, 0, 1};
  Dmat eps(NArms + 1);
  for (auto i : itertools::range(NArms)) eps.at(i) = e;
  const Cmat V = {
     {0.10, 0.20, 0.30, 0.0, 0.0, 0.0}, {0.10, 0.20, 0.30, 0.0, 0.0, 0.0}, {0.05, 0.06, 0.07, 0.3, 0.2, 0.1}, {0.05, 0.06, 0.07, 0.3, 0.2, 0.1}};

  Args args{"Cutoff", 1E-13, "maxsweeps", 20, "verbose", false, "NAppH", 1, "TevoMethod", "TDVP"};

  const double dt = 1.0, dt_ex = 0.001;
  const int NTimeSteps   = static_cast<int>(std::round(5 / dt));
  const int CompareEvery = static_cast<int>(std::round(dt / dt_ex));

  itensor::seedRNG(SEED_RNG);

  std::vector<std::vector<Complex>> ExactGF;
  GetExactGF_offDiag(ExactGF, "OffDiag_2Orbs.ref.txt");

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  double U = 0, Up = 0, J = 0;
  bath b(eps, V, int(NArms / 2), "up", "dn", true);
  hloc e0(eps, int(NArms / 2));
  ForkTPO H = ForkTPO(AIM_OffDiag(sites, b, e0, U, Up, J, args));
  H.position(N);
  H.position(1);

  for (auto i : range1(5)) {
    UNUSED_VAR(i);
    psi = forktps::exactApplyMPO(psi, H, args);
    psi.normalize();
  }
  double energy(0.);
  forktps::DMRG(psi, H, energy, args);

  int GFcount = 1;

  for (auto ch : {1, 3}) {
    int site       = psi.ImpSite(ch);
    ForkTPS CkDpsi = psi;
    CkDpsi.ApplySingleSiteOp(sites.op("CkD", site), site, true);
    ForkTPS psiT     = CkDpsi;
    double StartNorm = psiT.norm();
    std::vector<Complex> GF(0);
    GF.push_back(0 * Complex_i);

    forktps::ForkLocalOp Heff(H);

    for (auto i : range1(NTimeSteps)) {
      TDVP(psiT, Heff, Complex_i * dt, args);
      psiT *= StartNorm / psiT.norm();
      GF.push_back(overlap(CkDpsi, psiT) * std::exp(Complex_i * energy * (i)*dt));
    }

    for (auto i : range1(NTimeSteps)) {
      auto diff = std::abs(ExactGF.at(GFcount)[CompareEvery * i] - GF[i]);
      EXPECT_NEAR(diff, 0, 1E-6);
    }

    GFcount++;
  }
}

TEST(TDVP, OffDiagHyb_3Band) {
  //Tests TDVP for an off-diagonal 2 orbital model with
  //hybridizations diagonal in spin space.
  //The exact solution is written to the file "Comparison/TestGF_offDiag.txt"
  //and can be obtained from the following python code using the "calcExactGF"
  //function defined in the test "AllButOneChannelEmpty".
  //note that the off-diagonl hybridizations break orbital degeneracy and hence
  //two different GFs exist
  // V1diag = [0.1, 0.2, 0.3]
  // V2diag = [0.3,  0.2,  0.10]
  // Vod = [0.05, 0.06, 0.07]

  // eps = [0., 0. , -1, -1, 0., 0., 1., 1.];
  // mat = np.zeros( (8,8), dtype = np.float64 )
  // for i in range(3):
  //     mat[0, 2 + 2*i ] = V1diag[i]
  //     mat[2 + 2*i, 0 ] = V1diag[i]
  //     mat[1, 2 + 2*i +1 ] = V2diag[i]
  //     mat[2 + 2*i+1, 1 ] = V2diag[i]
  //     mat[1, 2 + 2*i ] = Vod[i]
  //     mat[2 + 2*i, 1 ] = Vod[i]

  // for i in range(8):
  //     mat[i,i] = eps[i]
  // t = np.array(range(5001))*0.001
  // Ggr1 = calcExactGF(mat, t, 4,0)
  // Ggr2 = calcExactGF(mat, t, 4,1)
  const int N = 24, NArms = 6;
  const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14, 17, 18, 21, 22};

  const std::vector<double> e = {0., -1, 0, 1};
  Dmat eps(NArms + 1);
  for (auto i : itertools::range(NArms)) eps.at(i) = e;
  const Cmat V = {{0.10, 0.20, 0.30, 0.00, 0.00, 0.00, 0.0, 0.0, 0.0}, {0.10, 0.20, 0.30, 0.00, 0.00, 0.00, 0.0, 0.0, 0.0},
                  {0.05, 0.06, 0.07, 0.30, 0.20, 0.10, 0.0, 0.0, 0.0}, {0.05, 0.06, 0.07, 0.30, 0.20, 0.10, 0.0, 0.0, 0.0},
                  {0.05, 0.06, 0.07, 0.05, 0.06, 0.07, 0.3, 0.2, 0.1}, {0.05, 0.06, 0.07, 0.05, 0.06, 0.07, 0.3, 0.2, 0.1}};

  Args args{"Cutoff", 1E-12, Names::MAXMI, 100, "maxsweeps", 20, "verbose", false, "NAppH", 1, "TevoMethod", "TDVP_2"};

  const double dt = 1.0, dt_ex = 0.001;
  const int NTimeSteps   = static_cast<int>(std::round(5 / dt));
  const int CompareEvery = static_cast<int>(std::round(dt / dt_ex));
  itensor::seedRNG(SEED_RNG);

  std::vector<std::vector<Complex>> ExactGF;
  GetExactGF_offDiag(ExactGF, "OffDiag_3Orbs.ref.txt");

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  double U = 0, Up = 0, J = 0;
  bath b(eps, V, int(NArms / 2), "up", "dn", true);
  hloc e0(eps, int(NArms / 2));
  ForkTPO H = ForkTPO(AIM_OffDiag(sites, b, e0, U, Up, J, args));
  H.position(N);
  H.position(1);

  for (auto i : range1(5)) {
    UNUSED_VAR(i);
    psi = forktps::exactApplyMPO(psi, H, args);
    psi.normalize();
  }

  double energy(0.);
  forktps::DMRG(psi, H, energy, args);

  int GFcount = 1;

  EXPECT_NEAR(-7.496926515935597, energy, 1E-06);

  for (auto ch : {1, 3}) {
    int site       = psi.ImpSite(ch);
    ForkTPS CkDpsi = psi;
    CkDpsi.ApplySingleSiteOp(sites.op("CkD", site), site, true);
    ForkTPS psiT     = CkDpsi;
    double StartNorm = psiT.norm();
    std::vector<Complex> GF(0);
    GF.push_back(0 * Complex_i);

    forktps::ForkLocalOp Heff(H);

    for (auto i : range1(NTimeSteps)) {
      TDVP(psiT, Heff, Complex_i * dt, args);
      psiT *= StartNorm / psiT.norm();
      GF.push_back(overlap(CkDpsi, psiT) * std::exp(Complex_i * energy * (i)*dt));

      //std::cout<< "[ " << i*dt << ", " << std::real(GF.back()) << " +1j* " << std::imag(GF.back())<<"],"<< std::endl;
    }

    for (auto i : range1(NTimeSteps)) {
      auto diff = std::abs(ExactGF.at(GFcount)[CompareEvery * i] - GF[i]);
      EXPECT_NEAR(diff, 0, 1E-6);
    }

    GFcount++;
  }
}

TEST(TDVP, OneOrb_TEBDvsTDVP) {
  const int NArms = 2, N = 4 * (NArms);
  const double U = 0, dt = 0.05;
  ;
  AIM_ForkSites sites(N, NArms);
  Args args{"Cutoff", 1E-13, "maxsweeps", 20, "verbose", true, "NAppH", 2, "TevoMethod", "TDVP"};

  const std::vector<int> occSites = {2, 3, 6, 7};
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS GS(init, NArms);

  const bath b(
     {
        0.,
        -.1,
        0.,
        .1,
     },
     {0.2, 0.2, 0.2}, 1);
  const hloc e0(
     {
        0.,
        -.1,
        0.,
        .1,
     },
     1);
  const H_int hint(U, 0, 0, true);

  ForkTPO H = ForkTPO(AIM(sites, b, e0, hint, args));

  for (auto i : range1(4)) {
    UNUSED_VAR(i);
    GS = exactApplyMPO(GS, H, args);
    GS.normalize();
  }

  double energy(0.);
  DMRG(GS, H, energy, args);

  ForkTPS psi0 = GS, psiTEBD, psiTDVP;
  psi0.ApplySingleSiteOp(sites.op("Ck", 1), 1, true);
  psiTEBD = psi0;
  psiTDVP = psi0;

  args.add("E0Shift", -energy);
  H = ForkTPO(AIM(sites, b, e0, hint, args));

  auto Ops = TEBD_container(hint, b, e0, Complex_i * dt, sites);
  ForkLocalOp Heff(H);

  for (auto i : range1(10)) {
    UNUSED_VAR(i);
    TDVP(psiTDVP, Heff, Complex_i * dt, args);

    TEBD(psiTEBD, Ops, args);
    psiTEBD *= std::exp(Complex_i * dt * energy);

    auto TDVP = overlap(psi0, psiTDVP);
    auto TEBD = overlap(psi0, psiTEBD);

    EXPECT_NEAR(TDVP.real(), TEBD.real(), 1E-5);
    EXPECT_NEAR(TDVP.imag(), TEBD.imag(), 1E-5);
  }
}
