#include <forktps/fork/ForkTPO.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <gtest/gtest.h>

#include <cmath>
#include <iomanip>
#include <vector>
#include <complex>

#include "TestHelpers.hpp"

using namespace itensor;
using namespace std;
using namespace forktps;

//todo write tests for read/write

TEST(FTPO, SiteSetConstructor) {
  //Check that the constructor using the site set produces identity tensors
  //also checks whether each tensor has the correct indices using commonIndex()
  const int N = 20, NArms = 4;

  AIM_ForkSites sites(N, NArms);

  ForkTPO H(sites, NArms);
  CheckUnityTensor(H);
}

TEST(FTPO, LinkTags) {
  //Test if the linkTags are correct after the contructor and after position() function
  const int N = 16, NArms = 4;

  AIM_ForkSites sites(N, NArms);
  ForkTPO H(sites, NArms);
  CheckAllTags(H);

  for (auto i : range1(N)) {
    H.position(i);
    CheckAllTags(H);
  }
}
