//#include <forktps/fork/Bath.hpp>

//#include "forktps/types.hpp"

#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/SiteSets/AIM_ForkSites.hpp"
#include "forktps/fork/typenames.hpp"

#include <itensor/mps/mps.h>
#include <itertools/itertools.hpp>
#include <triqs/operators/many_body_operator.hpp>

using namespace nda;
using namespace triqs::utility;
using namespace h5;

#include <nda/nda.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/GFComponent.hpp>
#include "gtest/gtest.h"

using namespace forktps;

void MYDAG(monomial_t &m) {
  for (auto &o : m) o.dagger = !o.dagger;
}

void InitFTPS(ForkTPS &psi, const std::vector<int> &ImpOccs) {
  InitState init(psi.sites());
  if (ImpOccs.size() != psi.NArms()) Error("Incompatible ImpOccs vector");

  for (auto [indx, occ] : itertools::enumerate(ImpOccs)) {
    int site = psi.ImpSite(indx + 1);
    if (occ == 1) init.set(site, "Occ");
  }

  psi = ForkTPS(init, psi.NArms());
}

using Op = many_body_operator;

// Tests ApplyOp functionality with states either starting empty ending empty
TEST(Component, ApplyOp_T1) {

  int Nb = 3, NArms(4), N(NArms * (Nb + 1));
  bath b({0.0, 0.1, 0.2, 0.3}, {0.1, 0.1, 0.1}, 2);

  AIM_ForkSites sites(N, NArms);
  ForkTPS psi(sites, NArms), ref(sites, NArms);

  std::vector<Op> Oplist{
     c_dag("dn", 1) * c_dag("up", 1),
     c_dag("up", 0) * c_dag("up", 1),
     c("dn", 1) * c("up", 1),
     c("up", 0) * c("dn", 0),
     c("up", 0) * c("dn", 1),
     c_dag("up", 0) * c_dag("up", 1) * c_dag("dn", 0),
     c_dag("dn", 1) * c_dag("up", 1) * c_dag("dn", 0),
     c_dag("up", 1) * c_dag("up", 0) * c_dag("dn", 1),
     c("up", 0) * c("up", 1) * c("dn", 0),
     c("dn", 1) * c("up", 1) * c("dn", 0),
     c("up", 1) * c("up", 0) * c("dn", 1),
     c_dag("up", 0) * c_dag("up", 1) * c_dag("dn", 0) * c_dag("dn", 1),
     c_dag("dn", 1) * c_dag("up", 1) * c_dag("dn", 0) * c_dag("up", 0),
     c("up", 0) * c("up", 1) * c("dn", 1) * c("dn", 0),
     c("dn", 1) * c("up", 1) * c("up", 0) * c("dn", 0),
  };

  std::vector<std::vector<int>> initOcc{{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 1, 1}, {1, 1, 0, 0}, {1, 0, 0, 1},
                                        {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 0}, {0, 1, 1, 1},
                                        {1, 0, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}, {1, 1, 1, 1}};

  std::vector<std::vector<int>> refOcc{{0, 0, 1, 1}, {1, 0, 1, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 0}, {0, 1, 1, 1}, {1, 0, 1, 1},
                                       {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}};

  std::vector<double> expectedOvlp{-1, +1, +1, -1, -1, -1, -1, -1, +1, +1, +1, -1, +1, +1, -1};

  for (auto [indx, gfop] : itertools::enumerate(Oplist)) {

    for (auto m : gfop) {
      std::cout << "Monomial: " << m << std::endl;
      InitFTPS(psi, initOcc.at(indx));
      InitFTPS(ref, refOcc.at(indx));
      GFComponent c(m.monomial, forktps::Ket, Forward);

      ApplyOperator(c.op, psi, b);
      auto val = m.coef * overlap(ref, psi);
      EXPECT_NEAR(real(val), expectedOvlp.at(indx), 1E-14);
    }
  }
}

// Tests ApplyOp functionality with states neither empty at start nor empty at end
TEST(Component, ApplyOp_T2) {

  int Nb = 3, NArms(4), N(NArms * (Nb + 1));
  bath b({0.0, 0.1, 0.2, 0.3}, {0.1, 0.1, 0.1}, 2);

  AIM_ForkSites sites(N, NArms);
  ForkTPS psi(sites, NArms), ref(sites, NArms);

  std::vector<Op> Oplist{c_dag("up", 1),
                         c_dag("dn", 0),
                         c("up", 0),
                         c("dn", 1),
                         c_dag("dn", 1) * c_dag("up", 1),
                         c_dag("up", 0) * c_dag("up", 1),
                         c("dn", 1) * c("up", 1),
                         c("up", 0) * c("dn", 0),
                         c("up", 0) * c("dn", 1)};

  std::vector<std::vector<int>> initOcc{{1, 1, 0, 0}, {1, 0, 0, 1}, {1, 1, 1, 0}, {1, 1, 1, 1}, {1, 0, 0, 0},
                                        {0, 1, 0, 0}, {1, 1, 1, 1}, {1, 1, 0, 1}, {1, 0, 1, 1}};

  std::vector<std::vector<int>> refOcc{{1, 1, 1, 0}, {1, 1, 0, 1}, {0, 1, 1, 0}, {1, 1, 1, 0}, {1, 0, 1, 1},
                                       {1, 1, 1, 0}, {1, 1, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}};

  std::vector<double> expectedOvlp{+1, -1, +1, -1, -1, -1, +1, -1, +1};

  for (auto [indx, gfop] : itertools::enumerate(Oplist)) {

    for (auto m : gfop) {
      std::cout << "Monomial: " << m << std::endl;
      InitFTPS(psi, initOcc.at(indx));
      InitFTPS(ref, refOcc.at(indx));
      GFComponent c(m.monomial, forktps::Ket, Forward);

      ApplyOperator(c.op, psi, b);
      auto val = m.coef * overlap(ref, psi);
      EXPECT_NEAR(real(val), expectedOvlp.at(indx), 1E-14);
    }
  }
}
