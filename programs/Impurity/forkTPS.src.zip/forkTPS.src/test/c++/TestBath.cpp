#include "forktps/fork/typenames.hpp"
#include "forktps/types.hpp"
#include <forktps/fork/Bath.hpp>
#include <forktps/fork/HelperFunctions.hpp>

#include <itensor/types.h>
#include <itertools/itertools.hpp>
#include <vector>

#include "gtest/gtest.h"

using namespace forktps;
using namespace itensor;

TEST(forktps, bath) {
  const std::string blockNameUp("up");
  const std::string blockNameDn("dn");

  const std::vector<Complex> V1{0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10};
  const std::vector<Complex> V2{0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20};
  const std::vector<Complex> V3{0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30};
  const std::vector<Complex> V4{0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40};

  const std::vector<double> eps1{0, 1.0, -0.80, -0.60, -0.40, 0.20, 0.00, 0.20, 0.40, -0.60, 0.80, 1.00};
  const std::vector<double> eps2{0, -1.01, -0.81, -0.61, -0.41, -0.21, 0.01, 0.21, 0.41, 0.61, 0.81, 1.01};
  const std::vector<double> eps3{0, -1.02, -0.82, -0.62, -0.42, -0.22, 0.02, -0.22, -0.42, -0.62, 0.82, -1.02};
  const std::vector<double> eps4{0, 1.03, 0.83, -0.63, -0.43, 0.23, 0.03, 0.23, 0.43, 0.63, 0.83, 1.03};

  Dmat eps = {eps1, eps2, eps3, eps4};
  Cmat V   = {V1, V2, V3, V4};

  int blockSize = 2;

  bath b(eps, V, blockSize, blockNameUp, blockNameDn);
  hloc e0(eps, blockSize, blockNameUp, blockNameDn);

  auto Nneg = b.numNegative();
  EXPECT_EQ(Nneg[0], 4);
  EXPECT_EQ(Nneg[1], 5);
  EXPECT_EQ(Nneg[2], 9);
  EXPECT_EQ(Nneg[3], 2);
}

TEST(forktps, bath_IndexConversion) {

  const int blockSize = 2;

  std::vector<double> eps = {0., 0.1, 0.2};
  std::vector<double> V   = {0.01, 0.01};
  bath b(eps, V, blockSize);

  std::vector<triqs_indx> expectedInds = {{"up", 0}, {"dn", 0}, {"up", 1}, {"dn", 1}};
  for (auto arm : range1(b.NArms())) {
    auto indx = b.FTPSIndxToBlock(arm);

    EXPECT_TRUE(indx == expectedInds.at(arm - 1));
  }

  std::vector<int> FTPSInds = {1, 2, 3, 4};
  for (auto [i, indx] : itertools::enumerate(expectedInds)) { EXPECT_EQ(FTPSInds.at(i), b.blockToFTPSIndx(indx)); }
}

TEST(forktps, e0_accessors) {

  const std::vector<double> eps1{0.00, 1.0};
  const std::vector<double> eps2{0.32, 1.0};
  const std::vector<double> eps3{0.71, 1.0};
  const std::vector<double> eps4{1.50, 1.0};

  Dmat eps = {eps1, eps2, eps3, eps4};

  int blockSize = 2;

  hloc e0(eps, blockSize, "up", "dn");

  // get arrays
  auto mat = e0("up");
  EXPECT_DOUBLE_EQ(std::real(mat(0, 0)), eps1[0]);
  EXPECT_DOUBLE_EQ(std::real(mat(1, 1)), eps3[0]);

  mat = e0("dn");
  EXPECT_DOUBLE_EQ(std::real(mat(0, 0)), eps2[0]);
  EXPECT_DOUBLE_EQ(std::real(mat(1, 1)), eps4[0]);

  // get entries diag
  EXPECT_DOUBLE_EQ(std::real(e0(triqs_indx{"up", 0})), eps1[0]);
  EXPECT_DOUBLE_EQ(std::real(e0(triqs_indx{"up", 1})), eps3[0]);

  EXPECT_DOUBLE_EQ(std::real(e0(triqs_indx{"dn", 0})), eps2[0]);
  EXPECT_DOUBLE_EQ(std::real(e0(triqs_indx{"dn", 1})), eps4[0]);

  // get entries off-diag
  EXPECT_DOUBLE_EQ(std::real(e0({"up", 1}, {"up", 1})), eps3[0]);
  EXPECT_DOUBLE_EQ(std::real(e0({"up", 0}, {"up", 1})), 0.);
  EXPECT_DOUBLE_EQ(std::real(e0({"dn", 1}, {"dn", 0})), 0.);
}

TEST(forktps, bath_OneOrbital) {
  std::string blockNameUp("up");
  std::string blockNameDn("dn");

  const std::vector<Complex> V1{0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10};
  const std::vector<Complex> V2{0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20};

  const std::vector<double> eps1{0.33, 1.0, -0.80, -0.60, -0.40, 0.20, 0.00, 0.20, 0.40, -0.60, 0.80, 1.00};
  const std::vector<double> eps2{0.44, -1.01, -0.81, -0.61, -0.41, -0.21, 0.01, 0.21, 0.41, 0.61, 0.81, 1.01};

  Dmat eps = {eps1, eps2};
  Cmat V   = {V1, V2};

  const int blockSize = 1;
  const int NBath     = 11;

  bath b(eps, V, blockSize, blockNameUp, blockNameDn);
  hloc e0(eps, blockSize, blockNameUp, blockNameDn);

  auto Nneg = b.numNegative();
  EXPECT_EQ(Nneg.at(0), 4);
  EXPECT_EQ(Nneg.at(1), 5);

  // check values
  for (auto bN : {"up", "dn"}) {
    auto &e = (std::strncmp(bN, "up", 2) == 0) ? eps1 : eps2;
    auto &v = (std::strncmp(bN, "up", 2) == 0) ? V1 : V2;
    triqs_indx I{bN, 0};
    for (auto i : itertools::range(NBath)) {
      EXPECT_EQ(e.at(i + 1), b.eps(I, i));
      EXPECT_EQ(v.at(i), b.V(I, i));
    }

    EXPECT_EQ(e0(I), e[0]);
  }
}

TEST(forktps, bath_PHSymm) {
  // tests the particle hole symmetry function
  // for even and odd number of bath sites

  const Dmat V{{0.10, 0.12, 0.13, 0.14}, {0.12, 0.12, 0.13, 0.14, 0.15}};
  const Dmat expectedV{{0.12, 0.125, 0.125, 0.12}, {0.135, 0.13, 0.13, 0.13, 0.135}};

  const Dmat eps{{0, -1.1, -0.7, 0.65, 1.0}, {0, -1.1, -0.7, 0.01, 0.65, 1.0}};

  const Dmat expectedeps{{-1.05, -0.675, 0.675, 1.05}, {-1.05, -0.675, 0., 0.675, 1.05}};

  int blockSize = 2;
  for (auto i : itertools::range(2)) {
    bath b(eps.at(i), V.at(i), blockSize);
    b.MakePHSymmetric();

    for (auto bN : b.blockNames()) {
      for (auto bI : itertools::range(blockSize)) {
        triqs_indx I{bN, bI};
        for (auto k : itertools::range(b.NBath(I))) {
          auto epsDiff = b.eps(I, k) - expectedeps[i][k];
          auto VDiff   = b.V(I, k) - expectedV[i][k];

          EXPECT_NEAR(epsDiff, 0., 1E-15);
          EXPECT_NEAR(VDiff.real(), 0., 1E-15);
        }
      }
    }
  }
}

TEST(forktps, bath_NonEqNb) {
  /// Tests the functions
  bath b({{"up", 2}, {"dn", 2}});
  std::vector<int> Nbs   = {0, 3, 2, 4, 5};
  std::vector<Complex> V = {1.0, 0.0};
  std::vector<double> eps{0., -1.0, 0.0, 1., 2., 3.};

  for (auto i : range1(Nbs.at(1))) b.addSite({"up", 0}, eps.at(i), V);

  for (auto i : range1(Nbs.at(2))) b.addSite({"dn", 0}, eps.at(i), V);

  for (auto i : range1(Nbs.at(3))) b.addSite({"up", 1}, eps.at(i), V);

  for (auto i : range1(Nbs.at(4))) b.addSite({"dn", 1}, eps.at(i), V);

  EXPECT_EQ(b.NBath({"up", 0}), Nbs.at(1));
  EXPECT_EQ(b.NBath({"dn", 0}), Nbs.at(2));
  EXPECT_EQ(b.NBath({"up", 1}), Nbs.at(3));
  EXPECT_EQ(b.NBath({"dn", 1}), Nbs.at(4));

  auto NbFromBath = b.NBathVec();
  for (auto [Nb1, Nb2] : itertools::zip(NbFromBath, Nbs)) { EXPECT_EQ(Nb1, Nb2); }
}

TEST(forktps, bath_todiag) {
  gf_struct_t gfstruct = {{"up", 2}, {"dn", 2}};
  bath b_od(gfstruct);

  cvec V_od = {0.10, 0.05};
  cvec V_d1 = {0.10, 0.00};
  cvec V_d2 = {0.00, 0.10};

  dvec eps = {-1., 1.};

  b_od.addSite({"up", 0}, eps[0], V_od);
  b_od.addSite({"up", 0}, eps[1], V_od);
  b_od.addSite({"dn", 0}, eps[0], V_od);
  b_od.addSite({"dn", 0}, eps[1], V_od);

  b_od.addSite({"up", 1}, eps[0], V_d2);
  b_od.addSite({"up", 1}, eps[1], V_d2);
  b_od.addSite({"dn", 1}, eps[0], V_d2);
  b_od.addSite({"dn", 1}, eps[1], V_d2);

  auto b_d = b_od.todiag();

  for (auto block : b_d.b) {
    for (auto [bI, arm] : itertools::enumerate(block.second)) {

      for (auto site : arm) {
        bool isDiag = true;
        for (auto bJ : itertools::range(block.second.size())) {
          if (bJ == bI)
            isDiag = isDiag && abs(site.V.at(bJ)) > 1E-16;
          else
            isDiag = isDiag && abs(site.V.at(bJ)) < 1E-16;
        }

        EXPECT_TRUE(isDiag);
      }
    }
  }
}

TEST(forktps, hloc_todiag) {
  gf_struct_t gfstruct = {{"up", 2}, {"dn", 2}};
  hloc e0(gfstruct);
  e0.Fill({{1.1, 0.3}, {0.3, 1.2}});

  auto e0diag = e0.todiag();

  for (auto mp : e0diag.e) {
    const auto &e0mat = mp.second;
    for (auto [i, j] : itertools::product_range(mp.second.shape()[0], mp.second.shape()[1])) {
      auto isDiag = true;

      if (i == j)
        isDiag = isDiag && abs(e0mat(i, j)) > 1E-16;
      else
        isDiag = isDiag && abs(e0mat(i, j)) < 1E-16;

      EXPECT_TRUE(isDiag);
    }
  }

  //
  //  for(auto block : b2.b){
  //    for(auto [bI, arm] : itertools::enumerate(block.second) ){
  //
  //      for(auto site : arm){
  //        bool isDiag = true;
  //        for(auto bJ : itertools::range(block.second.size())){
  //          if(bJ == bI) isDiag = isDiag && abs(site.V.at(bJ)) > 1E-16;
  //          else         isDiag = isDiag && abs(site.V.at(bJ)) < 1E-16;
  //        }
  //
  //      EXPECT_TRUE(isDiag);
  //    }
  //  }
  //}
}
