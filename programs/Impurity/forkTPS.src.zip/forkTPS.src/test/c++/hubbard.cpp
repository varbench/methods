/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http:///www.gnu.org/licenses/>.
 *
 ******************************************************************************/

#include <forktps/fork/Fork.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <iomanip>
#include <itensor/itensor.h>
#include <forktps/fork/typenames.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/solver_core.hpp>

#include <functional>
#include <iostream>
#include <itertools/itertools.hpp>
#include <limits>
#include <mpi/mpi.hpp>
#include <triqs/gfs.hpp>
#include <triqs/mesh.hpp>
#include <h5/h5.hpp>

#include <triqs/test_tools/gfs.hpp>
#include <tuple>
#include <utility>
#include <variant>
#include <vector>

using namespace forktps;
using namespace itensor;

std::pair<bath, hloc> GetBath() {

  std::string blockNameUp("up");
  std::string blockNameDn("dn");

  std::vector<Complex> V1{0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10};
  std::vector<Complex> V2{0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20};
  std::vector<Complex> V3{0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30};
  std::vector<Complex> V4{0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40};

  std::vector<double> eps1{0.3, -1.0, -0.80, -0.60, -0.40, -0.20, 0.00, 0.20, 0.40, 0.60, 0.80, 1.00};
  std::vector<double> eps2{0.1, -1.01, -0.81, -0.61, -0.41, -0.21, 0.01, 0.21, 0.41, 0.61, 0.81, 1.01};
  std::vector<double> eps3{0, -1.02, -0.82, -0.62, -0.42, -0.22, 0.02, 0.22, 0.42, 0.62, 0.82, 1.02};
  std::vector<double> eps4{0, -1.03, -0.83, -0.63, -0.43, -0.23, 0.03, 0.23, 0.43, 0.63, 0.83, 1.03};

  Dmat eps = {eps1, eps2, eps3, eps4, eps1, eps1};
  Cmat V   = {V1, V2, V3, V4, V1, V1};

  int blockSize = 2;

  std::vector<double> V2d{0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2};

  //return aim_h0(eps2, V2d, blockSize, blockNameUp, blockNameDn);
  return {bath(eps, V, blockSize, blockNameUp, blockNameDn), hloc(eps, blockSize, blockNameUp, blockNameDn)};
  //return {bath(eps1, V2d, blockSize, blockNameUp, blockNameDn), hloc(eps1, blockSize, blockNameUp, blockNameDn)};
}

std::vector<triqs_indx> BlockIndexIterator(gf_struct_t gfstruct) {

  std::vector<triqs_indx> v(0);
  for (auto [bl_name, bl_size] : gfstruct) {
    for (auto indx : itertools::range(bl_size)) { v.emplace_back(bl_name, indx); }
  }

  return v;
}

enum dummyEnum { a, b, c, NUMLETTERS = dummyEnum::c + 1 };

TEST(forktps, HubbardAtom) { /// NOLINT
  std::cout << a << " " << b << " "
            << " " << dummyEnum::c << NUMLETTERS << std::endl;

  //std::cout << "Starting test!!!!!!" << std::endl;

  /// System Parameters

  /// Construct Parameters
  constr_params_t cp;
  cp.w_min     = -10.0;
  cp.w_max     = 10.0;
  cp.n_w       = 1001;
  cp.gf_struct = {{"up", 2}, {"dn", 2}};

  auto [ba, e0] = GetBath();

  for (auto i : BlockIndexIterator(ba.gf_struct())) { std::cout << i << std::endl; }
  return;

  auto Gre = ba.reconstructDelta({-2, 2, 100}, 0.2);
  std::cout << "Stream for bath: " << std::endl << ba << std::endl;
  std::cout << e0 << std::endl;

  /// Set up the Solver
  solver_core S(cp);
  S.b  = ba;
  S.e0 = e0;

  ///int up = 0, dn = 1;
  ///S.G0_iw[up](iw_) << 1.0 / (iw_ + mu + h);
  ///S.G0_iw[dn](iw_) << 1.0 / (iw_ + mu - h);

  /// Solve Parameters
  solve_params_t sp;
  sp.h_int.U         = 0.1;
  sp.h_int.J         = 0.;
  sp.h_int.Up        = 0.;
  sp.h_int.dd_only   = false;
  sp.tevo.dt         = 0.1;
  sp.tevo.time_steps = 3;
  sp.GFs.push_back("N");
  sp.NPart                    = {{1, 1, 1, 1}};
  sp.params_partSector.sweeps = 3;
  sp.params_GS.sweeps         = 3;

  //sp.params_partSector.prep.imag_tevo = true;
  //sp.params_partSector.prep.napp_h = 10;
  //sp.params_partSector.prep.dtau = 0.2;
  //sp.params_partSector.prep.time_steps = 100;
  //sp.params_partSector.prep.method = "TEBD";

  //sp.calc_me.push_back(std::make_pair("up", 0));
  //sp.calc_me.push_back(std::make_pair("dn", 0));
  //sp.calc_me.push_back(std::make_pair("up", 1));
  //sp.calc_me.push_back(std::make_pair("dn", 1));

  sp.calc_me.emplace_back("up", 0);
  sp.calc_me.emplace_back("dn", 0);
  sp.calc_me.emplace_back("up", 1);
  sp.calc_me.emplace_back("dn", 1);
  sp.tevo.imag_tevo = true;
  //ba.doAtEachSite( func );

  ///GetBath();

  ///sp.h0.PrintH0();
  /// Solve the impurity model
  S.solve(sp);

  /*
  std::cout << "ggr: " << std::endl;
  for (auto [bI, bN] : itertools::enumerate(cp.block_names())) {
    std::cout << bN << std::endl;
    for (auto [i, j] : itertools::product(itertools::range(std::round(ba.NArms() / 2)), itertools::range(std::round(ba.NArms() / 2)))) {
      std::cout << "   "
                << "i " << i << " j " << j << std::endl;
      for (auto t : itertools::range(2 * sp.tevo.time_steps + 1)) { std::cout << std::setprecision(12) << std::real((*S.G_gr)[bI][t](i, j)) << ", "; }
      std::cout << std::endl;
    }
  }

  std::cout << "gle: " << std::endl;
  for (auto [bI, bN] : itertools::enumerate(cp.block_names())) {
    std::cout << bN << std::endl;
    for (auto [i, j] : itertools::product(itertools::range(std::round(ba.NArms() / 2)), itertools::range(std::round(ba.NArms() / 2)))) {
      std::cout << "   "
                << "i " << i << " j " << j << std::endl;
      for (auto t : itertools::range(2 * sp.tevo.time_steps + 1)) { std::cout << std::setprecision(12) << std::real((*S.G_le)[bI][t](i, j)) << ", "; }
      std::cout << std::endl;
    }
  }
*/

  /*
  /// Store the Result
  {
    auto arch = h5::file("Solver.h5", 'w');
    h5_write(arch, "S", S);
  }*/

  /// Compare against the reference data
  /// h5diff("hubbard.out.h5", "hubbard.ref.h5")
}

MAKE_MAIN
