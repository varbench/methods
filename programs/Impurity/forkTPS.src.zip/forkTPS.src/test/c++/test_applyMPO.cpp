/*******************************************************************************
 *
 * forktps: A TRIQS based impurity solver
 *
 * Copyright (c) 2019 The Simons foundation
 *   authors: Nils Wentzell
 *
 * forktps is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * forktps is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * forktps. If not, see <http:///www.gnu.org/licenses/>.
 *
 ******************************************************************************/

#include <cstdio>
#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/ForkLocalOp.hpp>
#include <forktps/fork/ForkTPS.hpp>
#include <forktps/fork/TevoMethods.hpp>
#include <forktps/params.hpp>
#include <forktps/fork/Fork.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/makros.hpp>

#include <forktps/fork/Tevo/AIM_ForkGates.hpp>
#include <forktps/fork/Tevo/SFTevo.hpp>

#include <iomanip>
#include <itensor/global.h>
#include <itensor/itensor.h>
#include <forktps/fork/typenames.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/solver_core.hpp>

#include <functional>
#include <iostream>
#include <itensor/mps/mps.h>
#include <itensor/types.h>
#include <itensor/util/error.h>
#include <itertools/itertools.hpp>
#include <triqs/gfs.hpp>
#include <triqs/mesh.hpp>

#include <triqs/test_tools/gfs.hpp>
#include <tuple>
#include <utility>
#include <vector>
#include <chrono>

using namespace forktps;
using namespace itensor;

std::pair<bath, hloc> GetBath() {

  std::string blockNameUp("up");
  std::string blockNameDn("dn");

  std::vector<Complex> V1{0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10};
  std::vector<Complex> V2{0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20};
  std::vector<Complex> V3{0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30, 0.30};
  std::vector<Complex> V4{0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40, 0.40};

  std::vector<double> eps1{0.3, -1.0, -0.80, -0.60, -0.40, -0.20, 0.00, 0.20, 0.40, 0.60, 0.80, 1.00};
  std::vector<double> eps2{0.1, -1.01, -0.81, -0.61, -0.41, -0.21, 0.01, 0.21, 0.41, 0.61, 0.81, 1.01};
  std::vector<double> eps3{0, -1.02, -0.82, -0.62, -0.42, -0.22, 0.02, 0.22, 0.42, 0.62, 0.82, 1.02};
  std::vector<double> eps4{0, -1.03, -0.83, -0.63, -0.43, -0.23, 0.03, 0.23, 0.43, 0.63, 0.83, 1.03};

  Dmat eps = {eps1, eps2, eps3, eps4, eps1, eps1};
  Cmat V   = {V1, V2, V3, V4, V1, V1};

  int blockSize = 2;

  std::vector<double> V2d{0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2};

  //return aim_h0(eps2, V2d, blockSize, blockNameUp, blockNameDn);
  return {bath(eps, V, blockSize, blockNameUp, blockNameDn), hloc(eps, blockSize, blockNameUp, blockNameDn)};
  //return {bath(eps1, V2d, blockSize, blockNameUp, blockNameDn), hloc(eps1, blockSize, blockNameUp, blockNameDn)};
}

using namespace std::chrono;
using elapsed_duration = std::chrono::duration<float, std::milli>;

TEST(apply, mpo) { /// NOLINT

  std::vector<double> eps  = {0.11, -2., -1., 0., 1., 2., 3.};
  std::vector<double> eps2 = {0., -2., -1., 0., 1., 2., 3.};
  std::vector<double> V    = {0.1, 0.2, 0.3, 0.15, 0.1, 0.2};

  int NArms = 4;
  bath ba(eps, V, NArms / 2);
  hloc e0({eps, eps2, eps, eps2, eps, eps2}, NArms / 2);
  H_int hint(2, 0.1, 1.8, false);
  Args args;
  args.add("Cutoff", 1E-08);

  AIM_ForkSites sites(ba.N(), ba.NArms());
  ForkTPO H = ForkTPO(AIM(sites, ba, e0, hint, args));

  InitState init(sites);
  for (auto arm : range1(NArms)) {
    for (auto k : range1(3)) {
      auto site = sites.ArmToSite(arm, k);
      init.set(site, "Occ");
    }
  }

  ForkTPS psi(init, NArms);
  for (auto i : range1(3)) {
    UNUSED_VAR(i);
    psi = exactApplyMPO(psi, H, args);
    psi.normalize();
  }
  psi.PrintOccs();

  //double energy = 1000;
  //DMRGSSImp_SubspaceExp(psi, H, energy, args);

  double dt = 0.1;
  auto SF   = ForkTPO(SFPH_TevoMPO(Complex_i * dt / 2, hint.J, SFPH::SF, std::make_pair(1, 2), sites));
  auto PH   = ForkTPO(SFPH_TevoMPO(Complex_i * dt / 2, hint.J, SFPH::PH, std::make_pair(1, 2), sites));

  auto DD    = DD_MPO(Complex_i * dt / 2, hint, sites);
  auto gates = createAIMGates(Complex_i * dt, ba, e0, sites);

  for (auto i : range1(SF.NArms() - 1)) { ITENSOR_Print(SF.GetLink(SF.ImpSite(i), SF.ImpSite(i) + 1)); }

  for (auto i : range1(SF.NArms() - 1)) { ITENSOR_Print(PH.GetLink(SF.ImpSite(i), SF.ImpSite(i) + 1)); }

  auto ops = TEBD_container(hint, ba, e0, -Complex_i * dt, sites);
  for (const auto &Op : *ops.SF) {
    for (auto i : range1(PH.NArms())) { ITENSOR_Print(Op.A(Op.ImpSite(i))); }
  }

  //for (auto i : range1(10))
  //  TEBD(psi, ops, args);

  /*
  psi.ApplySingleSiteOp( sites.op("Ck",1), 1, true);
  ForkTPS TevoGates = psi, TevoTDVP = psi;

  ForkLocalOp heff(H);
  double timeGates= 0, timeTDVP = 0;

  //void (*func)(ForkTPS, ForkTPO, Args);
  //auto func = &exactApplyMPO;
  auto func = &FitApplyMPO;

  for( auto i : itertools::range(10)){
    auto start = steady_clock::now();
    TevoGates = func(TevoGates, PH, args);
    TevoGates = func(TevoGates, SF, args);
    TevoGates.ZipUpImpurityMPO(DD, args);
    for(auto g : gates) ApplyGate(TevoGates, g, Rightwards, args);
    TevoGates.ZipUpImpurityMPO(DD, args);
    TevoGates = func(TevoGates, SF, args);
    TevoGates = func(TevoGates, PH, args);
    auto end = steady_clock::now();
    timeGates += duration_cast<milliseconds>(end-start).count();


    start = steady_clock::now();
    TDVP_SSImp(TevoTDVP, heff, Complex_i * dt);
    end = steady_clock::now();
    timeTDVP += duration_cast<milliseconds>(end-start).count();

    auto factor = std::exp(Complex_i*double(dt*i)*energy);
    auto valGates = factor * overlap(psi, TevoGates);
    auto valTDVP = factor * overlap(psi, TevoTDVP);


    PrintBorderLine(2);
  }


  */

  /*
  init = InitState(sites);
  init.set(sites.ImpSite(1), "Occ");
  init.set(sites.ImpSite(2), "Occ");
  //psi = ForkTPS(init,NArms);
  
  ForkTPS tevo1 = psi, tevo2 = psi;

  double time = 0;
  for(auto i :range1(10)){

    auto start =  std::chrono::steady_clock::now();
    tevo2 = FitApplyMPO(tevo2, H_2, args);
    auto end = std::chrono::steady_clock::now();

    time += std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    tevo1.PrintImpOcc();
    tevo2.PrintImpOcc();
    PrintBorderLine(2);
  }






  auto gatesOld = createAIMGates(Complex_i*0.12, ba, e0, sites);
  auto gatesNew = createAIMGates(Complex_i*0.12, ba, e0, sites);

*/
}

MAKE_MAIN
