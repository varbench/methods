#include <array>
#include <forktps/fork/EigSolver.hpp>
#include <forktps/fork/HelperFunctions.hpp>

#include "gtest/gtest.h"

#include <cmath>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace std;
using namespace forktps;

TEST(EigSolver, T1) {
  /// diagonalizes a 3x3 diagonal matrix using lapack dsyev_
  /// the matrix is:
  /// [[ 15.831097   0.      0. ]
  /// [  0.          3.96    0.   ]
  /// [  0.          0.      1.35666784  ]]

  const int L = 3;

  std::vector<double> diagonal{15.831097, 3.96, 1.35666784};

  double Mat[3 * 3], diag[3];
  for (auto i : itertools::range(L * L)) Mat[i] = 0.;

  char JOBZ = 'V';

  Mat[0]         = diagonal[0];
  Mat[L + 1]     = diagonal[1];
  Mat[2 * L + 2] = diagonal[2];

  forktps::ED::ev_hermitian(Mat, diag, L, JOBZ);

  ///sort diagonal
  std::sort(diagonal.begin(), diagonal.end());
  for (const auto i : {0, 1, 2}) EXPECT_FLOAT_EQ(diag[i], diagonal[i]);
}
/*
TEST(EigSolver, T2) {
  ///diagonalizes a 3x3 matrix using lapack dsyev_
  ///the matrix is
  /// [[ 1.3097 10.      2.666 ]
  /// [10.      8.9647  8.97   ]
  /// [ 2.666   8.97    0.47  ]]
  /// to test just run the python code:
  ///    mat = np.diag([1.3097, 8.9647, 0.47])
  ///    od1 = 10.0
  ///    od2 = 2.666
  ///    od3 = 8.97
  ///    mat[0,1] = od1;
  ///    mat[1,0] = od1;
  ///    mat[0,2] = od2;
  ///    mat[2,0] = od2;
  ///    mat[1,2] = od3;
  ///    mat[2,1] = od3;
  ///    D,V = np.linalg.eigh(mat)

  int L = 3;

  std::vector<double> diagonal{1.3097, 8.9647, 0.47};
  const double od1 = 10, od2 = 2.666, od3 = 8.97;

  double Mat[3*3], diag[3];
  for (auto i : itertools::range(L * L)) Mat[i] = 0.;
  char JOBZ = 'V';

  Mat[0]         = diagonal[0];
  Mat[L + 1]     = diagonal[1];
  Mat[2 * L + 2] = diagonal[2];

  Mat[1] = od1;
  Mat[L] = od1;

  Mat[2]     = od2;
  Mat[2 * L] = od2;

  Mat[5]         = od3;
  Mat[2 * L + 1] = od3;

  ev_hermitian(Mat, diag, L, JOBZ);

  std::vector<double> Evecs = {-0.563835236773381, 0.6337707165867785, -0.5295512294101361, -0.6760491273618798, 0.01412385506422,
                                      0.7367211779984104, 0.4743916137179766, 0.7733920063688309,  0.4204966127317176};

  std::vector<double> Evals = {-7.426759282767762, -1.8044778400062984, 19.975637122774057};
  for (auto i : {0, 1, 2}) EXPECT_FLOAT_EQ(Evals[i], diag[i]);

  for (int i = 0; i < L * L; ++i) EXPECT_FLOAT_EQ(std::abs(Evecs[i]), std::abs(Mat[i]));
}

TEST(EigSolver, T3) {
  ///diagonalizes a 6x6 tridiagonal matrix using lapack dsyev_
  /// to test just run the python code:
  ///      mat = np.diag([1.3097, 8.9647, 0.47, 4.8974, 6.0, 1.8814])
  ///      t = np.array( [0.3478, 0.7124, 2.5687, 5.913, 0.7] )
  ///
  ///      for i in range(5):
  ///          mat[i,i+1] = t[i]
  ///          mat[i+1,i] = t[i]
  ///      D,V = np.linalg.eigh(mat)

  const int L = 6;

  const std::vector<double> diagonal{1.3097, 8.9647, 0.47, 4.8974, 6.0, 1.8814};
  const std::vector<double> t = {0.3478, 0.7124, 2.5687, 5.913, 0.7};

  double Mat[6*6], diag[6];
  for (auto i : itertools::range(L * L)) Mat[i] = 0.;

  char JOBZ = 'V';

  for (auto i : itertools::range(L)) {
    Mat[i * (L + 1)] = diagonal[i];
    if (i == L - 1) continue;

    Mat[i * (L + 1) + 1]       = t[i];
    Mat[(i + 1) * (L + 1) - 1] = t[i];
  }
  ///Mat[L*]

  ev_hermitian(Mat, diag, L, JOBZ);

  const std::vector<double> Evecs = {
     0.0041533157792153,  -0.0407170585413687, 0.6303703942720498,  -0.6193870849247229, 0.4591310205371021,  -0.0807241113056711,
     0.9871312409073383,  -0.0536077296312015, 0.0955298406707213,  0.0453934684019815,  -0.0691870509877776, 0.0820046284791651,
     -0.1523820360436754, -0.0503477354626406, 0.6072777794209262,  0.2396480895446481,  -0.4045595779502161, 0.6199668219452559,
     0.0180867135993843,  0.0453312224458112,  -0.4404629601800344, -0.3060312760953006, 0.3319123908143755,  0.7744606863150328,
     -0.044780729166297,  -0.9945621445686746, -0.0751638083194085, 0.0252299733429488,  0.0503035028009218,  0.0049228910497687,
     0.0013911759303108,  0.0415290123147332,  0.1583151818894223,  0.6801295257001333,  0.7127742477634555,  0.0508567492587209};

  const std::vector<double> Evals = {-2.099959586096694, 1.2908121686832705, 1.4246147422396132, 2.1814006038725524, 9.034199362134638, 11.692132709166618};

  for (auto i : itertools::range(L)) EXPECT_FLOAT_EQ(Evals[i], diag[i]);

  for (int i = 0; i < L * L; ++i) EXPECT_FLOAT_EQ(std::abs(Evecs[i]), std::abs(Mat[i]));
}
*/
