#include "forktps/fork/typenames.hpp"
#include <forktps/fork/Fork.hpp>
#include "gtest/gtest.h"
#include <cstdio>
#include <fstream>
#include <itensor/util/error.h>
#include <itensor/util/iterate.h>
#include <limits.h>
#include <vector>

using namespace forktps;

namespace forktps {

  TEST(Fork_AllBathsEqual, ForkBaseStructure) {
    /// Tests basic fork structure of a fork with 16 sites and 4 arms.
    /// On a fork with an equal number of bath sites on each arm

    const int N     = 16;
    const int NArms = 4;

    const Fork f(N, NArms);

    EXPECT_EQ(1, f.ImpSite(1));
    EXPECT_EQ(5, f.ImpSite(2));
    EXPECT_EQ(9, f.ImpSite(3));
    EXPECT_EQ(13, f.ImpSite(4));

    EXPECT_EQ(16, f.N());
    EXPECT_EQ(4, f.NArms());
    EXPECT_EQ(3, f.NBath());

    bool first = true;
    for (auto val : f.NBathVec()) {
      if (first) {
        first = false;
        continue;
      }
      EXPECT_EQ(3, val);
    }
  }

  TEST(Fork_AllBathsEqual, IsImp_ImpSite_ImpIndx) {
    /// Test for member functions IsImp and ImpSite
    /// On a fork with an equal number of bath sites on each arm
    const int N     = 16;
    const int NArms = 4;

    const Fork f(N, NArms);
    /// ImpSite
    EXPECT_EQ(1, f.ImpSite(1));
    EXPECT_EQ(5, f.ImpSite(2));
    EXPECT_EQ(9, f.ImpSite(3));
    EXPECT_EQ(13, f.ImpSite(4));

    /// IsImp
    EXPECT_TRUE(f.IsImp(1) == true);
    EXPECT_TRUE(f.IsImp(5) == true);
    EXPECT_TRUE(f.IsImp(9) == true);
    EXPECT_TRUE(f.IsImp(13) == true);

    /// ImpIndx
    EXPECT_EQ(1, f.ImpIndx(1));
    EXPECT_EQ(2, f.ImpIndx(5));
    EXPECT_EQ(3, f.ImpIndx(9));
    EXPECT_EQ(4, f.ImpIndx(13));
  }

  TEST(Fork_AllBathsEqual, GetArm) {
    /// Test for member functions GetChain and GetArm
    /// On a fork with an equal number of bath sites on each arm
    const int N     = 16;
    const int NArms = 4;

    const Fork f(N, NArms);
    int count = 1;

    for (auto ch = 1; ch <= 4; ++ch) {
      for (auto i = 1; i <= 4; ++i) {
        if (i != 1) { EXPECT_EQ(ch, f.GetArm(count)); }
        count++;
      }
    }
  }

  TEST(Fork_AllBathsEqual, ArmToSite_SiteToArm) {
    /// Test for member functions ArmToSite and SiteToArm
    /// On a fork with an equal number of bath sites on each arm
    const int N     = 16;
    const int NArms = 4;
    const Fork f(N, NArms);

    for (int ch = 1; ch <= 4; ++ch) {
      for (int i = 1; i <= 3; ++i) { EXPECT_EQ(4 * ch + 1 - i, f.ArmToSite(ch, i)); }
    }

    int count    = 3;
    int countArm = 1;

    for (int i = 1; i <= N; ++i) {

      if (!f.IsImp(i)) {
        auto [arm, indx] = f.SiteToArm(i);
        EXPECT_EQ(count, indx);
        EXPECT_EQ(countArm, arm);
        count--;
      }
      if (i % 4 == 0) {
        count = 3;
        countArm++;
      }
    }
  }

  TEST(Fork_VariousBathSizes, ForkBaseStructure) {
    /// Tests basic fork structure of a fork with 4 arms and a different number of
    /// bath sites on each arm
    const std::vector<int> NBath = {0, 4, 7, 9, 2};

    const Fork f(NBath);

    EXPECT_EQ(1, f.ImpSite(1));
    EXPECT_EQ(6, f.ImpSite(2));
    EXPECT_EQ(14, f.ImpSite(3));
    EXPECT_EQ(24, f.ImpSite(4));

    EXPECT_EQ(26, f.N());
    EXPECT_EQ(4, f.NArms());
    EXPECT_EQ(4, f.NBath());

    for (int i = 1; i <= 4; ++i) { EXPECT_EQ(NBath[i], f.NBath(i)); }
  }

  TEST(Fork_VariousBathSizes, IsImp_ImpSite_ImpIndx) {
    /// Test for member functions IsImp and ImpSite
    /// For a fork with different number of bath sites on each arm

    const std::vector<int> NBath = {0, 4, 7, 9, 2};
    const Fork f(NBath);

    /// ImpSite
    EXPECT_EQ(1, f.ImpSite(1));
    EXPECT_EQ(6, f.ImpSite(2));
    EXPECT_EQ(14, f.ImpSite(3));
    EXPECT_EQ(24, f.ImpSite(4));

    /// IsImp
    EXPECT_TRUE(f.IsImp(1) == true);
    EXPECT_TRUE(f.IsImp(6) == true);
    EXPECT_TRUE(f.IsImp(14) == true);
    EXPECT_TRUE(f.IsImp(24) == true);

    /// ImpIndx
    EXPECT_EQ(1, f.ImpIndx(1));
    EXPECT_EQ(2, f.ImpIndx(6));
    EXPECT_EQ(3, f.ImpIndx(14));
    EXPECT_EQ(4, f.ImpIndx(24));
  }

  TEST(Fork_VariousBathSizes, GetArm) {
    /// Test for member functions GetChain and GetArm
    /// For a fork with different number of bath sites on each arm

    const std::vector<int> NBath = {0, 4, 7, 9, 2};
    const Fork f(NBath);

    int ch = 1;
    for (auto i : range1(f.N())) {
      if (!f.IsImp(i)) { EXPECT_EQ(ch, f.GetArm(i)); }
      if (i == f.ImpSite(2) || i == f.ImpSite(3) || i == f.ImpSite(4)) { ch++; }
    }
  }

  TEST(Fork_VariousBathSizes, ArmToSite_SiteToArm) {
    /// Test for member functions ArmToSite_SiteToArm
    /// For a fork with different number of bath sites on each arm
    const std::vector<int> NBath = {0, 4, 7, 9, 2};
    const Fork f(NBath);

    int base = 1;
    for (int ch = 1; ch <= 4; ++ch) {
      base += NBath[ch] + 1;
      for (int i = 1; i <= NBath[ch]; ++i) { EXPECT_EQ(base - i, f.ArmToSite(ch, i)); }
    }

    int arm  = 1;
    int indx = NBath[arm];
    for (int i = 1; i <= f.N(); ++i) {
      if (!f.IsImp(i)) {
        auto [arm2, indx2] = f.SiteToArm(i);

        EXPECT_EQ(arm, arm2);
        EXPECT_EQ(indx, indx2);
        indx--;
      }
      if (indx == 0) {
        arm++;
        indx = NBath[arm];
      }
    }
  }

  TEST(Fork, Neighbor) {
    /// Test of member function Neighbor
    const int NArms = 4;
    const int NBath = 5;
    const int N     = NArms * (NBath + 1);

    const Fork f(N, NArms);

    //first Impurity site
    int site = 1;
    EXPECT_EQ(f.Neighbor(site, Rightwards), 2);
    EXPECT_EQ(f.Neighbor(site, Downwards), 7);

    //Bath site on first arm
    site = 3;
    EXPECT_EQ(f.Neighbor(site, Rightwards), 4);
    EXPECT_EQ(f.Neighbor(site, Leftwards), 2);

    // second Impurity site
    site = f.ImpSite(2);
    EXPECT_EQ(f.Neighbor(site, Rightwards), 8);
    EXPECT_EQ(f.Neighbor(site, Downwards), 13);
    EXPECT_EQ(f.Neighbor(site, Upwards), 1);

    // bath site on arm 3
    site = f.ImpSite(3) + 4;
    EXPECT_EQ(f.Neighbor(site, Rightwards), 18);
    EXPECT_EQ(f.Neighbor(site, Leftwards), 16);
    // last Impurity site
    site = f.ImpSite(NArms);
    EXPECT_EQ(f.Neighbor(site, Rightwards), 20);
    EXPECT_EQ(f.Neighbor(site, Upwards), 13);

    // last bath site on arm 4
    site = N;
    EXPECT_EQ(f.Neighbor(site, Leftwards), N - 1);
  }

  TEST(Fork, HasNeighbor) {
    /// Test of member function Neighbor
    const int NArms = 4;
    const int NBath = 5;
    const int N     = NArms * (NBath + 1);

    const Fork f(N, NArms);

    // impurities
    for (auto arm : range1(NArms)) {
      int site = f.ImpSite(arm);

      EXPECT_TRUE(f.HasNeighbor(site, Rightwards));
      if (arm == 1)
        EXPECT_FALSE(f.HasNeighbor(site, Upwards));
      else
        EXPECT_TRUE(f.HasNeighbor(site, Upwards));

      if (arm == NArms)
        EXPECT_FALSE(f.HasNeighbor(site, Downwards));
      else
        EXPECT_TRUE(f.HasNeighbor(site, Downwards));
    }

    // bath sites
    for (auto arm : range1(NArms)) {
      for (auto indx : range1(f.NBath(arm))) {
        int site = f.ArmToSite(arm, indx);

        EXPECT_TRUE(f.HasNeighbor(site, Leftwards));
        EXPECT_FALSE(f.HasNeighbor(site, Upwards));
        EXPECT_FALSE(f.HasNeighbor(site, Downwards));

        if (indx == 1)
          EXPECT_FALSE(f.HasNeighbor(site, Rightwards));
        else
          EXPECT_TRUE(f.HasNeighbor(site, Rightwards));
      }
    }
  }

  TEST(Fork, RW) {
    /// Test of member function Neighbor
    const int NArms = 4;
    const int NBath = 5;
    const int N     = NArms * (NBath + 1);

    Fork f(N, NArms), f2;
    const std::string fn("fork");

    // write
    std::ofstream os(fn);
    if (os.bad()) throw ITError("cant write to file " + fn);

    f.write(os);
    os.close();

    // read
    std::ifstream is(fn);
    if (is.bad()) throw ITError("cant read to file " + fn);

    f2.read(is);
    is.close();

    EXPECT_EQ(f.N(), f2.N());
    EXPECT_EQ(f.NArms(), f2.NArms());
    EXPECT_EQ(f.NBath(), f2.NBath());
  }

  TEST(Fork, OneOrbtial) {

    const int NArms = 2;
    const int NBath = 7;
    const int N     = NArms * (NBath + 1);
    const Fork f(N, NArms);

    // ImpSites
    EXPECT_EQ(f.ImpSite(1), 1);
    EXPECT_EQ(f.ImpSite(2), 9);

    EXPECT_TRUE(f.IsImp(1));
    EXPECT_TRUE(f.IsImp(9));

    EXPECT_EQ(f.ImpIndx(1), 1);
    EXPECT_EQ(f.ImpIndx(9), 2);

    // Get Arm
    for (auto i : range1(N)) {
      auto expectedArm = (i > 8) ? 2 : 1;
      EXPECT_EQ(expectedArm, f.GetArm(i));
    }

    //Arm to site
    for (auto arm : range1(NArms)) {
      for (auto indx : range1(NBath)) {
        auto expectedSite = arm * (NBath + 1) - (indx - 1);
        EXPECT_EQ(expectedSite, f.ArmToSite(arm, indx));
      }
    }

    //Site to Arm
    for (auto i : range1(N)) {
      if (f.IsImp(i)) continue;
      auto expectedArm  = (i > NBath + 1) ? 2 : 1;
      auto expectedIndx = expectedArm * (NBath + 1) - i + 1;
      EXPECT_EQ(expectedIndx, f.SiteToArm(i).second);
    }

    //Neighbor ... impurities
    EXPECT_EQ(f.Neighbor(1, Rightwards), 2);
    EXPECT_EQ(f.Neighbor(1, Downwards), 9);
    EXPECT_EQ(f.Neighbor(9, Rightwards), 10);
    EXPECT_EQ(f.Neighbor(9, Upwards), 1);

    //Neighbor ... bath
    for (auto arm : range1(NArms)) {
      for (auto indx : range1(NBath)) {
        int site = f.ArmToSite(arm, indx);
        EXPECT_EQ(f.Neighbor(site, Leftwards), site - 1);
        if (indx > 1) EXPECT_EQ(f.Neighbor(site, Rightwards), site + 1);
      }
    }
  }

} // namespace forktps
