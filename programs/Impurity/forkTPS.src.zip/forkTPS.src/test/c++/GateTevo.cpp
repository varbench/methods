#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/Tevo/AIM_ForkGates.hpp>

#include "TestHelpers.hpp"
#include "forktps/fork/HelperFunctions.hpp"
#include "forktps/fork/typenames.hpp"

#include "gtest/gtest.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

namespace forktps {

  const int RNG_SEED(1598745);

  TEST(GateTevo, AllButOneChannelEmpty) {
    //itensor::seedRNG(RNG_SEED);
    const int N = 16, NArms = 4;
    const std::vector<double> eps = {0., -1, 0, 1};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    const double dt = 0.01, dt_ex = 0.001;
    const int NTimeSteps   = static_cast<int>(std::round(5 / dt));
    const int CompareEvery = static_cast<int>(std::round(dt / dt_ex));
    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};

    std::vector<Complex> ExactGF;
    GetExactGF(ExactGF, "TestGF.ref.txt");

    AIM_ForkSites sites(N, NArms);

    bath b(eps, V, NArms / 2);
    hloc e0(eps, NArms / 2);
    auto gates = createAIMGates(Complex_i * dt, b, e0, sites);

    for (auto ch : range1(4)) {
      std::vector<int> occSites = {4 * (ch - 1) + 1, 4 * (ch - 1) + 2};

      std::vector<double> times(0);

      InitState init(sites);
      for (auto s : occSites) init.set(s, "Occ");
      ForkTPS psi(init, NArms);

      double U = 0, Up = 0, J = 0;
      ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, {"DDonly", true}));
      H.position(N);
      H.position(1);

      for (int i = 0; i < 5; ++i) {
        psi = forktps::exactApplyMPO(psi, H, args);
        psi.normalize();
      }
      double energy(0.);
      forktps::DMRG(psi, H, energy, args);

      psi.ApplySingleSiteOp(sites.op("CkD", psi.ImpSite(ch)), psi.ImpSite(ch), true);
      ForkTPS psiT = psi, psiT_Bra = psi;
      double StartNorm = psiT.norm();
      std::vector<Complex> GF(0);

      times.push_back(0);
      GF.push_back(forktps::overlap(psiT_Bra, psiT));

      for (auto i : range1(NTimeSteps)) {

        for (auto g : gates) ApplyGate(psiT, g, Rightwards, args);

        psiT *= StartNorm / psiT.norm();
        CheckLinks(psiT);

        GF.push_back(overlap(psi, psiT) * std::exp(Complex_i * energy * i * dt));
        times.push_back(i * dt);
      }

      for (auto i : range1(NTimeSteps)) {
        auto diff = std::abs(ExactGF.at(CompareEvery * i) - GF.at(i));
        EXPECT_NEAR(diff, 0, 1E-6);
      }
    }
  }

  TEST(GateTevo, AllChannels) {
    itensor::seedRNG(RNG_SEED);
    const int N = 16, NArms = 4;
    const std::vector<double> eps = {0., -1, 0, 1};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    const double dt = 0.01, dt_ex = 0.001;
    const int NTimeSteps   = static_cast<int>(std::round(5 / dt));
    const int CompareEvery = static_cast<int>(std::round(dt / dt_ex));
    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "NAppH", 3};

    std::vector<Complex> ExactGF;
    GetExactGF(ExactGF, "TestGF.ref.txt");

    AIM_ForkSites sites(N, NArms);
    bath b(eps, V, NArms / 2);
    hloc e0(eps, NArms / 2);
    auto gates = createAIMGates(Complex_i * dt, b, e0, sites);

    const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14};
    std::vector<double> times(0);

    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    for (auto ch : range1(NArms)) {
      ForkTPS psi(init, NArms);

      double U = 0, Up = 0, J = 0;
      ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, {"DDonly", true}));
      H.position(N);
      H.position(1);

      for (int i = 0; i < 5; ++i) {
        psi = forktps::exactApplyMPO(psi, H, args);
        psi.normalize();
      }

      double energy(0.);
      forktps::DMRG(psi, H, energy, args);

      psi.ApplySingleSiteOp(sites.op("CkD", psi.ImpSite(ch)), psi.ImpSite(ch), true);
      ForkTPS psiT = psi, psiT_Bra = psi;
      double StartNorm = psiT.norm();

      std::vector<Complex> GF(0);

      times.push_back(0);
      GF.push_back(forktps::overlap(psiT_Bra, psiT));

      for (auto i : range1(NTimeSteps)) {
        for (auto g : gates) ApplyGate(psiT, g, Rightwards, args);

        psiT *= StartNorm / psiT.norm();
        CheckLinks(psiT);

        GF.push_back(overlap(psi, psiT) * std::exp(Complex_i * energy * i * dt));
        times.push_back(i * dt);
      }

      for (auto i : range1(NTimeSteps)) {
        auto diff = std::abs(ExactGF.at(CompareEvery * i) - GF.at(i));
        EXPECT_NEAR(diff, 0, 1E-6);
      }
    }
  }

} // namespace forktps
