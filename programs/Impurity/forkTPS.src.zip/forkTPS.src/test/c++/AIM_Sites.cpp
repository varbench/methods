#include <forktps/fork/Bath.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/params.hpp>

#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>

#include "gtest/gtest.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <itertools/itertools.hpp>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

//In these tests we compare MPOs in using parameter regimes where they should agree
//to do so, we look at the ground state energy as well as the ground state
//correlation matrix  <GS| cidag cj |GS>

namespace forktps {

  //checks that for diagonal baths, the off-diagonal Hamiltonian
  //produceses the same result as the diagonal for both cases
  //with and without spin flip and pair hoppings

  TEST(ForkSites, construction) {
    int N = 16, NArms = 4;
    AIM_ForkSites sites(N, NArms);
  }

  TEST(ForkSites, RW) {

    int N = 16, NArms = 4;
    AIM_ForkSites sites(N, NArms), sites2;
    ForkTPS GS;

    std::ofstream s("sites");
    sites.write(s);
    s.close();

    std::ifstream is("sites");
    sites2.read(is);
    is.close();

    for (auto i : range1(N)) EXPECT_TRUE(sites.si(i) == sites2.si(i));

    EXPECT_EQ(sites.NArms(), sites2.NArms());
    EXPECT_EQ(sites.NBath(), sites2.NBath());
  }

} // namespace forktps
