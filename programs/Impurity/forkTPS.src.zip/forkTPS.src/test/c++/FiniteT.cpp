#include <forktps/fork/Fork.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <iomanip>
#include <itensor/itensor.h>
#include <forktps/fork/typenames.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/params.hpp>
#include <forktps/finiteT_solver_core.hpp>

#include <functional>
#include <iostream>
#include <itertools/itertools.hpp>
#include <limits>
#include <mpi/mpi.hpp>
#include <triqs/gfs.hpp>
#include <triqs/mesh.hpp>
#include <h5/h5.hpp>

#include <triqs/test_tools/gfs.hpp>
#include <tuple>
#include <utility>
#include <variant>
#include <vector>

using namespace forktps;
using namespace itensor;

TEST(FiniteT, FiniteTTest) {
  finiteT_constr_params_t cp;
  cp.beta      = 1.0;
  cp.n_iw      = 1001;
  int n_orb    = 3;
  cp.gf_struct = {{"up", n_orb}, {"dn", n_orb}};
  finiteT_solver_core S(cp);
  double U  = 1.0;
  double J  = 0.1;
  double Up = U - 2. * J;
  double mu = 0.5 * (U + 2. * (n_orb - 1) * (U - 2.5 * J));

  /// Solve Parameters
  finiteT_solve_params_t sp;

  std::vector<std::vector<triqs_indx>> calcs;
  triqs_indx ind_0 = {"up", 0}, ind_1 = {"up", 0};
  calcs.push_back({ind_0, ind_1});
  ind_0 = {"up", 1}, ind_1 = {"up", 1};
  calcs.push_back({ind_0, ind_1});
  ind_0 = {"up", 0}, ind_1 = {"up", 1};
  calcs.push_back({ind_0, ind_1});
  ind_0 = {"up", 0}, ind_1 = {"up", 2};
  calcs.push_back({ind_0, ind_1});
  ind_0 = {"up", 1}, ind_1 = {"up", 2};
  calcs.push_back({ind_0, ind_1});

  sp.calc_me             = calcs;
  sp.h_int.U             = U;
  sp.h_int.J             = J;
  sp.h_int.Up            = Up;
  sp.h_int.dd_only       = false;
  sp.tevo.dt             = 0.1;
  sp.tevo.time_steps     = 1;
  sp.tevo.method         = "TDVP_2";
  sp.tevo.approx.maxm_i  = 10;
  sp.tevo.approx.maxm_ib = 10;
  sp.tevo.approx.maxm_b  = 10;
  sp.tevo.approx.tw_i    = 1e-8;
  sp.tevo.approx.tw_ib   = 1e-8;
  sp.tevo.approx.tw_b    = 1e-8;

  sp.sampling.n_sampling             = 3;
  sp.sampling.n_thermal              = 1;
  sp.sampling.purification_threshold = 0.1;
  sp.basisExpansion.cutoffBE         = 1E-4;
  sp.basisExpansion.nKrylovBE        = 1;
  sp.basisExpansion.expand_every     = 10000;
  sp.impPurified                     = false;
  sp.quickDMRG                       = false;

  sp.gKrylov.gKrylov   = true;
  sp.gKrylov.nKrylov   = 12;
  sp.gKrylov.orthoSize = 2;
  sp.gKrylov.threshold = 1E-4;

  //input bath
  const int blockSize     = 3;
  std::vector<double> eps = {-mu, -0.32, 0.0, 0.32};
  std::vector<double> V   = {1.3, 1.2, 1.126};
  bath b(eps, V, blockSize, "up", "dn");
  hloc e0(eps, blockSize, "up", "dn");

  S.b        = b;
  S.e0       = e0;
  sp.verbose = 4;

  S.solveBasis(sp);
};
