#include "forktps/fork/SiteSets/PurificationSites.hpp"
#include <forktps/fork/Gates.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/SiteSets/PurificationSites.hpp>
#include "gtest/gtest.h"

#include <cmath>
#include <iomanip>
#include <vector>
#include <complex>

using namespace itensor;
using namespace forktps;

namespace forktps {
  //todo write tests for read/write

  TEST(Gates, GatesConstructor) {
    const int N = 18, NArms = 6;
    const int i = 1, j = 2;
    AIM_ForkSites sites(N, NArms);

    Index si = sites(i), siP = prime(si), sj = sites(j), sjP = prime(sj);

    const Complex val = 0.154698 + 5.11163 * Complex_i, valdag = std::conj(val);
    ITensor T = val * sites.op("Ck", 1) * sites.op("CkD", 2);
    T += std::conj(val) * sites.op("CkD", 1) * sites.op("Ck", 2);

    ForkGate g(T, i, j);

    EXPECT_EQ(i, g.i());
    EXPECT_EQ(j, g.j());

    T = g.gate();
    EXPECT_DOUBLE_EQ(std::real(valdag), std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))));
    EXPECT_DOUBLE_EQ(std::imag(valdag), std::imag(T.eltC(si(1), siP(2), sj(2), sjP(1))));
    EXPECT_DOUBLE_EQ(std::real(val), std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))));
    EXPECT_DOUBLE_EQ(std::imag(val), std::imag(T.eltC(si(2), siP(1), sj(1), sjP(2))));
  }

  TEST(Gates, MakeSwap_d2HilbertSpce) {
    const int N = 18, NArms = 6;
    const int i = 1, j = 2;
    AIM_ForkSites sites(N, NArms);

    Index si = sites(i), siP = prime(si), sj = sites(j), sjP = prime(sj);

    ForkGate g;
    g.MakeSwap(i, j, sites);

    ITensor T = g.gate();

    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(1), siP(1), sj(1), sjP(1))));
    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))));
    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))));
    EXPECT_DOUBLE_EQ(-1., std::real(T.eltC(si(2), siP(2), sj(2), sjP(2))));
  }

  TEST(Gates, MakeSwap_d4HilbertSpce) {
    const int N = 18, NArms = 6;
    const int s1 = 1, s2 = 2;
    PurificationSites sites(N, NArms);

    Index si = sites(s1), siP = prime(si), sj = sites(s2), sjP = prime(sj);
    // purification sites must have hilbert space dimension 4
    EXPECT_EQ(dim(si), 4);
    EXPECT_EQ(dim(sj), 4);

    ForkGate g;
    g.MakeSwap(s1, s2, sites);

    ITensor T = g.gate();

    for (auto i : itertools::range(4)) {
      for (auto j : itertools::range(4)) {
        // number of fermions on i and j
        int Ni = i, Nj = j;
        if (i == 2) Ni = 1;
        if (i == 3) Ni = 2;

        if (j == 2) Nj = 1;
        if (j == 3) Nj = 2;

        // sign is negative if an odd number of particles is swaped with an odd number of particles
        int sign = 1;
        if (Ni % 2 == 1 && Nj % 2 == 1) sign = -1;

        EXPECT_DOUBLE_EQ(sign, std::real(T.eltC(si(i + 1), siP(j + 1), sj(j + 1), sjP(i + 1))));
      }
    }

    //
    //EXPECT_DOUBLE_EQ( 1., std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))));
    //EXPECT_DOUBLE_EQ( 1., std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))));
    //EXPECT_DOUBLE_EQ(-1., std::real(T.eltC(si(2), siP(2), sj(2), sjP(2))));
  }

  TEST(Gates, ExpGateReal) {
    //calculates exp(- dt * G ) and compares to the exact exponential from python
    //run the python code:
    //  mat = np.zeros((4,4), dtype = np.float64)
    //  dt = 0.157;
    //  mat[1,2] = 3.1415
    //  mat[2,1] = 3.1415
    //  np.set_printoptions(precision=16)
    //  print( expm(-dt*mat))

    const int N = 18, NArms = 6;
    const int i = 1, j = 2;
    const double dt = 0.157, val = 3.1415;
    AIM_ForkSites sites(N, NArms);

    Index si = sites(i), siP = prime(si), sj = sites(j), sjP = prime(sj);

    ITensor T = val * sites.op("Ck", 1) * sites.op("CkD", 2);
    T += val * sites.op("CkD", 1) * sites.op("Ck", 2);

    ForkGate g(T, i, j);

    g.expGate(dt, sites);
    T = g.gate();

    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(1), siP(1), sj(1), sjP(1))));
    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(2), siP(2), sj(2), sjP(2))));

    EXPECT_DOUBLE_EQ(1.1241165190798785, std::real(T.eltC(si(1), siP(1), sj(2), sjP(2))));
    EXPECT_DOUBLE_EQ(1.1241165190798785, std::real(T.eltC(si(2), siP(2), sj(1), sjP(1))));

    EXPECT_DOUBLE_EQ(-0.5134568613508471, std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))));
    EXPECT_DOUBLE_EQ(-0.5134568613508471, std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))));
  }

  TEST(Gates, ExpGateImag) {
    //calculates exp(- i * dt * G ) and compares to the exact exponential obtaine from python
    //to verify run the python code:
    //
    // mat = np.zeros((4,4), dtype = np.complex128)
    // dt = 1.354;
    // mat[1,2] = 0.7469 + 1j*0.44426;
    // mat[2,1] = 0.7469 - 1j*0.44426;
    // np.set_printoptions(precision=16)
    // print( expm(-1j*dt*mat))
    //

    const int N = 18, NArms = 6;
    const int i = 1, j = 2;
    const Complex dt = 1.354 * Complex_i, val = 0.7469 + Complex_i * 0.44426;
    AIM_ForkSites sites(N, NArms);

    Index si = sites(i), siP = prime(si), sj = sites(j), sjP = prime(sj);

    ITensor T = val * sites.op("Ck", 1) * sites.op("CkD", 2);
    T += std::conj(val) * sites.op("CkD", 1) * sites.op("Ck", 2);

    ForkGate g(T, i, j);

    g.expGate(dt, sites);
    T = g.gate();

    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(1), siP(1), sj(1), sjP(1))));
    EXPECT_DOUBLE_EQ(0., std::imag(T.eltC(si(1), siP(1), sj(1), sjP(1))));
    EXPECT_DOUBLE_EQ(1., std::real(T.eltC(si(2), siP(2), sj(2), sjP(2))));
    EXPECT_DOUBLE_EQ(0., std::imag(T.eltC(si(2), siP(2), sj(2), sjP(2))));

    ASSERT_NEAR(0.3839951149030276, std::real(T.eltC(si(1), siP(1), sj(2), sjP(2))), 1e-15);
    ASSERT_NEAR(0., std::imag(T.eltC(si(1), siP(1), sj(2), sjP(2))), 1e-15);
    ASSERT_NEAR(0.3839951149030276, std::real(T.eltC(si(2), siP(2), sj(1), sjP(1))), 1e-15);
    ASSERT_NEAR(0., std::imag(T.eltC(si(2), siP(2), sj(1), sjP(1))), 1e-15);

    ASSERT_NEAR(-0.472017328124951, std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))), 1e-15);
    ASSERT_NEAR(-0.793566250341074, std::imag(T.eltC(si(1), siP(2), sj(2), sjP(1))), 1e-15);
    ASSERT_NEAR(0.472017328124951, std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))), 1e-15);
    ASSERT_NEAR(-0.793566250341074, std::imag(T.eltC(si(2), siP(1), sj(1), sjP(2))), 1e-15);
  }

  TEST(Gates, ExpGateImagV2) {
    //calculates exp(- i * dt * G ) and compares to the exact exponential obtaine from python
    //to verify run the python code:
    //
    //  val1 = 1.5426 + 1j*3.7846;
    //  val2 = 0.001  + 1j*2.47779;
    //  val3 = 1.44763;
    //  dt = 0.8356;
    //  mat = np.zeros((4,4), dtype = np.complex128)
    //  mat[1,2] = val1;
    //  mat[2,1] = np.conj(val1);
    //  mat[0,3] = val2
    //  mat[3,0] = np.conj(val2)
    //  mat[3,3] = val3
    //  np.set_printoptions(precision=16)
    //  print(expm(-1j*dt*mat))

    const int N = 18, NArms = 6;
    const int i = 1, j = 2;
    const Complex dt = 0.8356 * Complex_i;
    AIM_ForkSites sites(N, NArms);

    Index si = sites(i), siP = prime(si), sj = sites(j), sjP = prime(sj);

    const Complex val1 = 1.5426 + Complex_i * 3.7846;
    const Complex val2 = 0.001 + Complex_i * 2.47779;
    const double val3  = 1.44763;

    ITensor T = removeQNs(val1 * sites.op("Ck", 1) * sites.op("CkD", 2));
    T += removeQNs(std::conj(val1) * sites.op("CkD", 1) * sites.op("Ck", 2));
    T += val2 * removeQNs(sites.op("Ck", 1) * sites.op("Ck", 2));
    T += std::conj(val2) * removeQNs(sites.op("CkD", 1) * sites.op("CkD", 2));
    T += val3 * removeQNs(sites.op("N", 1) * sites.op("N", 2));

    ForkGate g(T, i, j);

    g.expGate(dt, sites);
    T = g.gate();

    // diag terms
    ASSERT_NEAR(-0.3222250638069518, std::real(T.eltC(si(1), siP(1), sj(1), sjP(1))), 1e-15);
    ASSERT_NEAR(5.0670004831822169e-01, std::imag(T.eltC(si(1), siP(1), sj(1), sjP(1))), 1e-15);

    ASSERT_NEAR(-0.9628511091040856, std::real(T.eltC(si(1), siP(1), sj(2), sjP(2))), 1e-15);
    ASSERT_NEAR(0., std::imag(T.eltC(si(1), siP(1), sj(2), sjP(2))), 1e-15);

    ASSERT_NEAR(-0.9628511091040856, std::real(T.eltC(si(2), siP(2), sj(1), sjP(1))), 1e-15);
    ASSERT_NEAR(0., std::imag(T.eltC(si(2), siP(2), sj(1), sjP(1))), 1e-15);

    ASSERT_NEAR(-0.5878725171472071, std::real(T.eltC(si(2), siP(2), sj(2), sjP(2))), 1e-15);
    ASSERT_NEAR(1.2239213330148568e-01, std::imag(T.eltC(si(2), siP(2), sj(2), sjP(2))), 1e-15);

    // off diag terms
    ASSERT_NEAR(0.2500585995262391, std::real(T.eltC(si(1), siP(2), sj(2), sjP(1))), 1e-15);
    ASSERT_NEAR(1.0192368959181325e-01, std::imag(T.eltC(si(1), siP(2), sj(2), sjP(1))), 1e-15);
    ASSERT_NEAR(-0.2500585995262391, std::real(T.eltC(si(2), siP(1), sj(1), sjP(2))), 1e-15);
    ASSERT_NEAR(1.0192368959181325e-01, std::imag(T.eltC(si(2), siP(1), sj(1), sjP(2))), 1e-15);

    ASSERT_NEAR(-0.6579719653520985, std::real(T.eltC(si(1), siP(2), sj(1), sjP(2))), 1e-15);
    ASSERT_NEAR(+4.5442156869983052e-01, std::imag(T.eltC(si(1), siP(2), sj(1), sjP(2))), 1e-15);

    ASSERT_NEAR(0.6576049551998631, std::real(T.eltC(si(2), siP(1), sj(2), sjP(1))), 1e-15);
    ASSERT_NEAR(-4.5495251640748607e-01, std::imag(T.eltC(si(2), siP(1), sj(2), sjP(1))), 1e-15);
  }

} // namespace forktps
