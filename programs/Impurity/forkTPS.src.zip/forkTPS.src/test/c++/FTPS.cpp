#include <forktps/fork/ForkTPS.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>

#include "TestHelpers.hpp"
#include "gtest/gtest.h"

#include <cmath>
#include <iomanip>
#include <vector>
#include <complex>

using namespace itensor;
using namespace forktps;

//todo write tests for read/write
TEST(FTPS, InitStateConstructorAllBathEqual) {
  const int N = 18, NArms = 6;
  const std::vector<int> occSites = {1, 5, 7, 9, 10, 12};

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  CheckOccs(psi, occSites);
}

TEST(FTPS, InitStateConstructorDifferentBathSizes) {
  const std::vector<int> NBaths   = {0, 5, 15, 3, 2};
  const std::vector<int> occSites = {3, 8, 12, 17, 20, 26};

  AIM_ForkSites sites(NBaths);

  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NBaths);

  psi.position(4);

  CheckOccs(psi, occSites);
}

TEST(FTPS, LinkTags) {
  const int N = 24, NArms = 6, NBath = 3, setPos = 17;
  const std::vector<int> occSites = {1, 5, 7, 9, 10, 12};

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);

  psi.position(setPos);

  for (auto arm : range1(NArms - 1)) {
    auto linkII = psi.GetImpLink(arm, Downwards);
    EXPECT_TRUE(hasTags(linkII, Names::TAGSI));
  }

  for (auto arm : range1(NArms)) {
    int impSite = psi.ImpSite(arm);
    auto linkIB = psi.GetLink(impSite, impSite + 1);
    EXPECT_TRUE(hasTags(linkIB, Names::TAGSIB));
  }

  for (auto arm : range1(NArms)) {
    for (auto indx : range1(NBath - 1)) {
      int site    = psi.ImpSite(arm) + indx;
      auto linkBB = psi.GetLink(site, site + 1);
      EXPECT_TRUE(hasTags(linkBB, Names::TAGSB));
    }
  }
}

TEST(FTPS, MathOperators) {
  const int N = 18, NArms = 6;
  const std::vector<int> occSites = {3, 4, 8, 11, 16, 18};
  const double multd = 5.784971, divd = 1.77777;
  const Complex multc = 3.478 + Complex_i * 12.45, divc = 0.9726;

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi_multd(init, NArms), psi_multc(init, NArms), psi_divd(init, NArms), psi_divc(init, NArms);
  psi_multd *= multd;
  psi_multc *= multc;
  psi_divd /= divd;
  psi_divc /= divc;

  for (auto i : occSites) {

    double val_multd = Measure(psi_multd, "N", i);
    double val_multc = Measure(psi_multc, "N", i);
    double val_divd  = Measure(psi_divd, "N", i);
    double val_divc  = Measure(psi_divc, "N", i);

    EXPECT_FLOAT_EQ(multd * multd, val_multd);
    EXPECT_FLOAT_EQ(std::abs(multc) * std::abs(multc), val_multc);
    EXPECT_FLOAT_EQ(1. / (divd * divd), val_divd);
    EXPECT_FLOAT_EQ(1. / (std::abs(divc) * std::abs(divc)), val_divc);
  }
}

TEST(FTPS, Normalize) {
  const int N = 18, NArms = 6;
  const std::vector<int> occSites = {3, 4, 8, 11, 16, 18};
  const double multd              = 5.784971;

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms);
  psi *= multd;
  psi.normalize();

  for (auto i : occSites) {
    double val = Measure(psi, "N", i);
    EXPECT_FLOAT_EQ(1., val);
  }
}

TEST(FTPS, ReadWrite) {
  //Creates an FTPS, writes it to disk, reloads it an checks the occupied sites
  const int N = 18, NArms = 6;
  const std::vector<int> occSites = {1, 5, 7, 9, 10, 12};

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS save(init, NArms), load(sites, NArms);

  std::ofstream outst("MPS", std::ofstream::out);
  save.write(outst);
  outst.close();

  std::ifstream inst("MPS", std::ifstream::in);
  load.read(inst, sites);
  inst.close();

  CheckOccs(load, occSites);
}

TEST(FTPS, ApplySingleSiteOp) {
  //Test the function ApplySingleSiteOp by sweeping through every site of an FTPS
  //and dependending on whether this site is occupied or not it annihilates/creates
  //a particle. then it checks if the updated occupation is correct

  const int N = 18, NArms = 6;
  const std::vector<int> occSites = {1, 5, 7, 9, 10, 12};

  AIM_ForkSites sites(N, NArms);
  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi(init, NArms), psi2(init, NArms);

  for (auto i : range1(N)) {
    ITensor op;
    std::vector<int> actualoccSites = occSites;
    auto found                      = std::find(actualoccSites.begin(), actualoccSites.end(), i);

    if (found != actualoccSites.end()) {
      op = sites.op("Ck", i);
      actualoccSites.erase(found);
    } else {
      op = sites.op("CkD", i);
      actualoccSites.push_back(i);
    }

    psi2 = psi;
    psi2.ApplySingleSiteOp(op, i, true);
    CheckOccs(psi2, actualoccSites);
  }
}

TEST(FTPS, Randomize) { /// NOLINT
  const int NArms = 4, NBath = 2, N = NArms * (NBath + 1), bondDim = 5;

  AIM_ForkSites sites(N, NArms, {"conserveN", false, "conserveSz", false});
  ForkTPS psi(sites, NArms);
  psi.randomize(bondDim);
}

TEST(FTPS, OneOrbital) {
  const int N = 8, NArms = 2;
  const std::vector<int> occSites = {1, 4, 5, 6};

  AIM_ForkSites sites(N, NArms);

  // site set constructor
  ForkTPS psi1(sites, NArms);

  // positions
  for (auto i : range1(N)) { psi1.position(i); }

  // init state constructor

  InitState init(sites);
  for (auto s : occSites) init.set(s, "Occ");

  ForkTPS psi2(init, NArms);

  // positions
  for (auto i : range1(N)) { psi2.position(i); }
}
