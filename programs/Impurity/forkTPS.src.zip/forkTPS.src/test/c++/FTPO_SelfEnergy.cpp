#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/ForkTPS.hpp>
#include <forktps/fork/HelperFunctions.hpp>
#include <forktps/fork/FTPO/AIM_SelfEnergyTrick.hpp>

#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>

#include "gtest/gtest.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

//In these tests we compare MPOs in using parameter regimes where they should agree
//to do so, we look at the ground state energy as well as the ground state
//correlation matrix  <GS| cidag cj |GS>

namespace forktps {

  const int SEED_RNG(1598745);

  struct IntParams {
    double U;
    double Up;
    double J;
  };

  int GetOrb(int indx) { return std::round((indx + indx % 2) / 2); };
  double DD_entry(int siteN, int j, IntParams Ip);

  // tests the entries of the self energy MPO from the commutator of the density-density interactions with cnsigma
  // i.e.: [ H_{DD}, c_{n sigma} ] = - c_{n sigma} * ( U n_{n barsigma} + Up sum_{m != n} n_{m barsigma} +   (Up-J) sum_{m != n} n_{m sigma} +  )
  // For each (n,sigma) it prepares a product state such that only one term in the commutater contributes and
  // then looks at the value of the overlap with the corresponding product state that we expect from the action of
  // the FTPO
  TEST(SelfEnergy, DD_entries) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps     = {0., 1000, 1000};
    const dvec V       = {0., 0.};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-14, "maxsweeps", 3, "verbose", false, "NAppH", 0, "DDonly", true};
    AIM_ForkSites sites(N, NArms);

    for (auto siteN : range1(NArms)) {
      ForkTPO H = ForkTPO(AIM_SelfEnergyMPO(sites, Ip.U, Ip.Up, Ip.J, siteN, NArms, args));

      for (auto k : range1(NArms)) {
        if (k == siteN) continue;

        InitState init(sites);
        for (auto i : range1(N)) init.set(i, "Emp");

        init.set(H.ImpSite(siteN), "Occ");
        init.set(H.ImpSite(k), "Occ");

        ForkTPS res(init, NArms);
        res = exactApplyMPO(res, H, args);

        init.set(H.ImpSite(siteN), "Emp");
        ForkTPS ref(init, NArms);

        EXPECT_NEAR(DD_entry(siteN, k, Ip), overlap(ref, res).real(), 1E-14);
      }
    }
  }

  // tests the entries of the self energy MPO from the commutator of the spin-flip interactions with cnsigma
  // i.e.: [ H_{SF}, c_{n sigma} ] = J sum_{m != n} c_{n barsigma} c^dag_{m barsigma} * c_{m sigma}
  // For each (n,sigma) it prepares a product state such that only one term in the commutater contributes and
  // then looks at the value of the overlap with the corresponding product state that we expect from the action of
  // the FTPO
  TEST(SelfEnergy, SF_entries) {

    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps     = {0., 1000, 1000};
    const dvec V       = {0., 0.};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-14, "maxsweeps", 3, "verbose", false, "NAppH", 0, "DDonly", false};
    AIM_ForkSites sites(N, NArms);

    for (auto siteN : range1(NArms)) {
      ForkTPO H = ForkTPO(AIM_SelfEnergyMPO(sites, Ip.U, Ip.Up, Ip.J, siteN, NArms, args));

      for (auto M : range1(NArms / 2)) {
        if (GetOrb(siteN) == M) continue;
        if (siteN % 2 == 1) {
          // spin up
          InitState init(sites);

          for (auto i : range1(N)) init.set(i, "Emp");
          init.set(H.ImpSite(siteN + 1), "Occ");
          init.set(H.ImpSite(2 * M - 1), "Occ");

          ForkTPS res(init, NArms);
          res = exactApplyMPO(res, H, args);

          init.set(H.ImpSite(siteN + 1), "Emp");
          init.set(H.ImpSite(2 * M - 1), "Emp");
          init.set(H.ImpSite(2 * M), "Occ");

          ForkTPS ref(init, NArms);

          if (GetOrb(siteN) > M)
            EXPECT_NEAR(overlap(ref, res).real(), -Ip.J, 1E-14); // cn must be moved past one particle created by the operators on M -> sign
          else
            EXPECT_NEAR(overlap(ref, res).real(), Ip.J, 1E-14); // both M operators must be moved past one particle that is on orbital cn -> no sign

        } else {
          // spin dn
          InitState init(sites);

          for (auto i : range1(N)) init.set(i, "Emp");
          init.set(H.ImpSite(siteN - 1), "Occ");
          init.set(H.ImpSite(2 * M), "Occ");

          ForkTPS res(init, NArms);
          res = exactApplyMPO(res, H, args);

          init.set(H.ImpSite(siteN - 1), "Emp");
          init.set(H.ImpSite(2 * M), "Emp");
          init.set(H.ImpSite(2 * M - 1), "Occ");

          ForkTPS ref(init, NArms);

          if (GetOrb(siteN) > M)
            EXPECT_NEAR(overlap(ref, res).real(), -Ip.J, 1E-14); // cn must be moved past one particle created by the operators on M -> sign
          else
            EXPECT_NEAR(overlap(ref, res).real(), Ip.J, 1E-14); // both M operators must be moved past one particle that is on orbital cn -> no sign
        }
      }
    }
  }

  // tests the entries of the self energy MPO from the commutator of the pair-hopping interactions with cnsigma
  // i.e.: [ H_{PH}, c_{n sigma} ] = -J sum_{m != n} c^dag_{n barsigma} c_{m barsigma} * c_{m sigma}
  // For each (n,sigma) it prepares a product state such that only one term in the commutater contributes and
  // then looks at the value of the overlap with the corresponding product state that we expect from the action of
  // the FTPO
  TEST(SelfEnergy, PH_entries) {
    itensor::seedRNG(SEED_RNG);

    const int N = 18, NArms = 6;
    const dvec eps     = {0., 1000, 1000};
    const dvec V       = {0., 0.};
    const IntParams Ip = {1.0, 0.8, 0.1};

    Args args{"Cutoff", 1E-14, "maxsweeps", 3, "verbose", false, "NAppH", 0, "DDonly", false};
    AIM_ForkSites sites(N, NArms);

    for (auto siteN : range1(NArms)) {
      ForkTPO H = ForkTPO(AIM_SelfEnergyMPO(sites, Ip.U, Ip.Up, Ip.J, siteN, NArms, args));

      for (auto M : range1(NArms / 2)) {
        if (GetOrb(siteN) == M) continue;
        if (siteN % 2 == 1) {
          // spin up
          InitState init(sites);

          for (auto i : range1(N)) init.set(i, "Emp");
          init.set(H.ImpSite(2 * M - 1), "Occ");
          init.set(H.ImpSite(2 * M), "Occ");

          ForkTPS res(init, NArms);
          res = exactApplyMPO(res, H, args);

          init.set(H.ImpSite(2 * M - 1), "Emp");
          init.set(H.ImpSite(2 * M), "Emp");
          init.set(H.ImpSite(siteN + 1), "Occ");

          ForkTPS ref(init, NArms);

          EXPECT_NEAR(overlap(ref, res).real(), -Ip.J, 1E-14);
        } else {
          // spin dn
          InitState init(sites);

          for (auto i : range1(N)) init.set(i, "Emp");
          init.set(H.ImpSite(2 * M - 1), "Occ");
          init.set(H.ImpSite(2 * M), "Occ");

          ForkTPS res(init, NArms);
          res = exactApplyMPO(res, H, args);

          init.set(H.ImpSite(2 * M - 1), "Emp");
          init.set(H.ImpSite(2 * M), "Emp");
          init.set(H.ImpSite(siteN - 1), "Occ");

          ForkTPS ref(init, NArms);

          EXPECT_NEAR(overlap(ref, res).real(), Ip.J, 1E-14); // if GetOrb(siteN)>M cn must be moved past BOTH particle on M -> no sign
        }
      }
    }
  }

  double DD_entry(int siteN, int j, IntParams Ip) {
    int sign = (siteN < j) ? +1 : -1;

    if (siteN % 2 == 1) {
      //up

      // same orbital
      if (j == siteN + 1) return -sign * Ip.U;
      // different orbital same spin
      if (j % 2 == 1) return -sign * (Ip.Up - Ip.J);
      //different orbital different spin
      else
        return -sign * (Ip.Up);
    } else {
      // down

      // same orbital
      if (j == siteN - 1) return -sign * Ip.U;
      // different orbital same spin
      if (j % 2 == 0) return -sign * (Ip.Up - Ip.J);
      //different orbital different spin
      else
        return -sign * (Ip.Up);
    }

    return NAN;
  }

} // namespace forktps
