#include "forktps/fork/typenames.hpp"
#include <forktps/params.hpp>
#include <forktps/setargs.hpp>

#include "gtest/gtest.h"

#include <cmath>
#include <time.h>
#include <iomanip>
#include <vector>
#include <complex>

using namespace std;
using namespace forktps;

TEST(SetArgs, DMRG_params) {
  std::cout << "Testing SetArgs" << std::endl;
  const int nH = 17;
  const int sw = 238;

  const int mb = 21, mi = 89, mib = 3;
  const double twb = 0.11, twi = 2.58789, twib = 1E-15;

  const double conv = 1E-1, err = 0.4447;
  const int nmax = 14;

  const bool imag_tevo     = true;
  const int NT             = 18;
  const double dtau        = 0.88;
  const std::string method = "TEBD";
  const int nHPrep         = 4;

  DMRG_params p;
  p.napp_h = nH;
  p.sweeps = sw;

  p.approx.maxm_b  = mb;
  p.approx.maxm_i  = mi;
  p.approx.maxm_ib = mib;
  p.approx.tw_b    = twb;
  p.approx.tw_i    = twi;
  p.approx.tw_ib   = twib;

  p.krylov.conv     = conv;
  p.krylov.nmax     = nmax;
  p.krylov.norm_err = err;

  p.prep.imag_tevo  = imag_tevo;
  p.prep.dtau       = dtau;
  p.prep.method     = method;
  p.prep.napp_h     = nHPrep;
  p.prep.time_steps = NT;

  Args args;
  SetArgs(args, p);

  EXPECT_EQ(args.getInt("maxsweeps"), sw);
  EXPECT_EQ(args.getInt("NAppH"), nH);

  EXPECT_EQ(args.getInt(Names::MAXMB), mb);
  EXPECT_EQ(args.getInt(Names::MAXMI), mi);
  EXPECT_EQ(args.getInt(Names::MAXMIB), mib);
  EXPECT_EQ(args.getReal(Names::TWB), twb);
  EXPECT_EQ(args.getReal(Names::TWI), twi);
  EXPECT_EQ(args.getReal(Names::TWIB), twib);

  EXPECT_EQ(args.getReal("ErrGoal"), conv);
  EXPECT_EQ(args.getInt("MaxIter"), nmax);
  EXPECT_EQ(args.getReal("NormCutoff"), err);

  EXPECT_EQ(args.getBool("DoImagTevo"), imag_tevo);
  EXPECT_EQ(args.getReal("dtau"), dtau);
  EXPECT_EQ(args.getString("TevoMethod"), method);
  EXPECT_EQ(args.getInt("NAppHPrep"), nHPrep);
  EXPECT_EQ(args.getInt("NTimeSteps"), NT);
}
