#include <forktps/fork/ForkTN.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>

#include "TestHelpers.hpp"
#include "gtest/gtest.h"

#include <cmath>
#include <iomanip>
#include <vector>
#include <complex>

using namespace itensor;
using namespace std;
using namespace forktps;

//todo write more tests

TEST(TN, SiteSetConstructor) {
  const int N = 24, NArms = 6, NBath = 3;
  AIM_ForkSites sites(N, NArms);
  ;
  const std::vector<int> positions{1, 3, 4, 7, N};

  ForkTN psi(sites, NArms);
  for (auto pos : positions) {

    psi.position(pos);
    EXPECT_EQ(pos, psi.OrthoCenter());

    for (auto arm : range1(NArms - 1)) {
      auto linkII = psi.GetImpLink(arm, Downwards);
      EXPECT_TRUE(hasTags(linkII, Names::TAGSI));
    }

    for (auto arm : range1(NArms)) {
      int impSite = psi.ImpSite(arm);
      auto linkIB = psi.GetLink(impSite, impSite + 1);
      EXPECT_TRUE(hasTags(linkIB, Names::TAGSIB));
    }

    for (auto arm : range1(NArms)) {
      for (auto indx : range1(NBath - 1)) {
        int site    = psi.ImpSite(arm) + indx;
        auto linkBB = psi.GetLink(site, site + 1);
        EXPECT_TRUE(hasTags(linkBB, Names::TAGSB));
      }
    }
  }
}
