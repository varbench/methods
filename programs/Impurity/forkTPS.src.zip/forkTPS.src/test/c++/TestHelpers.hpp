
#include "forktps/fork/Fork.hpp"
#include "forktps/fork/ForkTPS.hpp"
#include "forktps/fork/ForkTPO.hpp"
#include "forktps/fork/ForkCalculus.hpp"

#include <itertools/itertools.hpp>

#include "gtest/gtest.h"

using namespace std;
using namespace forktps;
using namespace itensor;

namespace forktps {

  void CheckLinks(const ForkTPS &psi) {
    const int NArms = psi.NArms();
    const int NBath = psi.NBath();

    for (auto arm : range1(NArms - 1)) {
      auto linkII = psi.GetImpLink(arm, Downwards);
      EXPECT_TRUE(hasTags(linkII, Names::TAGSI)) << "failed at arm " << arm;
    }

    for (auto arm : range1(NArms)) {
      int impSite = psi.ImpSite(arm);
      auto linkIB = psi.GetLink(impSite, impSite + 1);
      EXPECT_TRUE(hasTags(linkIB, Names::TAGSIB)) << "failed at arm " << arm;
    }

    for (auto arm : range1(NArms)) {
      for (auto indx : range1(NBath - 1)) {
        int site    = psi.ImpSite(arm) + indx;
        auto linkBB = psi.GetLink(site, site + 1);
        EXPECT_TRUE(hasTags(linkBB, Names::TAGSB)) << "failed at arm " << arm << " indx " << indx;
      }
    }
  }

  void CheckAllTags(const ForkTPO &H) {
    int NArms = H.NArms();
    int NBath = H.NBath();

    for (auto ch : range1(NArms)) {
      //check imp tensor at ch
      {
        int site  = H.ImpSite(ch);
        ITensor T = H.A(site);

        //impurity tensors
        Index Blink = commonIndex(T, H.A(site + 1));
        EXPECT_TRUE(hasTags(Blink, Names::TAGSIB));

        if (ch == 1) {
          Index IlinkDn = commonIndex(T, H.A(H.ImpSite(ch + 1)));
          EXPECT_TRUE(hasTags(IlinkDn, Names::TAGSI));
        } else if (ch == NArms) {
          Index IlinkUp = commonIndex(T, H.A(H.ImpSite(ch - 1)));
          EXPECT_TRUE(hasTags(IlinkUp, Names::TAGSI));
        } else {
          Index IlinkUp = commonIndex(T, H.A(H.ImpSite(ch - 1)));
          Index IlinkDn = commonIndex(T, H.A(H.ImpSite(ch + 1)));
          EXPECT_TRUE(hasTags(IlinkDn, Names::TAGSI));
          EXPECT_TRUE(hasTags(IlinkUp, Names::TAGSI));
        }
      }

      //Check all bath tensors
      for (auto k : range1(NBath)) {
        int site = H.ArmToSite(ch, k);

        ITensor T = H.A(site);

        Index lLink = commonIndex(T, H.A(site - 1));

        if (k == NBath)
          EXPECT_TRUE(hasTags(lLink, Names::TAGSIB));
        else
          EXPECT_TRUE(hasTags(lLink, Names::TAGSB));

        if (k != 1) {
          Index rLink = commonIndex(T, H.A(site + 1));
          EXPECT_TRUE(hasTags(rLink, Names::TAGSB));
        }
      }
    }
  }

  void GetExactGF(std::vector<Complex> &GF, std::string fn) {
    std::ifstream infile(fn);
    GF.resize(0);
    double re(0.), im(0.), t(0.);

    if (infile.good()) {
      while (infile >> t >> re >> im) { GF.push_back(re + Complex_i * im); }
    }
    infile.close();
  }

  void GetExactGF_offDiag(std::vector<std::vector<Complex>> &GF, std::string fn) {
    std::ifstream infile(fn);
    GF.resize(3);
    for (auto i : itertools::range(3)) GF.at(i).resize(0);

    double re1(0.), im1(0.), re2(0.), im2(0.), t(0.);

    if (infile.good()) {
      while (infile >> t >> re1 >> im1 >> re2 >> im2) {
        GF.at(1).push_back(re1 + Complex_i * im1);
        GF.at(2).push_back(re2 + Complex_i * im2);
      }
    }
    infile.close();
  }

  void CheckOccs(ForkTPS &psi, const std::vector<int> occSites) {

    for (auto i : range1(psi.N())) {
      int val    = static_cast<int>(std::round(Measure(psi, "N", i)));
      auto found = std::find(occSites.begin(), occSites.end(), i);
      if (found != occSites.end())
        EXPECT_EQ(1, val);
      else
        EXPECT_EQ(0, val);
    }
  }

  void CheckUnityTensor(const ForkTPO &H, double factor = 1) {
    int NArms            = H.NArms();
    int NBath            = H.NBath();
    const SiteSet &sites = H.sites();

    for (auto ch : range1(NArms)) {
      //check imp tensor at ch
      {
        int site  = H.ImpSite(ch);
        ITensor T = H.A(site);

        //impurity tensors
        Index Blink = commonIndex(T, H.A(site + 1));
        Index si = sites(site), siP = prime(si);
        double val(0.);

        for (auto i : range1(2)) {
          for (auto j : range1(2)) {
            if (ch == 1) {
              Index IlinkDn = commonIndex(T, H.A(H.ImpSite(ch + 1)));
              val           = std::real(T.eltC(si(i), siP(j), IlinkDn(1), Blink(1)));
            } else if (ch == NArms) {
              Index IlinkUp = commonIndex(T, H.A(H.ImpSite(ch - 1)));
              val           = std::real(T.eltC(si(i), siP(j), IlinkUp(1), Blink(1)));
            } else {
              Index IlinkUp = commonIndex(T, H.A(H.ImpSite(ch - 1)));
              Index IlinkDn = commonIndex(T, H.A(H.ImpSite(ch + 1)));

              val = std::real(T.eltC(si(i), siP(j), IlinkDn(1), IlinkUp(1), Blink(1)));
            }

            double expectedVal = i == j ? 1. : 0.;
            EXPECT_DOUBLE_EQ(val, factor * expectedVal);
          }
        }
      }

      //Check all bath tensors
      for (auto k : range1(NBath)) {
        int site = H.ArmToSite(ch, k);

        ITensor T = H.A(site);

        Index lLink = commonIndex(T, H.A(site - 1));
        Index si = sites(site), siP = prime(si);
        double val(0.);

        for (auto i : range1(2)) {
          for (auto j : range1(2)) {
            if (k == 1) {
              val = std::real(T.eltC(si(i), siP(j), lLink(1)));
            } else {
              Index rLink = commonIndex(T, H.A(site + 1));
              val         = std::real(T.eltC(si(i), siP(j), lLink(1), rLink(1)));
            }

            double expectedVal = i == j ? 1. : 0.;
            EXPECT_DOUBLE_EQ(val, factor * expectedVal);
          }
        }
      }
    }
  }

  void ExpectTensorToHaveLinks(ITensor T, Index l1, Index l2, Index l3) {
    EXPECT_TRUE(hasIndex(T, l1));
    EXPECT_TRUE(hasIndex(T, l2));
    EXPECT_TRUE(hasIndex(T, l3));
  }

  void ExpectSameLinks(ITensor A, ITensor B) {
    for (auto ind : A.inds()) { EXPECT_TRUE(hasIndex(B, ind)); }
    for (auto ind : B.inds()) { EXPECT_TRUE(hasIndex(A, ind)); }
  }

} // namespace forktps
