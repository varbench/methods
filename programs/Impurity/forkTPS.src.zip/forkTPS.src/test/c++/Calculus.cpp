#include <forktps/fork/FTPO/AIM.hpp>
#include <forktps/fork/SiteSets/AIM_ForkSites.hpp>
#include <forktps/fork/ForkCalculus.hpp>
#include <forktps/fork/Bath.hpp>
#include <forktps/fork/makros.hpp>

#include "TestHelpers.hpp"

#include "gtest/gtest.h"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <vector>
#include <complex>

using namespace forktps;
using namespace itensor;

namespace forktps {

  const int RNG_SEED = 1598745;

  TEST(ForkCalculus, DMRG_Nb4) {
    //calculates the groundstate of a AIM with 4 bath sites and formally two orbitals
    //in this test, only the first orbital is occupied by 2 electrons
    //it compares the ground state energy as well as the groundstate
    //single particle correlation matrix to the exact solution obtained by the python program
    // eps = [0., 1 , 0  ,-1  ]
    // V   = [0.3, 0.2, 0.1]
    // mat = np.diag(eps)
    // for i in range(len(V)):
    //     mat[0,i+1] = V[i]
    //     mat[i+1,0] = V[i]
    // D,V = np.linalg.eigh(mat)
    //
    // Vdag = np.conj( V.transpose() )
    // FS = np.ones(len(D), dtype=np.float64);
    // FS[2:] = 0
    // correlations = np.dot(V, np.dot( np.diag(FS), Vdag) )
    //
    // print(D[0]+D[1])
    // print(correlations)

    const int N = 16, NArms = 4;
    const std::vector<int> occSites = {1, 2};
    const std::vector<double> eps   = {0., -1, 0, 1};
    const std::vector<double> V     = {0.1, 0.2, 0.3};

    const double expectedVar = 1E-14;

    Args args{"Cutoff", 1E-16, "maxsweeps", 20, "verbose", true, "NAppH", 3};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    itensor::seedRNG(RNG_SEED);

    ForkTPS psi(init, NArms);

    double U = 0, Up = 0, J = 0;
    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));

    H.position(N);
    H.position(1);

    for (int i = 0; i < 5; ++i) {
      psi = forktps::exactApplyMPO(psi, H, args);
      psi.normalize();
    }

    double energy(0.);
    std::cout << "DMRG\n";
    forktps::DMRG(psi, H, energy, args);
    std::cout << "DMRG done\n";

    //check convergence
    auto [psiHpsi, psiHHpsi] = GSConvergence(psi, H);
    double var               = psiHpsi * psiHpsi - psiHHpsi;
    EXPECT_NEAR(var, 0., expectedVar);

    //check observables
    const std::vector<std::vector<double>> corrMat = {{0.5616131297843147, -0.1356444935142322, -0.476005920921179, -0.03496794053742},
                                                      {-0.1356444935142322, 0.0328619108862356, 0.1156728775735074, -0.0015370335950988},
                                                      {-0.476005920921179, 0.1156728775735074, 0.4084073154163702, -0.0406070039846339},
                                                      {-0.03496794053742, -0.0015370335950988, -0.0406070039846339, 0.9971176439130779}};

    EXPECT_FLOAT_EQ(-1.2430383856113385, energy);

    for (auto i : itertools::range(4)) {
      for (auto j : itertools::range(i, 4)) {
        //calculate <GS |c_idag cj|GS> and compare to corrMat from python
        auto sitei = i + 1;
        auto sitej = j + 1;

        forktps::ForkTPS OpGs = psi;
        OpGs.ApplySingleSiteOp(sites.op("Ck", sitej), sitej, true);
        OpGs.ApplySingleSiteOp(sites.op("CkD", sitei), sitei, true);

        auto val = forktps::overlap(psi, OpGs).real();

        EXPECT_FLOAT_EQ(val, corrMat[i][j]);
      }
    }
  }

  TEST(ForkCalculus, DMRG_AllOrbs) {
    //calculates the groundstate of a AIM with 4 bath sites and three orbitals
    //in this test, all orbitals/spins are occupied by 2 electrons
    //it compares the ground state energy as well as the groundstate
    //single particle correlation matrix to the exact solution obtained by the python program
    //note that this also tests the fermionic sign, since the correlation matrix depends on it
    // eps = [0.2, -1.7852 , 0.36  , 1.4441  ]
    // V   = [0.13, 0.87, 5.888888 ]
    // mat = np.diag(eps)
    // for i in range(len(V)):
    //     mat[0,i+1] = V[i]
    //     mat[i+1,0] = V[i]

    // D,V = np.linalg.eigh(mat)

    // Vdag = np.conj( V.transpose() )
    // FS = np.ones(len(D), dtype=np.float64);
    // FS[2:] = 0
    // correlations = np.dot(V, np.dot( np.diag(FS), Vdag) )

    // print(D[0]+D[1])
    // print(correlations)

    const int N = 24, NArms = 6;
    std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14, 17, 18, 21, 22};

    Args args{"Cutoff", 1E-16, "maxsweeps", 20, "NAppH", 5, "verbose", false, "KrylovNormError", 1E-15, "LanzcosConv", 1E-14};

    const double expectedVar = 1E-11;

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    //itensor::seedRNG(RNG_SEED);

    ForkTPS psi(init, NArms);

    const std::vector<double> eps = {0.2, 1.4441, 0.36, -1.7852};
    const std::vector<double> V   = {5.888888, 0.87, 0.13};

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    for (int i = 0; i < 5; ++i) {
      psi = forktps::exactApplyMPO(psi, H, args);
      psi.normalize();
    }
    double energy(0.);
    forktps::DMRG(psi, H, energy, args);
    psi.normalize();

    //check convergence
    auto [psiHpsi, psiHHpsi] = GSConvergence(psi, H);
    double var               = psiHpsi * psiHpsi - psiHHpsi;
    EXPECT_NEAR(var, 0., expectedVar);

    //check observables
    const std::vector<std::vector<double>> corrMat = {{0.5505935128528482, -0.0068377807674237, -0.0865424247553334, -0.4897999080531286},
                                                      {-0.0068377807674237, 0.9998945874010963, -0.0024713993802605, -0.0072483395593456},
                                                      {-0.0865424247553334, -0.0024713993802605, 0.0136153374324, 0.0770341542536334},
                                                      {-0.4897999080531286, -0.0072483395593456, 0.0770341542536334, 0.4358965623136562}};

    //take GS energy times NArms for all orbitals
    EXPECT_FLOAT_EQ(NArms * -6.961628611689203, energy);
    for (auto ch : range1(NArms)) {
      for (auto i : itertools::range(4)) {
        for (auto j : itertools::range(i, 4)) {
          //calculate <GS |c_idag cj|GS> and compare to corrMat from python
          auto sitei = psi.ImpSite(ch) + i;
          auto sitej = psi.ImpSite(ch) + j;

          forktps::ForkTPS OpGs = psi;
          OpGs.ApplySingleSiteOp(sites.op("Ck", sitej), sitej, true);
          OpGs.ApplySingleSiteOp(sites.op("CkD", sitei), sitei, true);

          auto val = forktps::overlap(psi, OpGs).real();

          EXPECT_FLOAT_EQ(val, corrMat[i][j]);
        }
      }
    }
  }

  TEST(ForkCalculus, DMRG_CheckLinks) {
    //Checks whether the link tags are correct after DMRG
    const int N = 16, NArms = 4;
    std::vector<int> occSites = {1, 2};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "UseDavidson", true};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);

    const std::vector<double> eps = {0., -1, 0, 1};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    double energy(0.);
    forktps::DMRG(psi, H, energy, args);
    CheckLinks(psi);
  }

  TEST(ForkCalculus, DMRG_SSImp_Nb4) {
    //calculates the groundstate of a AIM with 4 bath sites and formally two orbitals
    //this function uses single-site DMRG for the impurity-impurity links
    //in this test, only the first orbital is occupied by 2 electrons
    //it compares the ground state energy as well as the groundstate
    //single particle correlation matrix to the exact solution obtained by the python program
    // eps = [0., 1 , 0  ,-1  ]
    // V   = [0.3, 0.2, 0.1]
    // mat = np.diag(eps)
    // for i in range(len(V)):
    //     mat[0,i+1] = V[i]
    //     mat[i+1,0] = V[i]
    // D,V = np.linalg.eigh(mat)
    //
    // Vdag = np.conj( V.transpose() )
    // FS = np.ones(len(D), dtype=np.float64);
    // FS[2:] = 0
    // correlations = np.dot(V, np.dot( np.diag(FS), Vdag) )
    //
    // print(D[0]+D[1])
    // print(correlations)

    const int N = 16, NArms = 4;
    const std::vector<int> occSites = {1, 2};

    const std::vector<double> eps = {0., -1, 0, 1};
    const std::vector<double> V   = {0.1, 0.2, 0.3};
    double expectedVar            = 1E-14;

    Args args{"Cutoff", 1E-16, "maxsweeps", 20, "verbose", false, "NAppH", 3};
    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    itensor::seedRNG(RNG_SEED);
    ForkTPS psi(init, NArms);

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    for (int i = 0; i < 10; ++i) {
      UNUSED_VAR(i);
      psi = forktps::exactApplyMPO(psi, H, args);
      psi.normalize();
    }
    double energy(0.);
    forktps::DMRG(psi, H, energy, args);

    //check convergence
    auto [psiHpsi, psiHHpsi] = GSConvergence(psi, H);
    double var               = psiHpsi * psiHpsi - psiHHpsi;
    EXPECT_NEAR(var, 0., expectedVar);

    //check observables
    const std::vector<std::vector<double>> corrMat = {{0.5616131297843147, -0.1356444935142322, -0.476005920921179, -0.03496794053742},
                                                      {-0.1356444935142322, 0.0328619108862356, 0.1156728775735074, -0.0015370335950988},
                                                      {-0.476005920921179, 0.1156728775735074, 0.4084073154163702, -0.0406070039846339},
                                                      {-0.03496794053742, -0.0015370335950988, -0.0406070039846339, 0.9971176439130779}};

    EXPECT_FLOAT_EQ(-1.2430383856113385, energy);

    for (auto i : itertools::range(4)) {
      for (auto j : itertools::range(i, 4)) {
        //calculate <GS |c_idag cj|GS> and compare to corrMat from python
        auto sitei = i + 1;
        auto sitej = j + 1;

        forktps::ForkTPS OpGs = psi;
        OpGs.ApplySingleSiteOp(sites.op("Ck", sitej), sitej, true);
        OpGs.ApplySingleSiteOp(sites.op("CkD", sitei), sitei, true);

        auto val = forktps::overlap(psi, OpGs).real();

        EXPECT_FLOAT_EQ(val, corrMat[i][j]);
      }
    }
  }

  TEST(ForkCalculus, DMRG_SSImp_AllOrbs) {
    //calculates the groundstate of a AIM with 4 bath sites and three orbitals
    //in this test, all orbitals/spins are occupied by 2 electrons
    //it compares the ground state energy as well as the groundstate
    //single particle correlation matrix to the exact solution obtained by the python program
    //note that this also tests the fermionic sign, since the correlation matrix depends on it
    // eps = [0.2, -1.7852 , 0.36  , 1.4441  ]
    // V   = [0.13, 0.87, 5.888888 ]
    // mat = np.diag(eps)
    // for i in range(len(V)):
    //     mat[0,i+1] = V[i]
    //     mat[i+1,0] = V[i]

    // D,V = np.linalg.eigh(mat)

    // Vdag = np.conj( V.transpose() )
    // FS = np.ones(len(D), dtype=np.float64);
    // FS[2:] = 0
    // correlations = np.dot(V, np.dot( np.diag(FS), Vdag) )

    // print(D[0]+D[1])
    // print(correlations)

    const int N = 24, NArms = 6;
    const std::vector<int> occSites = {1, 2, 5, 6, 9, 10, 13, 14, 17, 18, 21, 22};
    const std::vector<double> eps   = {0.2, 1.4441, 0.36, -1.7852};
    const std::vector<double> V     = {5.888888, 0.87, 0.13};

    const double expectedVar = 1E-11;

    Args args{"Cutoff", 1E-16, "maxsweeps", 20, "NAppH", 3, "verbose", false, "KrylovNormError", 1E-15, "LanzcosConv", 1E-14};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);
    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    itensor::seedRNG(RNG_SEED);

    for (int i = 0; i < 10; ++i) {
      UNUSED_VAR(i);
      psi = forktps::exactApplyMPO(psi, H, args);
      psi.normalize();
    }

    double energy(0.);
    forktps::DMRG(psi, H, energy, args);

    //check convergence
    auto [psiHpsi, psiHHpsi] = GSConvergence(psi, H);
    double var               = psiHpsi * psiHpsi - psiHHpsi;
    EXPECT_NEAR(var, 0., expectedVar);

    //check observables
    const std::vector<std::vector<double>> corrMat = {{0.5505935128528482, -0.0068377807674237, -0.0865424247553334, -0.4897999080531286},
                                                      {-0.0068377807674237, 0.9998945874010963, -0.0024713993802605, -0.0072483395593456},
                                                      {-0.0865424247553334, -0.0024713993802605, 0.0136153374324, 0.0770341542536334},
                                                      {-0.4897999080531286, -0.0072483395593456, 0.0770341542536334, 0.4358965623136562}};

    //take GS energy times NArms for all orbitals
    EXPECT_FLOAT_EQ(NArms * -6.961628611689203, energy);
    for (auto ch : range1(NArms)) {
      for (auto i : itertools::range(4)) {
        for (auto j : itertools::range(i, 4)) {
          //calculate <GS |c_idag cj|GS> and compare to corrMat from python
          auto sitei = psi.ImpSite(ch) + i;
          auto sitej = psi.ImpSite(ch) + j;

          forktps::ForkTPS OpGs = psi;
          OpGs.ApplySingleSiteOp(sites.op("Ck", sitej), sitej, true);
          OpGs.ApplySingleSiteOp(sites.op("CkD", sitei), sitei, true);

          auto val = forktps::overlap(psi, OpGs).real();

          EXPECT_FLOAT_EQ(val, corrMat[i][j]);
        }
      }
    }
  }

  TEST(ForkCalculus, DMRG_SSImp_CheckLinks) {
    //Checks whether the link tags are correct after DMRG
    const int N = 16, NArms = 4;
    std::vector<int> occSites = {1, 2};

    Args args{"Cutoff", 1E-15, "maxsweeps", 20, "verbose", false, "UseDavidson", true};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);

    psi.PrintTensors();

    const std::vector<double> eps = {0., -1, 0, 1};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    double energy(0.);
    forktps::DMRG(psi, H, energy, args);
    CheckLinks(psi);
  }

  TEST(ForkCalculus, ApplyGate) {
    //Checks wheter apply Gate works correctly, including link tags after svd
    //Therefore we initialize the FPTS in a product state with occupations at
    //some sites. Then we apply a simple gate on each link consisting of creation/annihilation
    //operators depending on whether the site is empty/occ. Then we check if
    //each site has the correct occupation after the gate acted.
    //Note that this test also checks the function Measure().
    const int N = 16, NArms = 4, NBath = int(std::round(N / NArms)) - 1;
    const std::vector<int> occSites = {1, 2, 5, 7, 10, 11, 13, 16};

    Args args{"Cutoff", 1E-15};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);

    for (auto ch : range1(NArms)) {
      for (auto indx : range1(NBath)) {
        auto i       = psi.ArmToSite(ch, indx) - 1;
        auto j       = i + 1;
        ForkTPS test = psi;
        std::string Opi, Opj;
        std::vector<int> occAfterGate = occSites;

        auto found = std::find(occAfterGate.begin(), occAfterGate.end(), i);
        if (found == occAfterGate.end()) {
          Opi = "CkD";
          occAfterGate.push_back(i);
        } else {
          Opi = "Ck";
          occAfterGate.erase(found);
        }

        found = std::find(occAfterGate.begin(), occAfterGate.end(), j);
        if (found == occAfterGate.end()) {
          Opj = "CkD";
          occAfterGate.push_back(j);
        } else {
          Opj = "Ck";
          occAfterGate.erase(found);
        }

        ITensor gate = sites.op(Opi, i) * sites.op(Opj, j);
        ForkGate G(gate, i, j);
        ApplyGate(test, G, Rightwards, args);

        CheckOccs(test, occAfterGate);
        CheckLinks(test);
      }
    }
  }

  TEST(ForkCalculus, ApplyMPO) {
    // Checks the exactApplyMPO function. Therefore we start with a product state with a
    // single particle on site 1 (impurity site). Then we apply a simple
    // MPO H = sum V_k (c0dag ck + hc).
    // finally we meansure the occupation on the relevant sites and expect Vk**2

    const int N = 16, NArms = 4, NBath = int(std::round(N / NArms)) - 1;
    std::vector<int> occSites = {1};

    Args args{"Cutoff", 1E-15};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);

    const std::vector<double> eps = {0., 0, 0, 0};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    auto hpsi = forktps::exactApplyMPO(psi, H, args);

    for (auto k : itertools::range(NBath)) {
      int site = psi.ArmToSite(1, k + 1);
      auto val = forktps::Measure(hpsi, "N", site);

      EXPECT_FLOAT_EQ(val, V[k] * V[k]);
    }
  }

  TEST(ForkCalculus, ApplyMPO_Links) {
    // Checks the exactApplyMPO function. Therefore we start with a product state with a
    // single particle on site 1 (impurity site). Then we apply a simple
    // MPO H = sum V_k (c0dag ck + hc).
    // finally we meansure the occupation on the relevant sites and expect Vk**2

    const int N = 16, NArms = 4;
    std::vector<int> occSites = {1};

    Args args{"Cutoff", 1E-15};

    AIM_ForkSites sites(N, NArms);
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psi(init, NArms);

    const std::vector<double> eps = {0., 0, 0, 0};
    const std::vector<double> V   = {0.1, 0.2, 0.3};

    double U = 0, Up = 0, J = 0;

    args.add("DDonly", true);
    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, Up, J, NArms, args));
    H.position(N);
    H.position(1);

    psi = forktps::exactApplyMPO(psi, H, args);

    CheckLinks(psi);
  }

  TEST(ForkCalculus, FitApplyMPO) {

    const std::vector<double> eps{0, -1, 0, 1}, V{0.11, 0.12, 0.13};
    bath ba(eps, V, 2);
    hloc e0(eps, 2);

    //auto [ba, e0] = GetBath();
    std::cout << "bath" << std::endl << ba << std::endl;
    std::cout << e0 << std::endl;

    Args args;
    AIM_ForkSites sites(ba.N(), ba.NArms(), {"conserveN", false, "conserveSz", false});
    ForkTPS phi(sites, ba.NArms());

    const H_int hint(1., 0.2, 0.7, false);
    ForkTPO H = ForkTPO(AIM(sites, ba, e0, hint, args));

    for (auto size : {4, 8, 16, 32}) {
      phi.randomize(size);
      phi.normalize();

      args.add("sweeps", 30);
      args.add("SubspaceAlpha", 0.1);
      args.add("SubspaceMaxm", 100);

      auto fit = FitApplyMPO(phi, H, args);
      auto ex  = exactApplyMPO(phi, H, args);

      fit.normalize();
      ex.normalize();

      EXPECT_NEAR(overlap(fit, ex).real(), 1, 1E-2);
    }
  }

  TEST(ForkCalculus, OneOrbital) {
    // tests most functions on a one-orbital model, functions tested:
    // exactApplyMPO(), FitApplyMPO(), DMRG(), DMRG() and
    // Measure()
    const int NArms = 2, N = 4 * (NArms);
    const double U = 1.1;
    AIM_ForkSites sites(N, NArms);
    Args args{"Cutoff", 1E-13, "maxsweeps", 20, "verbose", true, "NAppH", 2, "SubspaceAlpha", 0.1, "SubspaceMaxm", 100};

    const std::vector<int> occSites = {2, 3, 6, 7};
    InitState init(sites);
    for (auto s : occSites) init.set(s, "Occ");

    ForkTPS psiSS(init, NArms), psiTS(init, NArms);
    const dvec eps = {
       0.,
       -0.1,
       0.0,
       0.1,
    };
    const dvec V = {0.2, 0.2, 0.2};

    ForkTPO H = ForkTPO(AIM(sites, eps, V, U, 0, 0, NArms, args));

    for (auto i : range1(4)) {
      UNUSED_VAR(i);
      psiSS = exactApplyMPO(psiSS, H, args);
      psiTS = FitApplyMPO(psiTS, H, args);
      psiSS.normalize();
      psiTS.normalize();
    }

    double energySS(0.), energyTS(0.);
    DMRG(psiSS, H, energySS, args);
    DMRG(psiTS, H, energyTS, args);

    EXPECT_NEAR(energySS, energyTS, 1E-8);

    for (auto i : range1(N)) {
      UNUSED_VAR(i);
      auto nSS = Measure(psiSS, "N", i);
      auto nTS = Measure(psiTS, "N", i);

      EXPECT_NEAR(nSS, nTS, 1E-8);
    }

    return;
  }

} // namespace forktps
